(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-tasks-tasks-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/tasks/task-comment/task-comment.component.html":
/*!************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/tasks/task-comment/task-comment.component.html ***!
  \************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div [ngClass]=\"isMyComment ? 'my-comment comment-sizing' : 'comment comment-sizing'\">\r\n    <div class=\"comment-user\">{{comment.createdBy.firstName}} {{comment.createdBy.lastName}}</div>\r\n    <div class=\"comment-content\">\r\n        <div *ngIf=\"comment.attachment\" class=\"content-attachment-container\">\r\n            <span class=\"attachment-container\">\r\n                <div class=\"image-container\">\r\n                    <span class=\"image-format\">.{{comment.attachment.format}}</span>\r\n                    <img *ngIf=\"imageSrc\"\r\n                         [src]=\"imageSrc\"\r\n                         alt=\"Attachment\"\r\n                         (click)=\"openPreviewAttachment(imageSrc)\"\r\n                         class=\"image\"\r\n                    />\r\n                </div>\r\n                <span (click)=\"openPreviewAttachment(imageSrc)\" class=\"link\">{{comment.attachment.fileName}}</span>\r\n            </span>\r\n            <a href=\"{{imageSrc}}\" download=\"{{comment.attachment.fileName}}\" mat-icon-button>\r\n                <img\r\n                    [src]=\"'assets/img/svg-squares/download.svg'\"\r\n                    alt=\"download\"\r\n                >\r\n            </a>\r\n        </div>\r\n        <div *ngIf=\"!comment.attachment\">\r\n            <pre class=\"message-text\">{{comment.description}}</pre>\r\n        </div>\r\n    </div>\r\n\r\n    <div class=\"comment-created\">{{comment.created | date:'dd.MM.yyyy HH:mm'}}</div>\r\n</div>\r\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/tasks/task-create/task-create.component.html":
/*!**********************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/tasks/task-create/task-create.component.html ***!
  \**********************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div fxLayout=\"row\" class=\"basic-screen-header\">\r\n    <div class=\"pl-50\" fxLayoutAlign=\"start center\">\r\n        <h3>{{'tasks.new.newTask' | translate}}</h3>\r\n    </div>\r\n</div>\r\n\r\n<div fxLayout=\"row\" style=\"overflow: auto;  height: calc(100vh - 160px);\">\r\n    <div class=\"p-30\">\r\n        <task-form (formDataChange)=\"formData=$event\"></task-form>\r\n\r\n        <div>\r\n            <button type=\"submit\"\r\n                    mat-flat-button\r\n                    color=\"accent\"\r\n                    class=\"mr-10\"\r\n                    (click)=\"onSave()\"\r\n                    [disabled]=\"formData === null\"\r\n            >\r\n                {{ 'tasks.save' | translate }}\r\n            </button>\r\n            <button type=\"button\"\r\n                    mat-button\r\n                    class=\"mr-10\"\r\n                    (click)=\"onCancel()\"\r\n            >\r\n                {{ 'tasks.cancel' | translate }}\r\n            </button>\r\n        </div>\r\n    </div>\r\n</div>\r\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/tasks/task-edit/task-edit.component.html":
/*!******************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/tasks/task-edit/task-edit.component.html ***!
  \******************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div fxLayout=\"row\" class=\"basic-screen-header\">\r\n    <div class=\"pl-50\" fxLayoutAlign=\"start center\">\r\n        <h3>{{'tasks.edit.editTask' | translate}}</h3>\r\n    </div>\r\n</div>\r\n\r\n<div fxLayout=\"row\" style=\"overflow: auto;  height: calc(100vh - 160px);\">\r\n    <div fxFlex=\"65\" fxFlex.gt-sm=\"100%\" class=\"p-30 form-content\" fxLayout=\"column\">\r\n        <task-form (formDataChange)=\"formDataChange($event)\"></task-form>\r\n        <div>\r\n            <button *ngIf=\"projectEventService.instant.active && allowUpdateTask()\"\r\n                    type=\"submit\"\r\n                    mat-flat-button\r\n                    color=\"accent\"\r\n                    class=\"mr-10\"\r\n                    (click)=\"onSave()\"\r\n                    [disabled]=\"!formData\"\r\n            >\r\n                {{ 'tasks.save' | translate }}\r\n            </button>\r\n            <button type=\"button\"\r\n                    mat-button\r\n                    class=\"mr-10\"\r\n                    (click)=\"onCancel()\"\r\n            >\r\n                {{ 'tasks.cancel' | translate }}\r\n            </button>\r\n        </div>\r\n    </div>\r\n\r\n    <div fxFlex=\"35\" style=\"background:#f4f4f4\" fxLayout=\"column\" *ngIf=\"allowReadComment()\">\r\n        <div class=\"w-full\" fxLayout=\"row\">\r\n            <form [formGroup]=\"addCommentForm\" (ngSubmit)=\"onCommentAdded()\">\r\n                <div fxFlex=\"50px\" fxLayoutAlign=\"start end\" class=\"pl-20 pb-50\" *ngIf=\"hasRoleUploadImage()\">\r\n                    <button class=\"attachment-icon\"\r\n                            mat-icon-button\r\n                            (click)=\"file.click()\">\r\n                        <em class=\"material-icons\">attach_file</em>\r\n                    </button>\r\n                    <input\r\n                        (change)=\"onFileChange($event)\"\r\n                        accept=\"image/jpeg, image/jpg, image/png\"\r\n                        style=\"display: none\"\r\n                        #file\r\n                        formControlName=\"attachment\"\r\n                        id=\"attachment\"\r\n                        type=\"file\"/>\r\n\r\n                </div>\r\n                <haz-core-input [label]=\"'comment.newComment' | translate\"\r\n                                [type]=\"'textarea'\"\r\n                                [appearance]=\"'fill'\"\r\n                                formControlName=\"newComment\"\r\n                                [pattern]=\"notOnlyWhiteCharactersPattern\"\r\n                                class=\"theme-input m-20 comment-input\"\r\n                                [maxLength]=\"2000\"\r\n                                *ngIf=\"allowCreateComment()\"\r\n                >\r\n                </haz-core-input>\r\n\r\n                <div fxFlex=\"50px\" fxLayoutAlign=\"end end\" class=\"pr-20 pb-50\" *ngIf=\"allowCreateComment()\">\r\n                    <button mat-icon-button\r\n                            [disabled]=\"addCommentForm?.controls?.newComment?.errors\"\r\n                    >\r\n                        <mat-icon matSuffix>send</mat-icon>\r\n                    </button>\r\n                </div>\r\n            </form>\r\n        </div>\r\n\r\n        <haz-indeterminate-progress-bar [loading]=\"loading\"></haz-indeterminate-progress-bar>\r\n\r\n        <div class=\"comment-list\">\r\n            <div *ngFor=\"let comment of comments; let i = index\">\r\n                <task-comment [comment]=\"comment\" [index]=\"i\"></task-comment>\r\n            </div>\r\n        </div>\r\n\r\n    </div>\r\n\r\n\r\n</div>\r\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/tasks/task-list/task-list.component.html":
/*!******************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/tasks/task-list/task-list.component.html ***!
  \******************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<!--Complex task list screen for task management and report export-->\r\n<div class=\"basic-screen-header\" fxLayout=\"row\">\r\n    <div class=\"pl-50\" fxFlex=\"130px\" fxLayoutAlign=\"start center\">\r\n        <h2>{{'task.title' | translate}}</h2>\r\n    </div>\r\n    <div [formGroup]=\"areaGroup\" class=\"header-select\" fxFlex fxLayoutAlign=\"start center\">\r\n        <mat-form-field class=\"pt-17 w-250\">\r\n            <mat-label>{{'businessArea.title' | translate}}</mat-label>\r\n            <mat-select (selectionChange)=\"setTableData()\" formControlName=\"businessArea\">\r\n                <mat-option value=\"all\">{{'all.things' | translate}}</mat-option>\r\n                <mat-option *ngFor=\"let businessArea of businessAreaList\"\r\n                            [value]=\"businessArea.name\"\r\n                >\r\n                    {{businessArea.codeItem}} - {{businessArea.name}}\r\n                </mat-option>\r\n            </mat-select>\r\n        </mat-form-field>\r\n    </div>\r\n    <div fxFlex fxLayoutAlign=\"end center\">\r\n        <button (click)=\"createTask()\" *ngIf=\"projectEventService.instant.active && allowCreateTaskButton()\" class=\"mr-10\" color=\"accent\"\r\n                mat-flat-button\r\n        >\r\n            {{'common.create' | translate}}\r\n        </button>\r\n        <button (click)=\"export()\" *ngIf=\"allowExportReportTaskButton()\" class=\"mr-10\" color=\"accent\" mat-flat-button>\r\n            {{'common.export' | translate}}\r\n        </button>\r\n    </div>\r\n</div>\r\n\r\n<haz-indeterminate-progress-bar [loading]=\"loading\"></haz-indeterminate-progress-bar>\r\n<haz-core-table #taskTable\r\n                (requestData)=\"setTableData($event)\"\r\n                [configuration]=\"config\"\r\n                [data]=\"data\"\r\n></haz-core-table>\r\n<ng-template #updateColumn let-actRow=\"row\" let-context=\"context\">\r\n    <div *ngIf=\"allowTaskDetailButton()\" class=\"fr\">\r\n        <button (click)=\"update(actRow.id)\"\r\n                mat-icon-button\r\n        >\r\n            <mat-icon>keyboard_arrow_right</mat-icon>\r\n        </button>\r\n    </div>\r\n</ng-template>\r\n<ng-template #statusColumn let-actRow=\"row\" let-context=\"context\">\r\n    {{('task.statusValue.' + actRow.state.toLowerCase()) | translate}}\r\n</ng-template>\r\n<ng-template #taskTypeColumn let-actRow=\"row\" let-context=\"context\">\r\n    {{('task.taskTypeValue.' + actRow.taskType.toLowerCase()) | translate}}\r\n</ng-template>\r\n<ng-template #venueColumn let-actRow=\"row\" let-context=\"context\">\r\n    {{actRow.cityName | venue}}\r\n</ng-template>\r\n<ng-template #userColumn let-actRow=\"row\" let-context=\"context\">\r\n    <ng-container *ngIf=\"actRow.responsibleUser\">\r\n        {{actRow.responsibleUser.firstName}} {{actRow.responsibleUser.lastName}}\r\n    </ng-container>\r\n</ng-template>\r\n<ng-template #dateColumn let-actRow=\"row\" let-context=\"context\">\r\n    {{actRow.dueDate  | date:'d.M.yyyy'}}\r\n</ng-template>\r\n<ng-template #trafficLightColumn let-actRow=\"row\" let-context=\"context\">\r\n    <div *ngIf=\"actRow.trafficLight === 'RED'\"\r\n         style=\"width: 12px;height: 12px;background:#ce211f;border-radius:50%;\"\r\n    ></div>\r\n    <div *ngIf=\"actRow.trafficLight === 'GREEN'\"\r\n         style=\"width: 12px;height: 12px;background:#20bf55;border-radius:50%;\"\r\n    ></div>\r\n    <div *ngIf=\"actRow.trafficLight === 'AMBER'\"\r\n         style=\"width: 12px;height: 12px;background:#f79824;border-radius:50%;\"\r\n    ></div>\r\n</ng-template>\r\n");

/***/ }),

/***/ "./node_modules/rxjs/internal/Observer.js":
/*!************************************************!*\
  !*** ./node_modules/rxjs/internal/Observer.js ***!
  \************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
var config_1 = __webpack_require__(/*! ./config */ "./node_modules/rxjs/internal/config.js");
var hostReportError_1 = __webpack_require__(/*! ./util/hostReportError */ "./node_modules/rxjs/internal/util/hostReportError.js");
exports.empty = {
    closed: true,
    next: function (value) { },
    error: function (err) {
        if (config_1.config.useDeprecatedSynchronousErrorHandling) {
            throw err;
        }
        else {
            hostReportError_1.hostReportError(err);
        }
    },
    complete: function () { }
};
//# sourceMappingURL=Observer.js.map

/***/ }),

/***/ "./node_modules/rxjs/internal/Subscriber.js":
/*!**************************************************!*\
  !*** ./node_modules/rxjs/internal/Subscriber.js ***!
  \**************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    }
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
var isFunction_1 = __webpack_require__(/*! ./util/isFunction */ "./node_modules/rxjs/internal/util/isFunction.js");
var Observer_1 = __webpack_require__(/*! ./Observer */ "./node_modules/rxjs/internal/Observer.js");
var Subscription_1 = __webpack_require__(/*! ./Subscription */ "./node_modules/rxjs/internal/Subscription.js");
var rxSubscriber_1 = __webpack_require__(/*! ../internal/symbol/rxSubscriber */ "./node_modules/rxjs/internal/symbol/rxSubscriber.js");
var config_1 = __webpack_require__(/*! ./config */ "./node_modules/rxjs/internal/config.js");
var hostReportError_1 = __webpack_require__(/*! ./util/hostReportError */ "./node_modules/rxjs/internal/util/hostReportError.js");
var Subscriber = (function (_super) {
    __extends(Subscriber, _super);
    function Subscriber(destinationOrNext, error, complete) {
        var _this = _super.call(this) || this;
        _this.syncErrorValue = null;
        _this.syncErrorThrown = false;
        _this.syncErrorThrowable = false;
        _this.isStopped = false;
        switch (arguments.length) {
            case 0:
                _this.destination = Observer_1.empty;
                break;
            case 1:
                if (!destinationOrNext) {
                    _this.destination = Observer_1.empty;
                    break;
                }
                if (typeof destinationOrNext === 'object') {
                    if (destinationOrNext instanceof Subscriber) {
                        _this.syncErrorThrowable = destinationOrNext.syncErrorThrowable;
                        _this.destination = destinationOrNext;
                        destinationOrNext.add(_this);
                    }
                    else {
                        _this.syncErrorThrowable = true;
                        _this.destination = new SafeSubscriber(_this, destinationOrNext);
                    }
                    break;
                }
            default:
                _this.syncErrorThrowable = true;
                _this.destination = new SafeSubscriber(_this, destinationOrNext, error, complete);
                break;
        }
        return _this;
    }
    Subscriber.prototype[rxSubscriber_1.rxSubscriber] = function () { return this; };
    Subscriber.create = function (next, error, complete) {
        var subscriber = new Subscriber(next, error, complete);
        subscriber.syncErrorThrowable = false;
        return subscriber;
    };
    Subscriber.prototype.next = function (value) {
        if (!this.isStopped) {
            this._next(value);
        }
    };
    Subscriber.prototype.error = function (err) {
        if (!this.isStopped) {
            this.isStopped = true;
            this._error(err);
        }
    };
    Subscriber.prototype.complete = function () {
        if (!this.isStopped) {
            this.isStopped = true;
            this._complete();
        }
    };
    Subscriber.prototype.unsubscribe = function () {
        if (this.closed) {
            return;
        }
        this.isStopped = true;
        _super.prototype.unsubscribe.call(this);
    };
    Subscriber.prototype._next = function (value) {
        this.destination.next(value);
    };
    Subscriber.prototype._error = function (err) {
        this.destination.error(err);
        this.unsubscribe();
    };
    Subscriber.prototype._complete = function () {
        this.destination.complete();
        this.unsubscribe();
    };
    Subscriber.prototype._unsubscribeAndRecycle = function () {
        var _parentOrParents = this._parentOrParents;
        this._parentOrParents = null;
        this.unsubscribe();
        this.closed = false;
        this.isStopped = false;
        this._parentOrParents = _parentOrParents;
        return this;
    };
    return Subscriber;
}(Subscription_1.Subscription));
exports.Subscriber = Subscriber;
var SafeSubscriber = (function (_super) {
    __extends(SafeSubscriber, _super);
    function SafeSubscriber(_parentSubscriber, observerOrNext, error, complete) {
        var _this = _super.call(this) || this;
        _this._parentSubscriber = _parentSubscriber;
        var next;
        var context = _this;
        if (isFunction_1.isFunction(observerOrNext)) {
            next = observerOrNext;
        }
        else if (observerOrNext) {
            next = observerOrNext.next;
            error = observerOrNext.error;
            complete = observerOrNext.complete;
            if (observerOrNext !== Observer_1.empty) {
                context = Object.create(observerOrNext);
                if (isFunction_1.isFunction(context.unsubscribe)) {
                    _this.add(context.unsubscribe.bind(context));
                }
                context.unsubscribe = _this.unsubscribe.bind(_this);
            }
        }
        _this._context = context;
        _this._next = next;
        _this._error = error;
        _this._complete = complete;
        return _this;
    }
    SafeSubscriber.prototype.next = function (value) {
        if (!this.isStopped && this._next) {
            var _parentSubscriber = this._parentSubscriber;
            if (!config_1.config.useDeprecatedSynchronousErrorHandling || !_parentSubscriber.syncErrorThrowable) {
                this.__tryOrUnsub(this._next, value);
            }
            else if (this.__tryOrSetError(_parentSubscriber, this._next, value)) {
                this.unsubscribe();
            }
        }
    };
    SafeSubscriber.prototype.error = function (err) {
        if (!this.isStopped) {
            var _parentSubscriber = this._parentSubscriber;
            var useDeprecatedSynchronousErrorHandling = config_1.config.useDeprecatedSynchronousErrorHandling;
            if (this._error) {
                if (!useDeprecatedSynchronousErrorHandling || !_parentSubscriber.syncErrorThrowable) {
                    this.__tryOrUnsub(this._error, err);
                    this.unsubscribe();
                }
                else {
                    this.__tryOrSetError(_parentSubscriber, this._error, err);
                    this.unsubscribe();
                }
            }
            else if (!_parentSubscriber.syncErrorThrowable) {
                this.unsubscribe();
                if (useDeprecatedSynchronousErrorHandling) {
                    throw err;
                }
                hostReportError_1.hostReportError(err);
            }
            else {
                if (useDeprecatedSynchronousErrorHandling) {
                    _parentSubscriber.syncErrorValue = err;
                    _parentSubscriber.syncErrorThrown = true;
                }
                else {
                    hostReportError_1.hostReportError(err);
                }
                this.unsubscribe();
            }
        }
    };
    SafeSubscriber.prototype.complete = function () {
        var _this = this;
        if (!this.isStopped) {
            var _parentSubscriber = this._parentSubscriber;
            if (this._complete) {
                var wrappedComplete = function () { return _this._complete.call(_this._context); };
                if (!config_1.config.useDeprecatedSynchronousErrorHandling || !_parentSubscriber.syncErrorThrowable) {
                    this.__tryOrUnsub(wrappedComplete);
                    this.unsubscribe();
                }
                else {
                    this.__tryOrSetError(_parentSubscriber, wrappedComplete);
                    this.unsubscribe();
                }
            }
            else {
                this.unsubscribe();
            }
        }
    };
    SafeSubscriber.prototype.__tryOrUnsub = function (fn, value) {
        try {
            fn.call(this._context, value);
        }
        catch (err) {
            this.unsubscribe();
            if (config_1.config.useDeprecatedSynchronousErrorHandling) {
                throw err;
            }
            else {
                hostReportError_1.hostReportError(err);
            }
        }
    };
    SafeSubscriber.prototype.__tryOrSetError = function (parent, fn, value) {
        if (!config_1.config.useDeprecatedSynchronousErrorHandling) {
            throw new Error('bad call');
        }
        try {
            fn.call(this._context, value);
        }
        catch (err) {
            if (config_1.config.useDeprecatedSynchronousErrorHandling) {
                parent.syncErrorValue = err;
                parent.syncErrorThrown = true;
                return true;
            }
            else {
                hostReportError_1.hostReportError(err);
                return true;
            }
        }
        return false;
    };
    SafeSubscriber.prototype._unsubscribe = function () {
        var _parentSubscriber = this._parentSubscriber;
        this._context = null;
        this._parentSubscriber = null;
        _parentSubscriber.unsubscribe();
    };
    return SafeSubscriber;
}(Subscriber));
exports.SafeSubscriber = SafeSubscriber;
//# sourceMappingURL=Subscriber.js.map

/***/ }),

/***/ "./node_modules/rxjs/internal/Subscription.js":
/*!****************************************************!*\
  !*** ./node_modules/rxjs/internal/Subscription.js ***!
  \****************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
var isArray_1 = __webpack_require__(/*! ./util/isArray */ "./node_modules/rxjs/internal/util/isArray.js");
var isObject_1 = __webpack_require__(/*! ./util/isObject */ "./node_modules/rxjs/internal/util/isObject.js");
var isFunction_1 = __webpack_require__(/*! ./util/isFunction */ "./node_modules/rxjs/internal/util/isFunction.js");
var UnsubscriptionError_1 = __webpack_require__(/*! ./util/UnsubscriptionError */ "./node_modules/rxjs/internal/util/UnsubscriptionError.js");
var Subscription = (function () {
    function Subscription(unsubscribe) {
        this.closed = false;
        this._parentOrParents = null;
        this._subscriptions = null;
        if (unsubscribe) {
            this._unsubscribe = unsubscribe;
        }
    }
    Subscription.prototype.unsubscribe = function () {
        var errors;
        if (this.closed) {
            return;
        }
        var _a = this, _parentOrParents = _a._parentOrParents, _unsubscribe = _a._unsubscribe, _subscriptions = _a._subscriptions;
        this.closed = true;
        this._parentOrParents = null;
        this._subscriptions = null;
        if (_parentOrParents instanceof Subscription) {
            _parentOrParents.remove(this);
        }
        else if (_parentOrParents !== null) {
            for (var index = 0; index < _parentOrParents.length; ++index) {
                var parent_1 = _parentOrParents[index];
                parent_1.remove(this);
            }
        }
        if (isFunction_1.isFunction(_unsubscribe)) {
            try {
                _unsubscribe.call(this);
            }
            catch (e) {
                errors = e instanceof UnsubscriptionError_1.UnsubscriptionError ? flattenUnsubscriptionErrors(e.errors) : [e];
            }
        }
        if (isArray_1.isArray(_subscriptions)) {
            var index = -1;
            var len = _subscriptions.length;
            while (++index < len) {
                var sub = _subscriptions[index];
                if (isObject_1.isObject(sub)) {
                    try {
                        sub.unsubscribe();
                    }
                    catch (e) {
                        errors = errors || [];
                        if (e instanceof UnsubscriptionError_1.UnsubscriptionError) {
                            errors = errors.concat(flattenUnsubscriptionErrors(e.errors));
                        }
                        else {
                            errors.push(e);
                        }
                    }
                }
            }
        }
        if (errors) {
            throw new UnsubscriptionError_1.UnsubscriptionError(errors);
        }
    };
    Subscription.prototype.add = function (teardown) {
        var subscription = teardown;
        if (!teardown) {
            return Subscription.EMPTY;
        }
        switch (typeof teardown) {
            case 'function':
                subscription = new Subscription(teardown);
            case 'object':
                if (subscription === this || subscription.closed || typeof subscription.unsubscribe !== 'function') {
                    return subscription;
                }
                else if (this.closed) {
                    subscription.unsubscribe();
                    return subscription;
                }
                else if (!(subscription instanceof Subscription)) {
                    var tmp = subscription;
                    subscription = new Subscription();
                    subscription._subscriptions = [tmp];
                }
                break;
            default: {
                throw new Error('unrecognized teardown ' + teardown + ' added to Subscription.');
            }
        }
        var _parentOrParents = subscription._parentOrParents;
        if (_parentOrParents === null) {
            subscription._parentOrParents = this;
        }
        else if (_parentOrParents instanceof Subscription) {
            if (_parentOrParents === this) {
                return subscription;
            }
            subscription._parentOrParents = [_parentOrParents, this];
        }
        else if (_parentOrParents.indexOf(this) === -1) {
            _parentOrParents.push(this);
        }
        else {
            return subscription;
        }
        var subscriptions = this._subscriptions;
        if (subscriptions === null) {
            this._subscriptions = [subscription];
        }
        else {
            subscriptions.push(subscription);
        }
        return subscription;
    };
    Subscription.prototype.remove = function (subscription) {
        var subscriptions = this._subscriptions;
        if (subscriptions) {
            var subscriptionIndex = subscriptions.indexOf(subscription);
            if (subscriptionIndex !== -1) {
                subscriptions.splice(subscriptionIndex, 1);
            }
        }
    };
    Subscription.EMPTY = (function (empty) {
        empty.closed = true;
        return empty;
    }(new Subscription()));
    return Subscription;
}());
exports.Subscription = Subscription;
function flattenUnsubscriptionErrors(errors) {
    return errors.reduce(function (errs, err) { return errs.concat((err instanceof UnsubscriptionError_1.UnsubscriptionError) ? err.errors : err); }, []);
}
//# sourceMappingURL=Subscription.js.map

/***/ }),

/***/ "./node_modules/rxjs/internal/config.js":
/*!**********************************************!*\
  !*** ./node_modules/rxjs/internal/config.js ***!
  \**********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
var _enable_super_gross_mode_that_will_cause_bad_things = false;
exports.config = {
    Promise: undefined,
    set useDeprecatedSynchronousErrorHandling(value) {
        if (value) {
            var error = new Error();
            console.warn('DEPRECATED! RxJS was set to use deprecated synchronous error handling behavior by code at: \n' + error.stack);
        }
        else if (_enable_super_gross_mode_that_will_cause_bad_things) {
            console.log('RxJS: Back to a better error behavior. Thank you. <3');
        }
        _enable_super_gross_mode_that_will_cause_bad_things = value;
    },
    get useDeprecatedSynchronousErrorHandling() {
        return _enable_super_gross_mode_that_will_cause_bad_things;
    },
};
//# sourceMappingURL=config.js.map

/***/ }),

/***/ "./node_modules/rxjs/internal/operators/tap.js":
/*!*****************************************************!*\
  !*** ./node_modules/rxjs/internal/operators/tap.js ***!
  \*****************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    }
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
var Subscriber_1 = __webpack_require__(/*! ../Subscriber */ "./node_modules/rxjs/internal/Subscriber.js");
var noop_1 = __webpack_require__(/*! ../util/noop */ "./node_modules/rxjs/internal/util/noop.js");
var isFunction_1 = __webpack_require__(/*! ../util/isFunction */ "./node_modules/rxjs/internal/util/isFunction.js");
function tap(nextOrObserver, error, complete) {
    return function tapOperatorFunction(source) {
        return source.lift(new DoOperator(nextOrObserver, error, complete));
    };
}
exports.tap = tap;
var DoOperator = (function () {
    function DoOperator(nextOrObserver, error, complete) {
        this.nextOrObserver = nextOrObserver;
        this.error = error;
        this.complete = complete;
    }
    DoOperator.prototype.call = function (subscriber, source) {
        return source.subscribe(new TapSubscriber(subscriber, this.nextOrObserver, this.error, this.complete));
    };
    return DoOperator;
}());
var TapSubscriber = (function (_super) {
    __extends(TapSubscriber, _super);
    function TapSubscriber(destination, observerOrNext, error, complete) {
        var _this = _super.call(this, destination) || this;
        _this._tapNext = noop_1.noop;
        _this._tapError = noop_1.noop;
        _this._tapComplete = noop_1.noop;
        _this._tapError = error || noop_1.noop;
        _this._tapComplete = complete || noop_1.noop;
        if (isFunction_1.isFunction(observerOrNext)) {
            _this._context = _this;
            _this._tapNext = observerOrNext;
        }
        else if (observerOrNext) {
            _this._context = observerOrNext;
            _this._tapNext = observerOrNext.next || noop_1.noop;
            _this._tapError = observerOrNext.error || noop_1.noop;
            _this._tapComplete = observerOrNext.complete || noop_1.noop;
        }
        return _this;
    }
    TapSubscriber.prototype._next = function (value) {
        try {
            this._tapNext.call(this._context, value);
        }
        catch (err) {
            this.destination.error(err);
            return;
        }
        this.destination.next(value);
    };
    TapSubscriber.prototype._error = function (err) {
        try {
            this._tapError.call(this._context, err);
        }
        catch (err) {
            this.destination.error(err);
            return;
        }
        this.destination.error(err);
    };
    TapSubscriber.prototype._complete = function () {
        try {
            this._tapComplete.call(this._context);
        }
        catch (err) {
            this.destination.error(err);
            return;
        }
        return this.destination.complete();
    };
    return TapSubscriber;
}(Subscriber_1.Subscriber));
//# sourceMappingURL=tap.js.map

/***/ }),

/***/ "./node_modules/rxjs/internal/symbol/rxSubscriber.js":
/*!***********************************************************!*\
  !*** ./node_modules/rxjs/internal/symbol/rxSubscriber.js ***!
  \***********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.rxSubscriber = (function () {
    return typeof Symbol === 'function'
        ? Symbol('rxSubscriber')
        : '@@rxSubscriber_' + Math.random();
})();
exports.$$rxSubscriber = exports.rxSubscriber;
//# sourceMappingURL=rxSubscriber.js.map

/***/ }),

/***/ "./node_modules/rxjs/internal/util/UnsubscriptionError.js":
/*!****************************************************************!*\
  !*** ./node_modules/rxjs/internal/util/UnsubscriptionError.js ***!
  \****************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
var UnsubscriptionErrorImpl = (function () {
    function UnsubscriptionErrorImpl(errors) {
        Error.call(this);
        this.message = errors ?
            errors.length + " errors occurred during unsubscription:\n" + errors.map(function (err, i) { return i + 1 + ") " + err.toString(); }).join('\n  ') : '';
        this.name = 'UnsubscriptionError';
        this.errors = errors;
        return this;
    }
    UnsubscriptionErrorImpl.prototype = Object.create(Error.prototype);
    return UnsubscriptionErrorImpl;
})();
exports.UnsubscriptionError = UnsubscriptionErrorImpl;
//# sourceMappingURL=UnsubscriptionError.js.map

/***/ }),

/***/ "./node_modules/rxjs/internal/util/hostReportError.js":
/*!************************************************************!*\
  !*** ./node_modules/rxjs/internal/util/hostReportError.js ***!
  \************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
function hostReportError(err) {
    setTimeout(function () { throw err; }, 0);
}
exports.hostReportError = hostReportError;
//# sourceMappingURL=hostReportError.js.map

/***/ }),

/***/ "./node_modules/rxjs/internal/util/isArray.js":
/*!****************************************************!*\
  !*** ./node_modules/rxjs/internal/util/isArray.js ***!
  \****************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.isArray = (function () { return Array.isArray || (function (x) { return x && typeof x.length === 'number'; }); })();
//# sourceMappingURL=isArray.js.map

/***/ }),

/***/ "./node_modules/rxjs/internal/util/isFunction.js":
/*!*******************************************************!*\
  !*** ./node_modules/rxjs/internal/util/isFunction.js ***!
  \*******************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
function isFunction(x) {
    return typeof x === 'function';
}
exports.isFunction = isFunction;
//# sourceMappingURL=isFunction.js.map

/***/ }),

/***/ "./node_modules/rxjs/internal/util/isObject.js":
/*!*****************************************************!*\
  !*** ./node_modules/rxjs/internal/util/isObject.js ***!
  \*****************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
function isObject(x) {
    return x !== null && typeof x === 'object';
}
exports.isObject = isObject;
//# sourceMappingURL=isObject.js.map

/***/ }),

/***/ "./node_modules/rxjs/internal/util/noop.js":
/*!*************************************************!*\
  !*** ./node_modules/rxjs/internal/util/noop.js ***!
  \*************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
function noop() { }
exports.noop = noop;
//# sourceMappingURL=noop.js.map

/***/ }),

/***/ "./src/app/pages/tasks/task-comment/task-comment.component.scss":
/*!**********************************************************************!*\
  !*** ./src/app/pages/tasks/task-comment/task-comment.component.scss ***!
  \**********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".my-comment {\n  position: relative;\n  border-radius: 10px;\n  background: #c3c3c3;\n  min-height: 20px;\n  margin: 25px 75px 40px 25px;\n  padding: 15px;\n  max-width: 400px;\n  min-width: 100px;\n}\n.my-comment .comment-created {\n  right: 0;\n}\n.my-comment:after {\n  z-index: 77;\n  content: \"\";\n  position: absolute;\n  bottom: 0;\n  left: 20%;\n  border: 12px solid transparent;\n  border-top-color: #c3c3c3;\n  border-bottom: 0;\n  border-left: 0;\n  margin-left: -6px;\n  margin-bottom: -12px;\n}\n.my-comment-sizing:after {\n  width: 0;\n  height: 0;\n}\n.comment {\n  position: relative;\n  border-radius: 10px;\n  background: #89cae9;\n  min-height: 20px;\n  margin: 25px 25px 40px auto;\n  padding: 15px;\n  max-width: 400px;\n  min-width: 100px;\n}\n.comment .comment-created {\n  left: 0;\n}\n.comment:after {\n  z-index: 77;\n  content: \"\";\n  position: absolute;\n  bottom: 0;\n  left: 80%;\n  border: 12px solid transparent;\n  border-top-color: #89cae9;\n  border-bottom: 0;\n  border-right: 0;\n  margin-left: -6px;\n  margin-bottom: -12px;\n}\n.comment-user {\n  font-family: \"Roboto-Bold\", sans-serif;\n  font-size: 14px;\n}\n.comment-content {\n  font-family: \"Roboto\", sans-serif;\n  font-size: 14px;\n  word-wrap: break-word;\n}\n.comment-content .content-attachment-container {\n  display: flex;\n  margin-top: 10px;\n  align-items: center;\n}\n.comment-content .content-attachment-container .attachment-container {\n  display: flex;\n  flex-grow: 1;\n  align-items: center;\n}\n.comment-content .content-attachment-container .attachment-container .image-container {\n  min-width: 60px;\n  min-height: 70px;\n  width: 60px;\n  height: 70px;\n  overflow: hidden;\n  display: inline-block;\n  margin-right: 10px;\n  background: #fff;\n  padding: 5px;\n  border-radius: 5px;\n  position: relative;\n}\n.comment-content .content-attachment-container .attachment-container .image-container .image-format {\n  position: absolute;\n  left: 0;\n  top: 0;\n  color: #fff;\n  padding: 3px 6px;\n  background: #002d62;\n  text-transform: lowercase;\n  font-size: 0.7rem;\n  border-radius: 0 0 5px 0;\n}\n.comment-content .content-attachment-container .attachment-container .image-container .image {\n  width: 100%;\n  height: 100%;\n  -o-object-fit: cover;\n     object-fit: cover;\n  cursor: pointer;\n}\n.comment-content .content-attachment-container .attachment-container .link {\n  text-decoration: underline;\n  cursor: pointer;\n}\n.comment-content .content-attachment-container .attachment-container .link:hover {\n  text-decoration: none;\n}\n.comment-created {\n  position: absolute;\n  padding-top: 15px;\n  font-family: \"Roboto\", sans-serif;\n  font-size: 12px;\n  margin: 5px;\n}\n@media screen and (max-width: 2000px) {\n  .my-comment {\n    margin: 25px 25px 40px 75px;\n  }\n}\n.message-text {\n  white-space: pre-wrap;\n  font-family: Roboto, sans-serif;\n  font-size: 14px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvdGFza3MvdGFzay1jb21tZW50L0Q6XFxwcm9qZWN0c1xcaWloZlxcd2ZtLXdlYi9zcmNcXGFwcFxccGFnZXNcXHRhc2tzXFx0YXNrLWNvbW1lbnRcXHRhc2stY29tbWVudC5jb21wb25lbnQuc2NzcyIsInNyYy9hcHAvcGFnZXMvdGFza3MvdGFzay1jb21tZW50L3Rhc2stY29tbWVudC5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLGtCQUFBO0VBQ0EsbUJBQUE7RUFDQSxtQkFBQTtFQUNBLGdCQUFBO0VBQ0EsMkJBQUE7RUFDQSxhQUFBO0VBQ0EsZ0JBQUE7RUFDQSxnQkFBQTtBQ0NKO0FEQ0k7RUFDSSxRQUFBO0FDQ1I7QURHQTtFQUNJLFdBQUE7RUFDQSxXQUFBO0VBQ0Esa0JBQUE7RUFDQSxTQUFBO0VBQ0EsU0FBQTtFQUNBLDhCQUFBO0VBQ0EseUJBQUE7RUFDQSxnQkFBQTtFQUNBLGNBQUE7RUFDQSxpQkFBQTtFQUNBLG9CQUFBO0FDQUo7QURHQTtFQUNJLFFBQUE7RUFDQSxTQUFBO0FDQUo7QURHQTtFQUNJLGtCQUFBO0VBQ0EsbUJBQUE7RUFDQSxtQkFBQTtFQUNBLGdCQUFBO0VBQ0EsMkJBQUE7RUFDQSxhQUFBO0VBQ0EsZ0JBQUE7RUFDQSxnQkFBQTtBQ0FKO0FERUk7RUFDSSxPQUFBO0FDQVI7QURJQTtFQUNJLFdBQUE7RUFDQSxXQUFBO0VBQ0Esa0JBQUE7RUFDQSxTQUFBO0VBQ0EsU0FBQTtFQUNBLDhCQUFBO0VBQ0EseUJBQUE7RUFDQSxnQkFBQTtFQUNBLGVBQUE7RUFDQSxpQkFBQTtFQUNBLG9CQUFBO0FDREo7QURJQTtFQUNJLHNDQUFBO0VBQ0EsZUFBQTtBQ0RKO0FESUE7RUFDSSxpQ0FBQTtFQUNBLGVBQUE7RUFDQSxxQkFBQTtBQ0RKO0FER0k7RUFDSSxhQUFBO0VBQ0EsZ0JBQUE7RUFDQSxtQkFBQTtBQ0RSO0FER1E7RUFDSSxhQUFBO0VBQ0EsWUFBQTtFQUNBLG1CQUFBO0FDRFo7QURHWTtFQUNJLGVBQUE7RUFDQSxnQkFBQTtFQUNBLFdBQUE7RUFDQSxZQUFBO0VBQ0EsZ0JBQUE7RUFDQSxxQkFBQTtFQUNBLGtCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxZQUFBO0VBQ0Esa0JBQUE7RUFDQSxrQkFBQTtBQ0RoQjtBREdnQjtFQUNJLGtCQUFBO0VBQ0EsT0FBQTtFQUNBLE1BQUE7RUFDQSxXQUFBO0VBQ0EsZ0JBQUE7RUFDQSxtQkFBQTtFQUNBLHlCQUFBO0VBQ0EsaUJBQUE7RUFDQSx3QkFBQTtBQ0RwQjtBRElnQjtFQUNJLFdBQUE7RUFDQSxZQUFBO0VBQ0Esb0JBQUE7S0FBQSxpQkFBQTtFQUNBLGVBQUE7QUNGcEI7QURNWTtFQUNJLDBCQUFBO0VBQ0EsZUFBQTtBQ0poQjtBRE1nQjtFQUNJLHFCQUFBO0FDSnBCO0FEV0E7RUFDSSxrQkFBQTtFQUNBLGlCQUFBO0VBQ0EsaUNBQUE7RUFDQSxlQUFBO0VBQ0EsV0FBQTtBQ1JKO0FEV0E7RUFDSTtJQUNJLDJCQUFBO0VDUk47QUFDRjtBRFdBO0VBQ0kscUJBQUE7RUFDQSwrQkFBQTtFQUNBLGVBQUE7QUNUSiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL3Rhc2tzL3Rhc2stY29tbWVudC90YXNrLWNvbW1lbnQuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIubXktY29tbWVudCB7XHJcbiAgICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbiAgICBib3JkZXItcmFkaXVzOiAxMHB4O1xyXG4gICAgYmFja2dyb3VuZDogI2MzYzNjMztcclxuICAgIG1pbi1oZWlnaHQ6IDIwcHg7XHJcbiAgICBtYXJnaW46IDI1cHggNzVweCA0MHB4IDI1cHg7XHJcbiAgICBwYWRkaW5nOiAxNXB4O1xyXG4gICAgbWF4LXdpZHRoOiA0MDBweDtcclxuICAgIG1pbi13aWR0aDogMTAwcHg7XHJcblxyXG4gICAgLmNvbW1lbnQtY3JlYXRlZCB7XHJcbiAgICAgICAgcmlnaHQ6IDA7XHJcbiAgICB9XHJcbn1cclxuXHJcbi5teS1jb21tZW50OmFmdGVyIHtcclxuICAgIHotaW5kZXg6IDc3O1xyXG4gICAgY29udGVudDogJyc7XHJcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICBib3R0b206IDA7XHJcbiAgICBsZWZ0OiAyMCU7XHJcbiAgICBib3JkZXI6IDEycHggc29saWQgdHJhbnNwYXJlbnQ7XHJcbiAgICBib3JkZXItdG9wLWNvbG9yOiAjYzNjM2MzO1xyXG4gICAgYm9yZGVyLWJvdHRvbTogMDtcclxuICAgIGJvcmRlci1sZWZ0OiAwO1xyXG4gICAgbWFyZ2luLWxlZnQ6IC02cHg7XHJcbiAgICBtYXJnaW4tYm90dG9tOiAtMTJweDtcclxufVxyXG5cclxuLm15LWNvbW1lbnQtc2l6aW5nOmFmdGVyIHtcclxuICAgIHdpZHRoOiAwO1xyXG4gICAgaGVpZ2h0OiAwO1xyXG59XHJcblxyXG4uY29tbWVudCB7XHJcbiAgICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbiAgICBib3JkZXItcmFkaXVzOiAxMHB4O1xyXG4gICAgYmFja2dyb3VuZDogIzg5Y2FlOTtcclxuICAgIG1pbi1oZWlnaHQ6IDIwcHg7XHJcbiAgICBtYXJnaW46IDI1cHggMjVweCA0MHB4IGF1dG87XHJcbiAgICBwYWRkaW5nOiAxNXB4O1xyXG4gICAgbWF4LXdpZHRoOiA0MDBweDtcclxuICAgIG1pbi13aWR0aDogMTAwcHg7XHJcblxyXG4gICAgLmNvbW1lbnQtY3JlYXRlZCB7XHJcbiAgICAgICAgbGVmdDogMDtcclxuICAgIH1cclxufVxyXG5cclxuLmNvbW1lbnQ6YWZ0ZXIge1xyXG4gICAgei1pbmRleDogNzc7XHJcbiAgICBjb250ZW50OiAnJztcclxuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAgIGJvdHRvbTogMDtcclxuICAgIGxlZnQ6IDgwJTtcclxuICAgIGJvcmRlcjogMTJweCBzb2xpZCB0cmFuc3BhcmVudDtcclxuICAgIGJvcmRlci10b3AtY29sb3I6ICM4OWNhZTk7XHJcbiAgICBib3JkZXItYm90dG9tOiAwO1xyXG4gICAgYm9yZGVyLXJpZ2h0OiAwO1xyXG4gICAgbWFyZ2luLWxlZnQ6IC02cHg7XHJcbiAgICBtYXJnaW4tYm90dG9tOiAtMTJweDtcclxufVxyXG5cclxuLmNvbW1lbnQtdXNlciB7XHJcbiAgICBmb250LWZhbWlseTogJ1JvYm90by1Cb2xkJywgc2Fucy1zZXJpZjtcclxuICAgIGZvbnQtc2l6ZTogMTRweDtcclxufVxyXG5cclxuLmNvbW1lbnQtY29udGVudCB7XHJcbiAgICBmb250LWZhbWlseTogJ1JvYm90bycsIHNhbnMtc2VyaWY7XHJcbiAgICBmb250LXNpemU6IDE0cHg7XHJcbiAgICB3b3JkLXdyYXA6IGJyZWFrLXdvcmQ7XHJcblxyXG4gICAgLmNvbnRlbnQtYXR0YWNobWVudC1jb250YWluZXIge1xyXG4gICAgICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICAgICAgbWFyZ2luLXRvcDogMTBweDtcclxuICAgICAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG5cclxuICAgICAgICAuYXR0YWNobWVudC1jb250YWluZXIge1xyXG4gICAgICAgICAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgICAgICAgICBmbGV4LWdyb3c6IDE7XHJcbiAgICAgICAgICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcblxyXG4gICAgICAgICAgICAuaW1hZ2UtY29udGFpbmVyIHtcclxuICAgICAgICAgICAgICAgIG1pbi13aWR0aDogNjBweDtcclxuICAgICAgICAgICAgICAgIG1pbi1oZWlnaHQ6IDcwcHg7XHJcbiAgICAgICAgICAgICAgICB3aWR0aDogNjBweDtcclxuICAgICAgICAgICAgICAgIGhlaWdodDogNzBweDtcclxuICAgICAgICAgICAgICAgIG92ZXJmbG93OiBoaWRkZW47XHJcbiAgICAgICAgICAgICAgICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XHJcbiAgICAgICAgICAgICAgICBtYXJnaW4tcmlnaHQ6IDEwcHg7XHJcbiAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kOiAjZmZmO1xyXG4gICAgICAgICAgICAgICAgcGFkZGluZzogNXB4O1xyXG4gICAgICAgICAgICAgICAgYm9yZGVyLXJhZGl1czogNXB4O1xyXG4gICAgICAgICAgICAgICAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG5cclxuICAgICAgICAgICAgICAgIC5pbWFnZS1mb3JtYXQge1xyXG4gICAgICAgICAgICAgICAgICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAgICAgICAgICAgICAgICAgICBsZWZ0OiAwO1xyXG4gICAgICAgICAgICAgICAgICAgIHRvcDogMDtcclxuICAgICAgICAgICAgICAgICAgICBjb2xvcjogI2ZmZjtcclxuICAgICAgICAgICAgICAgICAgICBwYWRkaW5nOiAzcHggNnB4O1xyXG4gICAgICAgICAgICAgICAgICAgIGJhY2tncm91bmQ6ICMwMDJkNjI7XHJcbiAgICAgICAgICAgICAgICAgICAgdGV4dC10cmFuc2Zvcm06IGxvd2VyY2FzZTtcclxuICAgICAgICAgICAgICAgICAgICBmb250LXNpemU6IC43cmVtO1xyXG4gICAgICAgICAgICAgICAgICAgIGJvcmRlci1yYWRpdXM6IDAgMCA1cHggMDtcclxuICAgICAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgICAgICAuaW1hZ2Uge1xyXG4gICAgICAgICAgICAgICAgICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgICAgICAgICAgICAgICAgIGhlaWdodDogMTAwJTtcclxuICAgICAgICAgICAgICAgICAgICBvYmplY3QtZml0OiBjb3ZlcjtcclxuICAgICAgICAgICAgICAgICAgICBjdXJzb3I6IHBvaW50ZXI7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIC5saW5rIHtcclxuICAgICAgICAgICAgICAgIHRleHQtZGVjb3JhdGlvbjogdW5kZXJsaW5lO1xyXG4gICAgICAgICAgICAgICAgY3Vyc29yOiBwb2ludGVyO1xyXG5cclxuICAgICAgICAgICAgICAgICY6aG92ZXIge1xyXG4gICAgICAgICAgICAgICAgICAgIHRleHQtZGVjb3JhdGlvbjogbm9uZTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH1cclxufVxyXG5cclxuLmNvbW1lbnQtY3JlYXRlZCB7XHJcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICBwYWRkaW5nLXRvcDogMTVweDtcclxuICAgIGZvbnQtZmFtaWx5OiAnUm9ib3RvJywgc2Fucy1zZXJpZjtcclxuICAgIGZvbnQtc2l6ZTogMTJweDtcclxuICAgIG1hcmdpbjogNXB4O1xyXG59XHJcblxyXG5AbWVkaWEgc2NyZWVuIGFuZCAobWF4LXdpZHRoOiAyMDAwcHgpIHtcclxuICAgIC5teS1jb21tZW50IHtcclxuICAgICAgICBtYXJnaW46IDI1cHggMjVweCA0MHB4IDc1cHg7XHJcbiAgICB9XHJcbn1cclxuXHJcbi5tZXNzYWdlLXRleHQge1xyXG4gICAgd2hpdGUtc3BhY2U6IHByZS13cmFwO1xyXG4gICAgZm9udC1mYW1pbHk6IFJvYm90bywgc2Fucy1zZXJpZjtcclxuICAgIGZvbnQtc2l6ZTogMTRweDtcclxufVxyXG4iLCIubXktY29tbWVudCB7XG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgYm9yZGVyLXJhZGl1czogMTBweDtcbiAgYmFja2dyb3VuZDogI2MzYzNjMztcbiAgbWluLWhlaWdodDogMjBweDtcbiAgbWFyZ2luOiAyNXB4IDc1cHggNDBweCAyNXB4O1xuICBwYWRkaW5nOiAxNXB4O1xuICBtYXgtd2lkdGg6IDQwMHB4O1xuICBtaW4td2lkdGg6IDEwMHB4O1xufVxuLm15LWNvbW1lbnQgLmNvbW1lbnQtY3JlYXRlZCB7XG4gIHJpZ2h0OiAwO1xufVxuXG4ubXktY29tbWVudDphZnRlciB7XG4gIHotaW5kZXg6IDc3O1xuICBjb250ZW50OiBcIlwiO1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIGJvdHRvbTogMDtcbiAgbGVmdDogMjAlO1xuICBib3JkZXI6IDEycHggc29saWQgdHJhbnNwYXJlbnQ7XG4gIGJvcmRlci10b3AtY29sb3I6ICNjM2MzYzM7XG4gIGJvcmRlci1ib3R0b206IDA7XG4gIGJvcmRlci1sZWZ0OiAwO1xuICBtYXJnaW4tbGVmdDogLTZweDtcbiAgbWFyZ2luLWJvdHRvbTogLTEycHg7XG59XG5cbi5teS1jb21tZW50LXNpemluZzphZnRlciB7XG4gIHdpZHRoOiAwO1xuICBoZWlnaHQ6IDA7XG59XG5cbi5jb21tZW50IHtcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xuICBib3JkZXItcmFkaXVzOiAxMHB4O1xuICBiYWNrZ3JvdW5kOiAjODljYWU5O1xuICBtaW4taGVpZ2h0OiAyMHB4O1xuICBtYXJnaW46IDI1cHggMjVweCA0MHB4IGF1dG87XG4gIHBhZGRpbmc6IDE1cHg7XG4gIG1heC13aWR0aDogNDAwcHg7XG4gIG1pbi13aWR0aDogMTAwcHg7XG59XG4uY29tbWVudCAuY29tbWVudC1jcmVhdGVkIHtcbiAgbGVmdDogMDtcbn1cblxuLmNvbW1lbnQ6YWZ0ZXIge1xuICB6LWluZGV4OiA3NztcbiAgY29udGVudDogXCJcIjtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICBib3R0b206IDA7XG4gIGxlZnQ6IDgwJTtcbiAgYm9yZGVyOiAxMnB4IHNvbGlkIHRyYW5zcGFyZW50O1xuICBib3JkZXItdG9wLWNvbG9yOiAjODljYWU5O1xuICBib3JkZXItYm90dG9tOiAwO1xuICBib3JkZXItcmlnaHQ6IDA7XG4gIG1hcmdpbi1sZWZ0OiAtNnB4O1xuICBtYXJnaW4tYm90dG9tOiAtMTJweDtcbn1cblxuLmNvbW1lbnQtdXNlciB7XG4gIGZvbnQtZmFtaWx5OiBcIlJvYm90by1Cb2xkXCIsIHNhbnMtc2VyaWY7XG4gIGZvbnQtc2l6ZTogMTRweDtcbn1cblxuLmNvbW1lbnQtY29udGVudCB7XG4gIGZvbnQtZmFtaWx5OiBcIlJvYm90b1wiLCBzYW5zLXNlcmlmO1xuICBmb250LXNpemU6IDE0cHg7XG4gIHdvcmQtd3JhcDogYnJlYWstd29yZDtcbn1cbi5jb21tZW50LWNvbnRlbnQgLmNvbnRlbnQtYXR0YWNobWVudC1jb250YWluZXIge1xuICBkaXNwbGF5OiBmbGV4O1xuICBtYXJnaW4tdG9wOiAxMHB4O1xuICBhbGlnbi1pdGVtczogY2VudGVyO1xufVxuLmNvbW1lbnQtY29udGVudCAuY29udGVudC1hdHRhY2htZW50LWNvbnRhaW5lciAuYXR0YWNobWVudC1jb250YWluZXIge1xuICBkaXNwbGF5OiBmbGV4O1xuICBmbGV4LWdyb3c6IDE7XG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG59XG4uY29tbWVudC1jb250ZW50IC5jb250ZW50LWF0dGFjaG1lbnQtY29udGFpbmVyIC5hdHRhY2htZW50LWNvbnRhaW5lciAuaW1hZ2UtY29udGFpbmVyIHtcbiAgbWluLXdpZHRoOiA2MHB4O1xuICBtaW4taGVpZ2h0OiA3MHB4O1xuICB3aWR0aDogNjBweDtcbiAgaGVpZ2h0OiA3MHB4O1xuICBvdmVyZmxvdzogaGlkZGVuO1xuICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XG4gIG1hcmdpbi1yaWdodDogMTBweDtcbiAgYmFja2dyb3VuZDogI2ZmZjtcbiAgcGFkZGluZzogNXB4O1xuICBib3JkZXItcmFkaXVzOiA1cHg7XG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcbn1cbi5jb21tZW50LWNvbnRlbnQgLmNvbnRlbnQtYXR0YWNobWVudC1jb250YWluZXIgLmF0dGFjaG1lbnQtY29udGFpbmVyIC5pbWFnZS1jb250YWluZXIgLmltYWdlLWZvcm1hdCB7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgbGVmdDogMDtcbiAgdG9wOiAwO1xuICBjb2xvcjogI2ZmZjtcbiAgcGFkZGluZzogM3B4IDZweDtcbiAgYmFja2dyb3VuZDogIzAwMmQ2MjtcbiAgdGV4dC10cmFuc2Zvcm06IGxvd2VyY2FzZTtcbiAgZm9udC1zaXplOiAwLjdyZW07XG4gIGJvcmRlci1yYWRpdXM6IDAgMCA1cHggMDtcbn1cbi5jb21tZW50LWNvbnRlbnQgLmNvbnRlbnQtYXR0YWNobWVudC1jb250YWluZXIgLmF0dGFjaG1lbnQtY29udGFpbmVyIC5pbWFnZS1jb250YWluZXIgLmltYWdlIHtcbiAgd2lkdGg6IDEwMCU7XG4gIGhlaWdodDogMTAwJTtcbiAgb2JqZWN0LWZpdDogY292ZXI7XG4gIGN1cnNvcjogcG9pbnRlcjtcbn1cbi5jb21tZW50LWNvbnRlbnQgLmNvbnRlbnQtYXR0YWNobWVudC1jb250YWluZXIgLmF0dGFjaG1lbnQtY29udGFpbmVyIC5saW5rIHtcbiAgdGV4dC1kZWNvcmF0aW9uOiB1bmRlcmxpbmU7XG4gIGN1cnNvcjogcG9pbnRlcjtcbn1cbi5jb21tZW50LWNvbnRlbnQgLmNvbnRlbnQtYXR0YWNobWVudC1jb250YWluZXIgLmF0dGFjaG1lbnQtY29udGFpbmVyIC5saW5rOmhvdmVyIHtcbiAgdGV4dC1kZWNvcmF0aW9uOiBub25lO1xufVxuXG4uY29tbWVudC1jcmVhdGVkIHtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICBwYWRkaW5nLXRvcDogMTVweDtcbiAgZm9udC1mYW1pbHk6IFwiUm9ib3RvXCIsIHNhbnMtc2VyaWY7XG4gIGZvbnQtc2l6ZTogMTJweDtcbiAgbWFyZ2luOiA1cHg7XG59XG5cbkBtZWRpYSBzY3JlZW4gYW5kIChtYXgtd2lkdGg6IDIwMDBweCkge1xuICAubXktY29tbWVudCB7XG4gICAgbWFyZ2luOiAyNXB4IDI1cHggNDBweCA3NXB4O1xuICB9XG59XG4ubWVzc2FnZS10ZXh0IHtcbiAgd2hpdGUtc3BhY2U6IHByZS13cmFwO1xuICBmb250LWZhbWlseTogUm9ib3RvLCBzYW5zLXNlcmlmO1xuICBmb250LXNpemU6IDE0cHg7XG59Il19 */");

/***/ }),

/***/ "./src/app/pages/tasks/task-comment/task-comment.component.ts":
/*!********************************************************************!*\
  !*** ./src/app/pages/tasks/task-comment/task-comment.component.ts ***!
  \********************************************************************/
/*! exports provided: TaskCommentComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TaskCommentComponent", function() { return TaskCommentComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_material_dialog__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/material/dialog */ "./node_modules/@angular/material/esm5/dialog.es5.js");
/* harmony import */ var _shared_components_dialog_image_dialog_image_dialog_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../shared/components/dialog/image-dialog/image-dialog.component */ "./src/app/shared/components/dialog/image-dialog/image-dialog.component.ts");
/* harmony import */ var _shared_services_data_images_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../shared/services/data/images.service */ "./src/app/shared/services/data/images.service.ts");
/* harmony import */ var _shared_services_notification_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../shared/services/notification.service */ "./src/app/shared/services/notification.service.ts");
/* harmony import */ var _shared_services_storage_project_user_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../shared/services/storage/project-user.service */ "./src/app/shared/services/storage/project-user.service.ts");







var TaskCommentComponent = /** @class */ (function () {
    function TaskCommentComponent(projectUserService, imagesService, notificationService, matDialog) {
        this.projectUserService = projectUserService;
        this.imagesService = imagesService;
        this.notificationService = notificationService;
        this.matDialog = matDialog;
        this.isMyComment = false;
    }
    TaskCommentComponent.prototype.ngOnInit = function () {
        var _this = this;
        if (this.comment.attachment) {
            this.imagesService.getImage(this.comment.attachment.filePath)
                .subscribe(function (blob) {
                var reader = new FileReader();
                reader.onload = function (e) {
                    _this.imageSrc = reader.result;
                };
                reader.readAsDataURL(blob);
            }, function () {
                _this.notificationService.openErrorNotification('error.imageDownload');
            });
        }
        this.projectUserService.subject.userId.subscribe(function (userId) {
            _this.isMyComment = userId === _this.comment.createdBy.id;
        });
    };
    TaskCommentComponent.prototype.openPreviewAttachment = function (image) {
        this.matDialog.open(_shared_components_dialog_image_dialog_image_dialog_component__WEBPACK_IMPORTED_MODULE_3__["ImageDialogComponent"], {
            data: {
                image: image
            }
        });
    };
    TaskCommentComponent.ctorParameters = function () { return [
        { type: _shared_services_storage_project_user_service__WEBPACK_IMPORTED_MODULE_6__["ProjectUserService"] },
        { type: _shared_services_data_images_service__WEBPACK_IMPORTED_MODULE_4__["ImagesService"] },
        { type: _shared_services_notification_service__WEBPACK_IMPORTED_MODULE_5__["NotificationService"] },
        { type: _angular_material_dialog__WEBPACK_IMPORTED_MODULE_2__["MatDialog"] }
    ]; };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], TaskCommentComponent.prototype, "comment", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Number)
    ], TaskCommentComponent.prototype, "index", void 0);
    TaskCommentComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'task-comment',
            template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./task-comment.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/tasks/task-comment/task-comment.component.html")).default,
            styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./task-comment.component.scss */ "./src/app/pages/tasks/task-comment/task-comment.component.scss")).default]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_shared_services_storage_project_user_service__WEBPACK_IMPORTED_MODULE_6__["ProjectUserService"],
            _shared_services_data_images_service__WEBPACK_IMPORTED_MODULE_4__["ImagesService"],
            _shared_services_notification_service__WEBPACK_IMPORTED_MODULE_5__["NotificationService"],
            _angular_material_dialog__WEBPACK_IMPORTED_MODULE_2__["MatDialog"]])
    ], TaskCommentComponent);
    return TaskCommentComponent;
}());



/***/ }),

/***/ "./src/app/pages/tasks/task-create/task-create.component.scss":
/*!********************************************************************!*\
  !*** ./src/app/pages/tasks/task-create/task-create.component.scss ***!
  \********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL3Rhc2tzL3Rhc2stY3JlYXRlL3Rhc2stY3JlYXRlLmNvbXBvbmVudC5zY3NzIn0= */");

/***/ }),

/***/ "./src/app/pages/tasks/task-create/task-create.component.ts":
/*!******************************************************************!*\
  !*** ./src/app/pages/tasks/task-create/task-create.component.ts ***!
  \******************************************************************/
/*! exports provided: TaskCreateComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TaskCreateComponent", function() { return TaskCreateComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _shared_hazlenut_hazelnut_common_animations__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../shared/hazlenut/hazelnut-common/animations */ "./src/app/shared/hazlenut/hazelnut-common/animations/index.ts");
/* harmony import */ var _shared_services_data_task_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../shared/services/data/task.service */ "./src/app/shared/services/data/task.service.ts");
/* harmony import */ var _shared_services_notification_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../shared/services/notification.service */ "./src/app/shared/services/notification.service.ts");
/* harmony import */ var _shared_services_storage_project_event_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../shared/services/storage/project-event.service */ "./src/app/shared/services/storage/project-event.service.ts");
/* harmony import */ var _task_form_task_form_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../task-form/task-form.component */ "./src/app/pages/tasks/task-form/task-form.component.ts");








var TaskCreateComponent = /** @class */ (function () {
    function TaskCreateComponent(router, taskService, notificationService, projectEventService) {
        this.router = router;
        this.taskService = taskService;
        this.notificationService = notificationService;
        this.projectEventService = projectEventService;
        this.formData = null;
    }
    TaskCreateComponent.prototype.ngOnInit = function () {
    };
    TaskCreateComponent.prototype.onCancel = function () {
        this.router.navigate(['tasks/list']);
    };
    TaskCreateComponent.prototype.onSave = function () {
        var _this = this;
        this.taskService.createTask(this.transformTaskToApiObject(this.formData)).subscribe(function (response) {
            _this.notificationService.openSuccessNotification('success.add');
            _this.router.navigate(['tasks/list']);
        }, function (error) {
            _this.notificationService.openErrorNotification('error.add');
        });
    };
    TaskCreateComponent.prototype.transformTaskToApiObject = function (formObject) {
        var apiObject = {
            taskType: formObject.taskType,
            name: formObject.title,
            clBusinessAreaId: formObject.businessArea,
            projectId: this.projectEventService.instant.id
        };
        if (formObject.trafficLight) {
            apiObject.trafficLight = formObject.trafficLight;
        }
        if (formObject.sourceOfAgenda !== '') {
            apiObject.clSourceOfAgendaId = formObject.sourceOfAgenda;
        }
        if (formObject.phase !== '') {
            apiObject.projectPhaseId = formObject.phase;
        }
        if (formObject.dueDate !== null) {
            apiObject.dueDate = formObject.dueDate;
        }
        if (formObject.responsible !== '') {
            apiObject.responsibleUserId = formObject.responsible;
        }
        if (formObject.venue !== '') {
            apiObject.cityName = formObject.venue;
        }
        if (formObject.description !== '') {
            apiObject.description = formObject.description;
        }
        if (formObject.sourceDescription !== '') {
            apiObject.sourceDescription = formObject.sourceDescription;
        }
        return apiObject;
    };
    TaskCreateComponent.ctorParameters = function () { return [
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"] },
        { type: _shared_services_data_task_service__WEBPACK_IMPORTED_MODULE_4__["TaskService"] },
        { type: _shared_services_notification_service__WEBPACK_IMPORTED_MODULE_5__["NotificationService"] },
        { type: _shared_services_storage_project_event_service__WEBPACK_IMPORTED_MODULE_6__["ProjectEventService"] }
    ]; };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])(_task_form_task_form_component__WEBPACK_IMPORTED_MODULE_7__["TaskFormComponent"], { static: true }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _task_form_task_form_component__WEBPACK_IMPORTED_MODULE_7__["TaskFormComponent"])
    ], TaskCreateComponent.prototype, "taskForm", void 0);
    TaskCreateComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'task-create',
            template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./task-create.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/tasks/task-create/task-create.component.html")).default,
            animations: [_shared_hazlenut_hazelnut_common_animations__WEBPACK_IMPORTED_MODULE_3__["fadeEnterLeave"]],
            styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./task-create.component.scss */ "./src/app/pages/tasks/task-create/task-create.component.scss")).default]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"],
            _shared_services_data_task_service__WEBPACK_IMPORTED_MODULE_4__["TaskService"],
            _shared_services_notification_service__WEBPACK_IMPORTED_MODULE_5__["NotificationService"],
            _shared_services_storage_project_event_service__WEBPACK_IMPORTED_MODULE_6__["ProjectEventService"]])
    ], TaskCreateComponent);
    return TaskCreateComponent;
}());



/***/ }),

/***/ "./src/app/pages/tasks/task-edit/task-edit.component.scss":
/*!****************************************************************!*\
  !*** ./src/app/pages/tasks/task-edit/task-edit.component.scss ***!
  \****************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".comment-list {\n  height: calc(100vh - 280px);\n  overflow-x: auto;\n}\n\n.form-content {\n  overflow: auto;\n}\n\n::ng-deep .theme-input .mat-form-field-flex {\n  background-color: #e8f0fe;\n}\n\n.comment-input {\n  width: 600px;\n}\n\n@media screen and (max-width: 2100px) {\n  .comment-input {\n    width: 450px;\n  }\n}\n\n@media screen and (max-width: 1700px) {\n  .comment-input {\n    width: 100%;\n  }\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvdGFza3MvdGFzay1lZGl0L0Q6XFxwcm9qZWN0c1xcaWloZlxcd2ZtLXdlYi9zcmNcXGFwcFxccGFnZXNcXHRhc2tzXFx0YXNrLWVkaXRcXHRhc2stZWRpdC5jb21wb25lbnQuc2NzcyIsInNyYy9hcHAvcGFnZXMvdGFza3MvdGFzay1lZGl0L3Rhc2stZWRpdC5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLDJCQUFBO0VBQ0EsZ0JBQUE7QUNDSjs7QURFQTtFQUNJLGNBQUE7QUNDSjs7QURJSTtFQUNJLHlCQUFBO0FDRFI7O0FES0E7RUFDSSxZQUFBO0FDRko7O0FES0E7RUFDSTtJQUNJLFlBQUE7RUNGTjtBQUNGOztBREtBO0VBQ0k7SUFDSSxXQUFBO0VDSE47QUFDRiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL3Rhc2tzL3Rhc2stZWRpdC90YXNrLWVkaXQuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuY29tbWVudC1saXN0e1xyXG4gICAgaGVpZ2h0OiBjYWxjKDEwMHZoIC0gMjgwcHgpO1xyXG4gICAgb3ZlcmZsb3cteDogYXV0bztcclxufVxyXG5cclxuLmZvcm0tY29udGVudHtcclxuICAgIG92ZXJmbG93OiBhdXRvO1xyXG4gICAgLy9oZWlnaHQ6IGNhbGMoMTAwdmggLSAxNTVweCk7XHJcbn1cclxuXHJcbjo6bmctZGVlcCB7XHJcbiAgICAudGhlbWUtaW5wdXQgLm1hdC1mb3JtLWZpZWxkLWZsZXgge1xyXG4gICAgICAgIGJhY2tncm91bmQtY29sb3I6ICNlOGYwZmU7XHJcbiAgICB9XHJcbn1cclxuXHJcbi5jb21tZW50LWlucHV0IHtcclxuICAgIHdpZHRoOiA2MDBweDtcclxufVxyXG5cclxuQG1lZGlhIHNjcmVlbiBhbmQgKG1heC13aWR0aDogMjEwMHB4KSB7XHJcbiAgICAuY29tbWVudC1pbnB1dCB7XHJcbiAgICAgICAgd2lkdGg6IDQ1MHB4O1xyXG4gICAgfVxyXG59XHJcblxyXG5AbWVkaWEgc2NyZWVuIGFuZCAobWF4LXdpZHRoOiAxNzAwcHgpIHtcclxuICAgIC5jb21tZW50LWlucHV0IHtcclxuICAgICAgICB3aWR0aDogMTAwJTtcclxuICAgIH1cclxufVxyXG4iLCIuY29tbWVudC1saXN0IHtcbiAgaGVpZ2h0OiBjYWxjKDEwMHZoIC0gMjgwcHgpO1xuICBvdmVyZmxvdy14OiBhdXRvO1xufVxuXG4uZm9ybS1jb250ZW50IHtcbiAgb3ZlcmZsb3c6IGF1dG87XG59XG5cbjo6bmctZGVlcCAudGhlbWUtaW5wdXQgLm1hdC1mb3JtLWZpZWxkLWZsZXgge1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjZThmMGZlO1xufVxuXG4uY29tbWVudC1pbnB1dCB7XG4gIHdpZHRoOiA2MDBweDtcbn1cblxuQG1lZGlhIHNjcmVlbiBhbmQgKG1heC13aWR0aDogMjEwMHB4KSB7XG4gIC5jb21tZW50LWlucHV0IHtcbiAgICB3aWR0aDogNDUwcHg7XG4gIH1cbn1cbkBtZWRpYSBzY3JlZW4gYW5kIChtYXgtd2lkdGg6IDE3MDBweCkge1xuICAuY29tbWVudC1pbnB1dCB7XG4gICAgd2lkdGg6IDEwMCU7XG4gIH1cbn0iXX0= */");

/***/ }),

/***/ "./src/app/pages/tasks/task-edit/task-edit.component.ts":
/*!**************************************************************!*\
  !*** ./src/app/pages/tasks/task-edit/task-edit.component.ts ***!
  \**************************************************************/
/*! exports provided: TaskEditComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TaskEditComponent", function() { return TaskEditComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var rxjs_internal_operators_tap__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs/internal/operators/tap */ "./node_modules/rxjs/internal/operators/tap.js");
/* harmony import */ var rxjs_internal_operators_tap__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(rxjs_internal_operators_tap__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _shared_enums_role_enum__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../shared/enums/role.enum */ "./src/app/shared/enums/role.enum.ts");
/* harmony import */ var _shared_hazlenut_hazelnut_common_regex_regex__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../shared/hazlenut/hazelnut-common/regex/regex */ "./src/app/shared/hazlenut/hazelnut-common/regex/regex.ts");
/* harmony import */ var _shared_services_auth_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../../shared/services/auth.service */ "./src/app/shared/services/auth.service.ts");
/* harmony import */ var _shared_services_data_images_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../../shared/services/data/images.service */ "./src/app/shared/services/data/images.service.ts");
/* harmony import */ var _shared_services_data_task_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../../shared/services/data/task.service */ "./src/app/shared/services/data/task.service.ts");
/* harmony import */ var _shared_services_notification_service__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../../shared/services/notification.service */ "./src/app/shared/services/notification.service.ts");
/* harmony import */ var _shared_services_storage_project_event_service__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../../shared/services/storage/project-event.service */ "./src/app/shared/services/storage/project-event.service.ts");
/* harmony import */ var _shared_services_task_comment_service__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../../../shared/services/task-comment.service */ "./src/app/shared/services/task-comment.service.ts");
/* harmony import */ var _task_form_task_form_component__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../task-form/task-form.component */ "./src/app/pages/tasks/task-form/task-form.component.ts");














var TaskEditComponent = /** @class */ (function () {
    function TaskEditComponent(router, taskCommentService, notificationService, activatedRoute, taskService, formBuilder, imagesService, projectEventService, authService) {
        this.router = router;
        this.taskCommentService = taskCommentService;
        this.notificationService = notificationService;
        this.activatedRoute = activatedRoute;
        this.taskService = taskService;
        this.formBuilder = formBuilder;
        this.imagesService = imagesService;
        this.projectEventService = projectEventService;
        this.authService = authService;
        this.formData = null;
        this.comments = [];
        this.loading = false;
        this.notOnlyWhiteCharactersPattern = _shared_hazlenut_hazelnut_common_regex_regex__WEBPACK_IMPORTED_MODULE_6__["Regex"].notOnlyWhiteCharactersPattern;
        this.attachmentFormat = '';
        this.attachmentFileName = '';
        this.attachmentPathName = '';
    }
    TaskEditComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.activatedRoute.queryParams.subscribe(function (param) {
            _this.taskId = param.id;
            _this.getAllComments();
        });
        this.addCommentForm = this.formBuilder.group({
            newComment: [
                '',
                _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required
            ],
            attachment: ['']
        });
    };
    TaskEditComponent.prototype.onCancel = function () {
        this.router.navigate(['tasks/list']);
    };
    TaskEditComponent.prototype.onSave = function () {
        var _this = this;
        if (this.formData) {
            this.taskService.editTask(this.taskId, this.transformTaskToApiObject(this.formData))
                .subscribe(function (response) {
                _this.notificationService.openSuccessNotification('success.edit');
                _this.router.navigate(['tasks/list']);
            }, function (error) {
                _this.notificationService.openErrorNotification('error.edit');
            });
        }
    };
    TaskEditComponent.prototype.onCommentAdded = function () {
        if (this.addCommentForm.invalid) {
            return;
        }
        var taskComment = {
            description: this.addCommentForm.value.newComment.toString(),
            taskId: this.taskId,
            type: 'TEXT'
        };
        this.onSendCommentService(taskComment);
    };
    TaskEditComponent.prototype.onAttachmentAdded = function () {
        var taskComment = {
            description: '',
            taskId: this.taskId,
            type: 'ATTACHMENT',
            attachment: {
                type: 'COMMENT',
                format: this.attachmentFormat,
                fileName: this.attachmentFileName,
                filePath: this.attachmentPathName
            }
        };
        this.onSendCommentService(taskComment);
    };
    TaskEditComponent.prototype.onSendCommentService = function (taskComment) {
        var _this = this;
        this.loading = true;
        this.taskCommentService.addComment(taskComment)
            .subscribe(function (commentResponse) {
            _this.getAllComments();
            _this.addCommentForm.controls.newComment.reset();
            _this.loading = false;
        }, function (error) {
            _this.notificationService.openErrorNotification('error.addComment');
            _this.loading = false;
        });
    };
    TaskEditComponent.prototype.getAllComments = function () {
        var _this = this;
        this.loading = true;
        this.taskCommentService.getAllComment(this.taskId)
            .pipe(Object(rxjs_internal_operators_tap__WEBPACK_IMPORTED_MODULE_4__["tap"])(function () { return _this.loading = false; }))
            .subscribe(function (comments) {
            _this.comments = comments.slice().sort(function (a, b) { return (a.created > b.created) ? 1 : -1; }).reverse();
        }, function () {
            _this.notificationService.openErrorNotification('error.loadComments');
        });
    };
    TaskEditComponent.prototype.hasRoleUploadImage = function () {
        return this.authService.hasRole(_shared_enums_role_enum__WEBPACK_IMPORTED_MODULE_5__["Role"].RoleUploadImage);
    };
    TaskEditComponent.prototype.formDataChange = function ($event) {
        var _this = this;
        setTimeout(function () {
            _this.formData = $event;
        }, 200);
    };
    TaskEditComponent.prototype.onFileChange = function (event) {
        var _this = this;
        var file = event.target.files[0];
        if (!file) {
            return;
        }
        var reader = new FileReader();
        reader.onload = function () {
            _this.imagesService.uploadImages([file])
                .subscribe(function (data) {
                _this.attachmentFormat = file.name.split('.')
                    .pop()
                    .toUpperCase();
                _this.attachmentFileName = file.name;
                _this.attachmentPathName = data.fileNames[file.name].replace(/^.*[\\\/]/, '');
                _this.onAttachmentAdded();
            }, function () {
                _this.attachmentFormat = '';
                _this.attachmentFileName = '';
                _this.attachmentPathName = '';
                _this.notificationService.openErrorNotification('error.imageUpload');
            });
        };
        reader.readAsDataURL(file);
    };
    TaskEditComponent.prototype.allowReadComment = function () {
        return this.hasRoleReadComment() || this.hasRoleReadCommentInAssignProject();
    };
    TaskEditComponent.prototype.allowUpdateTask = function () {
        return this.hasRoleUpdateTask() || this.hasRoleUpdateTaskInAssignProject();
    };
    TaskEditComponent.prototype.allowCreateComment = function () {
        return this.hasRoleCreateComment() || this.hasRoleCreateCommentInAssignProject();
    };
    TaskEditComponent.prototype.hasRoleUpdateTask = function () {
        return this.authService.hasRole(_shared_enums_role_enum__WEBPACK_IMPORTED_MODULE_5__["Role"].RoleUpdateTask);
    };
    TaskEditComponent.prototype.hasRoleUpdateTaskInAssignProject = function () {
        return this.authService.hasRole(_shared_enums_role_enum__WEBPACK_IMPORTED_MODULE_5__["Role"].RoleUpdateTaskInAssignProject);
    };
    TaskEditComponent.prototype.hasRoleReadComment = function () {
        return this.authService.hasRole(_shared_enums_role_enum__WEBPACK_IMPORTED_MODULE_5__["Role"].RoleReadComment);
    };
    TaskEditComponent.prototype.hasRoleReadCommentInAssignProject = function () {
        return this.authService.hasRole(_shared_enums_role_enum__WEBPACK_IMPORTED_MODULE_5__["Role"].RoleReadCommentInAssignProject);
    };
    TaskEditComponent.prototype.hasRoleCreateComment = function () {
        return this.authService.hasRole(_shared_enums_role_enum__WEBPACK_IMPORTED_MODULE_5__["Role"].RoleCreateComment);
    };
    TaskEditComponent.prototype.hasRoleCreateCommentInAssignProject = function () {
        return this.authService.hasRole(_shared_enums_role_enum__WEBPACK_IMPORTED_MODULE_5__["Role"].RoleCreateCommentInAssignProject);
    };
    TaskEditComponent.prototype.transformTaskToApiObject = function (formObject) {
        var apiObject = {
            name: formObject.title,
            state: formObject.state,
            dueDate: formObject.dueDate,
            clSourceOfAgendaId: formObject.sourceOfAgenda,
            projectPhaseId: formObject.phase,
            responsibleUserId: formObject.responsible,
            cityName: formObject.venue,
            description: formObject.description,
            sourceDescription: formObject.sourceDescription,
        };
        if (formObject.trafficLight !== '') {
            apiObject.trafficLight = formObject.trafficLight;
        }
        return apiObject;
    };
    TaskEditComponent.ctorParameters = function () { return [
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"] },
        { type: _shared_services_task_comment_service__WEBPACK_IMPORTED_MODULE_12__["TaskCommentService"] },
        { type: _shared_services_notification_service__WEBPACK_IMPORTED_MODULE_10__["NotificationService"] },
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["ActivatedRoute"] },
        { type: _shared_services_data_task_service__WEBPACK_IMPORTED_MODULE_9__["TaskService"] },
        { type: _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormBuilder"] },
        { type: _shared_services_data_images_service__WEBPACK_IMPORTED_MODULE_8__["ImagesService"] },
        { type: _shared_services_storage_project_event_service__WEBPACK_IMPORTED_MODULE_11__["ProjectEventService"] },
        { type: _shared_services_auth_service__WEBPACK_IMPORTED_MODULE_7__["AuthService"] }
    ]; };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])(_task_form_task_form_component__WEBPACK_IMPORTED_MODULE_13__["TaskFormComponent"], { static: true }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _task_form_task_form_component__WEBPACK_IMPORTED_MODULE_13__["TaskFormComponent"])
    ], TaskEditComponent.prototype, "taskForm", void 0);
    TaskEditComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'task-edit',
            template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./task-edit.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/tasks/task-edit/task-edit.component.html")).default,
            styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./task-edit.component.scss */ "./src/app/pages/tasks/task-edit/task-edit.component.scss")).default]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"],
            _shared_services_task_comment_service__WEBPACK_IMPORTED_MODULE_12__["TaskCommentService"],
            _shared_services_notification_service__WEBPACK_IMPORTED_MODULE_10__["NotificationService"],
            _angular_router__WEBPACK_IMPORTED_MODULE_3__["ActivatedRoute"],
            _shared_services_data_task_service__WEBPACK_IMPORTED_MODULE_9__["TaskService"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormBuilder"],
            _shared_services_data_images_service__WEBPACK_IMPORTED_MODULE_8__["ImagesService"],
            _shared_services_storage_project_event_service__WEBPACK_IMPORTED_MODULE_11__["ProjectEventService"],
            _shared_services_auth_service__WEBPACK_IMPORTED_MODULE_7__["AuthService"]])
    ], TaskEditComponent);
    return TaskEditComponent;
}());



/***/ }),

/***/ "./src/app/pages/tasks/task-list/task-list.component.scss":
/*!****************************************************************!*\
  !*** ./src/app/pages/tasks/task-list/task-list.component.scss ***!
  \****************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("::ng-deep .header-select .mat-form-field .mat-form-field-flex {\n  background-color: rgba(0, 0, 0, 0);\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvdGFza3MvdGFzay1saXN0L0Q6XFxwcm9qZWN0c1xcaWloZlxcd2ZtLXdlYi9zcmNcXGFwcFxccGFnZXNcXHRhc2tzXFx0YXNrLWxpc3RcXHRhc2stbGlzdC5jb21wb25lbnQuc2NzcyIsInNyYy9hcHAvcGFnZXMvdGFza3MvdGFzay1saXN0L3Rhc2stbGlzdC5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFFSTtFQUNJLGtDQUFBO0FDRFIiLCJmaWxlIjoic3JjL2FwcC9wYWdlcy90YXNrcy90YXNrLWxpc3QvdGFzay1saXN0LmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiXHJcbjo6bmctZGVlcCB7XHJcbiAgICAuaGVhZGVyLXNlbGVjdCAubWF0LWZvcm0tZmllbGQgLm1hdC1mb3JtLWZpZWxkLWZsZXgge1xyXG4gICAgICAgIGJhY2tncm91bmQtY29sb3I6IHJnYmEoMCwwLDAsMCk7XHJcbiAgICB9XHJcbn1cclxuIiwiOjpuZy1kZWVwIC5oZWFkZXItc2VsZWN0IC5tYXQtZm9ybS1maWVsZCAubWF0LWZvcm0tZmllbGQtZmxleCB7XG4gIGJhY2tncm91bmQtY29sb3I6IHJnYmEoMCwgMCwgMCwgMCk7XG59Il19 */");

/***/ }),

/***/ "./src/app/pages/tasks/task-list/task-list.component.ts":
/*!**************************************************************!*\
  !*** ./src/app/pages/tasks/task-list/task-list.component.ts ***!
  \**************************************************************/
/*! exports provided: TaskListComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TaskListComponent", function() { return TaskListComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ngx-translate/core */ "./node_modules/@ngx-translate/core/fesm5/ngx-translate-core.js");
/* harmony import */ var _shared_enums_role_enum__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../shared/enums/role.enum */ "./src/app/shared/enums/role.enum.ts");
/* harmony import */ var _shared_hazlenut_core_table__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../shared/hazlenut/core-table */ "./src/app/shared/hazlenut/core-table/index.ts");
/* harmony import */ var _shared_hazlenut_hazelnut_common_animations__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../../shared/hazlenut/hazelnut-common/animations */ "./src/app/shared/hazlenut/hazelnut-common/animations/index.ts");
/* harmony import */ var _shared_hazlenut_hazelnut_common_hazelnut__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../../shared/hazlenut/hazelnut-common/hazelnut */ "./src/app/shared/hazlenut/hazelnut-common/hazelnut/index.ts");
/* harmony import */ var _shared_hazlenut_hazelnut_common_models__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../../shared/hazlenut/hazelnut-common/models */ "./src/app/shared/hazlenut/hazelnut-common/models/index.ts");
/* harmony import */ var _shared_hazlenut_hazelnut_common_utils_file_manager__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../../shared/hazlenut/hazelnut-common/utils/file-manager */ "./src/app/shared/hazlenut/hazelnut-common/utils/file-manager.ts");
/* harmony import */ var _shared_services_auth_service__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../../shared/services/auth.service */ "./src/app/shared/services/auth.service.ts");
/* harmony import */ var _shared_services_data_business_area_service__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../../../shared/services/data/business-area.service */ "./src/app/shared/services/data/business-area.service.ts");
/* harmony import */ var _shared_services_data_task_service__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../../../shared/services/data/task.service */ "./src/app/shared/services/data/task.service.ts");
/* harmony import */ var _shared_services_notification_service__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ../../../shared/services/notification.service */ "./src/app/shared/services/notification.service.ts");
/* harmony import */ var _shared_services_routing_storage_service__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ../../../shared/services/routing-storage.service */ "./src/app/shared/services/routing-storage.service.ts");
/* harmony import */ var _shared_services_storage_project_event_service__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ../../../shared/services/storage/project-event.service */ "./src/app/shared/services/storage/project-event.service.ts");
/* harmony import */ var _shared_services_storage_selected_area_service__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ../../../shared/services/storage/selected-area.service */ "./src/app/shared/services/storage/selected-area.service.ts");
/* harmony import */ var _shared_services_table_change_storage_service__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ../../../shared/services/table-change-storage.service */ "./src/app/shared/services/table-change-storage.service.ts");
/* harmony import */ var _shared_utils_headers__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ../../../shared/utils/headers */ "./src/app/shared/utils/headers.ts");




















var TaskListComponent = /** @class */ (function () {
    function TaskListComponent(projectEventService, selectedAreaService, businessAreaService, formBuilder, translateService, router, taskService, notificationService, routingStorageService, tableChangeStorageService, authService) {
        this.projectEventService = projectEventService;
        this.selectedAreaService = selectedAreaService;
        this.businessAreaService = businessAreaService;
        this.formBuilder = formBuilder;
        this.translateService = translateService;
        this.router = router;
        this.taskService = taskService;
        this.notificationService = notificationService;
        this.routingStorageService = routingStorageService;
        this.tableChangeStorageService = tableChangeStorageService;
        this.authService = authService;
        this.data = new _shared_hazlenut_hazelnut_common_models__WEBPACK_IMPORTED_MODULE_9__["BrowseResponse"]();
        this.loading = false;
        this.loadingExport = false;
        this.isInitialized = false;
        this.allTaskFilters = [];
        this.additionalFilters = [];
    }
    TaskListComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.loadBusinessAreaList();
        // Business area form group setup
        this.areaGroup = this.formBuilder.group({
            businessArea: [this.getBusinessAreaValue()]
        });
        // Business area input listener and table data reload
        this.areaGroup.valueChanges.subscribe(function (value) {
            // Add business area filter if ALL value selected in business area select
            if (value !== 'all') {
                _this.businessAreaFilter = new _shared_hazlenut_hazelnut_common_models__WEBPACK_IMPORTED_MODULE_9__["Filter"]('BUSINESS_AREA_NAME', value.businessArea);
            }
            _this.setTableData();
        });
        var allThingsKey = 'all.things';
        // Table config setup
        this.config = {
            stickyEnd: 7,
            columns: [
                new _shared_hazlenut_core_table__WEBPACK_IMPORTED_MODULE_6__["TableColumn"]({
                    columnDef: 'trafficLight',
                    labelKey: 'task.trafficLight',
                    type: _shared_hazlenut_core_table__WEBPACK_IMPORTED_MODULE_6__["TableCellType"].CONTENT,
                    tableCellTemplate: this.trafficLightColumn,
                    filter: new _shared_hazlenut_core_table__WEBPACK_IMPORTED_MODULE_6__["TableColumnFilter"]({
                        valueType: 'ENUM',
                        type: _shared_hazlenut_core_table__WEBPACK_IMPORTED_MODULE_6__["TableFilterType"].TRAFFIC_LIGHT,
                        select: [
                            new _shared_hazlenut_core_table__WEBPACK_IMPORTED_MODULE_6__["ListItem"]('', this.translateService.instant(allThingsKey)),
                            new _shared_hazlenut_core_table__WEBPACK_IMPORTED_MODULE_6__["ListItem"]('RED', this.translateService.instant('color.red')),
                            new _shared_hazlenut_core_table__WEBPACK_IMPORTED_MODULE_6__["ListItem"]('GREEN', this.translateService.instant('color.green')),
                            new _shared_hazlenut_core_table__WEBPACK_IMPORTED_MODULE_6__["ListItem"]('AMBER', this.translateService.instant('color.amber')),
                        ]
                    }),
                    sorting: true,
                }),
                new _shared_hazlenut_core_table__WEBPACK_IMPORTED_MODULE_6__["TableColumn"]({
                    columnDef: 'taskType',
                    labelKey: 'task.type',
                    sorting: true,
                    type: _shared_hazlenut_core_table__WEBPACK_IMPORTED_MODULE_6__["TableCellType"].CONTENT,
                    tableCellTemplate: this.taskTypeColumn,
                    filter: new _shared_hazlenut_core_table__WEBPACK_IMPORTED_MODULE_6__["TableColumnFilter"]({
                        valueType: 'ENUM',
                        type: _shared_hazlenut_core_table__WEBPACK_IMPORTED_MODULE_6__["TableFilterType"].SELECT,
                        select: [
                            new _shared_hazlenut_core_table__WEBPACK_IMPORTED_MODULE_6__["ListItem"]('', this.translateService.instant(allThingsKey)),
                            new _shared_hazlenut_core_table__WEBPACK_IMPORTED_MODULE_6__["ListItem"]('TASK', this.translateService.instant('task.taskTypeValue.task')),
                            new _shared_hazlenut_core_table__WEBPACK_IMPORTED_MODULE_6__["ListItem"]('ISSUE', this.translateService.instant('task.taskTypeValue.issue')),
                        ]
                    }),
                }),
                new _shared_hazlenut_core_table__WEBPACK_IMPORTED_MODULE_6__["TableColumn"]({
                    columnDef: 'code',
                    labelKey: 'task.code',
                    type: _shared_hazlenut_core_table__WEBPACK_IMPORTED_MODULE_6__["TableCellType"].NUMBER,
                    filter: new _shared_hazlenut_core_table__WEBPACK_IMPORTED_MODULE_6__["TableColumnFilter"]({
                        type: _shared_hazlenut_core_table__WEBPACK_IMPORTED_MODULE_6__["TableFilterType"].NUMBER,
                    }),
                    sorting: true,
                }),
                new _shared_hazlenut_core_table__WEBPACK_IMPORTED_MODULE_6__["TableColumn"]({
                    columnDef: 'name',
                    labelKey: 'task.name',
                    filter: new _shared_hazlenut_core_table__WEBPACK_IMPORTED_MODULE_6__["TableColumnFilter"]({}),
                    sorting: true,
                }),
                new _shared_hazlenut_core_table__WEBPACK_IMPORTED_MODULE_6__["TableColumn"]({
                    columnDef: 'cityName',
                    labelKey: 'task.venue',
                    filter: new _shared_hazlenut_core_table__WEBPACK_IMPORTED_MODULE_6__["TableColumnFilter"]({
                        valueType: 'STRING',
                        type: _shared_hazlenut_core_table__WEBPACK_IMPORTED_MODULE_6__["TableFilterType"].SELECT_STRING,
                        select: [
                            new _shared_hazlenut_core_table__WEBPACK_IMPORTED_MODULE_6__["ListItem"]('', this.translateService.instant('venue.value.all')),
                            new _shared_hazlenut_core_table__WEBPACK_IMPORTED_MODULE_6__["ListItem"]('NONE', this.translateService.instant('venue.value.none')),
                            new _shared_hazlenut_core_table__WEBPACK_IMPORTED_MODULE_6__["ListItem"](this.projectEventService.instant.firstVenue, this.projectEventService.instant.firstVenue),
                            new _shared_hazlenut_core_table__WEBPACK_IMPORTED_MODULE_6__["ListItem"](this.projectEventService.instant.secondVenue, this.projectEventService.instant.secondVenue),
                            new _shared_hazlenut_core_table__WEBPACK_IMPORTED_MODULE_6__["ListItem"]('BOTH', this.translateService.instant('venue.value.both')),
                        ]
                    }),
                    sorting: true,
                    type: _shared_hazlenut_core_table__WEBPACK_IMPORTED_MODULE_6__["TableCellType"].CONTENT,
                    tableCellTemplate: this.venueColumn,
                }),
                new _shared_hazlenut_core_table__WEBPACK_IMPORTED_MODULE_6__["TableColumn"]({
                    columnDef: 'responsibleUserId',
                    labelKey: 'task.responsible',
                    sorting: true,
                    type: _shared_hazlenut_core_table__WEBPACK_IMPORTED_MODULE_6__["TableCellType"].CONTENT,
                    tableCellTemplate: this.userColumn,
                    filter: new _shared_hazlenut_core_table__WEBPACK_IMPORTED_MODULE_6__["TableColumnFilter"]({
                        valueType: 'STRING',
                        type: _shared_hazlenut_core_table__WEBPACK_IMPORTED_MODULE_6__["TableFilterType"].RESPONSIBLE,
                    }),
                }),
                new _shared_hazlenut_core_table__WEBPACK_IMPORTED_MODULE_6__["TableColumn"]({
                    columnDef: 'dueDate',
                    labelKey: 'task.dueDate',
                    filter: new _shared_hazlenut_core_table__WEBPACK_IMPORTED_MODULE_6__["TableColumnFilter"]({
                        valueType: 'DATE_TIME',
                        type: _shared_hazlenut_core_table__WEBPACK_IMPORTED_MODULE_6__["TableFilterType"].DATETIME_AS_DATERANGE,
                    }),
                    sorting: true,
                    type: _shared_hazlenut_core_table__WEBPACK_IMPORTED_MODULE_6__["TableCellType"].CONTENT,
                    tableCellTemplate: this.dateColumn,
                }),
                new _shared_hazlenut_core_table__WEBPACK_IMPORTED_MODULE_6__["TableColumn"]({
                    columnDef: 'state',
                    labelKey: 'task.status',
                    type: _shared_hazlenut_core_table__WEBPACK_IMPORTED_MODULE_6__["TableCellType"].CONTENT,
                    tableCellTemplate: this.statusColumn,
                    filter: new _shared_hazlenut_core_table__WEBPACK_IMPORTED_MODULE_6__["TableColumnFilter"]({
                        valueType: 'ENUM',
                        type: _shared_hazlenut_core_table__WEBPACK_IMPORTED_MODULE_6__["TableFilterType"].SELECT,
                        select: [
                            new _shared_hazlenut_core_table__WEBPACK_IMPORTED_MODULE_6__["ListItem"]('', this.translateService.instant(allThingsKey)),
                            new _shared_hazlenut_core_table__WEBPACK_IMPORTED_MODULE_6__["ListItem"]('OPEN', this.translateService.instant('task.statusValue.open')),
                            new _shared_hazlenut_core_table__WEBPACK_IMPORTED_MODULE_6__["ListItem"]('CLOSED', this.translateService.instant('task.statusValue.closed')),
                        ]
                    }),
                    sorting: true,
                }),
                new _shared_hazlenut_core_table__WEBPACK_IMPORTED_MODULE_6__["TableColumn"]({
                    columnDef: ' ',
                    label: ' ',
                    type: _shared_hazlenut_core_table__WEBPACK_IMPORTED_MODULE_6__["TableCellType"].CONTENT,
                    tableCellTemplate: this.updateColumn,
                    filter: new _shared_hazlenut_core_table__WEBPACK_IMPORTED_MODULE_6__["TableColumnFilter"]({
                        type: _shared_hazlenut_core_table__WEBPACK_IMPORTED_MODULE_6__["TableFilterType"].CLEAR_FILTERS,
                    }),
                }),
            ],
            paging: true,
        };
        // Set table change event data from local storage
        if (!this.isInitialized && this.isReturnFromDetail() && this.tableChangeStorageService.getTasksLastTableChangeEvent()) {
            if (this.tableChangeStorageService.getTasksLastTableChangeEvent().filters) {
                this.config.predefinedFilters = this.tableChangeStorageService.getTasksLastTableChangeEvent().filters;
            }
            if (this.tableChangeStorageService.getTasksLastTableChangeEvent().pageIndex) {
                this.config.predefinedPageIndex = this.tableChangeStorageService.getTasksLastTableChangeEvent().pageIndex;
            }
            if (this.tableChangeStorageService.getTasksLastTableChangeEvent().pageSize) {
                this.config.predefinedPageSize = this.tableChangeStorageService.getTasksLastTableChangeEvent().pageSize;
            }
            if (this.tableChangeStorageService.getTasksLastTableChangeEvent().sortDirection) {
                this.config.predefinedSortDirection = this.tableChangeStorageService.getTasksLastTableChangeEvent()
                    .sortDirection
                    .toLowerCase();
            }
            if (this.tableChangeStorageService.getTasksLastTableChangeEvent().sortActive) {
                this.config.predefinedSortActive = _shared_hazlenut_hazelnut_common_hazelnut__WEBPACK_IMPORTED_MODULE_8__["StringUtils"].convertSnakeToCamel(this.tableChangeStorageService.getTasksLastTableChangeEvent()
                    .sortActive
                    .toLowerCase());
            }
        }
    };
    /**
     * navigate create task screen
     */
    TaskListComponent.prototype.createTask = function () {
        this.router.navigate(['tasks/create']);
    };
    /**
     * Export report from API based on selected filters
     */
    TaskListComponent.prototype.export = function () {
        var _this = this;
        this.loading = true;
        this.taskService.exportTasks(this.lastTableChangeEvent, this.additionalFilters, this.projectEventService.instant.id)
            .subscribe(function (response) {
            var contentDisposition = response.headers.get('Content-Disposition');
            var exportName = Object(_shared_utils_headers__WEBPACK_IMPORTED_MODULE_19__["GetFileNameFromContentDisposition"])(contentDisposition);
            new _shared_hazlenut_hazelnut_common_utils_file_manager__WEBPACK_IMPORTED_MODULE_10__["FileManager"]().saveFile(exportName, response.body, 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
            _this.loading = false;
        }, function () {
            _this.notificationService.openErrorNotification('error.api');
            _this.loading = false;
        });
    };
    /**
     * Navigate to update task screen
     * @param id
     */
    TaskListComponent.prototype.update = function (id) {
        this.router.navigate(['tasks/edit'], { queryParams: { id: id } });
    };
    TaskListComponent.prototype.setTableData = function (tableChangeEvent) {
        var _this = this;
        if (!tableChangeEvent) {
            tableChangeEvent = this.taskTable.reset();
        }
        if (tableChangeEvent && tableChangeEvent.filters && tableChangeEvent.filters.length > 0) {
            this.allTaskFilters = tableChangeEvent.filters;
        }
        this.lastTableChangeEvent = tableChangeEvent;
        this.additionalFilters = [
            new _shared_hazlenut_hazelnut_common_models__WEBPACK_IMPORTED_MODULE_9__["Filter"]('PROJECT_ID', this.projectEventService.instant.id, 'NUMBER'),
        ];
        if (this.businessAreaFilter && this.businessAreaFilter.value !== 'all') {
            this.additionalFilters.push(this.businessAreaFilter);
        }
        // Add business area filter to additional filters
        if (!this.isInitialized && this.getBusinessAreaValue() !== 'all') {
            this.additionalFilters.push(this.businessAreaFilter = new _shared_hazlenut_hazelnut_common_models__WEBPACK_IMPORTED_MODULE_9__["Filter"]('BUSINESS_AREA_NAME', this.getBusinessAreaValue()));
        }
        if (this.allTaskFilters) {
            this.allTaskFilters.forEach(function (filter) {
                _this.additionalFilters.push(filter);
            });
        }
        this.removeDuplicateFilters();
        this.loading = true;
        // Update table change event values from local storage
        if (!this.isInitialized && this.isReturnFromDetail() && this.tableChangeStorageService.getTasksLastTableChangeEvent()) {
            tableChangeEvent.pageIndex = this.tableChangeStorageService.getTasksLastTableChangeEvent().pageIndex;
            tableChangeEvent.pageSize = this.tableChangeStorageService.getTasksLastTableChangeEvent().pageSize;
            tableChangeEvent.sortDirection = this.tableChangeStorageService.getTasksLastTableChangeEvent().sortDirection;
            tableChangeEvent.sortActive = this.tableChangeStorageService.getTasksLastTableChangeEvent().sortActive;
        }
        this.taskService.browseTasks(tableChangeEvent, this.additionalFilters)
            .subscribe(function (data) {
            _this.data = data;
            _this.loading = false;
            _this.isInitialized = true;
        }, function () {
            _this.loading = false;
            _this.notificationService.openErrorNotification('error.api');
        });
        this.tableChangeStorageService.setTasksLastTableChangeEvent(tableChangeEvent, this.additionalFilters);
    };
    TaskListComponent.prototype.allowCreateTaskButton = function () {
        return this.hasCreateTaskRole() || this.hasCreateTaskRoleInAssignProject();
    };
    TaskListComponent.prototype.allowExportReportTaskButton = function () {
        return this.hasRoleExportReportTask() || this.hasRoleExportReportTaskInAssignProject();
    };
    TaskListComponent.prototype.allowTaskDetailButton = function () {
        return this.authService.hasRole(_shared_enums_role_enum__WEBPACK_IMPORTED_MODULE_5__["Role"].RoleReadTask) ||
            this.authService.hasRole(_shared_enums_role_enum__WEBPACK_IMPORTED_MODULE_5__["Role"].RoleReadTaskInAssignProject) ||
            this.authService.hasRole(_shared_enums_role_enum__WEBPACK_IMPORTED_MODULE_5__["Role"].RoleUpdateTask) ||
            this.authService.hasRole(_shared_enums_role_enum__WEBPACK_IMPORTED_MODULE_5__["Role"].RoleUpdateTaskInAssignProject);
    };
    TaskListComponent.prototype.hasCreateTaskRole = function () {
        return this.authService.hasRole(_shared_enums_role_enum__WEBPACK_IMPORTED_MODULE_5__["Role"].RoleCreateTask);
    };
    TaskListComponent.prototype.hasCreateTaskRoleInAssignProject = function () {
        return this.authService.hasRole(_shared_enums_role_enum__WEBPACK_IMPORTED_MODULE_5__["Role"].RoleCreateTaskInAssignProject);
    };
    TaskListComponent.prototype.hasRoleExportReportTask = function () {
        return this.authService.hasRole(_shared_enums_role_enum__WEBPACK_IMPORTED_MODULE_5__["Role"].RoleExportReportTask);
    };
    TaskListComponent.prototype.hasRoleExportReportTaskInAssignProject = function () {
        return this.authService.hasRole(_shared_enums_role_enum__WEBPACK_IMPORTED_MODULE_5__["Role"].RoleExportReportTaskInAssignProject);
    };
    TaskListComponent.prototype.removeDuplicateFilters = function () {
        var userIdFilters = this.additionalFilters.filter(function (el) { return el.property === 'RESPONSIBLE_USER_ID'; });
        if (userIdFilters.length > 1) {
            var allUserIdFilters = this.additionalFilters.filter(function (el) { return el.property === 'RESPONSIBLE_USER_ID'; });
            var oneFilter = allUserIdFilters[allUserIdFilters.length - 1];
            this.additionalFilters = this.additionalFilters.filter(function (el) { return el.property !== 'RESPONSIBLE_USER_ID'; });
            this.additionalFilters.push(oneFilter);
        }
    };
    /**
     * Load business area list from API
     */
    TaskListComponent.prototype.loadBusinessAreaList = function () {
        var _this = this;
        this.businessAreaService.listBusinessAreas()
            .subscribe(function (data) {
            _this.businessAreaList = data.content
                .filter(function (item) { return item.codeItem !== null && item.state === 'VALID'; });
        });
    };
    /**
     * Business area selected from business area list or saved local storage value
     */
    TaskListComponent.prototype.getBusinessAreaValue = function () {
        var businessAreaValue = this.selectedAreaService.instant.selectedArea;
        var tableChangeEventInStorage = this.tableChangeStorageService.getTasksLastTableChangeEvent();
        if (!this.isInitialized && this.isReturnFromDetail() && tableChangeEventInStorage && tableChangeEventInStorage.additionalFilters) {
            businessAreaValue = this.getStorageBusinessAreaFilter(tableChangeEventInStorage) ? this.getStorageBusinessAreaFilter(tableChangeEventInStorage).value : 'all';
        }
        return businessAreaValue;
    };
    /**
     * Get business area filter from local storage value
     * @param tableChangeEventInStorage
     */
    TaskListComponent.prototype.getStorageBusinessAreaFilter = function (tableChangeEventInStorage) {
        if (!tableChangeEventInStorage || !tableChangeEventInStorage.additionalFilters) {
            return;
        }
        return tableChangeEventInStorage.additionalFilters.find(function (filter) { return filter.property === 'BUSINESS_AREA_NAME'; });
    };
    /**
     * If returned from edit task form or create task form
     */
    TaskListComponent.prototype.isReturnFromDetail = function () {
        return this.routingStorageService.getPreviousUrl()
            .includes('tasks/edit') || this.routingStorageService.getPreviousUrl()
            .includes('tasks/create');
    };
    TaskListComponent.ctorParameters = function () { return [
        { type: _shared_services_storage_project_event_service__WEBPACK_IMPORTED_MODULE_16__["ProjectEventService"] },
        { type: _shared_services_storage_selected_area_service__WEBPACK_IMPORTED_MODULE_17__["SelectedAreaService"] },
        { type: _shared_services_data_business_area_service__WEBPACK_IMPORTED_MODULE_12__["BusinessAreaService"] },
        { type: _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormBuilder"] },
        { type: _ngx_translate_core__WEBPACK_IMPORTED_MODULE_4__["TranslateService"] },
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"] },
        { type: _shared_services_data_task_service__WEBPACK_IMPORTED_MODULE_13__["TaskService"] },
        { type: _shared_services_notification_service__WEBPACK_IMPORTED_MODULE_14__["NotificationService"] },
        { type: _shared_services_routing_storage_service__WEBPACK_IMPORTED_MODULE_15__["RoutingStorageService"] },
        { type: _shared_services_table_change_storage_service__WEBPACK_IMPORTED_MODULE_18__["TableChangeStorageService"] },
        { type: _shared_services_auth_service__WEBPACK_IMPORTED_MODULE_11__["AuthService"] }
    ]; };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])('trafficLightColumn', { static: true }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"])
    ], TaskListComponent.prototype, "trafficLightColumn", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])('statusColumn', { static: true }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"])
    ], TaskListComponent.prototype, "statusColumn", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])('updateColumn', { static: true }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"])
    ], TaskListComponent.prototype, "updateColumn", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])('taskTypeColumn', { static: true }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"])
    ], TaskListComponent.prototype, "taskTypeColumn", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])('userColumn', { static: true }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"])
    ], TaskListComponent.prototype, "userColumn", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])('dateColumn', { static: true }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"])
    ], TaskListComponent.prototype, "dateColumn", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])('venueColumn', { static: true }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"])
    ], TaskListComponent.prototype, "venueColumn", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])('taskTable', { static: true }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _shared_hazlenut_core_table__WEBPACK_IMPORTED_MODULE_6__["CoreTableComponent"])
    ], TaskListComponent.prototype, "taskTable", void 0);
    TaskListComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'iihf-task-list',
            template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./task-list.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/tasks/task-list/task-list.component.html")).default,
            animations: [_shared_hazlenut_hazelnut_common_animations__WEBPACK_IMPORTED_MODULE_7__["fadeEnterLeave"]],
            styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./task-list.component.scss */ "./src/app/pages/tasks/task-list/task-list.component.scss")).default]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_shared_services_storage_project_event_service__WEBPACK_IMPORTED_MODULE_16__["ProjectEventService"],
            _shared_services_storage_selected_area_service__WEBPACK_IMPORTED_MODULE_17__["SelectedAreaService"],
            _shared_services_data_business_area_service__WEBPACK_IMPORTED_MODULE_12__["BusinessAreaService"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormBuilder"],
            _ngx_translate_core__WEBPACK_IMPORTED_MODULE_4__["TranslateService"],
            _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"],
            _shared_services_data_task_service__WEBPACK_IMPORTED_MODULE_13__["TaskService"],
            _shared_services_notification_service__WEBPACK_IMPORTED_MODULE_14__["NotificationService"],
            _shared_services_routing_storage_service__WEBPACK_IMPORTED_MODULE_15__["RoutingStorageService"],
            _shared_services_table_change_storage_service__WEBPACK_IMPORTED_MODULE_18__["TableChangeStorageService"],
            _shared_services_auth_service__WEBPACK_IMPORTED_MODULE_11__["AuthService"]])
    ], TaskListComponent);
    return TaskListComponent;
}());



/***/ }),

/***/ "./src/app/pages/tasks/tasks-routing.module.ts":
/*!*****************************************************!*\
  !*** ./src/app/pages/tasks/tasks-routing.module.ts ***!
  \*****************************************************/
/*! exports provided: TasksRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TasksRoutingModule", function() { return TasksRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _task_create_task_create_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./task-create/task-create.component */ "./src/app/pages/tasks/task-create/task-create.component.ts");
/* harmony import */ var _task_edit_task_edit_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./task-edit/task-edit.component */ "./src/app/pages/tasks/task-edit/task-edit.component.ts");
/* harmony import */ var _task_list_task_list_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./task-list/task-list.component */ "./src/app/pages/tasks/task-list/task-list.component.ts");






var routes = [
    {
        path: '',
        children: [
            {
                path: '',
                pathMatch: 'full',
                redirectTo: 'list',
            },
            {
                path: 'list',
                component: _task_list_task_list_component__WEBPACK_IMPORTED_MODULE_5__["TaskListComponent"],
                data: { title: 'taskList' }
            },
            {
                path: 'create',
                component: _task_create_task_create_component__WEBPACK_IMPORTED_MODULE_3__["TaskCreateComponent"],
                data: { title: 'taskCreate' }
            },
            {
                path: 'edit',
                component: _task_edit_task_edit_component__WEBPACK_IMPORTED_MODULE_4__["TaskEditComponent"],
                data: { title: 'taskEdit' }
            }
        ],
    }
];
var TasksRoutingModule = /** @class */ (function () {
    function TasksRoutingModule() {
    }
    TasksRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
            exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
        })
    ], TasksRoutingModule);
    return TasksRoutingModule;
}());



/***/ }),

/***/ "./src/app/pages/tasks/tasks.module.ts":
/*!*********************************************!*\
  !*** ./src/app/pages/tasks/tasks.module.ts ***!
  \*********************************************/
/*! exports provided: TasksModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TasksModule", function() { return TasksModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_flex_layout__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/flex-layout */ "./node_modules/@angular/flex-layout/esm5/flex-layout.es5.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ngx-translate/core */ "./node_modules/@ngx-translate/core/fesm5/ngx-translate-core.js");
/* harmony import */ var _shared_hazlenut_abstract_inputs__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../shared/hazlenut/abstract-inputs */ "./src/app/shared/hazlenut/abstract-inputs/index.ts");
/* harmony import */ var _shared_hazlenut_core_table__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../shared/hazlenut/core-table */ "./src/app/shared/hazlenut/core-table/index.ts");
/* harmony import */ var _shared_hazlenut_hazelnut_common__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../shared/hazlenut/hazelnut-common */ "./src/app/shared/hazlenut/hazelnut-common/index.ts");
/* harmony import */ var _shared_hazlenut_small_components__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../shared/hazlenut/small-components */ "./src/app/shared/hazlenut/small-components/index.ts");
/* harmony import */ var _shared_pipes_pipes_module__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../shared/pipes/pipes.module */ "./src/app/shared/pipes/pipes.module.ts");
/* harmony import */ var _shared_services_translate_wrapper_service__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../shared/services/translate-wrapper.service */ "./src/app/shared/services/translate-wrapper.service.ts");
/* harmony import */ var _task_comment_task_comment_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./task-comment/task-comment.component */ "./src/app/pages/tasks/task-comment/task-comment.component.ts");
/* harmony import */ var _task_create_task_create_component__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./task-create/task-create.component */ "./src/app/pages/tasks/task-create/task-create.component.ts");
/* harmony import */ var _task_edit_task_edit_component__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./task-edit/task-edit.component */ "./src/app/pages/tasks/task-edit/task-edit.component.ts");
/* harmony import */ var _task_form_task_form_component__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ./task-form/task-form.component */ "./src/app/pages/tasks/task-form/task-form.component.ts");
/* harmony import */ var _task_list_task_list_component__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ./task-list/task-list.component */ "./src/app/pages/tasks/task-list/task-list.component.ts");
/* harmony import */ var _tasks_routing_module__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ./tasks-routing.module */ "./src/app/pages/tasks/tasks-routing.module.ts");


















var TasksModule = /** @class */ (function () {
    function TasksModule() {
    }
    TasksModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["NgModule"])({
            declarations: [_task_list_task_list_component__WEBPACK_IMPORTED_MODULE_16__["TaskListComponent"], _task_create_task_create_component__WEBPACK_IMPORTED_MODULE_13__["TaskCreateComponent"], _task_edit_task_edit_component__WEBPACK_IMPORTED_MODULE_14__["TaskEditComponent"], _task_comment_task_comment_component__WEBPACK_IMPORTED_MODULE_12__["TaskCommentComponent"], _task_form_task_form_component__WEBPACK_IMPORTED_MODULE_15__["TaskFormComponent"]],
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"],
                _tasks_routing_module__WEBPACK_IMPORTED_MODULE_17__["TasksRoutingModule"],
                _shared_hazlenut_hazelnut_common__WEBPACK_IMPORTED_MODULE_8__["MaterialModule"],
                _angular_flex_layout__WEBPACK_IMPORTED_MODULE_3__["FlexLayoutModule"],
                _ngx_translate_core__WEBPACK_IMPORTED_MODULE_5__["TranslateModule"].forChild(),
                _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormsModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_4__["ReactiveFormsModule"],
                _shared_hazlenut_core_table__WEBPACK_IMPORTED_MODULE_7__["CoreTableModule"],
                _shared_hazlenut_abstract_inputs__WEBPACK_IMPORTED_MODULE_6__["AbstractInputsModule"],
                _shared_hazlenut_small_components__WEBPACK_IMPORTED_MODULE_9__["SmallComponentsModule"],
                _shared_pipes_pipes_module__WEBPACK_IMPORTED_MODULE_10__["PipesModule"],
            ],
            providers: [_shared_services_translate_wrapper_service__WEBPACK_IMPORTED_MODULE_11__["TranslateWrapperService"]]
        })
    ], TasksModule);
    return TasksModule;
}());



/***/ }),

/***/ "./src/app/shared/services/task-comment.service.ts":
/*!*********************************************************!*\
  !*** ./src/app/shared/services/task-comment.service.ts ***!
  \*********************************************************/
/*! exports provided: TaskCommentService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TaskCommentService", function() { return TaskCommentService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../environments/environment */ "./src/environments/environment.ts");
/* harmony import */ var _notification_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./notification.service */ "./src/app/shared/services/notification.service.ts");
/* harmony import */ var _project_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./project.service */ "./src/app/shared/services/project.service.ts");
/* harmony import */ var _storage_project_user_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./storage/project-user.service */ "./src/app/shared/services/storage/project-user.service.ts");







var TaskCommentService = /** @class */ (function (_super) {
    tslib__WEBPACK_IMPORTED_MODULE_0__["__extends"](TaskCommentService, _super);
    function TaskCommentService(http, notificationService, userService) {
        return _super.call(this, http, 'comment', notificationService, userService) || this;
    }
    /**
     * Add comment object with API call
     * @param taskComment
     */
    TaskCommentService.prototype.addComment = function (taskComment) {
        return this.http.post(_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].URL_API + "/comment", taskComment, { headers: this.getHeader() });
    };
    /**
     * Get comment object from API
     * @param taskId
     */
    TaskCommentService.prototype.getAllComment = function (taskId) {
        return this.http.get(_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].URL_API + "/comment/" + taskId, { headers: this.getHeader() });
    };
    TaskCommentService.ctorParameters = function () { return [
        { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"] },
        { type: _notification_service__WEBPACK_IMPORTED_MODULE_4__["NotificationService"] },
        { type: _storage_project_user_service__WEBPACK_IMPORTED_MODULE_6__["ProjectUserService"] }
    ]; };
    TaskCommentService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Injectable"])({
            providedIn: 'root'
        })
        /**
         * Fact service communicating with 'comment' API url
         */
        ,
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"],
            _notification_service__WEBPACK_IMPORTED_MODULE_4__["NotificationService"],
            _storage_project_user_service__WEBPACK_IMPORTED_MODULE_6__["ProjectUserService"]])
    ], TaskCommentService);
    return TaskCommentService;
}(_project_service__WEBPACK_IMPORTED_MODULE_5__["ProjectService"]));



/***/ })

}]);
//# sourceMappingURL=pages-tasks-tasks-module.js.map