(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-project-project-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/project/project-detail-form/project-detail-form.component.html":
/*!****************************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/project/project-detail-form/project-detail-form.component.html ***!
  \****************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<form [formGroup]=\"projectDetailForm\">\r\n    <div fxLayout=\"row\" fxLayoutGap=\"10px\">\r\n        <div fxFlex=\"100px\" fxLayout=\"column\">\r\n            <div class=\"short-input\">\r\n                <div class=\"relative-parent\">\r\n                    <label *ngIf=\"editMode\"\r\n                           class=\"logo-container-style\"\r\n                           for=\"logo-image\"\r\n                           fxFlex=\"100px\"\r\n                           mat-ripple\r\n                    ></label>\r\n                    <input (change)=\"onLogoInserted($event)\"\r\n                           *ngIf=\"editMode\"\r\n                           accept=\"image/*\"\r\n                           class=\"hide-input\"\r\n                           formControlName=\"logo\"\r\n                           id=\"logo-image\"\r\n                           type=\"file\"\r\n                    >\r\n                    <div [class.logo-content-style-edit]=\"editMode\"\r\n                         class=\"logo-content-style\"\r\n                    >\r\n                        <img [src]=\"imageSrc\"\r\n                             alt=\"project logo\"\r\n                             class=\"project-logo\"\r\n                             height=\"90\"\r\n                        >\r\n                        <div class=\"edit-svg-wrapper\">\r\n                            <img *ngIf=\"editMode\"\r\n                                 [src]=\"'assets/img/svg-squares/edit.svg'\"\r\n                                 alt=\"edit\"\r\n                                 class=\"edit-svg\"\r\n                            >\r\n                        </div>\r\n                    </div>\r\n                </div>\r\n            </div>\r\n        </div>\r\n        <div fxFlex fxLayout=\"column\" fxLayoutGap=\"0\">\r\n            <div class=\"long-input\">\r\n                <haz-core-input [appearance]=\"'fill'\"\r\n                                [label]=\"'project.name' |  translate\"\r\n                                [maxLength]=\"50\"\r\n                                [pattern]=\"notOnlyWhiteCharactersPattern\"\r\n                                [required]=\"true\"\r\n                                class=\"theme-input\"\r\n                                formControlName=\"name\"\r\n                >\r\n                </haz-core-input>\r\n            </div>\r\n            \r\n            <div fxLayout=\"row\" fxLayoutGap=\"10px\">\r\n                <div class=\"short-input\">\r\n                    <haz-core-input [allowedCharactersPattern]=\"numericPattern\"\r\n                                    [appearance]=\"'fill'\"\r\n                                    [label]=\"'project.year' | translate\"\r\n                                    [maxLength]=\"4\"\r\n                                    [pattern]=\"yearPattern\"\r\n                                    [required]=\"true\"\r\n                                    class=\"theme-input\"\r\n                                    formControlName=\"year\"\r\n                    >\r\n                    </haz-core-input>\r\n                </div>\r\n                \r\n                <mat-form-field appearance=\"fill\" class=\" short-input\" required>\r\n                    <mat-label class=\"label-style\">{{ 'project.status' | translate }}</mat-label>\r\n                    <mat-select formControlName=\"status\" required>\r\n                        <mat-option [value]=\"'OPEN'\">{{'status.open' | translate}}</mat-option>\r\n                        <mat-option [value]=\"'CLOSED'\">{{'status.closed' | translate}}</mat-option>\r\n                    </mat-select>\r\n                    <mat-hint *ngIf=\"editMode && !isTouched('status') && isEmpty('status')\">\r\n                        {{'error.required' | translate}}\r\n                    </mat-hint>\r\n                    <mat-error *ngIf=\"editMode && isTouched('status') && hasError('status', 'required')\">\r\n                        {{'error.required' | translate}}\r\n                    </mat-error>\r\n                </mat-form-field>\r\n            </div>\r\n            \r\n            <div fxLayout=\"row\" fxLayoutGap=\"10px\">\r\n                <mat-form-field appearance=\"fill\" class=\"short-input\">\r\n                    <mat-label class=\"label-style\">{{ 'project.dateFrom' | translate }}</mat-label>\r\n                    <input (dateChange)=\"onDateChanged($event.value)\" [matDatepicker]=\"pickerDateFrom\" [max]=\"projectDetailForm.controls.dateTo.value\" formControlName=\"dateFrom\"\r\n                           matInput\r\n                    >\r\n                    <mat-datepicker-toggle [for]=\"pickerDateFrom\" matSuffix></mat-datepicker-toggle>\r\n                    <mat-datepicker #pickerDateFrom [dateClass]=\"dateClass\"></mat-datepicker>\r\n                    <mat-error *ngIf=\"dateInvalid\">{{ 'error.dateFormatIsInvalid' | translate }}</mat-error>\r\n                </mat-form-field>\r\n                <mat-form-field appearance=\"fill\" class=\"short-input\">\r\n                    <mat-label class=\"label-style\">{{ 'project.dateTo' | translate }}</mat-label>\r\n                    <input (dateChange)=\"onDateChanged($event.value)\" [matDatepicker]=\"pickerDateTo\" [min]=\"projectDetailForm.controls.dateFrom.value\" formControlName=\"dateTo\"\r\n                           matInput\r\n                    >\r\n                    <mat-datepicker-toggle [for]=\"pickerDateTo\" matSuffix></mat-datepicker-toggle>\r\n                    <mat-datepicker #pickerDateTo [dateClass]=\"dateClass\"></mat-datepicker>\r\n                    <mat-error *ngIf=\"dateInvalid\">{{ 'error.dateFormatIsInvalid' | translate }}</mat-error>\r\n                </mat-form-field>\r\n            </div>\r\n            <div fxLayout=\"row\" fxLayoutGap=\"10px\">\r\n                \r\n                <mat-form-field appearance=\"fill\" class=\"short-input\">\r\n                    <mat-label class=\"label-style\">{{ 'project.firstCountry' | translate }}</mat-label>\r\n                    <mat-select formControlName=\"firstCountry\">\r\n                        <mat-option [value]=\"null\"></mat-option>\r\n                        <mat-option *ngFor=\"let country of countryList\" [value]=\"country.id\">\r\n                            {{country.name}}\r\n                        </mat-option>\r\n                    </mat-select>\r\n                </mat-form-field>\r\n                \r\n                <mat-form-field appearance=\"fill\" class=\"short-input\">\r\n                    <mat-label class=\"label-style\">{{ 'project.secondCountry' | translate }}</mat-label>\r\n                    <mat-select formControlName=\"secondCountry\">\r\n                        <mat-option [value]=\"null\"></mat-option>\r\n                        <mat-option *ngFor=\"let country of countryList\" [value]=\"country.id\">\r\n                            {{country.name}}\r\n                        </mat-option>\r\n                    </mat-select>\r\n                    <mat-hint *ngIf=\"editMode\r\n                    && projectDetailForm.controls.secondCountry.value\r\n                    && !projectDetailForm.controls.firstCountry.value\"\r\n                              style=\"color:#cf2120\"\r\n                    >\r\n                        {{'error.fillFirstCountry' | translate}}\r\n                    </mat-hint>\r\n                </mat-form-field>\r\n            </div>\r\n            \r\n            <div fxLayout=\"row\" fxLayoutGap=\"10px\">\r\n                <div class=\"short-input\">\r\n                    <mat-error *ngIf=\"editMode\r\n                    && projectDetailForm.controls.firstVenue.value\r\n                    && !projectDetailForm.controls.firstCountry.value\"\r\n                               class=\"error-text\"\r\n                    >\r\n                        {{'error.fillCountry' | translate}}\r\n                    </mat-error>\r\n                    <haz-core-input [appearance]=\"'fill'\"\r\n                                    [label]=\"'project.firstVenue' |  translate\"\r\n                                    [maxLength]=\"50\"\r\n                                    [pattern]=\"notOnlyWhiteCharactersPattern\"\r\n                                    class=\"theme-input\"\r\n                                    formControlName=\"firstVenue\"\r\n                    >\r\n                    </haz-core-input>\r\n                </div>\r\n                <div class=\"short-input\">\r\n                    <mat-error *ngIf=\"editMode\r\n                    && projectDetailForm.controls.secondVenue.value\r\n                    && !projectDetailForm.controls.secondCountry.value\" class=\"error-text\"\r\n                    >\r\n                        {{'error.fillCountry' | translate}}\r\n                    </mat-error>\r\n                    <haz-core-input [appearance]=\"'fill'\"\r\n                                    [label]=\"'project.secondVenue' |  translate\"\r\n                                    [maxLength]=\"50\"\r\n                                    [pattern]=\"notOnlyWhiteCharactersPattern\"\r\n                                    class=\"theme-input\"\r\n                                    formControlName=\"secondVenue\"\r\n                    >\r\n                    </haz-core-input>\r\n                </div>\r\n            </div>\r\n            \r\n            <div fxLayout=\"row\" fxLayoutGap=\"10px\">\r\n                <div class=\"short-input\" fxLayout=\"column\">\r\n                    <mat-error *ngIf=\"editMode\r\n                    && projectDetailForm.controls.firstMapUploadId.value\r\n                    && !projectDetailForm.controls.firstVenue.value\"\r\n                               class=\"error-text\"\r\n                    >\r\n                        {{'error.fillVenue' | translate}}\r\n                    </mat-error>\r\n                    <div *ngIf=\"!editMode && firstMapSrc\">\r\n                        <div class=\"pdf-wrapper\">\r\n                            <div class=\"pdf-indicator\"><span>.pdf</span></div>\r\n                            <pdf-viewer (click)=\"openDialog(firstMapSrc)\"\r\n                                        [@fadeEnterLeave]\r\n                                        [fit-to-page]=\"true\"\r\n                                        [page]=\"1\"\r\n                                        [show-all]=\"false\"\r\n                                        [src]=\"firstMapSrc\"\r\n                                        class=\"pdf-content\"\r\n                            >\r\n                            </pdf-viewer>\r\n                        </div>\r\n                        <div class=\"p-10\" fxLayout=\"row\">\r\n                            <div (click)=\"openDialog(firstMapSrc)\" class=\"map-file\" fxFlex>\r\n                                {{firstMapPdfName}}\r\n                            </div>\r\n                            <div (click)=\"downloadFirst()\"\r\n                                 *ngIf=\"!editMode && firstMapSrc\"\r\n                                 [@enterLeave]\r\n                                 class=\"download\"\r\n                                 fxFlex=\"20px\"\r\n                                 fxLayoutAlign=\"end end\"\r\n                                 mat-ripple\r\n                            >\r\n                                <img\r\n                                    [src]=\"'assets/img/svg-squares/download.svg'\"\r\n                                    alt=\"download\"\r\n                                >\r\n                            </div>\r\n                        </div>\r\n                    \r\n                    </div>\r\n                    <div (onFileDropped)=\"onFirstMapDropped($event)\" *ngIf=\"editMode\"\r\n                         class=\"relative-parent\"\r\n                         dragDrop\r\n                         fxFlex\r\n                    >\r\n                        <label class=\"container-style\"\r\n                               for=\"first-map\"\r\n                               fxFlex=\"205px\"\r\n                               mat-ripple\r\n                        ></label>\r\n                        <input (change)=\"onFirstMapInserted($event)\"\r\n                               accept=\"application/pdf\"\r\n                               class=\"hide-input\"\r\n                               formControlName=\"firstMap\"\r\n                               id=\"first-map\"\r\n                               type=\"file\"\r\n                        >\r\n                        <div class=\"content-style\">\r\n                            <div class=\"relative-parent\" fxLayout=\"column\">\r\n                                <div class=\"pdf-wrapper\">\r\n                                    <pdf-viewer\r\n                                        *ngIf=\"firstMapSrc\"\r\n                                        [@fadeEnterLeave]\r\n                                        [fit-to-page]=\"true\"\r\n                                        [page]=\"1\"\r\n                                        [show-all]=\"false\"\r\n                                        [src]=\"firstMapSrc\"\r\n                                        class=\"pdf-content-bg\"\r\n                                    >\r\n                                    </pdf-viewer>\r\n                                </div>\r\n                                <img *ngIf=\"editMode && firstMapSrc\"\r\n                                     [src]=\"'assets/img/svg-squares/edit.svg'\"\r\n                                     alt=\"edit\"\r\n                                     class=\"edit-svg\"\r\n                                >\r\n                                <img *ngIf=\"editMode && !firstMapSrc\"\r\n                                     [src]=\"'assets/img/svg-squares/add.svg'\"\r\n                                     alt=\"add\"\r\n                                     class=\"add-svg\"\r\n                                >\r\n                                <p *ngIf=\"editMode && !firstMapSrc\"\r\n                                   class=\"drop-text\"\r\n                                >{{'project.drag' | translate}}</p>\r\n                            </div>\r\n                        </div>\r\n                    </div>\r\n                    <div *ngIf=\"editMode\" class=\"p-10\" fxLayout=\"row\">\r\n                        <div *ngIf=\"editMode && firstMapPdfName\" class=\"map-file-edit\" fxFlex>\r\n                            {{firstMapPdfName}}\r\n                        </div>\r\n                        <div (click)=\"resetValue('firstMap')\"\r\n                             *ngIf=\"editMode && firstMapSrc\"\r\n                             [@enterLeave]\r\n                             class=\"remove\"\r\n                             fxFlex=\"20px\"\r\n                             fxLayoutAlign=\"end end\"\r\n                             mat-ripple\r\n                        >\r\n                            <img\r\n                                [src]=\"'assets/img/svg-squares/remove.svg'\"\r\n                                alt=\"remove\"\r\n                            >\r\n                        </div>\r\n                    </div>\r\n                    <div *ngIf=\"!editMode && !firstMapSrc\" class=\"empty-map\" fxLayout=\"column\">\r\n                        <div fxFlex=\"40\" fxLayoutAlign=\"center flex-end\">\r\n                            <img [src]=\"'assets/img/custom-svg/stadium.svg'\"\r\n                                 alt=\"stadium\"\r\n                            >\r\n                        </div>\r\n                        <div fxFlex=\"40\" fxLayoutAlign=\"center center\">\r\n                            <p class=\"text-no-map-added\">{{'project.noMapAdded' | translate}}</p>\r\n                        </div>\r\n                        <div fxFlex fxLayoutAlign=\"center center\">\r\n                            <p class=\"project-to-upload-map\">{{'project.toUploadMap' | translate}}</p>\r\n                        </div>\r\n                    </div>\r\n                </div>\r\n                \r\n                <div class=\"short-input\" fxLayout=\"column\">\r\n                    <mat-error *ngIf=\"editMode\r\n                    && projectDetailForm.controls.secondMapUploadId.value\r\n                    && !projectDetailForm.controls.secondVenue.value\"\r\n                               class=\"error-text\"\r\n                    >\r\n                        {{'error.fillVenue' | translate}}\r\n                    </mat-error>\r\n                    <div *ngIf=\"!editMode && secondMapSrc\">\r\n                        <div class=\"pdf-wrapper\">\r\n                            <div class=\"pdf-indicator\"><span>.pdf</span></div>\r\n                            <pdf-viewer (click)=\"openDialog(secondMapSrc)\"\r\n                                        [@fadeEnterLeave]\r\n                                        [fit-to-page]=\"true\"\r\n                                        [original-size]=\"true\"\r\n                                        [page]=\"1\"\r\n                                        [render-text-mode]=\"0\"\r\n                                        [show-all]=\"false\"\r\n                                        [src]=\"secondMapSrc\"\r\n                                        class=\"pdf-content\"\r\n                            >\r\n                            </pdf-viewer>\r\n                        </div>\r\n                        <div class=\"p-10\" fxLayout=\"row\">\r\n                            <div (click)=\"openDialog(secondMapSrc)\" class=\"map-file\" fxFlex>{{secondMapPdfName}}</div>\r\n                            <div (click)=\"downloadSecond()\"\r\n                                 *ngIf=\"!editMode && secondMapSrc\"\r\n                                 [@enterLeave]\r\n                                 class=\"remove\"\r\n                                 fxFlex=\"20px\"\r\n                                 fxLayoutAlign=\"end end\"\r\n                                 mat-ripple\r\n                            >\r\n                                <img\r\n                                    [src]=\"'assets/img/svg-squares/download.svg'\"\r\n                                    alt=\"remove\"\r\n                                >\r\n                            </div>\r\n                        </div>\r\n                    \r\n                    </div>\r\n                    <div (onFileDropped)=\"onSecondMapDropped($event)\" *ngIf=\"editMode\"\r\n                         class=\"relative-parent\"\r\n                         dragDrop\r\n                         fxFlex\r\n                    >\r\n                        <label class=\"container-style\"\r\n                               for=\"second-map\"\r\n                               fxFlex=\"205px\"\r\n                               mat-ripple\r\n                        ></label>\r\n                        <input (change)=\"onSecondMapInserted($event)\"\r\n                               accept=\"application/pdf\"\r\n                               class=\"hide-input\"\r\n                               formControlName=\"secondMap\"\r\n                               id=\"second-map\"\r\n                               type=\"file\"\r\n                        >\r\n                        <div class=\"content-style\">\r\n                            <div class=\"relative-parent\" fxLayout=\"column\">\r\n                                <div class=\"pdf-wrapper\">\r\n                                    <pdf-viewer\r\n                                        *ngIf=\"secondMapSrc\"\r\n                                        [@fadeEnterLeave]\r\n                                        [fit-to-page]=\"true\"\r\n                                        [original-size]=\"true\"\r\n                                        [page]=\"1\"\r\n                                        [render-text-mode]=\"0\"\r\n                                        [show-all]=\"false\"\r\n                                        [src]=\"secondMapSrc\"\r\n                                        class=\"pdf-content-bg\"\r\n                                    >\r\n                                    </pdf-viewer>\r\n                                </div>\r\n                                <img *ngIf=\"editMode && secondMapSrc\"\r\n                                     [src]=\"'assets/img/svg-squares/edit.svg'\"\r\n                                     alt=\"edit\"\r\n                                     class=\"edit-svg\"\r\n                                >\r\n                                <img *ngIf=\"editMode && !secondMapSrc\"\r\n                                     [src]=\"'assets/img/svg-squares/add.svg'\"\r\n                                     alt=\"add\"\r\n                                     class=\"add-svg\"\r\n                                >\r\n                                <p *ngIf=\"editMode && !secondMapSrc\"\r\n                                   class=\"drop-text\"\r\n                                >{{'project.drag' | translate}}</p>\r\n                            </div>\r\n                        </div>\r\n                    </div>\r\n                    <div *ngIf=\"editMode\" class=\"p-10\" fxLayout=\"row\">\r\n                        <div *ngIf=\"editMode && secondMapPdfName\" class=\"map-file-edit\" fxFlex>\r\n                            {{secondMapPdfName}}\r\n                        </div>\r\n                        <div (click)=\"resetValue('secondMap')\"\r\n                             *ngIf=\"editMode && secondMapSrc\"\r\n                             [@enterLeave]\r\n                             class=\"remove\"\r\n                             fxFlex=\"20px\"\r\n                             fxLayoutAlign=\"end end\"\r\n                             mat-ripple\r\n                        >\r\n                            <img\r\n                                [src]=\"'assets/img/svg-squares/remove.svg'\"\r\n                                alt=\"remove\"\r\n                            >\r\n                        </div>\r\n                    </div>\r\n                    \r\n                    <div *ngIf=\"!editMode && !secondMapSrc\" class=\"empty-map\" fxLayout=\"column\">\r\n                        <div fxFlex=\"40\" fxLayoutAlign=\"center flex-end\">\r\n                            <img [src]=\"'assets/img/custom-svg/stadium.svg'\"\r\n                                 alt=\"stadium\"\r\n                            >\r\n                        </div>\r\n                        <div fxFlex=\"40\" fxLayoutAlign=\"center center\">\r\n                            <p class=\"text-no-map-added\">{{'project.noMapAdded' | translate}}</p>\r\n                        </div>\r\n                        <div fxFlex fxLayoutAlign=\"center center\">\r\n                            <p class=\"project-to-upload-map\">{{'project.toUploadMap' | translate}}</p>\r\n                        </div>\r\n                    </div>\r\n                </div>\r\n            \r\n            </div>\r\n            \r\n            <div class=\"long-input\">\r\n                <haz-core-input [appearance]=\"'fill'\"\r\n                                [label]=\"'project.description' | translate\"\r\n                                [maxLength]=\"500\"\r\n                                [pattern]=\"notOnlyWhiteCharactersPattern\"\r\n                                [type]=\"'textarea'\"\r\n                                class=\"theme-input\"\r\n                                formControlName=\"description\"\r\n                >\r\n                </haz-core-input>\r\n            </div>\r\n        </div>\r\n    </div>\r\n\r\n</form>\r\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/project/project-detail/project-detail.component.html":
/*!******************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/project/project-detail/project-detail.component.html ***!
  \******************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<!--Edit fact form with predefined values based on id from url parameters-->\r\n<div class=\"basic-screen-header\" fxLayout=\"row\">\r\n    <div class=\"pl-50\" fxFlex=\"50\" fxLayoutAlign=\"start center\">\r\n        <h3>{{'project.detailTitle' | translate}}</h3>\r\n    </div>\r\n    <div *ngIf=\"!editMode && hasEditRole()\" class=\"pr-20\" fxFlex fxLayoutAlign=\"end center\">\r\n        <button (click)=\"toggleEditMode()\" color=\"accent\" mat-flat-button>\r\n            {{'project.edit' | translate | uppercase}}\r\n        </button>\r\n    </div>\r\n</div>\r\n\r\n<div fxLayout=\"row\" style=\"overflow: auto;  height: calc(100vh - 160px);\">\r\n    <div class=\"p-30\">\r\n        <project-detail-form\r\n            (formDataChange)=\"formData=$event\"\r\n            [refreshSubject]=\"refreshSubject\"\r\n            [editMode]=\"editMode\"\r\n        >\r\n        </project-detail-form>\r\n        <div *ngIf=\"editMode\" [@enterLeave] class=\"pl-110\">\r\n            <button (click)=\"onSave()\"\r\n                    [disabled]=\"!formData || !canSave\"\r\n                    class=\"mr-10\"\r\n                    color=\"accent\"\r\n                    mat-flat-button\r\n                    type=\"submit\"\r\n            >\r\n                {{ 'tasks.save' | translate }}\r\n            </button>\r\n            <button (click)=\"onCancel()\"\r\n                    class=\"mr-10\"\r\n                    mat-button\r\n                    type=\"button\"\r\n            >\r\n                {{ 'tasks.cancel' | translate }}\r\n            </button>\r\n        </div>\r\n    </div>\r\n</div>\r\n");

/***/ }),

/***/ "./src/app/pages/project/project-detail-form/project-detail-form.component.scss":
/*!**************************************************************************************!*\
  !*** ./src/app/pages/project/project-detail-form/project-detail-form.component.scss ***!
  \**************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".hide-input {\n  width: 100px;\n  height: 100px;\n  opacity: 0;\n  position: absolute;\n  z-index: -1;\n}\n\n.container-style {\n  height: 100px;\n  z-index: 1;\n  cursor: pointer;\n  border-radius: 5px;\n  border: 1px dashed #87c8e7;\n}\n\n.content-style {\n  position: absolute;\n  pointer-events: none;\n  z-index: 0;\n  width: 200px;\n  display: grid;\n  align-items: center;\n  justify-items: center;\n}\n\n.content-style p {\n  font-family: Roboto, sans-serif;\n  color: #87c8e7 !important;\n}\n\n.logo-container-style {\n  height: 110px;\n  z-index: 1;\n  cursor: pointer;\n}\n\n.logo-content-style {\n  position: absolute;\n  pointer-events: none;\n  z-index: 0;\n  width: 100px !important;\n  display: grid;\n  border-radius: 5px;\n  padding-top: 10px;\n}\n\n.logo-content-style .project-logo {\n  margin: auto;\n  max-width: 80px;\n  max-height: 100px;\n  -o-object-fit: cover;\n     object-fit: cover;\n}\n\n.logo-content-style .edit-svg-wrapper {\n  display: flex;\n  justify-content: flex-end;\n}\n\n.logo-content-style-edit {\n  background: #e8f0fe;\n  height: 100px;\n}\n\n.relative-parent {\n  position: relative;\n}\n\n.remove {\n  cursor: pointer;\n}\n\n.map-file {\n  text-overflow: ellipsis;\n  overflow: hidden;\n  white-space: nowrap;\n  width: 180px;\n  font-family: Roboto, sans-serif;\n  font-size: 14px;\n  color: #002d62;\n  cursor: pointer;\n  text-decoration: underline;\n}\n\n.map-file-edit {\n  text-overflow: ellipsis;\n  overflow: hidden;\n  white-space: nowrap;\n  width: 180px;\n  font-family: Roboto, sans-serif;\n  font-size: 14px;\n  color: #002d62;\n}\n\n.pdf-content {\n  display: block;\n  cursor: pointer;\n}\n\n.pdf-content-bg {\n  display: block;\n}\n\n.pdf-wrapper {\n  width: 205px;\n  height: 100px;\n  border-radius: 5px;\n  overflow: hidden;\n  position: relative;\n}\n\n.add-svg {\n  position: absolute;\n  left: 45%;\n  top: 30%;\n}\n\n.drop-text {\n  position: absolute;\n  bottom: 10px;\n  left: 15px;\n}\n\n.edit-svg {\n  position: absolute;\n  right: 0;\n  bottom: 0;\n}\n\n::ng-deep .mat-primary .mat-pseudo-checkbox-checked {\n  background: #848484;\n}\n\n::ng-deep .mat-form-field .mat-form-field-flex {\n  background-color: #e8f0fe;\n  border-top-left-radius: 5px;\n  border-top-right-radius: 5px;\n}\n\n.label-style {\n  font-family: \"Roboto\", sans-serif;\n  font-weight: 500;\n  font-size: 16px;\n}\n\n.pdf-indicator {\n  position: absolute;\n  left: 0;\n  top: 0;\n  font-family: Roboto, sans-serif;\n  font-size: 12px;\n  z-index: 3;\n  background: #001c46;\n  color: white;\n  padding: 5px 10px;\n  border-bottom-right-radius: 5px;\n}\n\n.error-text {\n  position: absolute;\n  font-family: Roboto, sans-serif;\n  font-size: 12px;\n  bottom: 0;\n}\n\n.empty-map {\n  width: 205px;\n  height: 100px;\n  border-radius: 5px;\n  position: relative;\n  background: #f5f5f5;\n  margin-bottom: 20px;\n}\n\n.text-no-map-added {\n  font-family: Roboto, sans-serif;\n  font-size: 12px;\n  color: #525252;\n  width: 140px;\n  margin: 20px 5px 0 5px;\n}\n\n.project-to-upload-map {\n  font-family: Roboto, sans-serif;\n  font-size: 9px;\n  color: #525252;\n  margin: 3px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvcHJvamVjdC9wcm9qZWN0LWRldGFpbC1mb3JtL0Q6XFxwcm9qZWN0c1xcaWloZlxcd2ZtLXdlYi9zcmNcXGFwcFxccGFnZXNcXHByb2plY3RcXHByb2plY3QtZGV0YWlsLWZvcm1cXHByb2plY3QtZGV0YWlsLWZvcm0uY29tcG9uZW50LnNjc3MiLCJzcmMvYXBwL3BhZ2VzL3Byb2plY3QvcHJvamVjdC1kZXRhaWwtZm9ybS9wcm9qZWN0LWRldGFpbC1mb3JtLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUVBO0VBQ0ksWUFBQTtFQUNBLGFBQUE7RUFDQSxVQUFBO0VBQ0Esa0JBQUE7RUFDQSxXQUFBO0FDREo7O0FESUE7RUFDSSxhQUFBO0VBQ0EsVUFBQTtFQUNBLGVBQUE7RUFDQSxrQkFBQTtFQUNBLDBCQUFBO0FDREo7O0FESUE7RUFDSSxrQkFBQTtFQUNBLG9CQUFBO0VBQ0EsVUFBQTtFQUNBLFlBQUE7RUFDQSxhQUFBO0VBQ0EsbUJBQUE7RUFDQSxxQkFBQTtBQ0RKOztBREdJO0VBQ0ksK0JBQUE7RUFDQSx5QkFBQTtBQ0RSOztBRE1BO0VBQ0ksYUFBQTtFQUNBLFVBQUE7RUFDQSxlQUFBO0FDSEo7O0FETUE7RUFDSSxrQkFBQTtFQUNBLG9CQUFBO0VBQ0EsVUFBQTtFQUNBLHVCQUFBO0VBQ0EsYUFBQTtFQUNBLGtCQUFBO0VBQ0EsaUJBQUE7QUNISjs7QURLSTtFQUNJLFlBQUE7RUFDQSxlQUFBO0VBQ0EsaUJBQUE7RUFDQSxvQkFBQTtLQUFBLGlCQUFBO0FDSFI7O0FETUk7RUFDSSxhQUFBO0VBQ0EseUJBQUE7QUNKUjs7QURRQTtFQUNJLG1CQUFBO0VBQ0EsYUFBQTtBQ0xKOztBRFFBO0VBQ0ksa0JBQUE7QUNMSjs7QURRQTtFQUNJLGVBQUE7QUNMSjs7QURRQTtFQUNJLHVCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxtQkFBQTtFQUNBLFlBQUE7RUFDQSwrQkFBQTtFQUNBLGVBQUE7RUFDQSxjQWxGYztFQW1GZCxlQUFBO0VBQ0EsMEJBQUE7QUNMSjs7QURRQTtFQUNJLHVCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxtQkFBQTtFQUNBLFlBQUE7RUFDQSwrQkFBQTtFQUNBLGVBQUE7RUFDQSxjQTlGYztBQ3lGbEI7O0FEUUE7RUFDSSxjQUFBO0VBQ0EsZUFBQTtBQ0xKOztBRFFBO0VBQ0ksY0FBQTtBQ0xKOztBRFFBO0VBQ0ksWUFBQTtFQUNBLGFBQUE7RUFDQSxrQkFBQTtFQUNBLGdCQUFBO0VBQ0Esa0JBQUE7QUNMSjs7QURRQTtFQUNJLGtCQUFBO0VBQ0EsU0FBQTtFQUNBLFFBQUE7QUNMSjs7QURRQTtFQUNJLGtCQUFBO0VBQ0EsWUFBQTtFQUNBLFVBQUE7QUNMSjs7QURRQTtFQUNJLGtCQUFBO0VBQ0EsUUFBQTtFQUNBLFNBQUE7QUNMSjs7QURRQTtFQUNJLG1CQUFBO0FDTEo7O0FEU0k7RUFDSSx5QkFBQTtFQUNBLDJCQUFBO0VBQ0EsNEJBQUE7QUNOUjs7QURVQTtFQUNJLGlDQUFBO0VBQ0EsZ0JBQUE7RUFDQSxlQUFBO0FDUEo7O0FEVUE7RUFDSSxrQkFBQTtFQUNBLE9BQUE7RUFDQSxNQUFBO0VBQ0EsK0JBQUE7RUFDQSxlQUFBO0VBQ0EsVUFBQTtFQUNBLG1CQUFBO0VBQ0EsWUFBQTtFQUNBLGlCQUFBO0VBQ0EsK0JBQUE7QUNQSjs7QURVQTtFQUNJLGtCQUFBO0VBQ0EsK0JBQUE7RUFDQSxlQUFBO0VBQ0EsU0FBQTtBQ1BKOztBRFVBO0VBQ0ksWUFBQTtFQUNBLGFBQUE7RUFDQSxrQkFBQTtFQUNBLGtCQUFBO0VBQ0EsbUJBQUE7RUFDQSxtQkFBQTtBQ1BKOztBRFVBO0VBQ0ksK0JBQUE7RUFDQSxlQUFBO0VBQ0EsY0FBQTtFQUNBLFlBQUE7RUFDQSxzQkFBQTtBQ1BKOztBRFVBO0VBQ0ksK0JBQUE7RUFDQSxjQUFBO0VBQ0EsY0FBQTtFQUNBLFdBQUE7QUNQSiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL3Byb2plY3QvcHJvamVjdC1kZXRhaWwtZm9ybS9wcm9qZWN0LWRldGFpbC1mb3JtLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiJGNvbG9yLXNlY29uZGFyeTogIzAwMmQ2MjtcclxuXHJcbi5oaWRlLWlucHV0IHtcclxuICAgIHdpZHRoOiAxMDBweDtcclxuICAgIGhlaWdodDogMTAwcHg7XHJcbiAgICBvcGFjaXR5OiAwO1xyXG4gICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgei1pbmRleDogLTE7XHJcbn1cclxuXHJcbi5jb250YWluZXItc3R5bGUge1xyXG4gICAgaGVpZ2h0OiAxMDBweDtcclxuICAgIHotaW5kZXg6IDE7XHJcbiAgICBjdXJzb3I6IHBvaW50ZXI7XHJcbiAgICBib3JkZXItcmFkaXVzOiA1cHg7XHJcbiAgICBib3JkZXI6IDFweCBkYXNoZWQgIzg3YzhlNztcclxufVxyXG5cclxuLmNvbnRlbnQtc3R5bGUge1xyXG4gICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgcG9pbnRlci1ldmVudHM6IG5vbmU7XHJcbiAgICB6LWluZGV4OiAwO1xyXG4gICAgd2lkdGg6IDIwMHB4O1xyXG4gICAgZGlzcGxheTogZ3JpZDtcclxuICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgICBqdXN0aWZ5LWl0ZW1zOiBjZW50ZXI7XHJcblxyXG4gICAgcCB7XHJcbiAgICAgICAgZm9udC1mYW1pbHk6IFJvYm90bywgc2Fucy1zZXJpZjtcclxuICAgICAgICBjb2xvcjogIzg3YzhlNyAhaW1wb3J0YW50O1xyXG4gICAgfVxyXG5cclxufVxyXG5cclxuLmxvZ28tY29udGFpbmVyLXN0eWxlIHtcclxuICAgIGhlaWdodDogMTEwcHg7XHJcbiAgICB6LWluZGV4OiAxO1xyXG4gICAgY3Vyc29yOiBwb2ludGVyO1xyXG59XHJcblxyXG4ubG9nby1jb250ZW50LXN0eWxlIHtcclxuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAgIHBvaW50ZXItZXZlbnRzOiBub25lO1xyXG4gICAgei1pbmRleDogMDtcclxuICAgIHdpZHRoOiAxMDBweCAhaW1wb3J0YW50O1xyXG4gICAgZGlzcGxheTogZ3JpZDtcclxuICAgIGJvcmRlci1yYWRpdXM6IDVweDtcclxuICAgIHBhZGRpbmctdG9wOiAxMHB4O1xyXG5cclxuICAgIC5wcm9qZWN0LWxvZ28ge1xyXG4gICAgICAgIG1hcmdpbjogYXV0bztcclxuICAgICAgICBtYXgtd2lkdGg6IDgwcHg7XHJcbiAgICAgICAgbWF4LWhlaWdodDogMTAwcHg7XHJcbiAgICAgICAgb2JqZWN0LWZpdDogY292ZXI7XHJcbiAgICB9XHJcblxyXG4gICAgLmVkaXQtc3ZnLXdyYXBwZXIge1xyXG4gICAgICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICAgICAganVzdGlmeS1jb250ZW50OiBmbGV4LWVuZDtcclxuICAgIH1cclxufVxyXG5cclxuLmxvZ28tY29udGVudC1zdHlsZS1lZGl0IHtcclxuICAgIGJhY2tncm91bmQ6ICNlOGYwZmU7XHJcbiAgICBoZWlnaHQ6IDEwMHB4O1xyXG59XHJcblxyXG4ucmVsYXRpdmUtcGFyZW50IHtcclxuICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxufVxyXG5cclxuLnJlbW92ZSB7XHJcbiAgICBjdXJzb3I6IHBvaW50ZXI7XHJcbn1cclxuXHJcbi5tYXAtZmlsZSB7XHJcbiAgICB0ZXh0LW92ZXJmbG93OiBlbGxpcHNpcztcclxuICAgIG92ZXJmbG93OiBoaWRkZW47XHJcbiAgICB3aGl0ZS1zcGFjZTogbm93cmFwO1xyXG4gICAgd2lkdGg6IDE4MHB4O1xyXG4gICAgZm9udC1mYW1pbHk6IFJvYm90bywgc2Fucy1zZXJpZjtcclxuICAgIGZvbnQtc2l6ZTogMTRweDtcclxuICAgIGNvbG9yOiAkY29sb3Itc2Vjb25kYXJ5O1xyXG4gICAgY3Vyc29yOiBwb2ludGVyO1xyXG4gICAgdGV4dC1kZWNvcmF0aW9uOiB1bmRlcmxpbmU7XHJcbn1cclxuXHJcbi5tYXAtZmlsZS1lZGl0IHtcclxuICAgIHRleHQtb3ZlcmZsb3c6IGVsbGlwc2lzO1xyXG4gICAgb3ZlcmZsb3c6IGhpZGRlbjtcclxuICAgIHdoaXRlLXNwYWNlOiBub3dyYXA7XHJcbiAgICB3aWR0aDogMTgwcHg7XHJcbiAgICBmb250LWZhbWlseTogUm9ib3RvLCBzYW5zLXNlcmlmO1xyXG4gICAgZm9udC1zaXplOiAxNHB4O1xyXG4gICAgY29sb3I6ICRjb2xvci1zZWNvbmRhcnk7XHJcbn1cclxuXHJcbi5wZGYtY29udGVudCB7XHJcbiAgICBkaXNwbGF5OiBibG9jaztcclxuICAgIGN1cnNvcjogcG9pbnRlcjtcclxufVxyXG5cclxuLnBkZi1jb250ZW50LWJnIHtcclxuICAgIGRpc3BsYXk6IGJsb2NrO1xyXG59XHJcblxyXG4ucGRmLXdyYXBwZXIge1xyXG4gICAgd2lkdGg6IDIwNXB4O1xyXG4gICAgaGVpZ2h0OiAxMDBweDtcclxuICAgIGJvcmRlci1yYWRpdXM6IDVweDtcclxuICAgIG92ZXJmbG93OiBoaWRkZW47XHJcbiAgICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbn1cclxuXHJcbi5hZGQtc3ZnIHtcclxuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAgIGxlZnQ6IDQ1JTtcclxuICAgIHRvcDogMzAlXHJcbn1cclxuXHJcbi5kcm9wLXRleHQge1xyXG4gICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgYm90dG9tOiAxMHB4O1xyXG4gICAgbGVmdDogMTVweDtcclxufVxyXG5cclxuLmVkaXQtc3ZnIHtcclxuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAgIHJpZ2h0OiAwO1xyXG4gICAgYm90dG9tOiAwO1xyXG59XHJcblxyXG46Om5nLWRlZXAgLm1hdC1wcmltYXJ5IC5tYXQtcHNldWRvLWNoZWNrYm94LWNoZWNrZWQge1xyXG4gICAgYmFja2dyb3VuZDogIzg0ODQ4NDtcclxufVxyXG5cclxuOjpuZy1kZWVwIHtcclxuICAgIC5tYXQtZm9ybS1maWVsZCAubWF0LWZvcm0tZmllbGQtZmxleCB7XHJcbiAgICAgICAgYmFja2dyb3VuZC1jb2xvcjogI2U4ZjBmZTtcclxuICAgICAgICBib3JkZXItdG9wLWxlZnQtcmFkaXVzOiA1cHg7XHJcbiAgICAgICAgYm9yZGVyLXRvcC1yaWdodC1yYWRpdXM6IDVweDtcclxuICAgIH1cclxufVxyXG5cclxuLmxhYmVsLXN0eWxlIHtcclxuICAgIGZvbnQtZmFtaWx5OiAnUm9ib3RvJywgc2Fucy1zZXJpZjtcclxuICAgIGZvbnQtd2VpZ2h0OiA1MDA7XHJcbiAgICBmb250LXNpemU6IDE2cHg7XHJcbn1cclxuXHJcbi5wZGYtaW5kaWNhdG9yIHtcclxuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAgIGxlZnQ6IDA7XHJcbiAgICB0b3A6IDA7XHJcbiAgICBmb250LWZhbWlseTogUm9ib3RvLCBzYW5zLXNlcmlmO1xyXG4gICAgZm9udC1zaXplOiAxMnB4O1xyXG4gICAgei1pbmRleDogMztcclxuICAgIGJhY2tncm91bmQ6ICMwMDFjNDY7XHJcbiAgICBjb2xvcjogd2hpdGU7XHJcbiAgICBwYWRkaW5nOiA1cHggMTBweDtcclxuICAgIGJvcmRlci1ib3R0b20tcmlnaHQtcmFkaXVzOiA1cHg7XHJcbn1cclxuXHJcbi5lcnJvci10ZXh0IHtcclxuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAgIGZvbnQtZmFtaWx5OiBSb2JvdG8sIHNhbnMtc2VyaWY7XHJcbiAgICBmb250LXNpemU6IDEycHg7XHJcbiAgICBib3R0b206IDA7XHJcbn1cclxuXHJcbi5lbXB0eS1tYXAge1xyXG4gICAgd2lkdGg6IDIwNXB4O1xyXG4gICAgaGVpZ2h0OiAxMDBweDtcclxuICAgIGJvcmRlci1yYWRpdXM6IDVweDtcclxuICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICAgIGJhY2tncm91bmQ6ICNmNWY1ZjU7XHJcbiAgICBtYXJnaW4tYm90dG9tOiAyMHB4O1xyXG59XHJcblxyXG4udGV4dC1uby1tYXAtYWRkZWQge1xyXG4gICAgZm9udC1mYW1pbHk6IFJvYm90bywgc2Fucy1zZXJpZjtcclxuICAgIGZvbnQtc2l6ZTogMTJweDtcclxuICAgIGNvbG9yOiAjNTI1MjUyO1xyXG4gICAgd2lkdGg6IDE0MHB4O1xyXG4gICAgbWFyZ2luOiAyMHB4IDVweCAwIDVweFxyXG59XHJcblxyXG4ucHJvamVjdC10by11cGxvYWQtbWFwIHtcclxuICAgIGZvbnQtZmFtaWx5OiBSb2JvdG8sIHNhbnMtc2VyaWY7XHJcbiAgICBmb250LXNpemU6IDlweDtcclxuICAgIGNvbG9yOiAjNTI1MjUyO1xyXG4gICAgbWFyZ2luOiAzcHhcclxufVxyXG4iLCIuaGlkZS1pbnB1dCB7XG4gIHdpZHRoOiAxMDBweDtcbiAgaGVpZ2h0OiAxMDBweDtcbiAgb3BhY2l0eTogMDtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICB6LWluZGV4OiAtMTtcbn1cblxuLmNvbnRhaW5lci1zdHlsZSB7XG4gIGhlaWdodDogMTAwcHg7XG4gIHotaW5kZXg6IDE7XG4gIGN1cnNvcjogcG9pbnRlcjtcbiAgYm9yZGVyLXJhZGl1czogNXB4O1xuICBib3JkZXI6IDFweCBkYXNoZWQgIzg3YzhlNztcbn1cblxuLmNvbnRlbnQtc3R5bGUge1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIHBvaW50ZXItZXZlbnRzOiBub25lO1xuICB6LWluZGV4OiAwO1xuICB3aWR0aDogMjAwcHg7XG4gIGRpc3BsYXk6IGdyaWQ7XG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gIGp1c3RpZnktaXRlbXM6IGNlbnRlcjtcbn1cbi5jb250ZW50LXN0eWxlIHAge1xuICBmb250LWZhbWlseTogUm9ib3RvLCBzYW5zLXNlcmlmO1xuICBjb2xvcjogIzg3YzhlNyAhaW1wb3J0YW50O1xufVxuXG4ubG9nby1jb250YWluZXItc3R5bGUge1xuICBoZWlnaHQ6IDExMHB4O1xuICB6LWluZGV4OiAxO1xuICBjdXJzb3I6IHBvaW50ZXI7XG59XG5cbi5sb2dvLWNvbnRlbnQtc3R5bGUge1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIHBvaW50ZXItZXZlbnRzOiBub25lO1xuICB6LWluZGV4OiAwO1xuICB3aWR0aDogMTAwcHggIWltcG9ydGFudDtcbiAgZGlzcGxheTogZ3JpZDtcbiAgYm9yZGVyLXJhZGl1czogNXB4O1xuICBwYWRkaW5nLXRvcDogMTBweDtcbn1cbi5sb2dvLWNvbnRlbnQtc3R5bGUgLnByb2plY3QtbG9nbyB7XG4gIG1hcmdpbjogYXV0bztcbiAgbWF4LXdpZHRoOiA4MHB4O1xuICBtYXgtaGVpZ2h0OiAxMDBweDtcbiAgb2JqZWN0LWZpdDogY292ZXI7XG59XG4ubG9nby1jb250ZW50LXN0eWxlIC5lZGl0LXN2Zy13cmFwcGVyIHtcbiAgZGlzcGxheTogZmxleDtcbiAganVzdGlmeS1jb250ZW50OiBmbGV4LWVuZDtcbn1cblxuLmxvZ28tY29udGVudC1zdHlsZS1lZGl0IHtcbiAgYmFja2dyb3VuZDogI2U4ZjBmZTtcbiAgaGVpZ2h0OiAxMDBweDtcbn1cblxuLnJlbGF0aXZlLXBhcmVudCB7XG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcbn1cblxuLnJlbW92ZSB7XG4gIGN1cnNvcjogcG9pbnRlcjtcbn1cblxuLm1hcC1maWxlIHtcbiAgdGV4dC1vdmVyZmxvdzogZWxsaXBzaXM7XG4gIG92ZXJmbG93OiBoaWRkZW47XG4gIHdoaXRlLXNwYWNlOiBub3dyYXA7XG4gIHdpZHRoOiAxODBweDtcbiAgZm9udC1mYW1pbHk6IFJvYm90bywgc2Fucy1zZXJpZjtcbiAgZm9udC1zaXplOiAxNHB4O1xuICBjb2xvcjogIzAwMmQ2MjtcbiAgY3Vyc29yOiBwb2ludGVyO1xuICB0ZXh0LWRlY29yYXRpb246IHVuZGVybGluZTtcbn1cblxuLm1hcC1maWxlLWVkaXQge1xuICB0ZXh0LW92ZXJmbG93OiBlbGxpcHNpcztcbiAgb3ZlcmZsb3c6IGhpZGRlbjtcbiAgd2hpdGUtc3BhY2U6IG5vd3JhcDtcbiAgd2lkdGg6IDE4MHB4O1xuICBmb250LWZhbWlseTogUm9ib3RvLCBzYW5zLXNlcmlmO1xuICBmb250LXNpemU6IDE0cHg7XG4gIGNvbG9yOiAjMDAyZDYyO1xufVxuXG4ucGRmLWNvbnRlbnQge1xuICBkaXNwbGF5OiBibG9jaztcbiAgY3Vyc29yOiBwb2ludGVyO1xufVxuXG4ucGRmLWNvbnRlbnQtYmcge1xuICBkaXNwbGF5OiBibG9jaztcbn1cblxuLnBkZi13cmFwcGVyIHtcbiAgd2lkdGg6IDIwNXB4O1xuICBoZWlnaHQ6IDEwMHB4O1xuICBib3JkZXItcmFkaXVzOiA1cHg7XG4gIG92ZXJmbG93OiBoaWRkZW47XG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcbn1cblxuLmFkZC1zdmcge1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIGxlZnQ6IDQ1JTtcbiAgdG9wOiAzMCU7XG59XG5cbi5kcm9wLXRleHQge1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIGJvdHRvbTogMTBweDtcbiAgbGVmdDogMTVweDtcbn1cblxuLmVkaXQtc3ZnIHtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICByaWdodDogMDtcbiAgYm90dG9tOiAwO1xufVxuXG46Om5nLWRlZXAgLm1hdC1wcmltYXJ5IC5tYXQtcHNldWRvLWNoZWNrYm94LWNoZWNrZWQge1xuICBiYWNrZ3JvdW5kOiAjODQ4NDg0O1xufVxuXG46Om5nLWRlZXAgLm1hdC1mb3JtLWZpZWxkIC5tYXQtZm9ybS1maWVsZC1mbGV4IHtcbiAgYmFja2dyb3VuZC1jb2xvcjogI2U4ZjBmZTtcbiAgYm9yZGVyLXRvcC1sZWZ0LXJhZGl1czogNXB4O1xuICBib3JkZXItdG9wLXJpZ2h0LXJhZGl1czogNXB4O1xufVxuXG4ubGFiZWwtc3R5bGUge1xuICBmb250LWZhbWlseTogXCJSb2JvdG9cIiwgc2Fucy1zZXJpZjtcbiAgZm9udC13ZWlnaHQ6IDUwMDtcbiAgZm9udC1zaXplOiAxNnB4O1xufVxuXG4ucGRmLWluZGljYXRvciB7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgbGVmdDogMDtcbiAgdG9wOiAwO1xuICBmb250LWZhbWlseTogUm9ib3RvLCBzYW5zLXNlcmlmO1xuICBmb250LXNpemU6IDEycHg7XG4gIHotaW5kZXg6IDM7XG4gIGJhY2tncm91bmQ6ICMwMDFjNDY7XG4gIGNvbG9yOiB3aGl0ZTtcbiAgcGFkZGluZzogNXB4IDEwcHg7XG4gIGJvcmRlci1ib3R0b20tcmlnaHQtcmFkaXVzOiA1cHg7XG59XG5cbi5lcnJvci10ZXh0IHtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICBmb250LWZhbWlseTogUm9ib3RvLCBzYW5zLXNlcmlmO1xuICBmb250LXNpemU6IDEycHg7XG4gIGJvdHRvbTogMDtcbn1cblxuLmVtcHR5LW1hcCB7XG4gIHdpZHRoOiAyMDVweDtcbiAgaGVpZ2h0OiAxMDBweDtcbiAgYm9yZGVyLXJhZGl1czogNXB4O1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gIGJhY2tncm91bmQ6ICNmNWY1ZjU7XG4gIG1hcmdpbi1ib3R0b206IDIwcHg7XG59XG5cbi50ZXh0LW5vLW1hcC1hZGRlZCB7XG4gIGZvbnQtZmFtaWx5OiBSb2JvdG8sIHNhbnMtc2VyaWY7XG4gIGZvbnQtc2l6ZTogMTJweDtcbiAgY29sb3I6ICM1MjUyNTI7XG4gIHdpZHRoOiAxNDBweDtcbiAgbWFyZ2luOiAyMHB4IDVweCAwIDVweDtcbn1cblxuLnByb2plY3QtdG8tdXBsb2FkLW1hcCB7XG4gIGZvbnQtZmFtaWx5OiBSb2JvdG8sIHNhbnMtc2VyaWY7XG4gIGZvbnQtc2l6ZTogOXB4O1xuICBjb2xvcjogIzUyNTI1MjtcbiAgbWFyZ2luOiAzcHg7XG59Il19 */");

/***/ }),

/***/ "./src/app/pages/project/project-detail-form/project-detail-form.component.ts":
/*!************************************************************************************!*\
  !*** ./src/app/pages/project/project-detail-form/project-detail-form.component.ts ***!
  \************************************************************************************/
/*! exports provided: PROJECT_DATE_FORMATS, ProjectDetailFormComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PROJECT_DATE_FORMATS", function() { return PROJECT_DATE_FORMATS; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProjectDetailFormComponent", function() { return ProjectDetailFormComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_material_moment_adapter__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/material-moment-adapter */ "./node_modules/@angular/material-moment-adapter/esm5/material-moment-adapter.es5.js");
/* harmony import */ var _angular_material_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/material/core */ "./node_modules/@angular/material/esm5/core.es5.js");
/* harmony import */ var _angular_material_dialog__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/material/dialog */ "./node_modules/@angular/material/esm5/dialog.es5.js");
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/platform-browser */ "./node_modules/@angular/platform-browser/fesm5/platform-browser.js");
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! moment */ "./node_modules/moment/moment.js");
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm5/index.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm5/operators/index.js");
/* harmony import */ var _shared_components_dialog_pdf_dialog_pdf_dialog_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../../shared/components/dialog/pdf-dialog/pdf-dialog.component */ "./src/app/shared/components/dialog/pdf-dialog/pdf-dialog.component.ts");
/* harmony import */ var _shared_hazlenut_hazelnut_common_animations__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../../shared/hazlenut/hazelnut-common/animations */ "./src/app/shared/hazlenut/hazelnut-common/animations/index.ts");
/* harmony import */ var _shared_hazlenut_hazelnut_common_regex_regex__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../../../shared/hazlenut/hazelnut-common/regex/regex */ "./src/app/shared/hazlenut/hazelnut-common/regex/regex.ts");
/* harmony import */ var _shared_services_data_attachment_service__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../../../shared/services/data/attachment.service */ "./src/app/shared/services/data/attachment.service.ts");
/* harmony import */ var _shared_services_data_business_area_service__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ../../../shared/services/data/business-area.service */ "./src/app/shared/services/data/business-area.service.ts");
/* harmony import */ var _shared_services_data_images_service__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ../../../shared/services/data/images.service */ "./src/app/shared/services/data/images.service.ts");
/* harmony import */ var _shared_services_data_projects_service__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ../../../shared/services/data/projects.service */ "./src/app/shared/services/data/projects.service.ts");
/* harmony import */ var _shared_services_notification_service__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ../../../shared/services/notification.service */ "./src/app/shared/services/notification.service.ts");
/* harmony import */ var _shared_services_storage_project_event_service__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ../../../shared/services/storage/project-event.service */ "./src/app/shared/services/storage/project-event.service.ts");
/* harmony import */ var _shared_utils_blob_manager__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ../../../shared/utils/blob-manager */ "./src/app/shared/utils/blob-manager.ts");




















var moment = moment__WEBPACK_IMPORTED_MODULE_7__;
var PROJECT_DATE_FORMATS = {
    parse: {
        dateInput: 'D.M.YYYY',
    },
    display: {
        dateInput: 'D.M.YYYY',
        monthYearLabel: 'D.M.YYYY',
        dateA11yLabel: 'D.M.YYYY',
        monthYearA11yLabel: 'D.M.YYYY',
    },
};
var ProjectDetailFormComponent = /** @class */ (function () {
    function ProjectDetailFormComponent(formBuilder, domSanitizer, businessAreaService, notificationService, projectsService, imagesService, attachmentService, matDialog, projectEventService) {
        this.formBuilder = formBuilder;
        this.domSanitizer = domSanitizer;
        this.businessAreaService = businessAreaService;
        this.notificationService = notificationService;
        this.projectsService = projectsService;
        this.imagesService = imagesService;
        this.attachmentService = attachmentService;
        this.matDialog = matDialog;
        this.projectEventService = projectEventService;
        this.onFormDataChange = new _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"]();
        this.defaultLogoPath = 'assets/img/iihf-logo-without-text-transparent.png';
        this.yearPattern = _shared_hazlenut_hazelnut_common_regex_regex__WEBPACK_IMPORTED_MODULE_12__["Regex"].yearPattern;
        this.numericPattern = _shared_hazlenut_hazelnut_common_regex_regex__WEBPACK_IMPORTED_MODULE_12__["Regex"].numericPattern;
        this.dateInvalid = false;
        this.firstMapSrc = '';
        this.secondMapSrc = '';
        this.imageSrc = this.defaultLogoPath;
        this.dateInvalidClosed = false;
        this.countryList = [];
        this.countriesLoading = false;
        this.notOnlyWhiteCharactersPattern = _shared_hazlenut_hazelnut_common_regex_regex__WEBPACK_IMPORTED_MODULE_12__["Regex"].notOnlyWhiteCharactersPattern;
        this.dateClass = function (d) {
            var day = moment(d)
                .toDate()
                .getDay();
            return (day === 0 || day === 6) ? 'custom-date-class' : undefined;
        };
    }
    ProjectDetailFormComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.initializeForm();
        this.loadCountries();
        this.refreshSubject.subscribe(function (event) {
            _this.loadProjectDetail();
        });
        this.loadProjectDetail();
        this.projectDetailForm.disable();
        this.projectDetailForm.valueChanges.subscribe(function () {
            _this.emitFormDataChangeEmitter();
        });
    };
    ProjectDetailFormComponent.prototype.ngOnChanges = function (changes) {
        if (!this.projectDetailForm) {
            return;
        }
        var editMode = changes.editMode;
        if (!editMode.currentValue) {
            this.projectDetailForm.disable();
        }
        else {
            this.projectDetailForm.enable();
            this.projectDetailForm.markAsUntouched();
        }
    };
    ProjectDetailFormComponent.prototype.ngOnDestroy = function () {
        this.refreshSubject.unsubscribe();
    };
    ProjectDetailFormComponent.prototype.onDateChanged = function (event) {
        this.dateInvalid = true;
    };
    ProjectDetailFormComponent.prototype.onDateChangedClosed = function (event) {
        this.dateInvalidClosed = true;
    };
    ProjectDetailFormComponent.prototype.hasError = function (controlName, errorName) {
        return this.projectDetailForm.controls[controlName].hasError(errorName);
    };
    ProjectDetailFormComponent.prototype.isTouched = function (controlName) {
        return this.projectDetailForm.controls[controlName].touched;
    };
    ProjectDetailFormComponent.prototype.isEmpty = function (controlName) {
        return !this.projectDetailForm.controls[controlName].value;
    };
    ProjectDetailFormComponent.prototype.resetValue = function (controlName) {
        this.projectDetailForm.controls[controlName].reset();
        if (controlName === 'secondMap') {
            this.secondMapPdfName = null;
            this.secondMapBlob = null;
            this.secondMapSrc = null;
            this.projectDetailForm.controls.secondMapUploadId.reset();
        }
        else {
            this.firstMapPdfName = null;
            this.firstMapBlob = null;
            this.firstMapSrc = null;
            this.projectDetailForm.controls.firstMapUploadId.reset();
        }
    };
    ProjectDetailFormComponent.prototype.onFirstMapDropped = function (files) {
        var file = files[0];
        this.firstMapUpdate(file);
    };
    ProjectDetailFormComponent.prototype.onFirstMapInserted = function (event) {
        var file = event.target.files[0];
        if (!file) {
            return;
        }
        this.firstMapUpdate(file);
    };
    ProjectDetailFormComponent.prototype.onSecondMapDropped = function (files) {
        var file = files[0];
        this.secondMapUpdate(file);
    };
    ProjectDetailFormComponent.prototype.onSecondMapInserted = function (event) {
        var file = event.target.files[0];
        if (!file) {
            return;
        }
        this.secondMapUpdate(file);
    };
    ProjectDetailFormComponent.prototype.onLogoInserted = function (event) {
        var _this = this;
        var file = event.target.files[0];
        if (!file) {
            return;
        }
        var reader = new FileReader();
        reader.onload = function () {
            _this.imageSrc = reader.result;
            _this.imagesService.uploadImages([file])
                .subscribe(function (data) {
                _this.projectDetailForm.controls.logoUploadId.patchValue(data.fileNames[file.name].replace(/^.*[\\\/]/, ''));
            }, function () {
                _this.imageSrc = _this.defaultLogoPath;
                _this.notificationService.openErrorNotification('error.imageUpload');
            });
        };
        reader.readAsDataURL(file);
    };
    ProjectDetailFormComponent.prototype.downloadFirst = function () {
        _shared_utils_blob_manager__WEBPACK_IMPORTED_MODULE_19__["BlobManager"].downloadFromBlob(this.firstMapBlob, 'application/pdf', this.firstMapPdfName);
    };
    ProjectDetailFormComponent.prototype.downloadSecond = function () {
        _shared_utils_blob_manager__WEBPACK_IMPORTED_MODULE_19__["BlobManager"].downloadFromBlob(this.secondMapBlob, 'application/pdf', this.secondMapPdfName);
    };
    ProjectDetailFormComponent.prototype.openDialog = function (source) {
        this.matDialog.open(_shared_components_dialog_pdf_dialog_pdf_dialog_component__WEBPACK_IMPORTED_MODULE_10__["PdfDialogComponent"], {
            maxHeight: '80vh',
            minHeight: '80vh',
            maxWidth: '80vw',
            minWidth: '80vw',
            data: {
                source: source
            }
        });
    };
    /**
     * Emit data for wrapper form create or form edit component
     */
    ProjectDetailFormComponent.prototype.emitFormDataChangeEmitter = function () {
        if (this.projectDetailForm.invalid) {
            this.onFormDataChange.emit(null);
        }
        else {
            var actualValue = tslib__WEBPACK_IMPORTED_MODULE_0__["__assign"]({}, this.projectDetailForm.value);
            this.onFormDataChange.emit(actualValue);
        }
    };
    ProjectDetailFormComponent.prototype.loadCountries = function () {
        var _this = this;
        this.countriesLoading = true;
        this.businessAreaService.listCountries()
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_9__["finalize"])(function () { return _this.countriesLoading = false; }))
            .subscribe(function (data) {
            _this.countryList = data.content.filter(function (item) { return item.state === 'VALID'; });
        }, function () {
            _this.notificationService.openErrorNotification('error.api');
        });
    };
    ProjectDetailFormComponent.prototype.loadProjectDetail = function () {
        var _this = this;
        this.projectsService.getProjectByProjectId(this.projectEventService.instant.id)
            .subscribe(function (data) {
            _this.setFormWithDetailData(data);
        }, function () {
            _this.notificationService.openErrorNotification('error.getProjectDetail');
        });
    };
    ProjectDetailFormComponent.prototype.setFormWithDetailData = function (projectDetail) {
        var _this = this;
        this.firstMapSrc = null;
        this.firstMapBlob = null;
        this.firstMapPdfName = null;
        this.secondMapSrc = null;
        this.secondMapBlob = null;
        this.secondMapPdfName = null;
        this.projectDetailForm.patchValue({
            name: projectDetail.name,
            year: projectDetail.year,
            status: projectDetail.state,
        });
        if (projectDetail.dateFrom) {
            this.projectDetailForm.controls.dateFrom.patchValue(projectDetail.dateFrom);
        }
        if (projectDetail.dateTo) {
            this.projectDetailForm.controls.dateTo.patchValue(projectDetail.dateTo);
        }
        if (projectDetail.description) {
            this.projectDetailForm.controls.description.patchValue(projectDetail.description);
        }
        if (projectDetail.logo) {
            this.projectDetailForm.controls.logoUploadId.patchValue(projectDetail.logo);
        }
        if (projectDetail.id) {
            this.projectDetailForm.controls.projectId.patchValue(projectDetail.id);
        }
        var firstCountryObject = projectDetail.projectVenues.find(function (projectVenue) { return projectVenue.screenPosition === 1; });
        this.setFormFromFirstCountry(firstCountryObject);
        var secondCountryObject = projectDetail.projectVenues.find(function (projectVenue) { return projectVenue.screenPosition === 2; });
        this.setFormFromSecondCountry(secondCountryObject);
        if (projectDetail.logo) {
            this.imagesService.getImage(projectDetail.logo)
                .subscribe(function (blob) {
                var reader = new FileReader();
                reader.onload = function (e) {
                    _this.imageSrc = reader.result;
                };
                reader.readAsDataURL(blob);
            }, function () {
                _this.notificationService.openErrorNotification('error.imageDownload');
            });
        }
        if (firstCountryObject && firstCountryObject.attachment) {
            this.firstMapPdfName = firstCountryObject.attachment.fileName;
            this.attachmentService.getAttachment(firstCountryObject.attachment.filePath)
                .subscribe(function (blob) {
                _this.firstMapBlob = blob;
                var reader = new FileReader();
                reader.onload = function () {
                    _this.firstMapSrc = reader.result;
                };
                reader.readAsDataURL(blob);
            }, function () {
                _this.notificationService.openErrorNotification('error.attachmentDownload');
            });
        }
        else if (!firstCountryObject || !firstCountryObject.attachment) {
            this.firstMapSrc = null;
        }
        if (secondCountryObject && secondCountryObject.attachment) {
            this.secondMapPdfName = secondCountryObject.attachment.fileName;
            this.attachmentService.getAttachment(secondCountryObject.attachment.filePath)
                .subscribe(function (blob) {
                _this.secondMapBlob = blob;
                var reader = new FileReader();
                reader.onload = function () {
                    _this.secondMapSrc = reader.result;
                };
                reader.readAsDataURL(blob);
            }, function () {
                _this.notificationService.openErrorNotification('error.attachmentDownload');
            });
        }
        else if (!secondCountryObject || !secondCountryObject.attachment) {
            this.secondMapSrc = null;
        }
    };
    // TODO: add type
    ProjectDetailFormComponent.prototype.firstMapUpdate = function (file) {
        var _this = this;
        var reader = new FileReader();
        this.firstMapPdfName = file.name;
        reader.onload = function () {
            _this.firstMapSrc = reader.result;
            _this.attachmentService.uploadAttachment([file])
                .subscribe(function (data) {
                _this.projectDetailForm.controls.firstMapUploadId.patchValue(data.fileNames[file.name]);
                _this.projectDetailForm.controls.firstMapUploadName.patchValue(file.name);
            }, function () {
                _this.firstMapSrc = null;
                _this.firstMapBlob = null;
                _this.firstMapPdfName = null;
                _this.notificationService.openErrorNotification('error.attachmentUpload');
            });
        };
        reader.readAsDataURL(file);
    };
    ProjectDetailFormComponent.prototype.secondMapUpdate = function (file) {
        var _this = this;
        var reader = new FileReader();
        this.secondMapPdfName = file.name;
        reader.onload = function () {
            _this.secondMapSrc = reader.result;
            _this.attachmentService.uploadAttachment([file])
                .subscribe(function (data) {
                _this.projectDetailForm.controls.secondMapUploadId.patchValue(data.fileNames[file.name]);
                _this.projectDetailForm.controls.secondMapUploadName.patchValue(file.name);
            }, function () {
                _this.secondMapSrc = null;
                _this.secondMapBlob = null;
                _this.secondMapPdfName = null;
                _this.notificationService.openErrorNotification('error.attachmentUpload');
            });
        };
        reader.readAsDataURL(file);
    };
    ProjectDetailFormComponent.prototype.setFormFromFirstCountry = function (firstCountryObject) {
        if (firstCountryObject) {
            this.projectDetailForm.controls.firstCountry.patchValue(firstCountryObject.clCountry.id);
            if (firstCountryObject.cityName) {
                this.projectDetailForm.controls.firstVenue.patchValue(firstCountryObject.cityName);
                this.projectDetailForm.controls.oldFirstVenue.patchValue(firstCountryObject.cityName);
                if (firstCountryObject.attachment && firstCountryObject.attachment.filePath) {
                    this.projectDetailForm.controls.firstMapUploadId.patchValue(firstCountryObject.attachment.filePath);
                    this.projectDetailForm.controls.firstMapUploadName.patchValue(firstCountryObject.attachment.fileName);
                }
            }
        }
    };
    ProjectDetailFormComponent.prototype.setFormFromSecondCountry = function (secondCountryObject) {
        if (secondCountryObject) {
            this.projectDetailForm.controls.secondCountry.patchValue(secondCountryObject.clCountry.id);
            if (secondCountryObject.cityName) {
                this.projectDetailForm.controls.oldSecondVenue.patchValue(secondCountryObject.cityName);
                this.projectDetailForm.controls.secondVenue.patchValue(secondCountryObject.cityName);
                if (secondCountryObject.attachment && secondCountryObject.attachment.filePath) {
                    this.projectDetailForm.controls.secondMapUploadId.patchValue(secondCountryObject.attachment.filePath);
                    this.projectDetailForm.controls.secondMapUploadName.patchValue(secondCountryObject.attachment.fileName);
                }
            }
        }
    };
    ProjectDetailFormComponent.prototype.firstCountryEmptyWhenFirstVenue = function () {
        var _this = this;
        return function (group) {
            var firstCountryEmptyWhenFirstVenue = _this.editMode && _this.projectDetailForm.controls.firstVenue.value && !_this.projectDetailForm.controls.firstCountry.value;
            return firstCountryEmptyWhenFirstVenue ? { firstCountryEmptyWhenSecondCountry: firstCountryEmptyWhenFirstVenue } : null;
        };
    };
    ProjectDetailFormComponent.prototype.secondCountryEmptyWhenSecondVenue = function () {
        var _this = this;
        return function (group) {
            var secondCountryEmptyWhenSecondVenue = _this.editMode && _this.projectDetailForm.controls.secondVenue.value && !_this.projectDetailForm.controls.secondCountry.value;
            return secondCountryEmptyWhenSecondVenue ? { secondCountryEmptyWhenSecondVenue: secondCountryEmptyWhenSecondVenue } : null;
        };
    };
    ProjectDetailFormComponent.prototype.firstCountryEmptyWhenSecondCountry = function () {
        var _this = this;
        return function (group) {
            var firstCountryEmptyWhenSecondCountry = _this.editMode && _this.projectDetailForm.controls.secondCountry.value && !_this.projectDetailForm.controls.firstCountry.value;
            return firstCountryEmptyWhenSecondCountry ? { firstCountryEmptyWhenSecondCountry: firstCountryEmptyWhenSecondCountry } : null;
        };
    };
    ProjectDetailFormComponent.prototype.firstVenueEmptyWhenFirstMap = function () {
        var _this = this;
        return function (group) {
            var firstVenueEmptyWhenFirstMap = _this.editMode && _this.projectDetailForm.controls.firstMapUploadId.value && !_this.projectDetailForm.controls.firstVenue.value;
            return firstVenueEmptyWhenFirstMap ? { firstVenueEmptyWhenFirstMap: firstVenueEmptyWhenFirstMap } : null;
        };
    };
    ProjectDetailFormComponent.prototype.secondVenueEmptyWhenSecondMap = function () {
        var _this = this;
        return function (group) {
            var secondVenueEmptyWhenSecondMap = _this.editMode && _this.projectDetailForm.controls.secondMapUploadId.value && !_this.projectDetailForm.controls.secondVenue.value;
            return secondVenueEmptyWhenSecondMap ? { secondVenueEmptyWhenSecondMap: secondVenueEmptyWhenSecondMap } : null;
        };
    };
    ProjectDetailFormComponent.prototype.initializeForm = function () {
        this.projectDetailForm = this.formBuilder.group({
            projectId: [''],
            logo: [''],
            name: [''],
            year: [''],
            status: [''],
            dateFrom: [''],
            dateTo: [''],
            firstCountry: [''],
            secondCountry: [''],
            oldFirstVenue: [''],
            firstVenue: ['',],
            oldSecondVenue: [''],
            secondVenue: [''],
            firstMap: [''],
            secondMap: [''],
            logoUploadId: [''],
            firstMapUploadId: [''],
            firstMapUploadName: [''],
            secondMapUploadId: [''],
            secondMapUploadName: [''],
            description: [''],
        }, {
            validator: [
                this.firstCountryEmptyWhenFirstVenue(),
                this.secondCountryEmptyWhenSecondVenue(),
                this.firstCountryEmptyWhenSecondCountry(),
                this.firstVenueEmptyWhenFirstMap(),
                this.secondVenueEmptyWhenSecondMap(),
            ]
        });
    };
    ProjectDetailFormComponent.ctorParameters = function () { return [
        { type: _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormBuilder"] },
        { type: _angular_platform_browser__WEBPACK_IMPORTED_MODULE_6__["DomSanitizer"] },
        { type: _shared_services_data_business_area_service__WEBPACK_IMPORTED_MODULE_14__["BusinessAreaService"] },
        { type: _shared_services_notification_service__WEBPACK_IMPORTED_MODULE_17__["NotificationService"] },
        { type: _shared_services_data_projects_service__WEBPACK_IMPORTED_MODULE_16__["ProjectsService"] },
        { type: _shared_services_data_images_service__WEBPACK_IMPORTED_MODULE_15__["ImagesService"] },
        { type: _shared_services_data_attachment_service__WEBPACK_IMPORTED_MODULE_13__["AttachmentService"] },
        { type: _angular_material_dialog__WEBPACK_IMPORTED_MODULE_5__["MatDialog"] },
        { type: _shared_services_storage_project_event_service__WEBPACK_IMPORTED_MODULE_18__["ProjectEventService"] }
    ]; };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])('editMode'),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Boolean)
    ], ProjectDetailFormComponent.prototype, "editMode", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])('refreshSubject'),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", rxjs__WEBPACK_IMPORTED_MODULE_8__["Subject"])
    ], ProjectDetailFormComponent.prototype, "refreshSubject", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Output"])('formDataChange'),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], ProjectDetailFormComponent.prototype, "onFormDataChange", void 0);
    ProjectDetailFormComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'project-detail-form',
            template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./project-detail-form.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/project/project-detail-form/project-detail-form.component.html")).default,
            animations: [
                _shared_hazlenut_hazelnut_common_animations__WEBPACK_IMPORTED_MODULE_11__["enterLeave"],
                _shared_hazlenut_hazelnut_common_animations__WEBPACK_IMPORTED_MODULE_11__["fadeEnterLeave"]
            ],
            providers: [
                {
                    provide: _angular_material_core__WEBPACK_IMPORTED_MODULE_4__["DateAdapter"],
                    useClass: _angular_material_moment_adapter__WEBPACK_IMPORTED_MODULE_3__["MomentDateAdapter"],
                    deps: [_angular_material_core__WEBPACK_IMPORTED_MODULE_4__["MAT_DATE_LOCALE"]]
                },
                {
                    provide: _angular_material_core__WEBPACK_IMPORTED_MODULE_4__["MAT_DATE_FORMATS"],
                    useValue: PROJECT_DATE_FORMATS
                },
            ],
            styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./project-detail-form.component.scss */ "./src/app/pages/project/project-detail-form/project-detail-form.component.scss")).default]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormBuilder"],
            _angular_platform_browser__WEBPACK_IMPORTED_MODULE_6__["DomSanitizer"],
            _shared_services_data_business_area_service__WEBPACK_IMPORTED_MODULE_14__["BusinessAreaService"],
            _shared_services_notification_service__WEBPACK_IMPORTED_MODULE_17__["NotificationService"],
            _shared_services_data_projects_service__WEBPACK_IMPORTED_MODULE_16__["ProjectsService"],
            _shared_services_data_images_service__WEBPACK_IMPORTED_MODULE_15__["ImagesService"],
            _shared_services_data_attachment_service__WEBPACK_IMPORTED_MODULE_13__["AttachmentService"],
            _angular_material_dialog__WEBPACK_IMPORTED_MODULE_5__["MatDialog"],
            _shared_services_storage_project_event_service__WEBPACK_IMPORTED_MODULE_18__["ProjectEventService"]])
    ], ProjectDetailFormComponent);
    return ProjectDetailFormComponent;
}());



/***/ }),

/***/ "./src/app/pages/project/project-detail/project-detail.component.scss":
/*!****************************************************************************!*\
  !*** ./src/app/pages/project/project-detail/project-detail.component.scss ***!
  \****************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL3Byb2plY3QvcHJvamVjdC1kZXRhaWwvcHJvamVjdC1kZXRhaWwuY29tcG9uZW50LnNjc3MifQ== */");

/***/ }),

/***/ "./src/app/pages/project/project-detail/project-detail.component.ts":
/*!**************************************************************************!*\
  !*** ./src/app/pages/project/project-detail/project-detail.component.ts ***!
  \**************************************************************************/
/*! exports provided: ProjectDetailComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProjectDetailComponent", function() { return ProjectDetailComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm5/index.js");
/* harmony import */ var _shared_enums_attachment_format_enum__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../shared/enums/attachment-format.enum */ "./src/app/shared/enums/attachment-format.enum.ts");
/* harmony import */ var _shared_enums_attachment_type_enum__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../shared/enums/attachment-type.enum */ "./src/app/shared/enums/attachment-type.enum.ts");
/* harmony import */ var _shared_enums_role_enum__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../shared/enums/role.enum */ "./src/app/shared/enums/role.enum.ts");
/* harmony import */ var _shared_hazlenut_hazelnut_common_animations__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../shared/hazlenut/hazelnut-common/animations */ "./src/app/shared/hazlenut/hazelnut-common/animations/index.ts");
/* harmony import */ var _shared_services_auth_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../../shared/services/auth.service */ "./src/app/shared/services/auth.service.ts");
/* harmony import */ var _shared_services_data_projects_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../../shared/services/data/projects.service */ "./src/app/shared/services/data/projects.service.ts");
/* harmony import */ var _shared_services_notification_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../../shared/services/notification.service */ "./src/app/shared/services/notification.service.ts");
/* harmony import */ var _shared_services_storage_project_event_service__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../../shared/services/storage/project-event.service */ "./src/app/shared/services/storage/project-event.service.ts");











var ProjectDetailComponent = /** @class */ (function () {
    function ProjectDetailComponent(projectsService, notificationService, projectEventService, authService) {
        this.projectsService = projectsService;
        this.notificationService = notificationService;
        this.projectEventService = projectEventService;
        this.authService = authService;
        this.formData = null;
        this.canSave = true;
        this.editMode = false;
        this.refreshSubject = new rxjs__WEBPACK_IMPORTED_MODULE_2__["Subject"]();
    }
    ProjectDetailComponent.prototype.ngOnInit = function () {
    };
    /**
     * Cancel form, navigate to facts list screen
     */
    ProjectDetailComponent.prototype.onCancel = function () {
        this.toggleEditMode();
        this.refreshSubject.next('Refresh after cancel');
    };
    /**
     * Edit task with form values on save and navigate to facts list
     */
    ProjectDetailComponent.prototype.onSave = function () {
        var _this = this;
        if (this.formData) {
            this.projectsService.editProject(this.formData.projectId, this.transformProjectToApiObject(this.formData))
                .subscribe(function (response) {
                _this.notificationService.openSuccessNotification('success.edit');
                _this.refreshSubject.next('Refresh after save');
                _this.projectEventService.setEventDataFromDetail(_this.formData, true, _this.formData.logoUploadId);
            }, function (error) {
                _this.notificationService.openErrorNotification('error.edit');
            });
        }
        this.toggleEditMode();
    };
    /**
     * Toggle edit mode on edit button or accept/cancel form
     */
    ProjectDetailComponent.prototype.toggleEditMode = function () {
        this.editMode = !this.editMode;
    };
    ProjectDetailComponent.prototype.hasEditRole = function () {
        return this.authService.hasRole(_shared_enums_role_enum__WEBPACK_IMPORTED_MODULE_5__["Role"].RoleUpdateProject);
    };
    /**
     * Partial project form object to API fact object transformation
     * @param formObject
     */
    ProjectDetailComponent.prototype.transformProjectToApiObject = function (formObject) {
        var apiObject = {
            name: formObject.name,
            year: formObject.year,
            state: formObject.status,
        };
        if (formObject.dateFrom) {
            apiObject.dateFrom = formObject.dateFrom;
        }
        if (formObject.dateTo) {
            apiObject.dateTo = formObject.dateTo;
        }
        if (formObject.logoUploadId) {
            apiObject.logo = formObject.logoUploadId;
        }
        if (formObject.firstCountry || formObject.secondCountry) {
            apiObject.projectVenues = [];
        }
        if (formObject.firstCountry) {
            var firstVenueObject = {};
            firstVenueObject.screenPosition = 1;
            firstVenueObject.clCountry = { id: formObject.firstCountry };
            if (formObject.firstVenue) {
                firstVenueObject.cityName = formObject.firstVenue;
            }
            if (formObject.firstVenue && formObject.firstMapUploadId) {
                firstVenueObject.attachment = {
                    fileName: formObject.firstMapUploadName,
                    filePath: formObject.firstMapUploadId,
                    type: _shared_enums_attachment_type_enum__WEBPACK_IMPORTED_MODULE_4__["AttachmentType"].Map,
                    format: _shared_enums_attachment_format_enum__WEBPACK_IMPORTED_MODULE_3__["AttachmentFormat"].Pdf
                };
            }
            apiObject.projectVenues.push(firstVenueObject);
        }
        if (formObject.secondCountry) {
            var secondVenueObject = {};
            secondVenueObject.screenPosition = 2;
            secondVenueObject.clCountry = { id: formObject.secondCountry };
            if (formObject.secondVenue) {
                secondVenueObject.cityName = formObject.secondVenue;
            }
            if (formObject.secondVenue && formObject.secondMapUploadId) {
                secondVenueObject.attachment = {
                    fileName: formObject.secondMapUploadName,
                    filePath: formObject.secondMapUploadId,
                    type: _shared_enums_attachment_type_enum__WEBPACK_IMPORTED_MODULE_4__["AttachmentType"].Map,
                    format: _shared_enums_attachment_format_enum__WEBPACK_IMPORTED_MODULE_3__["AttachmentFormat"].Pdf
                };
            }
            apiObject.projectVenues.push(secondVenueObject);
        }
        if (formObject.description) {
            apiObject.description = formObject.description;
        }
        return apiObject;
    };
    ProjectDetailComponent.ctorParameters = function () { return [
        { type: _shared_services_data_projects_service__WEBPACK_IMPORTED_MODULE_8__["ProjectsService"] },
        { type: _shared_services_notification_service__WEBPACK_IMPORTED_MODULE_9__["NotificationService"] },
        { type: _shared_services_storage_project_event_service__WEBPACK_IMPORTED_MODULE_10__["ProjectEventService"] },
        { type: _shared_services_auth_service__WEBPACK_IMPORTED_MODULE_7__["AuthService"] }
    ]; };
    ProjectDetailComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'project-detail',
            template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./project-detail.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/project/project-detail/project-detail.component.html")).default,
            animations: [_shared_hazlenut_hazelnut_common_animations__WEBPACK_IMPORTED_MODULE_6__["enterLeave"]],
            styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./project-detail.component.scss */ "./src/app/pages/project/project-detail/project-detail.component.scss")).default]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_shared_services_data_projects_service__WEBPACK_IMPORTED_MODULE_8__["ProjectsService"],
            _shared_services_notification_service__WEBPACK_IMPORTED_MODULE_9__["NotificationService"],
            _shared_services_storage_project_event_service__WEBPACK_IMPORTED_MODULE_10__["ProjectEventService"],
            _shared_services_auth_service__WEBPACK_IMPORTED_MODULE_7__["AuthService"]])
    ], ProjectDetailComponent);
    return ProjectDetailComponent;
}());



/***/ }),

/***/ "./src/app/pages/project/project-routing.module.ts":
/*!*********************************************************!*\
  !*** ./src/app/pages/project/project-routing.module.ts ***!
  \*********************************************************/
/*! exports provided: ProjectRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProjectRoutingModule", function() { return ProjectRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _project_detail_project_detail_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./project-detail/project-detail.component */ "./src/app/pages/project/project-detail/project-detail.component.ts");




var routes = [
    {
        path: '',
        children: [
            {
                path: '',
                pathMatch: 'full',
                redirectTo: 'detail',
            },
            {
                path: 'detail',
                component: _project_detail_project_detail_component__WEBPACK_IMPORTED_MODULE_3__["ProjectDetailComponent"],
                data: { title: 'projectDetail' }
            },
        ],
    }
];
var ProjectRoutingModule = /** @class */ (function () {
    function ProjectRoutingModule() {
    }
    ProjectRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
            exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
        })
    ], ProjectRoutingModule);
    return ProjectRoutingModule;
}());



/***/ }),

/***/ "./src/app/pages/project/project.module.ts":
/*!*************************************************!*\
  !*** ./src/app/pages/project/project.module.ts ***!
  \*************************************************/
/*! exports provided: ProjectModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProjectModule", function() { return ProjectModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_flex_layout__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/flex-layout */ "./node_modules/@angular/flex-layout/esm5/flex-layout.es5.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ngx-translate/core */ "./node_modules/@ngx-translate/core/fesm5/ngx-translate-core.js");
/* harmony import */ var ng2_pdf_viewer__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ng2-pdf-viewer */ "./node_modules/ng2-pdf-viewer/fesm5/ng2-pdf-viewer.js");
/* harmony import */ var _shared_hazlenut_abstract_inputs__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../shared/hazlenut/abstract-inputs */ "./src/app/shared/hazlenut/abstract-inputs/index.ts");
/* harmony import */ var _shared_hazlenut_hazelnut_common__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../shared/hazlenut/hazelnut-common */ "./src/app/shared/hazlenut/hazelnut-common/index.ts");
/* harmony import */ var _shared_pipes_pipes_module__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../shared/pipes/pipes.module */ "./src/app/shared/pipes/pipes.module.ts");
/* harmony import */ var _project_detail_form_project_detail_form_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./project-detail-form/project-detail-form.component */ "./src/app/pages/project/project-detail-form/project-detail-form.component.ts");
/* harmony import */ var _project_detail_project_detail_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./project-detail/project-detail.component */ "./src/app/pages/project/project-detail/project-detail.component.ts");
/* harmony import */ var _project_routing_module__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./project-routing.module */ "./src/app/pages/project/project-routing.module.ts");













var ProjectModule = /** @class */ (function () {
    function ProjectModule() {
    }
    ProjectModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["NgModule"])({
            declarations: [
                _project_detail_project_detail_component__WEBPACK_IMPORTED_MODULE_11__["ProjectDetailComponent"],
                _project_detail_form_project_detail_form_component__WEBPACK_IMPORTED_MODULE_10__["ProjectDetailFormComponent"]
            ],
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"],
                _project_routing_module__WEBPACK_IMPORTED_MODULE_12__["ProjectRoutingModule"],
                _shared_hazlenut_hazelnut_common__WEBPACK_IMPORTED_MODULE_8__["MaterialModule"],
                _angular_flex_layout__WEBPACK_IMPORTED_MODULE_3__["FlexLayoutModule"],
                _ngx_translate_core__WEBPACK_IMPORTED_MODULE_5__["TranslateModule"].forChild(),
                _angular_forms__WEBPACK_IMPORTED_MODULE_4__["ReactiveFormsModule"],
                _shared_hazlenut_abstract_inputs__WEBPACK_IMPORTED_MODULE_7__["AbstractInputsModule"],
                _shared_pipes_pipes_module__WEBPACK_IMPORTED_MODULE_9__["PipesModule"],
                _shared_hazlenut_hazelnut_common__WEBPACK_IMPORTED_MODULE_8__["SharedDirectivesModule"],
                ng2_pdf_viewer__WEBPACK_IMPORTED_MODULE_6__["PdfViewerModule"]
            ]
        })
    ], ProjectModule);
    return ProjectModule;
}());



/***/ }),

/***/ "./src/app/shared/enums/attachment-format.enum.ts":
/*!********************************************************!*\
  !*** ./src/app/shared/enums/attachment-format.enum.ts ***!
  \********************************************************/
/*! exports provided: AttachmentFormat */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AttachmentFormat", function() { return AttachmentFormat; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");

var AttachmentFormat;
(function (AttachmentFormat) {
    AttachmentFormat["Pdf"] = "PDF";
})(AttachmentFormat || (AttachmentFormat = {}));


/***/ }),

/***/ "./src/app/shared/enums/attachment-type.enum.ts":
/*!******************************************************!*\
  !*** ./src/app/shared/enums/attachment-type.enum.ts ***!
  \******************************************************/
/*! exports provided: AttachmentType */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AttachmentType", function() { return AttachmentType; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");

var AttachmentType;
(function (AttachmentType) {
    AttachmentType["Map"] = "MAP";
})(AttachmentType || (AttachmentType = {}));


/***/ }),

/***/ "./src/app/shared/hazlenut/abstract-inputs/index.ts":
/*!**********************************************************!*\
  !*** ./src/app/shared/hazlenut/abstract-inputs/index.ts ***!
  \**********************************************************/
/*! exports provided: ABSTRACT_INPUT_TOKEN, AbstractInputsModule, ValidatorComposer, InputNumberComponent, CoreInputComponent, FORMAT, InputDateComponent, InputDateRangeComponent, InputNumberRangeComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _abstract_inputs_config__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./abstract-inputs-config */ "./src/app/shared/hazlenut/abstract-inputs/abstract-inputs-config.ts");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "ABSTRACT_INPUT_TOKEN", function() { return _abstract_inputs_config__WEBPACK_IMPORTED_MODULE_1__["ABSTRACT_INPUT_TOKEN"]; });

/* harmony import */ var _abstract_inputs_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./abstract-inputs.module */ "./src/app/shared/hazlenut/abstract-inputs/abstract-inputs.module.ts");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "AbstractInputsModule", function() { return _abstract_inputs_module__WEBPACK_IMPORTED_MODULE_2__["AbstractInputsModule"]; });

/* harmony import */ var _validator_composer__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./validator-composer */ "./src/app/shared/hazlenut/abstract-inputs/validator-composer.ts");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "ValidatorComposer", function() { return _validator_composer__WEBPACK_IMPORTED_MODULE_3__["ValidatorComposer"]; });

/* harmony import */ var _input_number_input_number_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./input-number/input-number.component */ "./src/app/shared/hazlenut/abstract-inputs/input-number/input-number.component.ts");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "InputNumberComponent", function() { return _input_number_input_number_component__WEBPACK_IMPORTED_MODULE_4__["InputNumberComponent"]; });

/* harmony import */ var _core_input_core_input_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./core-input/core-input.component */ "./src/app/shared/hazlenut/abstract-inputs/core-input/core-input.component.ts");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "CoreInputComponent", function() { return _core_input_core_input_component__WEBPACK_IMPORTED_MODULE_5__["CoreInputComponent"]; });

/* harmony import */ var _input_date_input_date_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./input-date/input-date.component */ "./src/app/shared/hazlenut/abstract-inputs/input-date/input-date.component.ts");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "FORMAT", function() { return _input_date_input_date_component__WEBPACK_IMPORTED_MODULE_6__["FORMAT"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "InputDateComponent", function() { return _input_date_input_date_component__WEBPACK_IMPORTED_MODULE_6__["InputDateComponent"]; });

/* harmony import */ var _input_date_range_input_date_range_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./input-date-range/input-date-range.component */ "./src/app/shared/hazlenut/abstract-inputs/input-date-range/input-date-range.component.ts");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "InputDateRangeComponent", function() { return _input_date_range_input_date_range_component__WEBPACK_IMPORTED_MODULE_7__["InputDateRangeComponent"]; });

/* harmony import */ var _input_number_range_input_number_range_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./input-number-range/input-number-range.component */ "./src/app/shared/hazlenut/abstract-inputs/input-number-range/input-number-range.component.ts");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "InputNumberRangeComponent", function() { return _input_number_range_input_number_range_component__WEBPACK_IMPORTED_MODULE_8__["InputNumberRangeComponent"]; });












/***/ }),

/***/ "./src/app/shared/services/data/attachment.service.ts":
/*!************************************************************!*\
  !*** ./src/app/shared/services/data/attachment.service.ts ***!
  \************************************************************/
/*! exports provided: AttachmentService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AttachmentService", function() { return AttachmentService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm5/operators/index.js");
/* harmony import */ var _hazlenut_hazelnut_common_config_hazelnut_config__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../hazlenut/hazelnut-common/config/hazelnut-config */ "./src/app/shared/hazlenut/hazelnut-common/config/hazelnut-config.ts");
/* harmony import */ var _notification_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../notification.service */ "./src/app/shared/services/notification.service.ts");
/* harmony import */ var _project_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../project.service */ "./src/app/shared/services/project.service.ts");
/* harmony import */ var _storage_project_user_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../storage/project-user.service */ "./src/app/shared/services/storage/project-user.service.ts");








var AttachmentService = /** @class */ (function (_super) {
    tslib__WEBPACK_IMPORTED_MODULE_0__["__extends"](AttachmentService, _super);
    function AttachmentService(http, notificationService, userService) {
        return _super.call(this, http, 'attachment', notificationService, userService) || this;
    }
    AttachmentService.prototype.uploadAttachment = function (files) {
        var formData = new FormData();
        for (var _i = 0, files_1 = files; _i < files_1.length; _i++) {
            var file = files_1[_i];
            formData.append('files', file, file.name);
        }
        var headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpHeaders"]();
        headers = headers.set('device-id', this.userService.instant.deviceId);
        headers = headers.set('token', this.userService.instant.authToken);
        return this.post({
            headers: headers,
            url: _hazlenut_hazelnut_common_config_hazelnut_config__WEBPACK_IMPORTED_MODULE_4__["HazelnutConfig"].URL_API + "/attachment/upload",
            mapFunction: function (e) { return e; },
            body: formData,
        });
    };
    AttachmentService.prototype.getAttachment = function (attachmentName) {
        return this.http.get(_hazlenut_hazelnut_common_config_hazelnut_config__WEBPACK_IMPORTED_MODULE_4__["HazelnutConfig"].URL_API + "/attachment/" + attachmentName, {
            headers: this.getHeader(),
            responseType: 'blob',
        })
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["map"])(function (result) {
            return result;
        }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["catchError"])(this.handleError));
    };
    AttachmentService.ctorParameters = function () { return [
        { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"] },
        { type: _notification_service__WEBPACK_IMPORTED_MODULE_5__["NotificationService"] },
        { type: _storage_project_user_service__WEBPACK_IMPORTED_MODULE_7__["ProjectUserService"] }
    ]; };
    AttachmentService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Injectable"])({
            providedIn: 'root'
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"], _notification_service__WEBPACK_IMPORTED_MODULE_5__["NotificationService"], _storage_project_user_service__WEBPACK_IMPORTED_MODULE_7__["ProjectUserService"]])
    ], AttachmentService);
    return AttachmentService;
}(_project_service__WEBPACK_IMPORTED_MODULE_6__["ProjectService"]));



/***/ }),

/***/ "./src/app/shared/services/data/projects.service.ts":
/*!**********************************************************!*\
  !*** ./src/app/shared/services/data/projects.service.ts ***!
  \**********************************************************/
/*! exports provided: ProjectsService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProjectsService", function() { return ProjectsService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _notification_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../notification.service */ "./src/app/shared/services/notification.service.ts");
/* harmony import */ var _project_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../project.service */ "./src/app/shared/services/project.service.ts");
/* harmony import */ var _storage_project_user_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../storage/project-user.service */ "./src/app/shared/services/storage/project-user.service.ts");






var ProjectsService = /** @class */ (function (_super) {
    tslib__WEBPACK_IMPORTED_MODULE_0__["__extends"](ProjectsService, _super);
    function ProjectsService(http, notificationService, userService) {
        return _super.call(this, http, 'projects', notificationService, userService) || this;
    }
    ProjectsService.prototype.getProjectByProjectId = function (projectId) {
        return this.getDetail(projectId);
    };
    /**
     * Edit project object API call
     * @param id
     * @param taskObject
     */
    ProjectsService.prototype.editProject = function (id, projectObject) {
        return this.update(id, projectObject);
    };
    ProjectsService.ctorParameters = function () { return [
        { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"] },
        { type: _notification_service__WEBPACK_IMPORTED_MODULE_3__["NotificationService"] },
        { type: _storage_project_user_service__WEBPACK_IMPORTED_MODULE_5__["ProjectUserService"] }
    ]; };
    ProjectsService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Injectable"])({
            providedIn: 'root'
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"], _notification_service__WEBPACK_IMPORTED_MODULE_3__["NotificationService"], _storage_project_user_service__WEBPACK_IMPORTED_MODULE_5__["ProjectUserService"]])
    ], ProjectsService);
    return ProjectsService;
}(_project_service__WEBPACK_IMPORTED_MODULE_4__["ProjectService"]));



/***/ }),

/***/ "./src/app/shared/utils/blob-manager.ts":
/*!**********************************************!*\
  !*** ./src/app/shared/utils/blob-manager.ts ***!
  \**********************************************/
/*! exports provided: BlobManager */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BlobManager", function() { return BlobManager; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");

var BlobManager = /** @class */ (function () {
    function BlobManager() {
    }
    BlobManager.downloadFromBlob = function (blob, type, filename) {
        var link;
        link = document.createElement('a');
        link.setAttribute('class', 'hide');
        link.setAttribute('href', '');
        document.body.appendChild(link);
        link.href = URL.createObjectURL(new Blob([blob], { type: type }));
        link.download = filename;
        link.click();
        document.body.removeChild(link);
    };
    return BlobManager;
}());



/***/ })

}]);
//# sourceMappingURL=pages-project-project-module.js.map