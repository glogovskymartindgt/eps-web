(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["default~pages-facts-facts-module~pages-tasks-tasks-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/tasks/task-form/task-form.component.html":
/*!******************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/tasks/task-form/task-form.component.html ***!
  \******************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<form [formGroup]=\"taskForm\" *ngIf=\"(isUpdate && formLoaded) || !isUpdate\">\r\n\r\n    <div fxLayout=\"row\" *ngIf=\"isUpdate\">\r\n        <div class=\"short-input mr-10\">\r\n            <haz-core-input [label]=\"'tasks.code' | translate\"\r\n                            [appearance]=\"'fill'\"\r\n                            formControlName=\"code\"\r\n                            class=\"theme-input\"\r\n            >\r\n            </haz-core-input>\r\n        </div>\r\n        <mat-form-field appearance=\"fill\" class=\"theme-input short-input\">\r\n            <mat-label class=\"label-style\">{{ 'tasks.status' | translate }}</mat-label>\r\n            <mat-select formControlName=\"state\" required>\r\n                <mat-option [value]=\"'OPEN'\">{{'status.open' | translate}}</mat-option>\r\n                <mat-option [value]=\"'CLOSED'\">{{'status.closed' | translate}}</mat-option>\r\n            </mat-select>\r\n        </mat-form-field>\r\n    </div>\r\n\r\n    <div fxLayout=\"row\">\r\n        <mat-form-field appearance=\"fill\" class=\"theme-input short-input mr-10\">\r\n            <mat-label class=\"label-style\">{{ 'tasks.type' | translate }}</mat-label>\r\n            <mat-select formControlName=\"taskType\" required>\r\n                <mat-option *ngFor=\"let taskType of taskTypeList\" [value]=\"taskType.toUpperCase()\">\r\n                    {{('task.taskTypeValue.' + taskType.toLowerCase()) | translate}}\r\n                </mat-option>\r\n            </mat-select>\r\n            <mat-error\r\n                *ngIf=\"f?.taskType?.errors?.required\">{{ 'error.required' | translate }}</mat-error>\r\n        </mat-form-field>\r\n\r\n        <mat-form-field *ngIf=\"f.taskType.value == 'ISSUE'\" appearance=\"fill\" class=\"theme-input short-input\">\r\n            <mat-label class=\"label-style\">{{ 'tasks.trafficLight' | translate }}</mat-label>\r\n            <mat-select formControlName=\"trafficLight\" required>\r\n                <mat-select-trigger>\r\n                    <div class=\"color-circle\"\r\n                         [style.background]=\"getCircleColor(f?.trafficLight?.value.toString().toLowerCase())\"\r\n                         [ngStyle]=\"{'background': getCircleColor(f?.trafficLight?.value.toString().toLowerCase())}\">\r\n                    </div>\r\n                    <span\r\n                        class=\"ml-20\">{{('color.' + f?.trafficLight?.value.toString().toLowerCase()) | translate}}</span>\r\n                </mat-select-trigger>\r\n                <mat-option *ngFor=\"let trafficLight of trafficLightList\"\r\n                            [value]=\"trafficLight.toUpperCase()\">\r\n                    <div [style.background]=\"getCircleColor(trafficLight)\"\r\n                         class=\"color-circle mt-17\"></div>\r\n                    <span class=\"ml-20\">{{('color.' + trafficLight) | translate}}</span>\r\n                </mat-option>\r\n            </mat-select>\r\n            <mat-error *ngIf=\"f?.trafficLight?.errors?.required\">\r\n                {{ 'error.required' | translate }}\r\n            </mat-error>\r\n        </mat-form-field>\r\n    </div>\r\n\r\n    <div class=\"long-input\">\r\n        <haz-core-input [label]=\"'tasks.title' | translate\"\r\n                        [required]=\"true\"\r\n                        [appearance]=\"'fill'\"\r\n                        formControlName=\"title\"\r\n                        class=\"theme-input\"\r\n                        [type]=\"'textarea'\"\r\n                        [maxLength]=\"255\"\r\n        >\r\n        </haz-core-input>\r\n    </div>\r\n\r\n    <div>\r\n        <mat-form-field appearance=\"fill\" class=\"long-input theme-input\">\r\n            <mat-label class=\"label-style\">{{'businessArea.title' | translate}}</mat-label>\r\n            <mat-select formControlName=\"businessArea\" required>\r\n                <mat-option class=\"color-none\" value=\"\">{{'all.empty' | translate}}</mat-option>\r\n                <mat-option *ngFor=\"let businessArea of businessAreaList\"\r\n                            [value]=\"businessArea.id\"\r\n                >\r\n                    {{businessArea.codeItem}} - {{businessArea.name}}\r\n                </mat-option>\r\n            </mat-select>\r\n            <mat-error\r\n                *ngIf=\"f?.businessArea?.errors?.required\">{{ 'error.required' | translate }}</mat-error>\r\n        </mat-form-field>\r\n    </div>\r\n\r\n    <div>\r\n        <mat-form-field appearance=\"fill\" class=\"theme-input long-input\">\r\n            <mat-label class=\"label-style\">{{ 'tasks.responsible' | translate }}</mat-label>\r\n            <mat-select formControlName=\"responsible\">\r\n                <mat-option value=\"\" class=\"color-none\">{{'all.empty' | translate}}</mat-option>\r\n                <mat-option *ngFor=\"let user of userList\"\r\n                            [value]=\"user.id\"\r\n                >\r\n                    {{user.firstName}} {{user.lastName}}\r\n                </mat-option>\r\n            </mat-select>\r\n        </mat-form-field>\r\n    </div>\r\n\r\n    <div>\r\n        <mat-form-field appearance=\"fill\" class=\"theme-input long-input\">\r\n            <mat-label class=\"label-style\">{{ 'tasks.sourceOfAgenda' | translate }}</mat-label>\r\n            <mat-select formControlName=\"sourceOfAgenda\">\r\n                <mat-option value=\"\" class=\"color-none\">{{'all.empty' | translate}}</mat-option>\r\n                <mat-option *ngFor=\"let sourceOfAgenda of sourceOfAgendaList\"\r\n                            [value]=\"sourceOfAgenda.id\"\r\n                >\r\n                    {{sourceOfAgenda.name}}\r\n                </mat-option>\r\n            </mat-select>\r\n        </mat-form-field>\r\n    </div>\r\n\r\n    <div class=\"long-input\">\r\n        <haz-core-input [label]=\"'tasks.sourceDescription' | translate\"\r\n                        [appearance]=\"'fill'\"\r\n                        [maxLength]=\"4092\"\r\n                        [type]=\"'textarea'\"\r\n                        formControlName=\"sourceDescription\"\r\n                        class=\"theme-input long-input\"\r\n        >\r\n        </haz-core-input>\r\n    </div>\r\n\r\n    <div>\r\n        <mat-form-field appearance=\"fill\" class=\"theme-input long-input\">\r\n            <mat-label class=\"label-style\">{{ 'tasks.phase' | translate }}</mat-label>\r\n            <mat-select formControlName=\"phase\">\r\n                <mat-option value=\"\" class=\"color-none\">{{'all.empty' | translate}}</mat-option>\r\n                <mat-option *ngFor=\"let phase of phaseList\"\r\n                            [value]=\"phase.id\">\r\n                    <span>\r\n                        {{phase.checkPointFrom  | date:'d.M.yyyy'}} - {{phase.checkPointTo  | date:'d.M.yyyy'}}\r\n                    </span>\r\n                    <span style=\"position:absolute; right: 15px;\">{{phase.clPhase.name}}</span>\r\n                </mat-option>\r\n            </mat-select>\r\n        </mat-form-field>\r\n    </div>\r\n\r\n    <div fxLayout=\"row\">\r\n        <mat-form-field appearance=\"fill\" class=\"short-input theme-input mr-10\">\r\n            <mat-label class=\"label-style\">{{ 'tasks.dueDate' | translate }}</mat-label>\r\n            <input matInput [matDatepicker]=\"picker\" (dateChange)=\"onDateChanged($event.value)\"\r\n                   formControlName=\"dueDate\">\r\n            <mat-datepicker-toggle matSuffix [for]=\"picker\"></mat-datepicker-toggle>\r\n            <mat-datepicker [dateClass]=\"dateClass\" #picker></mat-datepicker>\r\n            <mat-error *ngIf=\"dateInvalid\">{{ 'error.dateFormatIsInvalid' | translate }}</mat-error>\r\n        </mat-form-field>\r\n\r\n        <mat-form-field appearance=\"fill\" class=\"short-input theme-input\">\r\n            <mat-label class=\"label-style\">{{ 'tasks.venue' | translate }}</mat-label>\r\n            <mat-select formControlName=\"venue\">\r\n                <mat-option value='NONE' class=\"color-none\">{{ 'tasks.none' | translate }}</mat-option>\r\n                <mat-option *ngFor=\"let venue of venueList\" [value]=\"venue.city\">\r\n                    {{venue.city}}\r\n                </mat-option>\r\n                <mat-option value=\"BOTH\">{{ 'tasks.both' | translate }}</mat-option>\r\n            </mat-select>\r\n        </mat-form-field>\r\n    </div>\r\n\r\n    <mat-form-field appearance=\"fill\" class=\"short-input theme-input mr-10\" *ngIf=\"isUpdate\">\r\n        <mat-label class=\"label-style\">{{ 'tasks.closedDate' | translate }}</mat-label>\r\n        <input matInput [matDatepicker]=\"pickerClosed\" (dateChange)=\"onDateChangedClosed($event.value)\"\r\n               formControlName=\"closedDate\">\r\n        <mat-datepicker-toggle matSuffix [for]=\"pickerClosed\"></mat-datepicker-toggle>\r\n        <mat-datepicker [dateClass]=\"dateClass\" #pickerClosed></mat-datepicker>\r\n        <mat-error *ngIf=\"dateInvalid\">{{ 'error.dateFormatIsInvalid' | translate }}</mat-error>\r\n    </mat-form-field>\r\n\r\n    <div class=\"long-input\">\r\n        <haz-core-input [label]=\"'tasks.description' | translate\"\r\n                        [type]=\"'textarea'\"\r\n                        [appearance]=\"'fill'\"\r\n                        formControlName=\"description\"\r\n                        class=\"theme-input\"\r\n                        [maxLength]=\"4092\"\r\n        >\r\n        </haz-core-input>\r\n    </div>\r\n\r\n    <div class=\"long-input\" *ngIf=\"isUpdate\">\r\n        <haz-core-input [label]=\"'tasks.changedAt' |  translate\"\r\n                        [appearance]=\"'fill'\"\r\n                        formControlName=\"changedAt\"\r\n                        class=\"theme-input\"\r\n        >\r\n        </haz-core-input>\r\n    </div>\r\n\r\n    <div class=\"long-input\" *ngIf=\"isUpdate\">\r\n        <haz-core-input [label]=\"'tasks.changedBy' | translate\"\r\n                        [appearance]=\"'fill'\"\r\n                        formControlName=\"changedBy\"\r\n                        class=\"theme-input\"\r\n        >\r\n        </haz-core-input>\r\n    </div>\r\n\r\n</form>\r\n");

/***/ }),

/***/ "./src/app/pages/tasks/task-form/task-form.component.scss":
/*!****************************************************************!*\
  !*** ./src/app/pages/tasks/task-form/task-form.component.scss ***!
  \****************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".color-red {\n  color: #ff0000;\n}\n\n.color-amber {\n  color: #ff7b00;\n}\n\n.color-green {\n  color: #038f03;\n}\n\n.color-nocolor {\n  color: #bebebe;\n}\n\n.label-style {\n  font-family: \"Roboto\", sans-serif;\n  font-weight: 500;\n  font-size: 16px;\n}\n\n::ng-deep .mat-form-field-appearance-fill.mat-form-field-disabled .mat-form-field-flex {\n  background-color: #e8f0fe;\n}\n\n::ng-deep .theme-input .mat-form-field-flex {\n  background-color: #e8f0fe;\n}\n\n.input-w {\n  width: 100%;\n}\n\n.color-none {\n  color: #bebebe;\n}\n\n.color-circle {\n  width: 12px;\n  height: 12px;\n  border-radius: 50%;\n  position: absolute;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvdGFza3MvdGFzay1mb3JtL0Q6XFxwcm9qZWN0c1xcaWloZlxcd2ZtLXdlYi9zcmNcXGFwcFxccGFnZXNcXHRhc2tzXFx0YXNrLWZvcm1cXHRhc2stZm9ybS5jb21wb25lbnQuc2NzcyIsInNyYy9hcHAvcGFnZXMvdGFza3MvdGFzay1mb3JtL3Rhc2stZm9ybS5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFXSTtFQUNJLGNBVEM7QUNEVDs7QURTSTtFQUNJLGNBVEM7QUNHVDs7QURLSTtFQUNJLGNBVEM7QUNPVDs7QURDSTtFQUNJLGNBVEM7QUNXVDs7QURFQTtFQUNJLGlDQUFBO0VBQ0EsZ0JBQUE7RUFDQSxlQUFBO0FDQ0o7O0FER0k7RUFDSSx5QkFBQTtBQ0FSOztBREtJO0VBQ0kseUJBQUE7QUNGUjs7QURNQTtFQUNJLFdBQUE7QUNISjs7QURNQTtFQUNJLGNBQUE7QUNISjs7QURNQTtFQUNJLFdBQUE7RUFDQSxZQUFBO0VBQ0Esa0JBQUE7RUFDQSxrQkFBQTtBQ0hKIiwiZmlsZSI6InNyYy9hcHAvcGFnZXMvdGFza3MvdGFzay1mb3JtL3Rhc2stZm9ybS5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIiRjb2xvci1wcmltYXJ5OiAjMTU5NWQzO1xyXG4kY29sb3Itc2Vjb25kYXJ5OiAjMDAyZDYyO1xyXG5cclxuJGNvbG9yczogKFxyXG4gICAgcmVkOiAjZmYwMDAwLFxyXG4gICAgYW1iZXI6ICNmZjdiMDAsXHJcbiAgICBncmVlbjogIzAzOGYwMyxcclxuICAgIG5vY29sb3I6ICNiZWJlYmVcclxuKTtcclxuXHJcbkBlYWNoICRjb2xvci1uYW1lLCAkY29sb3IgaW4gJGNvbG9ycyB7XHJcbiAgICAuY29sb3ItI3skY29sb3ItbmFtZX0ge1xyXG4gICAgICAgIGNvbG9yOiAkY29sb3I7XHJcbiAgICB9XHJcbn1cclxuXHJcbi5sYWJlbC1zdHlsZSB7XHJcbiAgICBmb250LWZhbWlseTogJ1JvYm90bycsIHNhbnMtc2VyaWY7XHJcbiAgICBmb250LXdlaWdodDogNTAwO1xyXG4gICAgZm9udC1zaXplOiAxNnB4O1xyXG59XHJcblxyXG46Om5nLWRlZXAge1xyXG4gICAgLm1hdC1mb3JtLWZpZWxkLWFwcGVhcmFuY2UtZmlsbC5tYXQtZm9ybS1maWVsZC1kaXNhYmxlZCAubWF0LWZvcm0tZmllbGQtZmxleCB7XHJcbiAgICAgICAgYmFja2dyb3VuZC1jb2xvcjogI2U4ZjBmZTtcclxuICAgIH1cclxufVxyXG5cclxuOjpuZy1kZWVwIHtcclxuICAgIC50aGVtZS1pbnB1dCAubWF0LWZvcm0tZmllbGQtZmxleCB7XHJcbiAgICAgICAgYmFja2dyb3VuZC1jb2xvcjogI2U4ZjBmZTtcclxuICAgIH1cclxufVxyXG5cclxuLmlucHV0LXcge1xyXG4gICAgd2lkdGg6IDEwMCU7XHJcbn1cclxuXHJcbi5jb2xvci1ub25lIHtcclxuICAgIGNvbG9yOiAjYmViZWJlO1xyXG59XHJcblxyXG4uY29sb3ItY2lyY2xlIHtcclxuICAgIHdpZHRoOiAxMnB4O1xyXG4gICAgaGVpZ2h0OiAxMnB4O1xyXG4gICAgYm9yZGVyLXJhZGl1czogNTAlO1xyXG4gICAgcG9zaXRpb246IGFic29sdXRlO1xyXG59XHJcbiIsIi5jb2xvci1yZWQge1xuICBjb2xvcjogI2ZmMDAwMDtcbn1cblxuLmNvbG9yLWFtYmVyIHtcbiAgY29sb3I6ICNmZjdiMDA7XG59XG5cbi5jb2xvci1ncmVlbiB7XG4gIGNvbG9yOiAjMDM4ZjAzO1xufVxuXG4uY29sb3Itbm9jb2xvciB7XG4gIGNvbG9yOiAjYmViZWJlO1xufVxuXG4ubGFiZWwtc3R5bGUge1xuICBmb250LWZhbWlseTogXCJSb2JvdG9cIiwgc2Fucy1zZXJpZjtcbiAgZm9udC13ZWlnaHQ6IDUwMDtcbiAgZm9udC1zaXplOiAxNnB4O1xufVxuXG46Om5nLWRlZXAgLm1hdC1mb3JtLWZpZWxkLWFwcGVhcmFuY2UtZmlsbC5tYXQtZm9ybS1maWVsZC1kaXNhYmxlZCAubWF0LWZvcm0tZmllbGQtZmxleCB7XG4gIGJhY2tncm91bmQtY29sb3I6ICNlOGYwZmU7XG59XG5cbjo6bmctZGVlcCAudGhlbWUtaW5wdXQgLm1hdC1mb3JtLWZpZWxkLWZsZXgge1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjZThmMGZlO1xufVxuXG4uaW5wdXQtdyB7XG4gIHdpZHRoOiAxMDAlO1xufVxuXG4uY29sb3Itbm9uZSB7XG4gIGNvbG9yOiAjYmViZWJlO1xufVxuXG4uY29sb3ItY2lyY2xlIHtcbiAgd2lkdGg6IDEycHg7XG4gIGhlaWdodDogMTJweDtcbiAgYm9yZGVyLXJhZGl1czogNTAlO1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG59Il19 */");

/***/ }),

/***/ "./src/app/pages/tasks/task-form/task-form.component.ts":
/*!**************************************************************!*\
  !*** ./src/app/pages/tasks/task-form/task-form.component.ts ***!
  \**************************************************************/
/*! exports provided: PROJECT_DATE_FORMATS, TaskFormComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PROJECT_DATE_FORMATS", function() { return PROJECT_DATE_FORMATS; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TaskFormComponent", function() { return TaskFormComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_material_moment_adapter__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/material-moment-adapter */ "./node_modules/@angular/material-moment-adapter/esm5/material-moment-adapter.es5.js");
/* harmony import */ var _angular_material_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/material/core */ "./node_modules/@angular/material/esm5/core.es5.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! moment */ "./node_modules/moment/moment.js");
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _shared_services_data_business_area_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../../shared/services/data/business-area.service */ "./src/app/shared/services/data/business-area.service.ts");
/* harmony import */ var _shared_services_data_phase_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../../shared/services/data/phase.service */ "./src/app/shared/services/data/phase.service.ts");
/* harmony import */ var _shared_services_data_task_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../../shared/services/data/task.service */ "./src/app/shared/services/data/task.service.ts");
/* harmony import */ var _shared_services_data_user_data_service__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../../shared/services/data/user-data.service */ "./src/app/shared/services/data/user-data.service.ts");
/* harmony import */ var _shared_services_data_venue_service__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../../shared/services/data/venue.service */ "./src/app/shared/services/data/venue.service.ts");
/* harmony import */ var _shared_services_notification_service__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../../../shared/services/notification.service */ "./src/app/shared/services/notification.service.ts");
/* harmony import */ var _shared_services_storage_project_event_service__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../../../shared/services/storage/project-event.service */ "./src/app/shared/services/storage/project-event.service.ts");














var moment = moment__WEBPACK_IMPORTED_MODULE_6__;
var PROJECT_DATE_FORMATS = {
    parse: {
        dateInput: 'D.M.YYYY',
    },
    display: {
        dateInput: 'D.M.YYYY',
        monthYearLabel: 'D.M.YYYY',
        dateA11yLabel: 'D.M.YYYY',
        monthYearA11yLabel: 'D.M.YYYY',
    },
};
var TaskFormComponent = /** @class */ (function () {
    function TaskFormComponent(formBuilder, businessAreaService, phaseService, venueService, userDataService, projectEventService, activatedRoute, notificationService, taskService) {
        this.formBuilder = formBuilder;
        this.businessAreaService = businessAreaService;
        this.phaseService = phaseService;
        this.venueService = venueService;
        this.userDataService = userDataService;
        this.projectEventService = projectEventService;
        this.activatedRoute = activatedRoute;
        this.notificationService = notificationService;
        this.taskService = taskService;
        this.onFormDataChange = new _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"]();
        this.taskTypeList = ['Task', 'Issue'];
        this.trafficLightList = ['red', 'amber', 'green', 'none'];
        this.dateInvalid = false;
        this.dateInvalidClosed = false;
        this.isUpdate = false;
        this.formLoaded = false;
        this.dateClass = function (d) {
            var day = moment(d).toDate().getDay();
            return (day === 0 || day === 6) ? 'custom-date-class' : undefined;
        };
    }
    TaskFormComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.loadBusinessAreaList();
        this.loadSourceOfAgendaList();
        this.loadPhaseList();
        this.loadVenueList();
        this.loadUserList();
        this.createForm();
        this.checkIfUpdate();
        this.taskForm.get('taskType').valueChanges.subscribe(function (value) {
            _this.onTypeChanged(value);
        });
    };
    Object.defineProperty(TaskFormComponent.prototype, "f", {
        get: function () {
            return this.taskForm.controls;
        },
        enumerable: true,
        configurable: true
    });
    TaskFormComponent.prototype.onDateChanged = function (event) {
        this.dateInvalid = true;
    };
    TaskFormComponent.prototype.onDateChangedClosed = function (event) {
        this.dateInvalidClosed = true;
    };
    TaskFormComponent.prototype.getCircleColor = function (value) {
        switch (value) {
            case 'red':
                return '#ce211f';
            case 'amber':
                return '#f79824';
            case 'green':
                return '#20bf55';
            default:
                return 'none';
        }
    };
    TaskFormComponent.prototype.loadBusinessAreaList = function () {
        var _this = this;
        this.businessAreaService.listBusinessAreas().subscribe(function (data) {
            _this.businessAreaList = data.content
                .filter(function (item) { return item.codeItem !== null && item.state === 'VALID'; });
        });
    };
    TaskFormComponent.prototype.loadSourceOfAgendaList = function () {
        var _this = this;
        this.businessAreaService.listSourceOfAgendas().subscribe(function (data) {
            _this.sourceOfAgendaList = data.content
                .filter(function (item) { return item.state === 'VALID'; });
        });
    };
    TaskFormComponent.prototype.loadPhaseList = function () {
        var _this = this;
        this.phaseService.getPhasesByProjectId(this.projectEventService.instant.id).subscribe(function (data) {
            _this.phaseList = data;
        });
    };
    TaskFormComponent.prototype.loadVenueList = function () {
        var _this = this;
        this.venueService.getVenuesByProjectId(this.projectEventService.instant.id).subscribe(function (data) {
            _this.venueList = data;
        });
    };
    TaskFormComponent.prototype.loadUserList = function () {
        var _this = this;
        this.userDataService.getUsers().subscribe(function (data) {
            _this.userList = data;
        });
    };
    TaskFormComponent.prototype.onTypeChanged = function (type) {
        if (type === 'ISSUE' && this.taskForm.get('trafficLight') === null) {
            this.taskForm.addControl('trafficLight', this.formBuilder.control(null, [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required]));
            this.taskForm.get('trafficLight').setValue('');
        }
        if (type === 'TASK') {
            this.taskForm.removeControl('trafficLight');
        }
    };
    TaskFormComponent.prototype.createForm = function () {
        var _this = this;
        this.taskForm = this.formBuilder.group({
            taskType: ['TASK', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
            title: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
            businessArea: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
            sourceOfAgenda: [''],
            phase: [''],
            dueDate: [null],
            responsible: [''],
            venue: ['NONE'],
            description: [''],
            sourceDescription: [''],
            state: [''],
            code: [''],
            closedDate: [''],
            changedBy: [''],
            changedAt: [''],
        });
        this.taskForm.valueChanges.subscribe(function () {
            _this.emitFormDataChangeEmitter();
        });
    };
    TaskFormComponent.prototype.emitFormDataChangeEmitter = function () {
        if (this.taskForm.invalid) {
            this.onFormDataChange.emit(null);
        }
        else {
            var actualValue = tslib__WEBPACK_IMPORTED_MODULE_0__["__assign"]({}, this.taskForm.value);
            this.onFormDataChange.emit(actualValue);
        }
    };
    TaskFormComponent.prototype.checkIfUpdate = function () {
        var _this = this;
        this.activatedRoute.queryParams.subscribe(function (param) {
            if (Object.keys(param).length > 0) {
                _this.isUpdate = true;
                _this.getIdFromRouteParamsAndSetDetail(param);
            }
        });
    };
    TaskFormComponent.prototype.getIdFromRouteParamsAndSetDetail = function (param) {
        var _this = this;
        this.taskService.getTaskById(param.id).subscribe(function (apiTask) {
            _this.setForm(apiTask);
        }, function (error) { return _this.notificationService.openErrorNotification(error); });
    };
    TaskFormComponent.prototype.setForm = function (task) {
        var _this = this;
        this.taskForm = this.formBuilder.group({
            taskType: ['TASK', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
            title: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
            businessArea: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
            sourceOfAgenda: [''],
            phase: [''],
            dueDate: [null],
            responsible: [''],
            venue: [''],
            description: [''],
            sourceDescription: [''],
            state: [''],
            code: [''],
            closedDate: [''],
            changedBy: [''],
            changedAt: [''],
        });
        this.taskForm.controls.title.patchValue(task.name);
        this.taskForm.controls.taskType.patchValue(task.taskType);
        if (task.projectPhase) {
            this.taskForm.controls.phase.patchValue(task.projectPhase.id);
        }
        this.taskForm.controls.businessArea.patchValue(task.clBusinessArea.id);
        if (task.dueDate) {
            this.taskForm.controls.dueDate.patchValue(task.dueDate);
        }
        if (task.closedDate) {
            this.taskForm.controls.closedDate.patchValue(task.closedDate);
        }
        if (task.responsibleUser) {
            this.taskForm.controls.responsible.patchValue(task.responsibleUser.id);
        }
        if (task.clSourceOfAgenda) {
            this.taskForm.controls.sourceOfAgenda.patchValue(task.clSourceOfAgenda.id);
        }
        if (task.cityName) {
            this.taskForm.controls.venue.patchValue(task.cityName);
        }
        if (task.description) {
            this.taskForm.controls.description.patchValue(task.description);
        }
        if (task.sourceDescription) {
            this.taskForm.controls.sourceDescription.patchValue(task.sourceDescription);
        }
        if (task.state) {
            this.taskForm.controls.state.patchValue(task.state);
        }
        if (task.code) {
            this.taskForm.controls.code.patchValue(task.code);
        }
        if (task.trafficLight) {
            this.taskForm.addControl('trafficLight', this.formBuilder.control(null, [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required]));
            this.taskForm.get('trafficLight').setValue(task.trafficLight);
        }
        if (task.changedAt) {
            this.taskForm.controls.changedAt.patchValue(moment(task.changedAt).format('D.M.YYYY - HH:mm:ss'));
        }
        if (task.changedBy) {
            this.taskForm.controls.changedBy.patchValue(task.changedBy.firstName + " " + task.changedBy.lastName);
        }
        this.taskForm.controls.taskType.disable();
        this.taskForm.controls.businessArea.disable();
        this.taskForm.controls.code.disable();
        this.taskForm.controls.closedDate.disable();
        this.taskForm.controls.changedAt.disable();
        this.taskForm.controls.changedBy.disable();
        this.taskForm.updateValueAndValidity();
        this.formLoaded = true;
        this.taskForm.valueChanges.subscribe(function () {
            _this.emitFormDataChangeEmitter();
        });
    };
    TaskFormComponent.ctorParameters = function () { return [
        { type: _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormBuilder"] },
        { type: _shared_services_data_business_area_service__WEBPACK_IMPORTED_MODULE_7__["BusinessAreaService"] },
        { type: _shared_services_data_phase_service__WEBPACK_IMPORTED_MODULE_8__["PhaseService"] },
        { type: _shared_services_data_venue_service__WEBPACK_IMPORTED_MODULE_11__["VenueService"] },
        { type: _shared_services_data_user_data_service__WEBPACK_IMPORTED_MODULE_10__["UserDataService"] },
        { type: _shared_services_storage_project_event_service__WEBPACK_IMPORTED_MODULE_13__["ProjectEventService"] },
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__["ActivatedRoute"] },
        { type: _shared_services_notification_service__WEBPACK_IMPORTED_MODULE_12__["NotificationService"] },
        { type: _shared_services_data_task_service__WEBPACK_IMPORTED_MODULE_9__["TaskService"] }
    ]; };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Output"])('formDataChange'),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], TaskFormComponent.prototype, "onFormDataChange", void 0);
    TaskFormComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'task-form',
            template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./task-form.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/tasks/task-form/task-form.component.html")).default,
            providers: [
                { provide: _angular_material_core__WEBPACK_IMPORTED_MODULE_4__["DateAdapter"], useClass: _angular_material_moment_adapter__WEBPACK_IMPORTED_MODULE_3__["MomentDateAdapter"], deps: [_angular_material_core__WEBPACK_IMPORTED_MODULE_4__["MAT_DATE_LOCALE"]] },
                { provide: _angular_material_core__WEBPACK_IMPORTED_MODULE_4__["MAT_DATE_FORMATS"], useValue: PROJECT_DATE_FORMATS },
            ],
            styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./task-form.component.scss */ "./src/app/pages/tasks/task-form/task-form.component.scss")).default]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormBuilder"],
            _shared_services_data_business_area_service__WEBPACK_IMPORTED_MODULE_7__["BusinessAreaService"],
            _shared_services_data_phase_service__WEBPACK_IMPORTED_MODULE_8__["PhaseService"],
            _shared_services_data_venue_service__WEBPACK_IMPORTED_MODULE_11__["VenueService"],
            _shared_services_data_user_data_service__WEBPACK_IMPORTED_MODULE_10__["UserDataService"],
            _shared_services_storage_project_event_service__WEBPACK_IMPORTED_MODULE_13__["ProjectEventService"],
            _angular_router__WEBPACK_IMPORTED_MODULE_5__["ActivatedRoute"],
            _shared_services_notification_service__WEBPACK_IMPORTED_MODULE_12__["NotificationService"],
            _shared_services_data_task_service__WEBPACK_IMPORTED_MODULE_9__["TaskService"]])
    ], TaskFormComponent);
    return TaskFormComponent;
}());



/***/ }),

/***/ "./src/app/shared/hazlenut/abstract-inputs/index.ts":
/*!**********************************************************!*\
  !*** ./src/app/shared/hazlenut/abstract-inputs/index.ts ***!
  \**********************************************************/
/*! exports provided: ABSTRACT_INPUT_TOKEN, AbstractInputsModule, ValidatorComposer, InputNumberComponent, CoreInputComponent, FORMAT, InputDateComponent, InputDateRangeComponent, InputNumberRangeComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _abstract_inputs_config__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./abstract-inputs-config */ "./src/app/shared/hazlenut/abstract-inputs/abstract-inputs-config.ts");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "ABSTRACT_INPUT_TOKEN", function() { return _abstract_inputs_config__WEBPACK_IMPORTED_MODULE_1__["ABSTRACT_INPUT_TOKEN"]; });

/* harmony import */ var _abstract_inputs_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./abstract-inputs.module */ "./src/app/shared/hazlenut/abstract-inputs/abstract-inputs.module.ts");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "AbstractInputsModule", function() { return _abstract_inputs_module__WEBPACK_IMPORTED_MODULE_2__["AbstractInputsModule"]; });

/* harmony import */ var _validator_composer__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./validator-composer */ "./src/app/shared/hazlenut/abstract-inputs/validator-composer.ts");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "ValidatorComposer", function() { return _validator_composer__WEBPACK_IMPORTED_MODULE_3__["ValidatorComposer"]; });

/* harmony import */ var _input_number_input_number_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./input-number/input-number.component */ "./src/app/shared/hazlenut/abstract-inputs/input-number/input-number.component.ts");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "InputNumberComponent", function() { return _input_number_input_number_component__WEBPACK_IMPORTED_MODULE_4__["InputNumberComponent"]; });

/* harmony import */ var _core_input_core_input_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./core-input/core-input.component */ "./src/app/shared/hazlenut/abstract-inputs/core-input/core-input.component.ts");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "CoreInputComponent", function() { return _core_input_core_input_component__WEBPACK_IMPORTED_MODULE_5__["CoreInputComponent"]; });

/* harmony import */ var _input_date_input_date_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./input-date/input-date.component */ "./src/app/shared/hazlenut/abstract-inputs/input-date/input-date.component.ts");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "FORMAT", function() { return _input_date_input_date_component__WEBPACK_IMPORTED_MODULE_6__["FORMAT"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "InputDateComponent", function() { return _input_date_input_date_component__WEBPACK_IMPORTED_MODULE_6__["InputDateComponent"]; });

/* harmony import */ var _input_date_range_input_date_range_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./input-date-range/input-date-range.component */ "./src/app/shared/hazlenut/abstract-inputs/input-date-range/input-date-range.component.ts");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "InputDateRangeComponent", function() { return _input_date_range_input_date_range_component__WEBPACK_IMPORTED_MODULE_7__["InputDateRangeComponent"]; });

/* harmony import */ var _input_number_range_input_number_range_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./input-number-range/input-number-range.component */ "./src/app/shared/hazlenut/abstract-inputs/input-number-range/input-number-range.component.ts");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "InputNumberRangeComponent", function() { return _input_number_range_input_number_range_component__WEBPACK_IMPORTED_MODULE_8__["InputNumberRangeComponent"]; });












/***/ }),

/***/ "./src/app/shared/hazlenut/hazelnut-common/utils/file-manager.ts":
/*!***********************************************************************!*\
  !*** ./src/app/shared/hazlenut/hazelnut-common/utils/file-manager.ts ***!
  \***********************************************************************/
/*! exports provided: FileManager */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FileManager", function() { return FileManager; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");

var FileManager = /** @class */ (function () {
    function FileManager() {
        this._input = document.createElement('input');
        this._input.setAttribute('type', 'file');
        this._input.setAttribute('value', 'files');
        this._input.setAttribute('multiple', '');
        this._input.setAttribute('class', 'hide');
        this._link = document.createElement('a');
        this._link.setAttribute('class', 'hide');
        this._link.setAttribute('href', '');
    }
    FileManager.prototype.saveFile = function (name, text, type) {
        if (type === void 0) { type = 'text/plain'; }
        document.body.appendChild(this._link);
        this._link.href = URL.createObjectURL(new Blob([text], { type: type }));
        this._link.download = name;
        this._link.click();
        document.body.removeChild(this._link);
    };
    FileManager.prototype.saveImage = function (name, image) {
        document.body.appendChild(this._link);
        this._link.href = typeof image === 'string' ? image : image.src;
        this._link.download = name;
        this._link.click();
        document.body.removeChild(this._link);
    };
    FileManager.prototype.saveImageByNameAndSource = function (name, src) {
        document.body.appendChild(this._link);
        this._link.href = src;
        this._link.download = name;
        this._link.click();
        document.body.removeChild(this._link);
    };
    FileManager.prototype.loadImage = function (func) {
        var _this = this;
        this.onFileChange(function (files) {
            var reader = new FileReader();
            reader.onload = function () {
                var image = new Image();
                image.src = reader.result;
                _this._input.value = null;
                func(image, files[0]);
            };
            reader.readAsDataURL(files[0]);
        });
    };
    FileManager.prototype.loadImages = function (func) {
        var _this = this;
        this.onFileChange(function (files) {
            var promises = [];
            var _loop_1 = function (file) {
                promises.push(new Promise(function (success, reject) {
                    var reader = new FileReader();
                    reader.onload = function () {
                        var image = new Image();
                        image.src = reader.result;
                        success({ image: image, file: file });
                    };
                    reader.onerror = function () { return reject(reader.error); };
                    reader.readAsDataURL(file);
                }));
            };
            for (var _i = 0, files_1 = files; _i < files_1.length; _i++) {
                var file = files_1[_i];
                _loop_1(file);
            }
            Promise.all(promises).then(function (data) {
                _this._input.value = null;
                func(data);
            }).catch(function (error) {
                throw new Error('Cannot upload files: ' + error.message);
            });
        });
    };
    FileManager.prototype.loadFile = function (func) {
        this._input.onchange = function (e) {
            var reader = new FileReader();
            reader.onload = function () { return func(reader.result); };
            reader.readAsText(e.target.files[0]);
        };
        this._input.click();
    };
    FileManager.prototype.loadBinaryFile = function (func) {
        this._input.onchange = function (event) {
            var reader = new FileReader();
            var files = event.target.files;
            if (files.length > 0) {
                reader.onload = function () { return func(reader.result, files[0].name); };
                reader.readAsBinaryString(files[0]);
            }
        };
        this._input.click();
    };
    FileManager.prototype.onFileChange = function (callback) {
        this._input.onchange = function (event) {
            var files = event.target.files;
            if (files.length > 0) {
                callback(files);
            }
        };
        this._input.click();
    };
    return FileManager;
}());



/***/ }),

/***/ "./src/app/shared/services/data/phase.service.ts":
/*!*******************************************************!*\
  !*** ./src/app/shared/services/data/phase.service.ts ***!
  \*******************************************************/
/*! exports provided: PhaseService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PhaseService", function() { return PhaseService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _notification_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../notification.service */ "./src/app/shared/services/notification.service.ts");
/* harmony import */ var _project_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../project.service */ "./src/app/shared/services/project.service.ts");
/* harmony import */ var _storage_project_user_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../storage/project-user.service */ "./src/app/shared/services/storage/project-user.service.ts");






var PhaseService = /** @class */ (function (_super) {
    tslib__WEBPACK_IMPORTED_MODULE_0__["__extends"](PhaseService, _super);
    function PhaseService(http, notificationService, userService) {
        return _super.call(this, http, 'phase', notificationService, userService) || this;
    }
    /**
     * Get phases objects from API
     * @param projectId
     */
    PhaseService.prototype.getPhasesByProjectId = function (projectId) {
        return this.getDetail(projectId);
    };
    PhaseService.ctorParameters = function () { return [
        { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"] },
        { type: _notification_service__WEBPACK_IMPORTED_MODULE_3__["NotificationService"] },
        { type: _storage_project_user_service__WEBPACK_IMPORTED_MODULE_5__["ProjectUserService"] }
    ]; };
    PhaseService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Injectable"])({
            providedIn: 'root'
        })
        /**
         * Fact service communicating with 'phase' API url
         */
        ,
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"],
            _notification_service__WEBPACK_IMPORTED_MODULE_3__["NotificationService"],
            _storage_project_user_service__WEBPACK_IMPORTED_MODULE_5__["ProjectUserService"]])
    ], PhaseService);
    return PhaseService;
}(_project_service__WEBPACK_IMPORTED_MODULE_4__["ProjectService"]));



/***/ }),

/***/ "./src/app/shared/services/data/task.service.ts":
/*!******************************************************!*\
  !*** ./src/app/shared/services/data/task.service.ts ***!
  \******************************************************/
/*! exports provided: TaskService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TaskService", function() { return TaskService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _hazlenut_hazelnut_common_hazelnut__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../hazlenut/hazelnut-common/hazelnut */ "./src/app/shared/hazlenut/hazelnut-common/hazelnut/index.ts");
/* harmony import */ var _hazlenut_hazelnut_common_models__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../hazlenut/hazelnut-common/models */ "./src/app/shared/hazlenut/hazelnut-common/models/index.ts");
/* harmony import */ var _notification_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../notification.service */ "./src/app/shared/services/notification.service.ts");
/* harmony import */ var _project_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../project.service */ "./src/app/shared/services/project.service.ts");
/* harmony import */ var _storage_project_user_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../storage/project-user.service */ "./src/app/shared/services/storage/project-user.service.ts");








var TaskService = /** @class */ (function (_super) {
    tslib__WEBPACK_IMPORTED_MODULE_0__["__extends"](TaskService, _super);
    function TaskService(http, notificationService, userService) {
        return _super.call(this, http, 'task', notificationService, userService) || this;
    }
    /**
     * Ger task objects from API based on criteria
     * @param tableChangeEvent
     * @param additionalFilters
     */
    TaskService.prototype.browseTasks = function (tableChangeEvent, additionalFilters) {
        var filters = [];
        var sort = [];
        var limit = 15;
        var offset = 0;
        if (tableChangeEvent) {
            limit = tableChangeEvent.pageSize;
            offset = tableChangeEvent.pageIndex * tableChangeEvent.pageSize;
            filters = Object.values(tableChangeEvent.filters);
            filters.forEach(function (filter) { return filter.property = _hazlenut_hazelnut_common_hazelnut__WEBPACK_IMPORTED_MODULE_3__["StringUtils"].convertCamelToSnakeUpper(filter.property); });
            if (tableChangeEvent.sortActive && tableChangeEvent.sortDirection) {
                sort = [new _hazlenut_hazelnut_common_models__WEBPACK_IMPORTED_MODULE_4__["Sort"](tableChangeEvent.sortActive, tableChangeEvent.sortDirection)];
            }
        }
        filters = filters.concat(additionalFilters);
        var allFilters = filters.filter(function (el) { return el.property === 'RESPONSIBLE_USER_ID'; });
        if (allFilters.length > 1) {
            var oneFilter = allFilters[allFilters.length - 1];
            filters = filters.filter(function (el) { return el.property !== 'RESPONSIBLE_USER_ID'; });
            if (oneFilter.value !== 'All') {
                filters.push(oneFilter);
            }
        }
        // Traffic color must be first to proper filtering
        filters = this.reorderFiltersToApplyCorectTrafficColor(filters);
        return this.browseWithSummary(_hazlenut_hazelnut_common_models__WEBPACK_IMPORTED_MODULE_4__["PostContent"].create(limit, offset, filters, sort));
    };
    /**
     * Report task objects into report file and download from API
     * @param tableChangeEvent
     * @param additionalFilters
     */
    TaskService.prototype.exportTasks = function (tableChangeEvent, additionalFilters, projectId) {
        var filters = [];
        var sort = [];
        if (tableChangeEvent && tableChangeEvent.sortActive && tableChangeEvent.sortDirection) {
            sort = [new _hazlenut_hazelnut_common_models__WEBPACK_IMPORTED_MODULE_4__["Sort"](tableChangeEvent.sortActive, tableChangeEvent.sortDirection)];
        }
        filters = filters.concat(additionalFilters);
        filters = this.reorderFiltersToApplyCorectTrafficColor(filters);
        return this.report(filters, sort, projectId);
    };
    /**
     * Create task object with API call
     * @param taskObject
     */
    TaskService.prototype.createTask = function (taskObject) {
        return this.add(taskObject);
    };
    /**
     * Edit task object with API call
     * @param id
     * @param taskObject
     */
    TaskService.prototype.editTask = function (id, taskObject) {
        return this.update(id, taskObject);
    };
    /**
     * Get task object from API
     * @param id
     */
    TaskService.prototype.getTaskById = function (id) {
        return this.getDetail(id);
    };
    /**
     * Reorder filters with conditiona that traffic light filters are first
     * @param filters
     */
    TaskService.prototype.reorderFiltersToApplyCorectTrafficColor = function (filters) {
        return filters.sort(this.compare);
    };
    /**
     * Compare sort function with traffic light property preselection
     * @param a
     * @param b
     */
    TaskService.prototype.compare = function (a, b) {
        if (a.property === 'TRAFFIC_LIGHT') {
            return -1;
        }
        if (a.property !== 'TRAFFIC_LIGHT') {
            return 1;
        }
        return 0;
    };
    TaskService.ctorParameters = function () { return [
        { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"] },
        { type: _notification_service__WEBPACK_IMPORTED_MODULE_5__["NotificationService"] },
        { type: _storage_project_user_service__WEBPACK_IMPORTED_MODULE_7__["ProjectUserService"] }
    ]; };
    TaskService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Injectable"])({
            providedIn: 'root'
        })
        /**
         * Fact service communicating with 'task' API url
         */
        ,
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"],
            _notification_service__WEBPACK_IMPORTED_MODULE_5__["NotificationService"],
            _storage_project_user_service__WEBPACK_IMPORTED_MODULE_7__["ProjectUserService"]])
    ], TaskService);
    return TaskService;
}(_project_service__WEBPACK_IMPORTED_MODULE_6__["ProjectService"]));



/***/ }),

/***/ "./src/app/shared/services/data/venue.service.ts":
/*!*******************************************************!*\
  !*** ./src/app/shared/services/data/venue.service.ts ***!
  \*******************************************************/
/*! exports provided: VenueService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "VenueService", function() { return VenueService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _notification_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../notification.service */ "./src/app/shared/services/notification.service.ts");
/* harmony import */ var _project_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../project.service */ "./src/app/shared/services/project.service.ts");
/* harmony import */ var _storage_project_user_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../storage/project-user.service */ "./src/app/shared/services/storage/project-user.service.ts");






var VenueService = /** @class */ (function (_super) {
    tslib__WEBPACK_IMPORTED_MODULE_0__["__extends"](VenueService, _super);
    function VenueService(http, notificationService, userService) {
        return _super.call(this, http, 'venue', notificationService, userService) || this;
    }
    /**
     * Get venue objects from API
     * @param projectId
     */
    VenueService.prototype.getVenuesByProjectId = function (projectId) {
        return this.getDetail(projectId);
    };
    VenueService.ctorParameters = function () { return [
        { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"] },
        { type: _notification_service__WEBPACK_IMPORTED_MODULE_3__["NotificationService"] },
        { type: _storage_project_user_service__WEBPACK_IMPORTED_MODULE_5__["ProjectUserService"] }
    ]; };
    VenueService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Injectable"])({
            providedIn: 'root'
        })
        /**
         * Fact service communicating with 'venue' API url
         */
        ,
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"],
            _notification_service__WEBPACK_IMPORTED_MODULE_3__["NotificationService"],
            _storage_project_user_service__WEBPACK_IMPORTED_MODULE_5__["ProjectUserService"]])
    ], VenueService);
    return VenueService;
}(_project_service__WEBPACK_IMPORTED_MODULE_4__["ProjectService"]));



/***/ }),

/***/ "./src/app/shared/services/table-change-storage.service.ts":
/*!*****************************************************************!*\
  !*** ./src/app/shared/services/table-change-storage.service.ts ***!
  \*****************************************************************/
/*! exports provided: TableChangeStorageService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TableChangeStorageService", function() { return TableChangeStorageService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");


var TableChangeStorageService = /** @class */ (function () {
    function TableChangeStorageService() {
    }
    /**
     * Storing data from task list and also additional filters, because we need business area filter which is not in
     * table
     * @param changeEvent
     * @param additionalFilers
     */
    TableChangeStorageService.prototype.setTasksLastTableChangeEvent = function (changeEvent, additionalFilers) {
        this.tasksLastTableChangeEvent = tslib__WEBPACK_IMPORTED_MODULE_0__["__assign"]({}, changeEvent, { filters: changeEvent.filters.slice(), additionalFilters: additionalFilers });
    };
    /**
     * Store table change event in facts
     * @param changeEvent
     */
    TableChangeStorageService.prototype.setFactsLastTableChangeEvent = function (changeEvent) {
        this.factsLastTableChangeEvent = tslib__WEBPACK_IMPORTED_MODULE_0__["__assign"]({}, changeEvent, { filters: changeEvent.filters.slice() });
    };
    /**
     * Get stored tasks table change event
     */
    TableChangeStorageService.prototype.getTasksLastTableChangeEvent = function () {
        return this.tasksLastTableChangeEvent;
    };
    /**
     * Get stored facts table change event
     */
    TableChangeStorageService.prototype.getFactsLastTableChangeEvent = function () {
        return this.factsLastTableChangeEvent;
    };
    TableChangeStorageService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root'
        })
        /**
         * Store table change events
         */
        ,
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
    ], TableChangeStorageService);
    return TableChangeStorageService;
}());



/***/ }),

/***/ "./src/app/shared/utils/headers.ts":
/*!*****************************************!*\
  !*** ./src/app/shared/utils/headers.ts ***!
  \*****************************************/
/*! exports provided: GetFileNameFromContentDisposition */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "GetFileNameFromContentDisposition", function() { return GetFileNameFromContentDisposition; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _hazlenut_hazelnut_common_regex_regex__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../hazlenut/hazelnut-common/regex/regex */ "./src/app/shared/hazlenut/hazelnut-common/regex/regex.ts");


function GetFileNameFromContentDisposition(disposition) {
    var exportName = 'EXPORT';
    if (disposition && disposition.indexOf('attachment') !== -1) {
        var filenameRegex = _hazlenut_hazelnut_common_regex_regex__WEBPACK_IMPORTED_MODULE_1__["Regex"].fileNameFromContentDispositionPattern;
        var matches = filenameRegex.exec(disposition);
        if (matches !== null && matches[1]) {
            exportName = matches[1].replace(/['"]/g, '');
        }
    }
    return exportName;
}


/***/ })

}]);
//# sourceMappingURL=default~pages-facts-facts-module~pages-tasks-tasks-module.js.map