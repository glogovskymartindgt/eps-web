(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-facts-facts-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/facts/fact-create/fact-create.component.html":
/*!**********************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/facts/fact-create/fact-create.component.html ***!
  \**********************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<!--Create fact form component-->\r\n<div fxLayout=\"row\" class=\"basic-screen-header\">\r\n    <div class=\"pl-50\" fxLayoutAlign=\"start center\">\r\n        <h3>{{'fact.newFact' | translate}}</h3>\r\n    </div>\r\n</div>\r\n\r\n<div fxLayout=\"row\" style=\"overflow: auto; height: calc(100vh - 160px);\">\r\n    <div class=\"p-30\">\r\n        <fact-form (formDataChange)=\"formData=$event\"></fact-form>\r\n        <div>\r\n            <button type=\"submit\"\r\n                    mat-flat-button\r\n                    color=\"accent\"\r\n                    class=\"mr-10\"\r\n                    (click)=\"onSave()\"\r\n                    [disabled]=\"formData === null\"\r\n            >\r\n                {{ 'tasks.save' | translate }}\r\n            </button>\r\n            <button type=\"button\"\r\n                    mat-button\r\n                    class=\"mr-10\"\r\n                    (click)=\"onCancel()\"\r\n            >\r\n                {{ 'tasks.cancel' | translate }}\r\n            </button>\r\n        </div>\r\n    </div>\r\n</div>\r\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/facts/fact-edit/fact-edit.component.html":
/*!******************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/facts/fact-edit/fact-edit.component.html ***!
  \******************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<!--Edit fact form with predefined values based on id from url parameters-->\r\n<div class=\"basic-screen-header\" fxLayout=\"row\">\r\n    <div class=\"pl-50\" fxLayoutAlign=\"start center\">\r\n        <h3>{{'fact.editFact' | translate}}</h3>\r\n    </div>\r\n</div>\r\n\r\n<div fxLayout=\"row\" style=\"overflow: auto;  height: calc(100vh - 160px);\">\r\n    <div class=\"p-30\">\r\n        <fact-form (formDataChange)=\"formData=$event\"></fact-form>\r\n        <div>\r\n            <button (click)=\"onSave()\"\r\n                    *ngIf=\"allowSaveButton()\"\r\n                    [disabled]=\"!formData || !canSave\"\r\n                    class=\"mr-10\"\r\n                    color=\"accent\"\r\n                    mat-flat-button\r\n                    type=\"submit\"\r\n            >\r\n                {{ 'tasks.save' | translate }}\r\n            </button>\r\n            <button (click)=\"onCancel()\"\r\n                    class=\"mr-10\"\r\n                    mat-button\r\n                    type=\"button\"\r\n            >\r\n                {{ 'tasks.cancel' | translate }}\r\n            </button>\r\n        </div>\r\n    </div>\r\n</div>\r\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/facts/fact-form/fact-form.component.html":
/*!******************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/facts/fact-form/fact-form.component.html ***!
  \******************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<form [formGroup]=\"factForm\">\r\n    <div>\r\n        <mat-form-field appearance=\"fill\" class=\"long-input\">\r\n            <mat-label>{{'fact.category' | translate}}</mat-label>\r\n            <mat-select formControlName=\"category\" required>\r\n                <ng-container *ngIf=\"!formLoaded\">\r\n                    <mat-option *ngFor=\"let category of categories\" [value]=\"category.id\">\r\n                        {{ category.name }}\r\n                    </mat-option>\r\n                </ng-container>\r\n                <mat-option *ngIf=\"formLoaded\" [value]=\"factForm?.value?.category\">\r\n                    {{factForm?.value?.category}}\r\n                </mat-option>\r\n            </mat-select>\r\n\r\n            <mat-error *ngIf=\"controls?.category?.errors?.required\">\r\n                {{ 'error.required' | translate }}\r\n            </mat-error>\r\n        </mat-form-field>\r\n    </div>\r\n\r\n    <div *ngIf=\"subCategories !== null || formLoaded\" [@enterLeaveSmooth]>\r\n        <mat-form-field appearance=\"fill\" class=\"long-input\">\r\n            <mat-label>{{'fact.factItemType' | translate}}</mat-label>\r\n            <mat-select formControlName=\"subCategory\" required>\r\n                <ng-container *ngIf=\"subCategories && subCategories.length && !formLoaded\">\r\n                    <mat-option *ngFor=\"let subcategory of subCategories\" [value]=\"subcategory.id\">\r\n                        <span class=\"fact-text\">{{ subcategory.subCategory }}</span>\r\n                    </mat-option>\r\n                </ng-container>\r\n                <mat-option\r\n                    *ngIf=\"subCategories && subCategories.length === 0 && !formLoaded\">{{'all.empty' | translate}}</mat-option>\r\n                <mat-option *ngIf=\"formLoaded\" [value]=\"factForm?.value?.subCategory\">\r\n                    {{factForm?.value?.subCategory}}\r\n                </mat-option>\r\n            </mat-select>\r\n            <mat-error *ngIf=\"controls?.subCategory?.errors?.required\">\r\n                {{ 'error.required' | translate }}\r\n            </mat-error>\r\n        </mat-form-field>\r\n    </div>\r\n\r\n    <div class=\"long-input\">\r\n        <haz-core-input formControlName=\"firstValue\"\r\n                        [label]=\"firstVenueLabel\"\r\n                        appearance=\"fill\"\r\n                        [textSuffix]=\"actualUnitShortName\"\r\n                        [allowedCharactersPattern]=\"decimalPattern\"\r\n                        [maxLength]=\"15\"\r\n                        [required]=\"'isFirstValueRequired'\"\r\n                        [handleFocusAndBlur]='true'\r\n                        [inputStyles]=\"{width: '100%', 'position': 'relative', 'right': '5px', 'text-align': 'right'}\"\r\n        >\r\n        </haz-core-input>\r\n    </div>\r\n    <div class=\"long-input\">\r\n        <haz-core-input formControlName=\"secondValue\"\r\n                        [label]=\"secondVenueLabel\"\r\n                        appearance=\"fill\"\r\n                        [textSuffix]=\"actualUnitShortName\"\r\n                        [allowedCharactersPattern]=\"decimalPattern\"\r\n                        [maxLength]=\"15\"\r\n                        [required]=\"'isSecondValueRequired'\"\r\n                        [handleFocusAndBlur]='true'\r\n                        [inputStyles]=\"{width: '100%', 'position': 'relative', 'right': '5px', 'text-align': 'right'}\"\r\n        >\r\n        </haz-core-input>\r\n    </div>\r\n    <div class=\"mb-20\">\r\n        <mat-checkbox formControlName=\"hasOnlyTotalValue\">{{'fact.hasOnlyTotalValue' | translate}}</mat-checkbox>\r\n    </div>\r\n    <div class=\"long-input\">\r\n        <haz-core-input formControlName=\"totalValue\"\r\n                        [label]=\"'fact.totalValue' | translate\"\r\n                        appearance=\"fill\"\r\n                        [textSuffix]=\"actualUnitShortName\"\r\n                        [allowedCharactersPattern]=\"decimalPattern\"\r\n                        [maxLength]=\"15\"\r\n                        [required]=\"'isTotalRequired'\"\r\n                        [handleFocusAndBlur]='true'\r\n                        [inputStyles]=\"{width: '100%', 'position': 'relative', 'right': '5px', 'text-align': 'right'}\"\r\n        >\r\n        </haz-core-input>\r\n    </div>\r\n\r\n    <div class=\"long-input\" *ngIf=\"formLoaded\">\r\n        <haz-core-input [label]=\"'fact.changedAt' |  translate\"\r\n                        [appearance]=\"'fill'\"\r\n                        formControlName=\"changedAt\"\r\n                        class=\"theme-input\"\r\n        >\r\n        </haz-core-input>\r\n    </div>\r\n\r\n    <div class=\"long-input\" *ngIf=\"formLoaded\">\r\n        <haz-core-input [label]=\"'fact.changedBy' | translate\"\r\n                        [appearance]=\"'fill'\"\r\n                        formControlName=\"changedBy\"\r\n                        class=\"theme-input\"\r\n        >\r\n        </haz-core-input>\r\n    </div>\r\n    \r\n</form>\r\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/facts/fact-list/fact-list.component.html":
/*!******************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/facts/fact-list/fact-list.component.html ***!
  \******************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<!--List of facts and figures with title, create button and table with loader-->\r\n<div>\r\n    <div class=\"basic-screen-header\" fxLayout=\"row\">\r\n        <div class=\"pl-50\" fxFlex=\"400px\" fxLayoutAlign=\"start center\">\r\n            <h2>{{ (allFacts ? 'fact.titleAllFacts' : 'fact.title') | translate}}</h2>\r\n        </div>\r\n        <!--Fact create button is only in Facts and Figures screen in active project, not in All Facts and Figures-->\r\n        <div *ngIf=\"allowCreateFactButton()\" fxFlex fxLayoutAlign=\"end center\">\r\n            <button (click)=\"createFact()\"\r\n                    *ngIf=\"projectEventService.instant.active && !allFacts\"\r\n                    class=\"mr-10\"\r\n                    color=\"accent\"\r\n                    mat-raised-button\r\n            >\r\n                {{'common.create' | translate}}\r\n            </button>\r\n            <button mat-flat-button (click)=\"export()\" class=\"mr-10\" color=\"accent\" *ngIf=\"allowExportAllFactItemButton()\">\r\n                {{'common.export' | translate}}\r\n            </button>\r\n        </div>\r\n    </div>\r\n\r\n    <div *ngIf=\"(!projectEventService.instant.firstVenue || !projectEventService.instant.secondVenue) && !router.url.includes('all-facts')\">\r\n        <p class=\"text-unavailable-facts\">{{'fact.unavailable' | translate}}</p>\r\n    </div>\r\n    <!--Core table with custom columns, value columns have measureUnit-->\r\n    <haz-core-table (requestData)=\"setTableData($event)\"\r\n                    *ngIf=\"!((!projectEventService.instant.firstVenue || !projectEventService.instant.secondVenue) && !router.url.includes('all-facts'))\"\r\n                    [configuration]=\"config\"\r\n                    [data]=\"data\"\r\n    >\r\n    </haz-core-table>\r\n    <ng-template #categoryColumn let-actRow=\"row\" let-context=\"context\">\r\n        {{actRow.categoryName}}\r\n    </ng-template>\r\n    <ng-template #firstValueColumn let-actRow=\"row\" let-context=\"context\">\r\n        <div class=\"fr\">\r\n            {{actRow?.valueFirst === null ? '-' : actRow?.valueFirst | thousandDelimiter: ','}} {{actRow?.valueFirst === null ? '' : actRow.measureUnit}}\r\n        </div>\r\n    </ng-template>\r\n    <ng-template #secondValueColumn let-actRow=\"row\" let-context=\"context\">\r\n        <div class=\"fr\">\r\n            {{actRow?.valueSecond === null ? '-' : actRow?.valueSecond | thousandDelimiter: ','}} {{actRow?.valueSecond === null ? '' : actRow.measureUnit}}\r\n        </div>\r\n    </ng-template>\r\n    <ng-template #totalValueColumn let-actRow=\"row\" let-context=\"context\">\r\n        <div class=\"fr\">\r\n            {{actRow?.totalValue === null ? '-' : actRow?.totalValue | thousandDelimiter: ','}} {{actRow?.totalValue !== null ? actRow.measureUnit : ''}}\r\n        </div>\r\n    </ng-template>\r\n    <ng-template #updateColumn let-actRow=\"row\" let-context=\"context\">\r\n        <div class=\"fr\" *ngIf=\"allowFactDetailButton()\">\r\n            <button (click)=\"update(actRow.id, actRow.year, actRow.projectId)\"\r\n                    mat-icon-button\r\n            >\r\n                <mat-icon>keyboard_arrow_right</mat-icon>\r\n            </button>\r\n        </div>\r\n    </ng-template>\r\n\r\n</div>\r\n");

/***/ }),

/***/ "./src/app/pages/facts/fact-create/fact-create.component.scss":
/*!********************************************************************!*\
  !*** ./src/app/pages/facts/fact-create/fact-create.component.scss ***!
  \********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL2ZhY3RzL2ZhY3QtY3JlYXRlL2ZhY3QtY3JlYXRlLmNvbXBvbmVudC5zY3NzIn0= */");

/***/ }),

/***/ "./src/app/pages/facts/fact-create/fact-create.component.ts":
/*!******************************************************************!*\
  !*** ./src/app/pages/facts/fact-create/fact-create.component.ts ***!
  \******************************************************************/
/*! exports provided: FactCreateComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FactCreateComponent", function() { return FactCreateComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _shared_services_data_fact_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../shared/services/data/fact.service */ "./src/app/shared/services/data/fact.service.ts");
/* harmony import */ var _shared_services_notification_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../shared/services/notification.service */ "./src/app/shared/services/notification.service.ts");
/* harmony import */ var _shared_services_storage_project_event_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../shared/services/storage/project-event.service */ "./src/app/shared/services/storage/project-event.service.ts");
/* harmony import */ var _shared_utils_removeLastChar__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../shared/utils/removeLastChar */ "./src/app/shared/utils/removeLastChar.ts");







var FactCreateComponent = /** @class */ (function () {
    function FactCreateComponent(router, factService, notificationService, projectEventService) {
        this.router = router;
        this.factService = factService;
        this.notificationService = notificationService;
        this.projectEventService = projectEventService;
        this.formData = null;
        this.loading = false;
    }
    /**
     * Default form initialization is in child form component
     */
    FactCreateComponent.prototype.ngOnInit = function () {
    };
    /**
     * Cancel create form and navigate to list component
     */
    FactCreateComponent.prototype.onCancel = function () {
        this.router.navigate(['facts/list']);
    };
    /**
     * Save fact with formm values and navigate to list component
     */
    FactCreateComponent.prototype.onSave = function () {
        var _this = this;
        this.factService.createFact(this.transformTaskToApiObject(this.formData)).subscribe(function (response) {
            _this.notificationService.openSuccessNotification('success.add');
            _this.router.navigate(['facts/list']);
        });
    };
    /**
     * Partial fact form object to API fact object transformation
     * @param formObject
     */
    FactCreateComponent.prototype.transformTaskToApiObject = function (formObject) {
        formObject.firstValue = Object(_shared_utils_removeLastChar__WEBPACK_IMPORTED_MODULE_6__["checkAndRemoveLastDotComma"])(formObject.firstValue);
        formObject.secondValue = Object(_shared_utils_removeLastChar__WEBPACK_IMPORTED_MODULE_6__["checkAndRemoveLastDotComma"])(formObject.secondValue);
        formObject.totalValue = Object(_shared_utils_removeLastChar__WEBPACK_IMPORTED_MODULE_6__["checkAndRemoveLastDotComma"])(formObject.totalValue);
        return {
            categoryId: formObject.category,
            subCategoryId: formObject.subCategory,
            valueFirst: formObject.firstValue,
            valueSecond: formObject.secondValue,
            hasOnlyTotalValue: formObject.hasOnlyTotalValue,
            totalValue: (formObject.totalValue) ? formObject.totalValue : (+formObject.firstValue + +formObject.secondValue),
            projectId: this.projectEventService.instant.id
        };
    };
    FactCreateComponent.ctorParameters = function () { return [
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"] },
        { type: _shared_services_data_fact_service__WEBPACK_IMPORTED_MODULE_3__["FactService"] },
        { type: _shared_services_notification_service__WEBPACK_IMPORTED_MODULE_4__["NotificationService"] },
        { type: _shared_services_storage_project_event_service__WEBPACK_IMPORTED_MODULE_5__["ProjectEventService"] }
    ]; };
    FactCreateComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'fact-create',
            template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./fact-create.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/facts/fact-create/fact-create.component.html")).default,
            styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./fact-create.component.scss */ "./src/app/pages/facts/fact-create/fact-create.component.scss")).default]
        })
        /**
         * Fact create component
         */
        ,
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"],
            _shared_services_data_fact_service__WEBPACK_IMPORTED_MODULE_3__["FactService"],
            _shared_services_notification_service__WEBPACK_IMPORTED_MODULE_4__["NotificationService"],
            _shared_services_storage_project_event_service__WEBPACK_IMPORTED_MODULE_5__["ProjectEventService"]])
    ], FactCreateComponent);
    return FactCreateComponent;
}());



/***/ }),

/***/ "./src/app/pages/facts/fact-edit/fact-edit.component.scss":
/*!****************************************************************!*\
  !*** ./src/app/pages/facts/fact-edit/fact-edit.component.scss ***!
  \****************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL2ZhY3RzL2ZhY3QtZWRpdC9mYWN0LWVkaXQuY29tcG9uZW50LnNjc3MifQ== */");

/***/ }),

/***/ "./src/app/pages/facts/fact-edit/fact-edit.component.ts":
/*!**************************************************************!*\
  !*** ./src/app/pages/facts/fact-edit/fact-edit.component.ts ***!
  \**************************************************************/
/*! exports provided: FactEditComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FactEditComponent", function() { return FactEditComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _shared_enums_role_enum__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../shared/enums/role.enum */ "./src/app/shared/enums/role.enum.ts");
/* harmony import */ var _shared_services_auth_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../shared/services/auth.service */ "./src/app/shared/services/auth.service.ts");
/* harmony import */ var _shared_services_data_fact_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../shared/services/data/fact.service */ "./src/app/shared/services/data/fact.service.ts");
/* harmony import */ var _shared_services_notification_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../shared/services/notification.service */ "./src/app/shared/services/notification.service.ts");
/* harmony import */ var _shared_services_storage_project_event_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../../shared/services/storage/project-event.service */ "./src/app/shared/services/storage/project-event.service.ts");
/* harmony import */ var _shared_utils_removeLastChar__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../../shared/utils/removeLastChar */ "./src/app/shared/utils/removeLastChar.ts");
/* harmony import */ var _tasks_task_form_task_form_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../tasks/task-form/task-form.component */ "./src/app/pages/tasks/task-form/task-form.component.ts");










var ALL_FACTS_SCREEN = 'all-facts';
var FACTS_SCREEN = 'facts';
var FactEditComponent = /** @class */ (function () {
    function FactEditComponent(router, notificationService, factService, activatedRoute, projectEventService, authService) {
        this.router = router;
        this.notificationService = notificationService;
        this.factService = factService;
        this.activatedRoute = activatedRoute;
        this.projectEventService = projectEventService;
        this.authService = authService;
        this.formData = null;
        this.canSave = true;
        this.factRoute = FACTS_SCREEN;
    }
    /**
     * Sect fact id from url parameter and set can save property if screen is Facts and Figures and not All Facts and Figures
     */
    FactEditComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.activatedRoute.queryParams.subscribe(function (param) {
            _this.factId = param.id;
        });
        if (this.router.url.includes(ALL_FACTS_SCREEN)) {
            this.factRoute = ALL_FACTS_SCREEN;
            if (!this.router.url.includes(this.projectEventService.instant.year.toString())) {
                this.canSave = false;
            }
        }
    };
    /**
     * Cancel form, navigate to facts list screen
     */
    FactEditComponent.prototype.onCancel = function () {
        this.router.navigate([this.factRoute + "/list"]);
    };
    /**
     * Edit task with form values on save and navigate to facts list
     */
    FactEditComponent.prototype.onSave = function () {
        var _this = this;
        if (this.formData) {
            this.factService.editTask(this.factId, this.transformTaskToApiObject(this.formData))
                .subscribe(function (response) {
                _this.notificationService.openSuccessNotification('success.edit');
                _this.router.navigate([_this.factRoute + '/list']);
            }, function (error) {
                _this.notificationService.openErrorNotification('error.edit');
            });
        }
    };
    FactEditComponent.prototype.allowSaveButton = function () {
        return this.hasRoleUpdateFactItem() || this.hasRoleUpdateFactItemInAssignProject();
    };
    FactEditComponent.prototype.hasRoleUpdateFactItem = function () {
        return this.authService.hasRole(_shared_enums_role_enum__WEBPACK_IMPORTED_MODULE_3__["Role"].RoleUpdateFactItem);
    };
    FactEditComponent.prototype.hasRoleUpdateFactItemInAssignProject = function () {
        return this.authService.hasRole(_shared_enums_role_enum__WEBPACK_IMPORTED_MODULE_3__["Role"].RoleUpdateFactItemInAssignProject);
    };
    /**
     * Partial fact form object to API fact object transformation
     * @param formObject
     */
    FactEditComponent.prototype.transformTaskToApiObject = function (formObject) {
        formObject.firstValue = Object(_shared_utils_removeLastChar__WEBPACK_IMPORTED_MODULE_8__["checkAndRemoveLastDotComma"])(formObject.firstValue);
        formObject.secondValue = Object(_shared_utils_removeLastChar__WEBPACK_IMPORTED_MODULE_8__["checkAndRemoveLastDotComma"])(formObject.secondValue);
        formObject.totalValue = Object(_shared_utils_removeLastChar__WEBPACK_IMPORTED_MODULE_8__["checkAndRemoveLastDotComma"])(formObject.totalValue);
        return {
            valueFirst: formObject.firstValue,
            valueSecond: formObject.secondValue,
            hasOnlyTotalValue: formObject.hasOnlyTotalValue,
            totalValue: (formObject.totalValue) ? formObject.totalValue : (+formObject.firstValue + +formObject.secondValue),
        };
    };
    FactEditComponent.ctorParameters = function () { return [
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"] },
        { type: _shared_services_notification_service__WEBPACK_IMPORTED_MODULE_6__["NotificationService"] },
        { type: _shared_services_data_fact_service__WEBPACK_IMPORTED_MODULE_5__["FactService"] },
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"] },
        { type: _shared_services_storage_project_event_service__WEBPACK_IMPORTED_MODULE_7__["ProjectEventService"] },
        { type: _shared_services_auth_service__WEBPACK_IMPORTED_MODULE_4__["AuthService"] }
    ]; };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])(_tasks_task_form_task_form_component__WEBPACK_IMPORTED_MODULE_9__["TaskFormComponent"], { static: true }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _tasks_task_form_task_form_component__WEBPACK_IMPORTED_MODULE_9__["TaskFormComponent"])
    ], FactEditComponent.prototype, "taskForm", void 0);
    FactEditComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'fact-edit',
            template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./fact-edit.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/facts/fact-edit/fact-edit.component.html")).default,
            styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./fact-edit.component.scss */ "./src/app/pages/facts/fact-edit/fact-edit.component.scss")).default]
        })
        /**
         * Fact edit form
         */ ,
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"],
            _shared_services_notification_service__WEBPACK_IMPORTED_MODULE_6__["NotificationService"],
            _shared_services_data_fact_service__WEBPACK_IMPORTED_MODULE_5__["FactService"],
            _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"],
            _shared_services_storage_project_event_service__WEBPACK_IMPORTED_MODULE_7__["ProjectEventService"],
            _shared_services_auth_service__WEBPACK_IMPORTED_MODULE_4__["AuthService"]])
    ], FactEditComponent);
    return FactEditComponent;
}());



/***/ }),

/***/ "./src/app/pages/facts/fact-form/fact-form.component.scss":
/*!****************************************************************!*\
  !*** ./src/app/pages/facts/fact-form/fact-form.component.scss ***!
  \****************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".fact-text {\n  font-size: 15px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvZmFjdHMvZmFjdC1mb3JtL0Q6XFxwcm9qZWN0c1xcaWloZlxcd2ZtLXdlYi9zcmNcXGFwcFxccGFnZXNcXGZhY3RzXFxmYWN0LWZvcm1cXGZhY3QtZm9ybS5jb21wb25lbnQuc2NzcyIsInNyYy9hcHAvcGFnZXMvZmFjdHMvZmFjdC1mb3JtL2ZhY3QtZm9ybS5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLGVBQUE7QUNDSiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL2ZhY3RzL2ZhY3QtZm9ybS9mYWN0LWZvcm0uY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuZmFjdC10ZXh0IHtcclxuICAgIGZvbnQtc2l6ZTogMTVweDtcclxufVxyXG4iLCIuZmFjdC10ZXh0IHtcbiAgZm9udC1zaXplOiAxNXB4O1xufSJdfQ== */");

/***/ }),

/***/ "./src/app/pages/facts/fact-form/fact-form.component.ts":
/*!**************************************************************!*\
  !*** ./src/app/pages/facts/fact-form/fact-form.component.ts ***!
  \**************************************************************/
/*! exports provided: FactFormComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FactFormComponent", function() { return FactFormComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! moment */ "./node_modules/moment/moment.js");
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm5/operators/index.js");
/* harmony import */ var util__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! util */ "./node_modules/util/util.js");
/* harmony import */ var util__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(util__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _shared_hazlenut_hazelnut_common_animations__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../../shared/hazlenut/hazelnut-common/animations */ "./src/app/shared/hazlenut/hazelnut-common/animations/index.ts");
/* harmony import */ var _shared_hazlenut_hazelnut_common_regex_regex__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../../shared/hazlenut/hazelnut-common/regex/regex */ "./src/app/shared/hazlenut/hazelnut-common/regex/regex.ts");
/* harmony import */ var _shared_pipes_thousand_delimiter_pipe__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../../shared/pipes/thousand-delimiter.pipe */ "./src/app/shared/pipes/thousand-delimiter.pipe.ts");
/* harmony import */ var _shared_services_data_business_area_service__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../../shared/services/data/business-area.service */ "./src/app/shared/services/data/business-area.service.ts");
/* harmony import */ var _shared_services_data_fact_service__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../../shared/services/data/fact.service */ "./src/app/shared/services/data/fact.service.ts");
/* harmony import */ var _shared_services_notification_service__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../../../shared/services/notification.service */ "./src/app/shared/services/notification.service.ts");
/* harmony import */ var _shared_services_storage_project_event_service__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../../../shared/services/storage/project-event.service */ "./src/app/shared/services/storage/project-event.service.ts");














var FactFormComponent = /** @class */ (function () {
    function FactFormComponent(projectEventService, formBuilder, businessAreaService, activatedRoute, factService, notificationService) {
        this.projectEventService = projectEventService;
        this.formBuilder = formBuilder;
        this.businessAreaService = businessAreaService;
        this.activatedRoute = activatedRoute;
        this.factService = factService;
        this.notificationService = notificationService;
        this.onFormDataChange = new _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"]();
        // Regex pattern for number with two decimal places
        this.decimalPattern = _shared_hazlenut_hazelnut_common_regex_regex__WEBPACK_IMPORTED_MODULE_8__["Regex"].decimalPattern;
        this.categories = [];
        this.subCategories = [];
        this.categoryLoading = false;
        this.actualUnitShortName = '';
        this.isUpdate = false;
        this.formLoaded = false;
        // Venue labels are set from local storage
        this.firstVenueLabel = this.projectEventService.instant.firstVenue;
        this.secondVenueLabel = this.projectEventService.instant.secondVenue;
        this.isTotalRequired = false;
        this.isFirstValueRequired = false;
        this.isSecondValueRequired = false;
    }
    /**
     * Set listeners and default form in initialization
     */
    FactFormComponent.prototype.ngOnInit = function () {
        var _this = this;
        // Set default form group
        this.factForm = this.formBuilder.group({
            category: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
            subCategory: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
            firstValue: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
            secondValue: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
            hasOnlyTotalValue: [false],
            totalValue: [{ value: '', disabled: true }]
        });
        this.loadCategories();
        this.checkIfUpdate();
        // Category input listener
        this.factForm.controls.category.valueChanges.subscribe(function (value) {
            _this.actualUnitShortName = '';
            _this.factForm.controls.subCategory.patchValue('');
            if (value && Number(value)) {
                _this.loadSubCategories(value);
            }
        });
        // Subcategory input listener
        this.factForm.controls.subCategory.valueChanges.subscribe(function (value) {
            var subcategory = _this.subCategories.find(function (subCategory) { return subCategory.id === value; });
            if (!Object(util__WEBPACK_IMPORTED_MODULE_6__["isNullOrUndefined"])(subcategory)) {
                _this.actualUnitShortName = subcategory.unitShortName;
            }
        });
        // First value input listener
        this.factForm.controls.firstValue.valueChanges.subscribe(function (value) {
            var number = _this.transformNumberValue(_this.factForm.value.secondValue, value);
            _this.factForm.controls.totalValue.patchValue(_this.pipe.transform(number.toString(), ','));
        });
        // Second value input listener
        this.factForm.controls.secondValue.valueChanges.subscribe(function (value) {
            var number = _this.transformNumberValue(_this.factForm.value.firstValue, value);
            _this.factForm.controls.totalValue.patchValue(_this.pipe.transform(number.toString(), ','));
        });
        // Emit value changes to parent component
        this.factForm.valueChanges.subscribe(function () {
            _this.emitFormDataChangeEmitter();
        });
        // Listener on checkbox input if has only total value
        this.factForm.controls.hasOnlyTotalValue.valueChanges.subscribe(function () {
            _this.oneValueSelected();
        });
        this.pipe = new _shared_pipes_thousand_delimiter_pipe__WEBPACK_IMPORTED_MODULE_9__["ThousandDelimiterPipe"]();
    };
    Object.defineProperty(FactFormComponent.prototype, "controls", {
        /**
         * Fact form getter of controls
         */
        get: function () {
            return this.factForm.controls;
        },
        enumerable: true,
        configurable: true
    });
    /**
     * Load categories from API into selected array
     */
    FactFormComponent.prototype.loadCategories = function () {
        var _this = this;
        this.categoryLoading = true;
        this.businessAreaService.listCategories()
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["finalize"])(function () { return _this.categoryLoading = false; }))
            .subscribe(function (data) {
            _this.categories = data.content;
        });
    };
    /**
     * Load specified category subcategories from API into selected array
     * @param categoryId
     */
    FactFormComponent.prototype.loadSubCategories = function (categoryId) {
        var _this = this;
        this.categoryLoading = true;
        this.businessAreaService.listSubCategories(categoryId)
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["finalize"])(function () { return _this.categoryLoading = false; }))
            .subscribe(function (data) {
            _this.subCategories = data;
        });
    };
    /**
     * Emit data for wrapper form create or form edit component
     */
    FactFormComponent.prototype.emitFormDataChangeEmitter = function () {
        var isInvalid = (this.factForm.value.firstValue === '.' || this.factForm.value.secondValue === '.' || this.factForm.value.totalValue === '.')
            || (this.factForm.value.firstValue === ',' || this.factForm.value.secondValue === ',' || this.factForm.value.totalValue === ',');
        if (this.factForm.invalid || isInvalid) {
            this.onFormDataChange.emit(null);
        }
        else {
            var actualValue = tslib__WEBPACK_IMPORTED_MODULE_0__["__assign"]({}, this.factForm.value);
            this.onFormDataChange.emit(actualValue);
        }
    };
    /**
     * Check if form is for update fact screen based on url parameters
     */
    FactFormComponent.prototype.checkIfUpdate = function () {
        var _this = this;
        this.activatedRoute.queryParams.subscribe(function (param) {
            if (Object.keys(param).length > 0) {
                _this.isUpdate = true;
                _this.getIdFromRouteParamsAndSetDetail(param);
            }
        });
    };
    /**
     * Set update form based on id from url
     * @param param
     */
    FactFormComponent.prototype.getIdFromRouteParamsAndSetDetail = function (param) {
        var _this = this;
        this.factService.getFactById(param.id, param.projectId).subscribe(function (apiTask) {
            _this.setForm(apiTask);
        }, function (error) { return _this.notificationService.openErrorNotification(error); });
    };
    /**
     * Set controls of fact form if has only total value
     */
    FactFormComponent.prototype.oneValueSelected = function () {
        var hasOnlyTotalValue = this.factForm.controls.hasOnlyTotalValue.value;
        if (hasOnlyTotalValue) {
            this.controls.firstValue.clearValidators();
            this.controls.secondValue.clearValidators();
            this.controls.totalValue.setValidators(_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required);
            this.isFirstValueRequired = false;
            this.isSecondValueRequired = false;
            this.isTotalRequired = true;
            this.factForm.controls.totalValue.enable();
            this.factForm.controls.firstValue.disable();
            this.factForm.controls.secondValue.disable();
        }
        else {
            this.controls.firstValue.setValidators(_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required);
            this.controls.secondValue.setValidators(_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required);
            this.controls.totalValue.clearValidators();
            this.isFirstValueRequired = true;
            this.isSecondValueRequired = true;
            this.isTotalRequired = false;
            this.factForm.controls.totalValue.disable();
            this.factForm.controls.firstValue.enable();
            this.factForm.controls.secondValue.enable();
        }
        this.controls.firstValue.setValue('');
        this.controls.secondValue.setValue('');
        this.controls.totalValue.setValue('');
    };
    /**
     * Set form for update fact commponent, listeners update and form controls update
     * @param task
     */
    FactFormComponent.prototype.setForm = function (task) {
        var _this = this;
        this.firstVenueLabel = task.venueFirst;
        this.secondVenueLabel = task.venueSecond;
        this.actualUnitShortName = task.subCategory.unitShortName;
        var hasChangedBy = task.changedBy && task.changedBy.firstName && task.changedBy.lastName;
        this.isFirstValueRequired = true;
        this.isSecondValueRequired = true;
        this.isTotalRequired = false;
        this.factForm = this.formBuilder.group({
            category: [task.category.category, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
            subCategory: [task.subCategory.subCategory, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
            firstValue: [!Object(util__WEBPACK_IMPORTED_MODULE_6__["isNullOrUndefined"])(task.valueFirst) ? this.pipe.transform(task.valueFirst.toString(), ',') : '', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
            secondValue: [!Object(util__WEBPACK_IMPORTED_MODULE_6__["isNullOrUndefined"])(task.valueSecond) ? this.pipe.transform(task.valueSecond.toString(), ',') : '', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
            hasOnlyTotalValue: [task.hasOnlyTotalValue],
            totalValue: [!Object(util__WEBPACK_IMPORTED_MODULE_6__["isNullOrUndefined"])(task.totalValue) ? this.pipe.transform(parseFloat(task.totalValue).toFixed(2).toString(), ',') : ''],
            changedAt: [task.changedAt ? this.formatDateTime(new Date(task.changedAt)) : ''],
            changedBy: [hasChangedBy ? task.changedBy.firstName + " " + task.changedBy.lastName : '']
        });
        this.factForm.controls.firstValue.valueChanges.subscribe(function (value) {
            var number = _this.transformNumberValue(_this.factForm.value.secondValue, value);
            _this.factForm.controls.totalValue.patchValue(_this.pipe.transform(number.toString(), ','));
        });
        this.factForm.controls.secondValue.valueChanges.subscribe(function (value) {
            var number = _this.transformNumberValue(_this.factForm.value.firstValue, value);
            _this.factForm.controls.totalValue.patchValue(_this.pipe.transform(number.toString(), ','));
        });
        this.factForm.valueChanges.subscribe(function () {
            _this.emitFormDataChangeEmitter();
        });
        this.factForm.controls.totalValue.disable();
        this.factForm.controls.changedAt.disable();
        this.factForm.controls.changedBy.disable();
        this.formLoaded = true;
        this.factForm.controls.hasOnlyTotalValue.valueChanges.subscribe(function () {
            _this.oneValueSelected();
        });
        if (task.hasOnlyTotalValue) {
            this.controls.firstValue.clearValidators();
            this.controls.secondValue.clearValidators();
            this.controls.totalValue.setValidators(_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required);
            this.isFirstValueRequired = false;
            this.isSecondValueRequired = false;
            this.isTotalRequired = true;
            setTimeout(function () {
                _this.factForm.controls.firstValue.disable();
                _this.factForm.controls.secondValue.disable();
                _this.factForm.controls.totalValue.enable();
                _this.factForm.controls.totalValue.patchValue(task.totalValue.toString());
            }, 200);
        }
    };
    /**
     * Transform Date object into formated
     * @param date
     */
    FactFormComponent.prototype.formatDateTime = function (date) {
        if (!date) {
            return '';
        }
        return moment__WEBPACK_IMPORTED_MODULE_4__(date).format('D.M.YYYY - HH:mm:ss');
    };
    /**
     * Transformation for number value
     * @param formValue
     * @param value
     */
    FactFormComponent.prototype.transformNumberValue = function (formValue, value) {
        return formValue
            ? (+value.replace(',', '.').replace(' ', '') + parseFloat(formValue.replace(',', '.').replace(' ', '')))
                .toFixed(2)
            : +value.replace(',', '.').replace(' ', '');
    };
    FactFormComponent.ctorParameters = function () { return [
        { type: _shared_services_storage_project_event_service__WEBPACK_IMPORTED_MODULE_13__["ProjectEventService"] },
        { type: _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormBuilder"] },
        { type: _shared_services_data_business_area_service__WEBPACK_IMPORTED_MODULE_10__["BusinessAreaService"] },
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["ActivatedRoute"] },
        { type: _shared_services_data_fact_service__WEBPACK_IMPORTED_MODULE_11__["FactService"] },
        { type: _shared_services_notification_service__WEBPACK_IMPORTED_MODULE_12__["NotificationService"] }
    ]; };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Output"])('formDataChange'),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], FactFormComponent.prototype, "onFormDataChange", void 0);
    FactFormComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'fact-form',
            template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./fact-form.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/facts/fact-form/fact-form.component.html")).default,
            animations: [_shared_hazlenut_hazelnut_common_animations__WEBPACK_IMPORTED_MODULE_7__["enterLeaveSmooth"]],
            styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./fact-form.component.scss */ "./src/app/pages/facts/fact-form/fact-form.component.scss")).default]
        })
        /**
         * Fact form component for multiple usage: edit | create | detail
         */
        ,
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_shared_services_storage_project_event_service__WEBPACK_IMPORTED_MODULE_13__["ProjectEventService"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormBuilder"],
            _shared_services_data_business_area_service__WEBPACK_IMPORTED_MODULE_10__["BusinessAreaService"],
            _angular_router__WEBPACK_IMPORTED_MODULE_3__["ActivatedRoute"],
            _shared_services_data_fact_service__WEBPACK_IMPORTED_MODULE_11__["FactService"],
            _shared_services_notification_service__WEBPACK_IMPORTED_MODULE_12__["NotificationService"]])
    ], FactFormComponent);
    return FactFormComponent;
}());



/***/ }),

/***/ "./src/app/pages/facts/fact-list/fact-list.component.scss":
/*!****************************************************************!*\
  !*** ./src/app/pages/facts/fact-list/fact-list.component.scss ***!
  \****************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".text-unavailable-facts {\n  font-size: 14px;\n  color: #274d7a;\n  padding: 10px 0 0 30px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvZmFjdHMvZmFjdC1saXN0L0Q6XFxwcm9qZWN0c1xcaWloZlxcd2ZtLXdlYi9zcmNcXGFwcFxccGFnZXNcXGZhY3RzXFxmYWN0LWxpc3RcXGZhY3QtbGlzdC5jb21wb25lbnQuc2NzcyIsInNyYy9hcHAvcGFnZXMvZmFjdHMvZmFjdC1saXN0L2ZhY3QtbGlzdC5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLGVBQUE7RUFDQSxjQUFBO0VBQ0Esc0JBQUE7QUNDSiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL2ZhY3RzL2ZhY3QtbGlzdC9mYWN0LWxpc3QuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIudGV4dC11bmF2YWlsYWJsZS1mYWN0cyB7XHJcbiAgICBmb250LXNpemU6IDE0cHg7XHJcbiAgICBjb2xvcjogIzI3NGQ3YTtcclxuICAgIHBhZGRpbmc6IDEwcHggMCAwIDMwcHg7XHJcbn1cclxuIiwiLnRleHQtdW5hdmFpbGFibGUtZmFjdHMge1xuICBmb250LXNpemU6IDE0cHg7XG4gIGNvbG9yOiAjMjc0ZDdhO1xuICBwYWRkaW5nOiAxMHB4IDAgMCAzMHB4O1xufSJdfQ== */");

/***/ }),

/***/ "./src/app/pages/facts/fact-list/fact-list.component.ts":
/*!**************************************************************!*\
  !*** ./src/app/pages/facts/fact-list/fact-list.component.ts ***!
  \**************************************************************/
/*! exports provided: FactListComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FactListComponent", function() { return FactListComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ngx-translate/core */ "./node_modules/@ngx-translate/core/fesm5/ngx-translate-core.js");
/* harmony import */ var _shared_enums_role_enum__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../shared/enums/role.enum */ "./src/app/shared/enums/role.enum.ts");
/* harmony import */ var _shared_hazlenut_core_table__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../shared/hazlenut/core-table */ "./src/app/shared/hazlenut/core-table/index.ts");
/* harmony import */ var _shared_hazlenut_hazelnut_common_hazelnut__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../shared/hazlenut/hazelnut-common/hazelnut */ "./src/app/shared/hazlenut/hazelnut-common/hazelnut/index.ts");
/* harmony import */ var _shared_hazlenut_hazelnut_common_models__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../../shared/hazlenut/hazelnut-common/models */ "./src/app/shared/hazlenut/hazelnut-common/models/index.ts");
/* harmony import */ var _shared_hazlenut_hazelnut_common_utils_file_manager__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../../shared/hazlenut/hazelnut-common/utils/file-manager */ "./src/app/shared/hazlenut/hazelnut-common/utils/file-manager.ts");
/* harmony import */ var _shared_services_auth_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../../shared/services/auth.service */ "./src/app/shared/services/auth.service.ts");
/* harmony import */ var _shared_services_data_fact_service__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../../shared/services/data/fact.service */ "./src/app/shared/services/data/fact.service.ts");
/* harmony import */ var _shared_services_notification_service__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../../shared/services/notification.service */ "./src/app/shared/services/notification.service.ts");
/* harmony import */ var _shared_services_routing_storage_service__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../../../shared/services/routing-storage.service */ "./src/app/shared/services/routing-storage.service.ts");
/* harmony import */ var _shared_services_storage_project_event_service__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../../../shared/services/storage/project-event.service */ "./src/app/shared/services/storage/project-event.service.ts");
/* harmony import */ var _shared_services_table_change_storage_service__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ../../../shared/services/table-change-storage.service */ "./src/app/shared/services/table-change-storage.service.ts");
/* harmony import */ var _shared_utils_headers__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ../../../shared/utils/headers */ "./src/app/shared/utils/headers.ts");
















var ALL_FACTS = 'all-facts';
var FactListComponent = /** @class */ (function () {
    function FactListComponent(projectEventService, translateService, notificationService, factService, router, routingStorageService, tableChangeStorageService, authService) {
        this.projectEventService = projectEventService;
        this.translateService = translateService;
        this.notificationService = notificationService;
        this.factService = factService;
        this.router = router;
        this.routingStorageService = routingStorageService;
        this.tableChangeStorageService = tableChangeStorageService;
        this.authService = authService;
        this.loading = false;
        this.isInitialized = false;
        this.data = new _shared_hazlenut_hazelnut_common_models__WEBPACK_IMPORTED_MODULE_7__["BrowseResponse"]([]);
        this.allFacts = false;
        this.allTaskFilters = [];
    }
    FactListComponent.prototype.ngOnInit = function () {
        // Default config for table initialization
        this.config = {
            stickyEnd: 4,
            columns: [
                new _shared_hazlenut_core_table__WEBPACK_IMPORTED_MODULE_5__["TableColumn"]({
                    columnDef: 'categoryName',
                    labelKey: 'fact.category',
                    type: _shared_hazlenut_core_table__WEBPACK_IMPORTED_MODULE_5__["TableCellType"].CONTENT,
                    filter: new _shared_hazlenut_core_table__WEBPACK_IMPORTED_MODULE_5__["TableColumnFilter"]({
                        type: _shared_hazlenut_core_table__WEBPACK_IMPORTED_MODULE_5__["TableFilterType"].CATEGORY,
                    }),
                    sorting: true,
                    tableCellTemplate: this.categoryColumn,
                }),
                new _shared_hazlenut_core_table__WEBPACK_IMPORTED_MODULE_5__["TableColumn"]({
                    columnDef: 'subCategoryName',
                    labelKey: 'fact.subCategory',
                    filter: new _shared_hazlenut_core_table__WEBPACK_IMPORTED_MODULE_5__["TableColumnFilter"]({}),
                    sorting: true,
                }),
                new _shared_hazlenut_core_table__WEBPACK_IMPORTED_MODULE_5__["TableColumn"]({
                    columnDef: 'valueFirst',
                    label: this.projectEventService.instant.firstVenue ? this.projectEventService.instant.firstVenue : '-',
                    align: 'right',
                    type: _shared_hazlenut_core_table__WEBPACK_IMPORTED_MODULE_5__["TableCellType"].CONTENT,
                    filter: new _shared_hazlenut_core_table__WEBPACK_IMPORTED_MODULE_5__["TableColumnFilter"]({
                        type: _shared_hazlenut_core_table__WEBPACK_IMPORTED_MODULE_5__["TableFilterType"].NUMBER,
                    }),
                    sorting: true,
                    tableCellTemplate: this.firstValueColumn,
                }),
                new _shared_hazlenut_core_table__WEBPACK_IMPORTED_MODULE_5__["TableColumn"]({
                    columnDef: 'valueSecond',
                    label: this.projectEventService.instant.secondVenue ? this.projectEventService.instant.secondVenue : '-',
                    align: 'right',
                    type: _shared_hazlenut_core_table__WEBPACK_IMPORTED_MODULE_5__["TableCellType"].CONTENT,
                    filter: new _shared_hazlenut_core_table__WEBPACK_IMPORTED_MODULE_5__["TableColumnFilter"]({
                        type: _shared_hazlenut_core_table__WEBPACK_IMPORTED_MODULE_5__["TableFilterType"].NUMBER,
                    }),
                    sorting: true,
                    tableCellTemplate: this.secondValueColumn,
                }),
                new _shared_hazlenut_core_table__WEBPACK_IMPORTED_MODULE_5__["TableColumn"]({
                    columnDef: 'totalValue',
                    labelKey: 'fact.totalValue',
                    align: 'right',
                    type: _shared_hazlenut_core_table__WEBPACK_IMPORTED_MODULE_5__["TableCellType"].CONTENT,
                    filter: new _shared_hazlenut_core_table__WEBPACK_IMPORTED_MODULE_5__["TableColumnFilter"]({
                        type: _shared_hazlenut_core_table__WEBPACK_IMPORTED_MODULE_5__["TableFilterType"].NUMBER,
                    }),
                    sorting: true,
                    tableCellTemplate: this.totalValueColumn,
                }),
                new _shared_hazlenut_core_table__WEBPACK_IMPORTED_MODULE_5__["TableColumn"]({
                    columnDef: ' ',
                    label: ' ',
                    type: _shared_hazlenut_core_table__WEBPACK_IMPORTED_MODULE_5__["TableCellType"].CONTENT,
                    tableCellTemplate: this.updateColumn,
                    filter: new _shared_hazlenut_core_table__WEBPACK_IMPORTED_MODULE_5__["TableColumnFilter"]({
                        type: _shared_hazlenut_core_table__WEBPACK_IMPORTED_MODULE_5__["TableFilterType"].CLEAR_FILTERS,
                    }),
                }),
            ],
            paging: true,
        };
        if (!this.isInitialized && this.isReturnFromDetail() && this.tableChangeStorageService.getFactsLastTableChangeEvent()) {
            if (this.tableChangeStorageService.getFactsLastTableChangeEvent().filters) {
                this.config.predefinedFilters = this.tableChangeStorageService.getFactsLastTableChangeEvent().filters;
            }
            if (this.tableChangeStorageService.getFactsLastTableChangeEvent().pageIndex) {
                this.config.predefinedPageIndex = this.tableChangeStorageService.getFactsLastTableChangeEvent().pageIndex;
            }
            if (this.tableChangeStorageService.getFactsLastTableChangeEvent().pageSize) {
                this.config.predefinedPageSize = this.tableChangeStorageService.getFactsLastTableChangeEvent().pageSize;
            }
            if (this.tableChangeStorageService.getFactsLastTableChangeEvent().sortDirection) {
                this.config.predefinedSortDirection = this.tableChangeStorageService.getFactsLastTableChangeEvent()
                    .sortDirection
                    .toLowerCase();
            }
            if (this.tableChangeStorageService.getFactsLastTableChangeEvent().sortActive) {
                this.config.predefinedSortActive = _shared_hazlenut_hazelnut_common_hazelnut__WEBPACK_IMPORTED_MODULE_6__["StringUtils"].convertSnakeToCamel(this.tableChangeStorageService.getFactsLastTableChangeEvent()
                    .sortActive
                    .toLowerCase());
            }
        }
        // Update config for All Facts and Figures screen
        if (this.router.url.includes(ALL_FACTS)) {
            this.config.stickyEnd = 5;
            this.allFacts = true;
            this.config.columns.splice(0, 0, new _shared_hazlenut_core_table__WEBPACK_IMPORTED_MODULE_5__["TableColumn"]({
                columnDef: 'year',
                labelKey: 'fact.year',
                align: 'right',
                type: _shared_hazlenut_core_table__WEBPACK_IMPORTED_MODULE_5__["TableCellType"].NUMBER_SIMPLE,
                filter: new _shared_hazlenut_core_table__WEBPACK_IMPORTED_MODULE_5__["TableColumnFilter"]({
                    type: _shared_hazlenut_core_table__WEBPACK_IMPORTED_MODULE_5__["TableFilterType"].NUMBER,
                }),
                sorting: true,
            }));
            this.setLabel('valueFirst', 'fact.firstValue');
            this.setLabel('valueSecond', 'fact.secondValue');
        }
    };
    /**
     * Route to create screen of fact
     */
    FactListComponent.prototype.createFact = function () {
        this.router.navigate(['facts/create']);
    };
    /**
     * Route to edit screen of fact detail
     * @param id
     * @param year
     * @param projectId
     */
    FactListComponent.prototype.update = function (id, year, projectId) {
        if (this.router.url.includes(ALL_FACTS)) {
            this.router.navigate(['all-facts/edit'], {
                queryParams: {
                    id: id,
                    projectId: projectId,
                    year: year
                }
            });
        }
        else {
            this.router.navigate(['facts/edit'], {
                queryParams: {
                    id: id,
                    projectId: projectId
                }
            });
        }
    };
    FactListComponent.prototype.setTableData = function (tableChangeEvent) {
        var _this = this;
        this.loading = true;
        var projectFilter = null;
        // Create filter which will be use in Facts and Figures screen API call
        if (!this.router.url.includes(ALL_FACTS)) {
            projectFilter = new _shared_hazlenut_hazelnut_common_models__WEBPACK_IMPORTED_MODULE_7__["Filter"]('PROJECT_ID', this.projectEventService.instant.id, 'NUMBER');
        }
        if (tableChangeEvent && tableChangeEvent.filters && tableChangeEvent.filters.length > 0) {
            this.allTaskFilters = tableChangeEvent.filters;
        }
        // Set paging and sort when initializating table
        if (!this.isInitialized && this.isReturnFromDetail() && this.tableChangeStorageService.getFactsLastTableChangeEvent()) {
            tableChangeEvent.pageIndex = this.tableChangeStorageService.getFactsLastTableChangeEvent().pageIndex;
            tableChangeEvent.pageSize = this.tableChangeStorageService.getFactsLastTableChangeEvent().pageSize;
            tableChangeEvent.sortDirection = this.tableChangeStorageService.getFactsLastTableChangeEvent().sortDirection;
            tableChangeEvent.sortActive = this.tableChangeStorageService.getFactsLastTableChangeEvent().sortActive;
        }
        // Api call
        this.factService.browseFacts(tableChangeEvent, projectFilter)
            .subscribe(function (data) {
            _this.data = data;
            _this.loading = false;
            _this.isInitialized = true;
        }, function () {
            _this.loading = false;
            _this.notificationService.openErrorNotification('error.api');
        });
        this.tableChangeStorageService.setFactsLastTableChangeEvent(tableChangeEvent);
        this.lastTableChangeEvent = tableChangeEvent;
    };
    FactListComponent.prototype.allowCreateFactButton = function () {
        return this.hasRoleCreateFactItem() || this.hasRoleCreateFactItemInAssignProject();
    };
    FactListComponent.prototype.allowExportAllFactItemButton = function () {
        return this.allFacts && this.hasRoleExportAllFactItem();
    };
    FactListComponent.prototype.allowFactDetailButton = function () {
        return (!this.allFacts &&
            (this.authService.hasRole(_shared_enums_role_enum__WEBPACK_IMPORTED_MODULE_4__["Role"].RoleReadFactItem) ||
                this.authService.hasRole(_shared_enums_role_enum__WEBPACK_IMPORTED_MODULE_4__["Role"].RoleReadFactItemInAssignProject) ||
                this.authService.hasRole(_shared_enums_role_enum__WEBPACK_IMPORTED_MODULE_4__["Role"].RoleUpdateFactItem) ||
                this.authService.hasRole(_shared_enums_role_enum__WEBPACK_IMPORTED_MODULE_4__["Role"].RoleUpdateFactItemInAssignProject))) || (this.allFacts && this.authService.hasRole(_shared_enums_role_enum__WEBPACK_IMPORTED_MODULE_4__["Role"].RoleReadAllFactItem));
    };
    /**
     * Export report from API based on selected filters
     */
    FactListComponent.prototype.export = function () {
        var _this = this;
        this.loading = true;
        this.factService.exportTasks(this.lastTableChangeEvent, this.allTaskFilters, this.projectEventService.instant.id)
            .subscribe(function (response) {
            var contentDisposition = response.headers.get('Content-Disposition');
            var exportName = Object(_shared_utils_headers__WEBPACK_IMPORTED_MODULE_15__["GetFileNameFromContentDisposition"])(contentDisposition);
            new _shared_hazlenut_hazelnut_common_utils_file_manager__WEBPACK_IMPORTED_MODULE_8__["FileManager"]().saveFile(exportName, response.body, 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
            _this.loading = false;
        }, function () {
            _this.notificationService.openErrorNotification('error.api');
            _this.loading = false;
        });
    };
    FactListComponent.prototype.hasRoleCreateFactItem = function () {
        return this.authService.hasRole(_shared_enums_role_enum__WEBPACK_IMPORTED_MODULE_4__["Role"].RoleCreateFactItem);
    };
    FactListComponent.prototype.hasRoleCreateFactItemInAssignProject = function () {
        return this.authService.hasRole(_shared_enums_role_enum__WEBPACK_IMPORTED_MODULE_4__["Role"].RoleCreateFactItemInAssignProject);
    };
    FactListComponent.prototype.hasRoleExportAllFactItem = function () {
        return this.authService.hasRole(_shared_enums_role_enum__WEBPACK_IMPORTED_MODULE_4__["Role"].RoleExportAllFactItem);
    };
    /**
     * Set column label
     * @param columnName
     * @param replaceLabel
     */
    FactListComponent.prototype.setLabel = function (columnName, replaceLabel) {
        var index = this.config.columns.findIndex(function (column) { return column.columnDef === columnName; });
        this.config.columns[index].label = null;
        this.config.columns[index].labelKey = replaceLabel;
    };
    /**
     * Function if returned from create or detail screen
     */
    FactListComponent.prototype.isReturnFromDetail = function () {
        return this.routingStorageService.getPreviousUrl()
            .includes('facts/edit') || this.routingStorageService.getPreviousUrl()
            .includes('facts/create');
    };
    FactListComponent.ctorParameters = function () { return [
        { type: _shared_services_storage_project_event_service__WEBPACK_IMPORTED_MODULE_13__["ProjectEventService"] },
        { type: _ngx_translate_core__WEBPACK_IMPORTED_MODULE_3__["TranslateService"] },
        { type: _shared_services_notification_service__WEBPACK_IMPORTED_MODULE_11__["NotificationService"] },
        { type: _shared_services_data_fact_service__WEBPACK_IMPORTED_MODULE_10__["FactService"] },
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"] },
        { type: _shared_services_routing_storage_service__WEBPACK_IMPORTED_MODULE_12__["RoutingStorageService"] },
        { type: _shared_services_table_change_storage_service__WEBPACK_IMPORTED_MODULE_14__["TableChangeStorageService"] },
        { type: _shared_services_auth_service__WEBPACK_IMPORTED_MODULE_9__["AuthService"] }
    ]; };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])('updateColumn', { static: true }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"])
    ], FactListComponent.prototype, "updateColumn", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])('firstValueColumn', { static: true }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"])
    ], FactListComponent.prototype, "firstValueColumn", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])('secondValueColumn', { static: true }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"])
    ], FactListComponent.prototype, "secondValueColumn", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])('totalValueColumn', { static: true }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"])
    ], FactListComponent.prototype, "totalValueColumn", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])('categoryColumn', { static: true }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"])
    ], FactListComponent.prototype, "categoryColumn", void 0);
    FactListComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'fact-list',
            template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./fact-list.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/facts/fact-list/fact-list.component.html")).default,
            styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./fact-list.component.scss */ "./src/app/pages/facts/fact-list/fact-list.component.scss")).default]
        })
        /**
         * Fact list used in screens Facts and Figures | All Facts and Figures
         */
        ,
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_shared_services_storage_project_event_service__WEBPACK_IMPORTED_MODULE_13__["ProjectEventService"],
            _ngx_translate_core__WEBPACK_IMPORTED_MODULE_3__["TranslateService"],
            _shared_services_notification_service__WEBPACK_IMPORTED_MODULE_11__["NotificationService"],
            _shared_services_data_fact_service__WEBPACK_IMPORTED_MODULE_10__["FactService"],
            _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"],
            _shared_services_routing_storage_service__WEBPACK_IMPORTED_MODULE_12__["RoutingStorageService"],
            _shared_services_table_change_storage_service__WEBPACK_IMPORTED_MODULE_14__["TableChangeStorageService"],
            _shared_services_auth_service__WEBPACK_IMPORTED_MODULE_9__["AuthService"]])
    ], FactListComponent);
    return FactListComponent;
}());



/***/ }),

/***/ "./src/app/pages/facts/facts-routing.module.ts":
/*!*****************************************************!*\
  !*** ./src/app/pages/facts/facts-routing.module.ts ***!
  \*****************************************************/
/*! exports provided: FactsRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FactsRoutingModule", function() { return FactsRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _fact_create_fact_create_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./fact-create/fact-create.component */ "./src/app/pages/facts/fact-create/fact-create.component.ts");
/* harmony import */ var _fact_edit_fact_edit_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./fact-edit/fact-edit.component */ "./src/app/pages/facts/fact-edit/fact-edit.component.ts");
/* harmony import */ var _fact_list_fact_list_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./fact-list/fact-list.component */ "./src/app/pages/facts/fact-list/fact-list.component.ts");






var routes = [
    {
        path: '',
        children: [
            {
                path: '',
                pathMatch: 'full',
                redirectTo: 'list',
            },
            {
                path: 'list',
                component: _fact_list_fact_list_component__WEBPACK_IMPORTED_MODULE_5__["FactListComponent"],
                data: { title: 'factList' }
            },
            {
                path: 'create',
                component: _fact_create_fact_create_component__WEBPACK_IMPORTED_MODULE_3__["FactCreateComponent"],
                data: { title: 'factCreate' }
            },
            {
                path: 'edit',
                component: _fact_edit_fact_edit_component__WEBPACK_IMPORTED_MODULE_4__["FactEditComponent"],
                data: { title: 'factEdit' }
            },
        ],
    }
];
var FactsRoutingModule = /** @class */ (function () {
    function FactsRoutingModule() {
    }
    FactsRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
            exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
        })
    ], FactsRoutingModule);
    return FactsRoutingModule;
}());



/***/ }),

/***/ "./src/app/pages/facts/facts.module.ts":
/*!*********************************************!*\
  !*** ./src/app/pages/facts/facts.module.ts ***!
  \*********************************************/
/*! exports provided: FactsModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FactsModule", function() { return FactsModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_flex_layout__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/flex-layout */ "./node_modules/@angular/flex-layout/esm5/flex-layout.es5.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ngx-translate/core */ "./node_modules/@ngx-translate/core/fesm5/ngx-translate-core.js");
/* harmony import */ var _shared_hazlenut_abstract_inputs__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../shared/hazlenut/abstract-inputs */ "./src/app/shared/hazlenut/abstract-inputs/index.ts");
/* harmony import */ var _shared_hazlenut_core_table__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../shared/hazlenut/core-table */ "./src/app/shared/hazlenut/core-table/index.ts");
/* harmony import */ var _shared_hazlenut_hazelnut_common__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../shared/hazlenut/hazelnut-common */ "./src/app/shared/hazlenut/hazelnut-common/index.ts");
/* harmony import */ var _shared_pipes_pipes_module__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../shared/pipes/pipes.module */ "./src/app/shared/pipes/pipes.module.ts");
/* harmony import */ var _fact_create_fact_create_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./fact-create/fact-create.component */ "./src/app/pages/facts/fact-create/fact-create.component.ts");
/* harmony import */ var _fact_edit_fact_edit_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./fact-edit/fact-edit.component */ "./src/app/pages/facts/fact-edit/fact-edit.component.ts");
/* harmony import */ var _fact_form_fact_form_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./fact-form/fact-form.component */ "./src/app/pages/facts/fact-form/fact-form.component.ts");
/* harmony import */ var _fact_list_fact_list_component__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./fact-list/fact-list.component */ "./src/app/pages/facts/fact-list/fact-list.component.ts");
/* harmony import */ var _facts_routing_module__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./facts-routing.module */ "./src/app/pages/facts/facts-routing.module.ts");















var FactsModule = /** @class */ (function () {
    function FactsModule() {
    }
    FactsModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["NgModule"])({
            declarations: [_fact_list_fact_list_component__WEBPACK_IMPORTED_MODULE_13__["FactListComponent"], _fact_create_fact_create_component__WEBPACK_IMPORTED_MODULE_10__["FactCreateComponent"], _fact_form_fact_form_component__WEBPACK_IMPORTED_MODULE_12__["FactFormComponent"], _fact_edit_fact_edit_component__WEBPACK_IMPORTED_MODULE_11__["FactEditComponent"]],
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"],
                _facts_routing_module__WEBPACK_IMPORTED_MODULE_14__["FactsRoutingModule"],
                _shared_hazlenut_hazelnut_common__WEBPACK_IMPORTED_MODULE_8__["MaterialModule"],
                _angular_flex_layout__WEBPACK_IMPORTED_MODULE_3__["FlexLayoutModule"],
                _ngx_translate_core__WEBPACK_IMPORTED_MODULE_5__["TranslateModule"].forChild(),
                _angular_forms__WEBPACK_IMPORTED_MODULE_4__["ReactiveFormsModule"],
                _shared_hazlenut_core_table__WEBPACK_IMPORTED_MODULE_7__["CoreTableModule"],
                _shared_hazlenut_abstract_inputs__WEBPACK_IMPORTED_MODULE_6__["AbstractInputsModule"],
                _shared_pipes_pipes_module__WEBPACK_IMPORTED_MODULE_9__["PipesModule"]
            ]
        })
    ], FactsModule);
    return FactsModule;
}());



/***/ }),

/***/ "./src/app/shared/services/data/fact.service.ts":
/*!******************************************************!*\
  !*** ./src/app/shared/services/data/fact.service.ts ***!
  \******************************************************/
/*! exports provided: FactService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FactService", function() { return FactService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _hazlenut_hazelnut_common_hazelnut__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../hazlenut/hazelnut-common/hazelnut */ "./src/app/shared/hazlenut/hazelnut-common/hazelnut/index.ts");
/* harmony import */ var _hazlenut_hazelnut_common_models__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../hazlenut/hazelnut-common/models */ "./src/app/shared/hazlenut/hazelnut-common/models/index.ts");
/* harmony import */ var _notification_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../notification.service */ "./src/app/shared/services/notification.service.ts");
/* harmony import */ var _project_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../project.service */ "./src/app/shared/services/project.service.ts");
/* harmony import */ var _storage_project_user_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../storage/project-user.service */ "./src/app/shared/services/storage/project-user.service.ts");








var FactService = /** @class */ (function (_super) {
    tslib__WEBPACK_IMPORTED_MODULE_0__["__extends"](FactService, _super);
    function FactService(http, notificationService, userService) {
        return _super.call(this, http, 'factItem', notificationService, userService) || this;
    }
    /**
     * Get list of Facts and Figures objects bast on table change event criteria and project filter
     * @param tableChangeEvent
     * @param projectFilter
     */
    FactService.prototype.browseFacts = function (tableChangeEvent, projectFilter) {
        var filters = [];
        var sort = [];
        var limit = 15;
        var offset = 0;
        if (tableChangeEvent) {
            limit = tableChangeEvent.pageSize;
            offset = tableChangeEvent.pageIndex * tableChangeEvent.pageSize;
            filters = Object.values(tableChangeEvent.filters);
            filters.forEach(function (filter) { return filter.property = _hazlenut_hazelnut_common_hazelnut__WEBPACK_IMPORTED_MODULE_3__["StringUtils"].convertCamelToSnakeUpper(filter.property); });
            if (tableChangeEvent.sortActive && tableChangeEvent.sortDirection) {
                sort = [new _hazlenut_hazelnut_common_models__WEBPACK_IMPORTED_MODULE_4__["Sort"](tableChangeEvent.sortActive, tableChangeEvent.sortDirection)];
            }
        }
        if (projectFilter) {
            filters.push(projectFilter);
        }
        return this.browseWithSummary(_hazlenut_hazelnut_common_models__WEBPACK_IMPORTED_MODULE_4__["PostContent"].create(limit, offset, filters, sort));
    };
    /**
     * Create fact object with API call
     * @param factObject
     */
    FactService.prototype.createFact = function (factObject) {
        return this.add(factObject);
    };
    /**
     * Get fact object from API
     * @param id
     * @param projectId
     */
    FactService.prototype.getFactById = function (id, projectId) {
        return this.getFactItemDetail(id, projectId);
    };
    /**
     * Edit task object API call
     * @param id
     * @param taskObject
     */
    FactService.prototype.editTask = function (id, taskObject) {
        return this.update(id, taskObject);
    };
    /**
     * Report task objects into report file and download from API
     * @param tableChangeEvent
     * @param additionalFilters
     */
    FactService.prototype.exportTasks = function (tableChangeEvent, additionalFilters, projectId) {
        var filters = [];
        var sort = [];
        if (tableChangeEvent && tableChangeEvent.sortActive && tableChangeEvent.sortDirection) {
            sort = [new _hazlenut_hazelnut_common_models__WEBPACK_IMPORTED_MODULE_4__["Sort"](tableChangeEvent.sortActive, tableChangeEvent.sortDirection)];
        }
        filters = filters.concat(additionalFilters);
        filters = this.reorderFiltersToApplyCorectTrafficColor(filters);
        return this.report(filters, sort, projectId);
    };
    /**
     * Reorder filters with conditiona that traffic light filters are first
     * @param filters
     */
    FactService.prototype.reorderFiltersToApplyCorectTrafficColor = function (filters) {
        return filters.sort(this.compare);
    };
    /**
     * Compare sort function with traffic light property preselection
     * @param a
     * @param b
     */
    FactService.prototype.compare = function (a, b) {
        if (a.property === 'TRAFFIC_LIGHT') {
            return -1;
        }
        if (a.property !== 'TRAFFIC_LIGHT') {
            return 1;
        }
        return 0;
    };
    FactService.ctorParameters = function () { return [
        { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"] },
        { type: _notification_service__WEBPACK_IMPORTED_MODULE_5__["NotificationService"] },
        { type: _storage_project_user_service__WEBPACK_IMPORTED_MODULE_7__["ProjectUserService"] }
    ]; };
    FactService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Injectable"])({
            providedIn: 'root'
        })
        /**
         * Fact service communicating with 'factItem' API url
         */
        ,
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"],
            _notification_service__WEBPACK_IMPORTED_MODULE_5__["NotificationService"],
            _storage_project_user_service__WEBPACK_IMPORTED_MODULE_7__["ProjectUserService"]])
    ], FactService);
    return FactService;
}(_project_service__WEBPACK_IMPORTED_MODULE_6__["ProjectService"]));



/***/ })

}]);
//# sourceMappingURL=pages-facts-facts-module.js.map