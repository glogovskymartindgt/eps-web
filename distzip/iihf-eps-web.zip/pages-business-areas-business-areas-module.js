(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-business-areas-business-areas-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/business-areas/business-area-list/business-area-list.component.html":
/*!*********************************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/business-areas/business-area-list/business-area-list.component.html ***!
  \*********************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div>\r\n    \r\n    <!--    Simple title of screen-->\r\n    <div fxLayout=\"row\" class=\"basic-screen-header\">\r\n        <div class=\"pl-50\" fxLayoutAlign=\"start center\">\r\n            <h2>{{'businessArea.title' | translate}}</h2>\r\n        </div>\r\n    </div>\r\n\r\n    <!--    Core table representing list of business areas with custom column-->\r\n    <haz-indeterminate-progress-bar [loading]=\"loading\"></haz-indeterminate-progress-bar>\r\n    <haz-core-table (requestData)=\"setTableData($event)\"\r\n                    [configuration]=\"config\"\r\n                    [data]=\"data\"\r\n                    style=\"width: 500px\"\r\n    ></haz-core-table>\r\n\r\n    <!--    Custom column navigate to Tasks-->\r\n    <ng-template #navigationToTasksColumn let-actRow=\"row\" let-context=\"context\">\r\n        <div class=\"fr\" *ngIf=\"hasRoleReadTask()\">\r\n            <button (click)=\"showTasks(actRow.name)\" mat-icon-button>\r\n                <mat-icon>keyboard_arrow_right</mat-icon>\r\n            </button>\r\n        </div>\r\n    </ng-template>\r\n\r\n</div>\r\n");

/***/ }),

/***/ "./src/app/pages/business-areas/business-area-list/business-area-list.component.scss":
/*!*******************************************************************************************!*\
  !*** ./src/app/pages/business-areas/business-area-list/business-area-list.component.scss ***!
  \*******************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL2J1c2luZXNzLWFyZWFzL2J1c2luZXNzLWFyZWEtbGlzdC9idXNpbmVzcy1hcmVhLWxpc3QuY29tcG9uZW50LnNjc3MifQ== */");

/***/ }),

/***/ "./src/app/pages/business-areas/business-area-list/business-area-list.component.ts":
/*!*****************************************************************************************!*\
  !*** ./src/app/pages/business-areas/business-area-list/business-area-list.component.ts ***!
  \*****************************************************************************************/
/*! exports provided: BusinessAreaListComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BusinessAreaListComponent", function() { return BusinessAreaListComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ngx-translate/core */ "./node_modules/@ngx-translate/core/fesm5/ngx-translate-core.js");
/* harmony import */ var _shared_enums_role_enum__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../shared/enums/role.enum */ "./src/app/shared/enums/role.enum.ts");
/* harmony import */ var _shared_hazlenut_core_table__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../shared/hazlenut/core-table */ "./src/app/shared/hazlenut/core-table/index.ts");
/* harmony import */ var _shared_hazlenut_hazelnut_common_models__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../shared/hazlenut/hazelnut-common/models */ "./src/app/shared/hazlenut/hazelnut-common/models/index.ts");
/* harmony import */ var _shared_services_auth_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../../shared/services/auth.service */ "./src/app/shared/services/auth.service.ts");
/* harmony import */ var _shared_services_data_business_area_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../../shared/services/data/business-area.service */ "./src/app/shared/services/data/business-area.service.ts");
/* harmony import */ var _shared_services_notification_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../../shared/services/notification.service */ "./src/app/shared/services/notification.service.ts");
/* harmony import */ var _shared_services_storage_selected_area_service__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../../shared/services/storage/selected-area.service */ "./src/app/shared/services/storage/selected-area.service.ts");











var BusinessAreaListComponent = /** @class */ (function () {
    function BusinessAreaListComponent(translateService, router, businessAreaService, selectedAreaService, notificationService, authService) {
        this.translateService = translateService;
        this.router = router;
        this.businessAreaService = businessAreaService;
        this.selectedAreaService = selectedAreaService;
        this.notificationService = notificationService;
        this.authService = authService;
        this.loading = false;
        this.data = new _shared_hazlenut_hazelnut_common_models__WEBPACK_IMPORTED_MODULE_6__["BrowseResponse"]();
        this.isInitialized = false;
    }
    /**
     * Config setup on initialization
     */
    BusinessAreaListComponent.prototype.ngOnInit = function () {
        this.config = {
            columns: [
                new _shared_hazlenut_core_table__WEBPACK_IMPORTED_MODULE_5__["TableColumn"]({
                    columnDef: 'codeItem',
                    labelKey: 'businessArea.code',
                    type: _shared_hazlenut_core_table__WEBPACK_IMPORTED_MODULE_5__["TableCellType"].NUMBER,
                    filter: new _shared_hazlenut_core_table__WEBPACK_IMPORTED_MODULE_5__["TableColumnFilter"]({
                        type: _shared_hazlenut_core_table__WEBPACK_IMPORTED_MODULE_5__["TableFilterType"].NUMBER,
                    }),
                    sorting: true,
                }),
                new _shared_hazlenut_core_table__WEBPACK_IMPORTED_MODULE_5__["TableColumn"]({
                    columnDef: 'name',
                    labelKey: 'businessArea.name',
                    filter: new _shared_hazlenut_core_table__WEBPACK_IMPORTED_MODULE_5__["TableColumnFilter"]({}),
                    sorting: true,
                }),
                new _shared_hazlenut_core_table__WEBPACK_IMPORTED_MODULE_5__["TableColumn"]({
                    columnDef: ' ',
                    labelKey: ' ',
                    type: _shared_hazlenut_core_table__WEBPACK_IMPORTED_MODULE_5__["TableCellType"].CONTENT,
                    tableCellTemplate: this.navigationToTasksColumn,
                    filter: new _shared_hazlenut_core_table__WEBPACK_IMPORTED_MODULE_5__["TableColumnFilter"]({
                        type: _shared_hazlenut_core_table__WEBPACK_IMPORTED_MODULE_5__["TableFilterType"].CLEAR_FILTERS,
                    }),
                }),
            ],
            paging: true,
        };
    };
    /**
     * Navigate to task list screen and save value of selectedArea
     * @param selectedArea
     */
    BusinessAreaListComponent.prototype.showTasks = function (selectedArea) {
        this.selectedAreaService.setSelectedArea(selectedArea);
        this.router.navigate(['tasks/list']);
    };
    /**
     * Load data from service for table
     * On first call is initialized
     * @param tableChangeEvent
     */
    BusinessAreaListComponent.prototype.setTableData = function (tableChangeEvent) {
        var _this = this;
        this.loading = true;
        this.businessAreaService.browseBusinessAreas(tableChangeEvent)
            .subscribe(function (data) {
            _this.data = data;
            _this.loading = false;
            _this.isInitialized = true;
        }, function () {
            _this.loading = false;
            _this.notificationService.openErrorNotification('error.api');
        });
    };
    BusinessAreaListComponent.prototype.hasRoleReadTask = function () {
        return this.authService.hasRole(_shared_enums_role_enum__WEBPACK_IMPORTED_MODULE_4__["Role"].RoleReadTask);
    };
    BusinessAreaListComponent.ctorParameters = function () { return [
        { type: _ngx_translate_core__WEBPACK_IMPORTED_MODULE_3__["TranslateService"] },
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"] },
        { type: _shared_services_data_business_area_service__WEBPACK_IMPORTED_MODULE_8__["BusinessAreaService"] },
        { type: _shared_services_storage_selected_area_service__WEBPACK_IMPORTED_MODULE_10__["SelectedAreaService"] },
        { type: _shared_services_notification_service__WEBPACK_IMPORTED_MODULE_9__["NotificationService"] },
        { type: _shared_services_auth_service__WEBPACK_IMPORTED_MODULE_7__["AuthService"] }
    ]; };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])('expandedContent', { static: true }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"])
    ], BusinessAreaListComponent.prototype, "expandedContent", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])('navigationToTasksColumn', { static: true }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"])
    ], BusinessAreaListComponent.prototype, "navigationToTasksColumn", void 0);
    BusinessAreaListComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'business-area-list',
            template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./business-area-list.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/business-areas/business-area-list/business-area-list.component.html")).default,
            styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./business-area-list.component.scss */ "./src/app/pages/business-areas/business-area-list/business-area-list.component.scss")).default]
        })
        /**
         * Business area list with title table and loader
         */ ,
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ngx_translate_core__WEBPACK_IMPORTED_MODULE_3__["TranslateService"],
            _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"],
            _shared_services_data_business_area_service__WEBPACK_IMPORTED_MODULE_8__["BusinessAreaService"],
            _shared_services_storage_selected_area_service__WEBPACK_IMPORTED_MODULE_10__["SelectedAreaService"],
            _shared_services_notification_service__WEBPACK_IMPORTED_MODULE_9__["NotificationService"],
            _shared_services_auth_service__WEBPACK_IMPORTED_MODULE_7__["AuthService"]])
    ], BusinessAreaListComponent);
    return BusinessAreaListComponent;
}());



/***/ }),

/***/ "./src/app/pages/business-areas/business-areas-routing.module.ts":
/*!***********************************************************************!*\
  !*** ./src/app/pages/business-areas/business-areas-routing.module.ts ***!
  \***********************************************************************/
/*! exports provided: BusinessAreasRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BusinessAreasRoutingModule", function() { return BusinessAreasRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _business_area_list_business_area_list_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./business-area-list/business-area-list.component */ "./src/app/pages/business-areas/business-area-list/business-area-list.component.ts");




var routes = [
    {
        path: '',
        children: [
            {
                path: '',
                pathMatch: 'full',
                redirectTo: 'list',
                data: { title: 'businessAreaList' },
            },
            {
                path: 'list',
                component: _business_area_list_business_area_list_component__WEBPACK_IMPORTED_MODULE_3__["BusinessAreaListComponent"],
                data: { title: 'businessAreaList' },
            },
        ],
    }
];
var BusinessAreasRoutingModule = /** @class */ (function () {
    function BusinessAreasRoutingModule() {
    }
    BusinessAreasRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
            exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
        })
    ], BusinessAreasRoutingModule);
    return BusinessAreasRoutingModule;
}());



/***/ }),

/***/ "./src/app/pages/business-areas/business-areas.module.ts":
/*!***************************************************************!*\
  !*** ./src/app/pages/business-areas/business-areas.module.ts ***!
  \***************************************************************/
/*! exports provided: BusinessAreasModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BusinessAreasModule", function() { return BusinessAreasModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_flex_layout__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/flex-layout */ "./node_modules/@angular/flex-layout/esm5/flex-layout.es5.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ngx-translate/core */ "./node_modules/@ngx-translate/core/fesm5/ngx-translate-core.js");
/* harmony import */ var _shared_hazlenut_core_table__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../shared/hazlenut/core-table */ "./src/app/shared/hazlenut/core-table/index.ts");
/* harmony import */ var _shared_hazlenut_hazelnut_common__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../shared/hazlenut/hazelnut-common */ "./src/app/shared/hazlenut/hazelnut-common/index.ts");
/* harmony import */ var _shared_hazlenut_small_components__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../shared/hazlenut/small-components */ "./src/app/shared/hazlenut/small-components/index.ts");
/* harmony import */ var _business_area_list_business_area_list_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./business-area-list/business-area-list.component */ "./src/app/pages/business-areas/business-area-list/business-area-list.component.ts");
/* harmony import */ var _business_areas_routing_module__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./business-areas-routing.module */ "./src/app/pages/business-areas/business-areas-routing.module.ts");











var BusinessAreasModule = /** @class */ (function () {
    function BusinessAreasModule() {
    }
    BusinessAreasModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["NgModule"])({
            declarations: [_business_area_list_business_area_list_component__WEBPACK_IMPORTED_MODULE_9__["BusinessAreaListComponent"]],
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"],
                _business_areas_routing_module__WEBPACK_IMPORTED_MODULE_10__["BusinessAreasRoutingModule"],
                _shared_hazlenut_hazelnut_common__WEBPACK_IMPORTED_MODULE_7__["MaterialModule"],
                _angular_flex_layout__WEBPACK_IMPORTED_MODULE_3__["FlexLayoutModule"],
                _ngx_translate_core__WEBPACK_IMPORTED_MODULE_5__["TranslateModule"].forChild(),
                _angular_forms__WEBPACK_IMPORTED_MODULE_4__["ReactiveFormsModule"],
                _shared_hazlenut_core_table__WEBPACK_IMPORTED_MODULE_6__["CoreTableModule"],
                _shared_hazlenut_small_components__WEBPACK_IMPORTED_MODULE_8__["SmallComponentsModule"]
            ]
        })
    ], BusinessAreasModule);
    return BusinessAreasModule;
}());



/***/ })

}]);
//# sourceMappingURL=pages-business-areas-business-areas-module.js.map