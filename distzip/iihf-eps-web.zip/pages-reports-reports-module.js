(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-reports-reports-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/reports/report-list/report-list.component.html":
/*!************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/reports/report-list/report-list.component.html ***!
  \************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<!--Table of predefined reports with title and export button in each report row-->\r\n<div class=\"basic-screen-header\" fxLayout=\"row\">\r\n    <div class=\"pl-50\" fxLayoutAlign=\"start center\">\r\n        <h2>{{'report.title' | translate}}</h2>\r\n    </div>\r\n</div>\r\n\r\n<haz-indeterminate-progress-bar [loading]=\"loading\"></haz-indeterminate-progress-bar>\r\n<haz-core-table [configuration]=\"config\" [data]=\"data\"></haz-core-table>\r\n<ng-template #descriptionColumn let-actRow=\"row\" let-context=\"context\">\r\n    <div class=\"p-5\">{{actRow.description}}</div>\r\n</ng-template>\r\n<ng-template #actionColumn let-actRow=\"row\" let-context=\"context\">\r\n    <button (click)=\"export(actRow.id)\"\r\n            *ngIf=\"(actRow.id === 1 && hasRoleExportReportToDoList()) || (actRow.id === 2 && hasRoleExportReportRedFlagList())\"\r\n            mat-icon-button\r\n    >\r\n        <mat-icon>save_alt</mat-icon>\r\n    </button>\r\n</ng-template>\r\n");

/***/ }),

/***/ "./src/app/pages/reports/report-list/report-list.component.scss":
/*!**********************************************************************!*\
  !*** ./src/app/pages/reports/report-list/report-list.component.scss ***!
  \**********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL3JlcG9ydHMvcmVwb3J0LWxpc3QvcmVwb3J0LWxpc3QuY29tcG9uZW50LnNjc3MifQ== */");

/***/ }),

/***/ "./src/app/pages/reports/report-list/report-list.component.ts":
/*!********************************************************************!*\
  !*** ./src/app/pages/reports/report-list/report-list.component.ts ***!
  \********************************************************************/
/*! exports provided: ReportListComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ReportListComponent", function() { return ReportListComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _shared_enums_role_enum__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../shared/enums/role.enum */ "./src/app/shared/enums/role.enum.ts");
/* harmony import */ var _shared_hazlenut_core_table__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../shared/hazlenut/core-table */ "./src/app/shared/hazlenut/core-table/index.ts");
/* harmony import */ var _shared_hazlenut_hazelnut_common_models__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../shared/hazlenut/hazelnut-common/models */ "./src/app/shared/hazlenut/hazelnut-common/models/index.ts");
/* harmony import */ var _shared_hazlenut_hazelnut_common_utils_file_manager__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../shared/hazlenut/hazelnut-common/utils/file-manager */ "./src/app/shared/hazlenut/hazelnut-common/utils/file-manager.ts");
/* harmony import */ var _shared_services_auth_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../shared/services/auth.service */ "./src/app/shared/services/auth.service.ts");
/* harmony import */ var _shared_services_data_report_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../../shared/services/data/report.service */ "./src/app/shared/services/data/report.service.ts");
/* harmony import */ var _shared_services_notification_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../../shared/services/notification.service */ "./src/app/shared/services/notification.service.ts");
/* harmony import */ var _shared_services_storage_project_event_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../../shared/services/storage/project-event.service */ "./src/app/shared/services/storage/project-event.service.ts");
/* harmony import */ var _shared_utils_headers__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../../shared/utils/headers */ "./src/app/shared/utils/headers.ts");











var ReportListComponent = /** @class */ (function () {
    function ReportListComponent(notificationService, reportService, projectEventService, authService) {
        this.notificationService = notificationService;
        this.reportService = reportService;
        this.projectEventService = projectEventService;
        this.authService = authService;
        this.loading = false;
        this.data = new _shared_hazlenut_hazelnut_common_models__WEBPACK_IMPORTED_MODULE_4__["BrowseResponse"]();
    }
    /**
     * Set table data values and config setup
     */
    ReportListComponent.prototype.ngOnInit = function () {
        this.setTableData();
        this.config = {
            stickyEnd: 2,
            columns: [
                new _shared_hazlenut_core_table__WEBPACK_IMPORTED_MODULE_3__["TableColumn"]({
                    columnDef: 'name',
                    labelKey: 'report.name',
                }),
                new _shared_hazlenut_core_table__WEBPACK_IMPORTED_MODULE_3__["TableColumn"]({
                    columnDef: 'description',
                    labelKey: 'report.description',
                    type: _shared_hazlenut_core_table__WEBPACK_IMPORTED_MODULE_3__["TableCellType"].CONTENT,
                    tableCellTemplate: this.descriptionColumn,
                }),
                new _shared_hazlenut_core_table__WEBPACK_IMPORTED_MODULE_3__["TableColumn"]({
                    columnDef: ' ',
                    label: ' ',
                    type: _shared_hazlenut_core_table__WEBPACK_IMPORTED_MODULE_3__["TableCellType"].CONTENT,
                    tableCellTemplate: this.actionColumn,
                }),
            ],
            paging: false,
        };
    };
    /**
     * Export excel report from API
     * @param reportId
     */
    ReportListComponent.prototype.export = function (reportId) {
        var _this = this;
        this.loading = true;
        this.reportService.exportReport(this.projectEventService.instant.id, reportId)
            .subscribe(function (response) {
            new _shared_hazlenut_hazelnut_common_utils_file_manager__WEBPACK_IMPORTED_MODULE_5__["FileManager"]().saveFile(Object(_shared_utils_headers__WEBPACK_IMPORTED_MODULE_10__["GetFileNameFromContentDisposition"])(response.headers.get('Content-Disposition')), response.body, 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
            _this.loading = false;
        }, function () {
            _this.notificationService.openErrorNotification('error.api');
            _this.loading = false;
        });
    };
    ReportListComponent.prototype.hasRoleExportReportRedFlagList = function () {
        return this.authService.hasRole(_shared_enums_role_enum__WEBPACK_IMPORTED_MODULE_2__["Role"].RoleExportReportRedFlagList);
    };
    ReportListComponent.prototype.hasRoleExportReportToDoList = function () {
        return this.authService.hasRole(_shared_enums_role_enum__WEBPACK_IMPORTED_MODULE_2__["Role"].RoleExportReportToDoList);
    };
    /**
     * Set report table data from API
     */
    ReportListComponent.prototype.setTableData = function () {
        var _this = this;
        this.loading = true;
        this.reportService.getAllReports()
            .subscribe(function (data) {
            _this.data.content = data;
            _this.data.totalElements = data.length;
            _this.loading = false;
        }, function () {
            _this.loading = false;
            _this.notificationService.openErrorNotification('error.api');
        });
    };
    ReportListComponent.ctorParameters = function () { return [
        { type: _shared_services_notification_service__WEBPACK_IMPORTED_MODULE_8__["NotificationService"] },
        { type: _shared_services_data_report_service__WEBPACK_IMPORTED_MODULE_7__["ReportService"] },
        { type: _shared_services_storage_project_event_service__WEBPACK_IMPORTED_MODULE_9__["ProjectEventService"] },
        { type: _shared_services_auth_service__WEBPACK_IMPORTED_MODULE_6__["AuthService"] }
    ]; };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])('descriptionColumn', { static: true }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"])
    ], ReportListComponent.prototype, "descriptionColumn", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])('actionColumn', { static: true }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"])
    ], ReportListComponent.prototype, "actionColumn", void 0);
    ReportListComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'report-list',
            template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./report-list.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/reports/report-list/report-list.component.html")).default,
            styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./report-list.component.scss */ "./src/app/pages/reports/report-list/report-list.component.scss")).default]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_shared_services_notification_service__WEBPACK_IMPORTED_MODULE_8__["NotificationService"],
            _shared_services_data_report_service__WEBPACK_IMPORTED_MODULE_7__["ReportService"],
            _shared_services_storage_project_event_service__WEBPACK_IMPORTED_MODULE_9__["ProjectEventService"],
            _shared_services_auth_service__WEBPACK_IMPORTED_MODULE_6__["AuthService"]])
    ], ReportListComponent);
    return ReportListComponent;
}());



/***/ }),

/***/ "./src/app/pages/reports/reports-routing.module.ts":
/*!*********************************************************!*\
  !*** ./src/app/pages/reports/reports-routing.module.ts ***!
  \*********************************************************/
/*! exports provided: ReportsRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ReportsRoutingModule", function() { return ReportsRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _report_list_report_list_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./report-list/report-list.component */ "./src/app/pages/reports/report-list/report-list.component.ts");




var routes = [
    {
        path: '',
        children: [
            {
                path: '',
                pathMatch: 'full',
                redirectTo: 'list',
            },
            {
                path: 'list',
                component: _report_list_report_list_component__WEBPACK_IMPORTED_MODULE_3__["ReportListComponent"],
                data: { title: 'reportList' }
            },
        ],
    }
];
var ReportsRoutingModule = /** @class */ (function () {
    function ReportsRoutingModule() {
    }
    ReportsRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
            exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
        })
    ], ReportsRoutingModule);
    return ReportsRoutingModule;
}());



/***/ }),

/***/ "./src/app/pages/reports/reports.module.ts":
/*!*************************************************!*\
  !*** ./src/app/pages/reports/reports.module.ts ***!
  \*************************************************/
/*! exports provided: ReportsModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ReportsModule", function() { return ReportsModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_flex_layout__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/flex-layout */ "./node_modules/@angular/flex-layout/esm5/flex-layout.es5.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ngx-translate/core */ "./node_modules/@ngx-translate/core/fesm5/ngx-translate-core.js");
/* harmony import */ var _shared_hazlenut_abstract_inputs__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../shared/hazlenut/abstract-inputs */ "./src/app/shared/hazlenut/abstract-inputs/index.ts");
/* harmony import */ var _shared_hazlenut_core_table__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../shared/hazlenut/core-table */ "./src/app/shared/hazlenut/core-table/index.ts");
/* harmony import */ var _shared_hazlenut_hazelnut_common__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../shared/hazlenut/hazelnut-common */ "./src/app/shared/hazlenut/hazelnut-common/index.ts");
/* harmony import */ var _shared_hazlenut_small_components__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../shared/hazlenut/small-components */ "./src/app/shared/hazlenut/small-components/index.ts");
/* harmony import */ var _report_list_report_list_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./report-list/report-list.component */ "./src/app/pages/reports/report-list/report-list.component.ts");
/* harmony import */ var _reports_routing_module__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./reports-routing.module */ "./src/app/pages/reports/reports-routing.module.ts");












var ReportsModule = /** @class */ (function () {
    function ReportsModule() {
    }
    ReportsModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["NgModule"])({
            declarations: [_report_list_report_list_component__WEBPACK_IMPORTED_MODULE_10__["ReportListComponent"]],
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"],
                _reports_routing_module__WEBPACK_IMPORTED_MODULE_11__["ReportsRoutingModule"],
                _shared_hazlenut_hazelnut_common__WEBPACK_IMPORTED_MODULE_8__["MaterialModule"],
                _angular_flex_layout__WEBPACK_IMPORTED_MODULE_3__["FlexLayoutModule"],
                _ngx_translate_core__WEBPACK_IMPORTED_MODULE_5__["TranslateModule"].forChild(),
                _angular_forms__WEBPACK_IMPORTED_MODULE_4__["ReactiveFormsModule"],
                _shared_hazlenut_core_table__WEBPACK_IMPORTED_MODULE_7__["CoreTableModule"],
                _shared_hazlenut_abstract_inputs__WEBPACK_IMPORTED_MODULE_6__["AbstractInputsModule"],
                _shared_hazlenut_small_components__WEBPACK_IMPORTED_MODULE_9__["SmallComponentsModule"]
            ]
        })
    ], ReportsModule);
    return ReportsModule;
}());



/***/ }),

/***/ "./src/app/shared/hazlenut/abstract-inputs/index.ts":
/*!**********************************************************!*\
  !*** ./src/app/shared/hazlenut/abstract-inputs/index.ts ***!
  \**********************************************************/
/*! exports provided: ABSTRACT_INPUT_TOKEN, AbstractInputsModule, ValidatorComposer, InputNumberComponent, CoreInputComponent, FORMAT, InputDateComponent, InputDateRangeComponent, InputNumberRangeComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _abstract_inputs_config__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./abstract-inputs-config */ "./src/app/shared/hazlenut/abstract-inputs/abstract-inputs-config.ts");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "ABSTRACT_INPUT_TOKEN", function() { return _abstract_inputs_config__WEBPACK_IMPORTED_MODULE_1__["ABSTRACT_INPUT_TOKEN"]; });

/* harmony import */ var _abstract_inputs_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./abstract-inputs.module */ "./src/app/shared/hazlenut/abstract-inputs/abstract-inputs.module.ts");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "AbstractInputsModule", function() { return _abstract_inputs_module__WEBPACK_IMPORTED_MODULE_2__["AbstractInputsModule"]; });

/* harmony import */ var _validator_composer__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./validator-composer */ "./src/app/shared/hazlenut/abstract-inputs/validator-composer.ts");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "ValidatorComposer", function() { return _validator_composer__WEBPACK_IMPORTED_MODULE_3__["ValidatorComposer"]; });

/* harmony import */ var _input_number_input_number_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./input-number/input-number.component */ "./src/app/shared/hazlenut/abstract-inputs/input-number/input-number.component.ts");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "InputNumberComponent", function() { return _input_number_input_number_component__WEBPACK_IMPORTED_MODULE_4__["InputNumberComponent"]; });

/* harmony import */ var _core_input_core_input_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./core-input/core-input.component */ "./src/app/shared/hazlenut/abstract-inputs/core-input/core-input.component.ts");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "CoreInputComponent", function() { return _core_input_core_input_component__WEBPACK_IMPORTED_MODULE_5__["CoreInputComponent"]; });

/* harmony import */ var _input_date_input_date_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./input-date/input-date.component */ "./src/app/shared/hazlenut/abstract-inputs/input-date/input-date.component.ts");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "FORMAT", function() { return _input_date_input_date_component__WEBPACK_IMPORTED_MODULE_6__["FORMAT"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "InputDateComponent", function() { return _input_date_input_date_component__WEBPACK_IMPORTED_MODULE_6__["InputDateComponent"]; });

/* harmony import */ var _input_date_range_input_date_range_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./input-date-range/input-date-range.component */ "./src/app/shared/hazlenut/abstract-inputs/input-date-range/input-date-range.component.ts");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "InputDateRangeComponent", function() { return _input_date_range_input_date_range_component__WEBPACK_IMPORTED_MODULE_7__["InputDateRangeComponent"]; });

/* harmony import */ var _input_number_range_input_number_range_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./input-number-range/input-number-range.component */ "./src/app/shared/hazlenut/abstract-inputs/input-number-range/input-number-range.component.ts");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "InputNumberRangeComponent", function() { return _input_number_range_input_number_range_component__WEBPACK_IMPORTED_MODULE_8__["InputNumberRangeComponent"]; });












/***/ }),

/***/ "./src/app/shared/hazlenut/hazelnut-common/utils/file-manager.ts":
/*!***********************************************************************!*\
  !*** ./src/app/shared/hazlenut/hazelnut-common/utils/file-manager.ts ***!
  \***********************************************************************/
/*! exports provided: FileManager */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FileManager", function() { return FileManager; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");

var FileManager = /** @class */ (function () {
    function FileManager() {
        this._input = document.createElement('input');
        this._input.setAttribute('type', 'file');
        this._input.setAttribute('value', 'files');
        this._input.setAttribute('multiple', '');
        this._input.setAttribute('class', 'hide');
        this._link = document.createElement('a');
        this._link.setAttribute('class', 'hide');
        this._link.setAttribute('href', '');
    }
    FileManager.prototype.saveFile = function (name, text, type) {
        if (type === void 0) { type = 'text/plain'; }
        document.body.appendChild(this._link);
        this._link.href = URL.createObjectURL(new Blob([text], { type: type }));
        this._link.download = name;
        this._link.click();
        document.body.removeChild(this._link);
    };
    FileManager.prototype.saveImage = function (name, image) {
        document.body.appendChild(this._link);
        this._link.href = typeof image === 'string' ? image : image.src;
        this._link.download = name;
        this._link.click();
        document.body.removeChild(this._link);
    };
    FileManager.prototype.saveImageByNameAndSource = function (name, src) {
        document.body.appendChild(this._link);
        this._link.href = src;
        this._link.download = name;
        this._link.click();
        document.body.removeChild(this._link);
    };
    FileManager.prototype.loadImage = function (func) {
        var _this = this;
        this.onFileChange(function (files) {
            var reader = new FileReader();
            reader.onload = function () {
                var image = new Image();
                image.src = reader.result;
                _this._input.value = null;
                func(image, files[0]);
            };
            reader.readAsDataURL(files[0]);
        });
    };
    FileManager.prototype.loadImages = function (func) {
        var _this = this;
        this.onFileChange(function (files) {
            var promises = [];
            var _loop_1 = function (file) {
                promises.push(new Promise(function (success, reject) {
                    var reader = new FileReader();
                    reader.onload = function () {
                        var image = new Image();
                        image.src = reader.result;
                        success({ image: image, file: file });
                    };
                    reader.onerror = function () { return reject(reader.error); };
                    reader.readAsDataURL(file);
                }));
            };
            for (var _i = 0, files_1 = files; _i < files_1.length; _i++) {
                var file = files_1[_i];
                _loop_1(file);
            }
            Promise.all(promises).then(function (data) {
                _this._input.value = null;
                func(data);
            }).catch(function (error) {
                throw new Error('Cannot upload files: ' + error.message);
            });
        });
    };
    FileManager.prototype.loadFile = function (func) {
        this._input.onchange = function (e) {
            var reader = new FileReader();
            reader.onload = function () { return func(reader.result); };
            reader.readAsText(e.target.files[0]);
        };
        this._input.click();
    };
    FileManager.prototype.loadBinaryFile = function (func) {
        this._input.onchange = function (event) {
            var reader = new FileReader();
            var files = event.target.files;
            if (files.length > 0) {
                reader.onload = function () { return func(reader.result, files[0].name); };
                reader.readAsBinaryString(files[0]);
            }
        };
        this._input.click();
    };
    FileManager.prototype.onFileChange = function (callback) {
        this._input.onchange = function (event) {
            var files = event.target.files;
            if (files.length > 0) {
                callback(files);
            }
        };
        this._input.click();
    };
    return FileManager;
}());



/***/ }),

/***/ "./src/app/shared/services/data/report.service.ts":
/*!********************************************************!*\
  !*** ./src/app/shared/services/data/report.service.ts ***!
  \********************************************************/
/*! exports provided: ReportService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ReportService", function() { return ReportService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _notification_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../notification.service */ "./src/app/shared/services/notification.service.ts");
/* harmony import */ var _project_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../project.service */ "./src/app/shared/services/project.service.ts");
/* harmony import */ var _storage_project_user_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../storage/project-user.service */ "./src/app/shared/services/storage/project-user.service.ts");






var ReportService = /** @class */ (function (_super) {
    tslib__WEBPACK_IMPORTED_MODULE_0__["__extends"](ReportService, _super);
    function ReportService(http, notificationService, userService) {
        return _super.call(this, http, 'report', notificationService, userService) || this;
    }
    /**
     * Get report objects from API
     */
    ReportService.prototype.getAllReports = function () {
        return this.getDetail('');
    };
    /**
     * Export report from API
     */
    ReportService.prototype.exportReport = function (projectId, reportId) {
        return this.reportGet(projectId, reportId);
    };
    ReportService.ctorParameters = function () { return [
        { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"] },
        { type: _notification_service__WEBPACK_IMPORTED_MODULE_3__["NotificationService"] },
        { type: _storage_project_user_service__WEBPACK_IMPORTED_MODULE_5__["ProjectUserService"] }
    ]; };
    ReportService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Injectable"])({
            providedIn: 'root'
        })
        /**
         * Fact service communicating with 'report' API url
         */
        ,
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"],
            _notification_service__WEBPACK_IMPORTED_MODULE_3__["NotificationService"],
            _storage_project_user_service__WEBPACK_IMPORTED_MODULE_5__["ProjectUserService"]])
    ], ReportService);
    return ReportService;
}(_project_service__WEBPACK_IMPORTED_MODULE_4__["ProjectService"]));



/***/ }),

/***/ "./src/app/shared/utils/headers.ts":
/*!*****************************************!*\
  !*** ./src/app/shared/utils/headers.ts ***!
  \*****************************************/
/*! exports provided: GetFileNameFromContentDisposition */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "GetFileNameFromContentDisposition", function() { return GetFileNameFromContentDisposition; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _hazlenut_hazelnut_common_regex_regex__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../hazlenut/hazelnut-common/regex/regex */ "./src/app/shared/hazlenut/hazelnut-common/regex/regex.ts");


function GetFileNameFromContentDisposition(disposition) {
    var exportName = 'EXPORT';
    if (disposition && disposition.indexOf('attachment') !== -1) {
        var filenameRegex = _hazlenut_hazelnut_common_regex_regex__WEBPACK_IMPORTED_MODULE_1__["Regex"].fileNameFromContentDispositionPattern;
        var matches = filenameRegex.exec(disposition);
        if (matches !== null && matches[1]) {
            exportName = matches[1].replace(/['"]/g, '');
        }
    }
    return exportName;
}


/***/ })

}]);
//# sourceMappingURL=pages-reports-reports-module.js.map