(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["main"],{

/***/ "./node_modules/moment/locale sync recursive ^\\.\\/.*$":
/*!**************************************************!*\
  !*** ./node_modules/moment/locale sync ^\.\/.*$ ***!
  \**************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var map = {
	"./af": "./node_modules/moment/locale/af.js",
	"./af.js": "./node_modules/moment/locale/af.js",
	"./ar": "./node_modules/moment/locale/ar.js",
	"./ar-dz": "./node_modules/moment/locale/ar-dz.js",
	"./ar-dz.js": "./node_modules/moment/locale/ar-dz.js",
	"./ar-kw": "./node_modules/moment/locale/ar-kw.js",
	"./ar-kw.js": "./node_modules/moment/locale/ar-kw.js",
	"./ar-ly": "./node_modules/moment/locale/ar-ly.js",
	"./ar-ly.js": "./node_modules/moment/locale/ar-ly.js",
	"./ar-ma": "./node_modules/moment/locale/ar-ma.js",
	"./ar-ma.js": "./node_modules/moment/locale/ar-ma.js",
	"./ar-sa": "./node_modules/moment/locale/ar-sa.js",
	"./ar-sa.js": "./node_modules/moment/locale/ar-sa.js",
	"./ar-tn": "./node_modules/moment/locale/ar-tn.js",
	"./ar-tn.js": "./node_modules/moment/locale/ar-tn.js",
	"./ar.js": "./node_modules/moment/locale/ar.js",
	"./az": "./node_modules/moment/locale/az.js",
	"./az.js": "./node_modules/moment/locale/az.js",
	"./be": "./node_modules/moment/locale/be.js",
	"./be.js": "./node_modules/moment/locale/be.js",
	"./bg": "./node_modules/moment/locale/bg.js",
	"./bg.js": "./node_modules/moment/locale/bg.js",
	"./bm": "./node_modules/moment/locale/bm.js",
	"./bm.js": "./node_modules/moment/locale/bm.js",
	"./bn": "./node_modules/moment/locale/bn.js",
	"./bn.js": "./node_modules/moment/locale/bn.js",
	"./bo": "./node_modules/moment/locale/bo.js",
	"./bo.js": "./node_modules/moment/locale/bo.js",
	"./br": "./node_modules/moment/locale/br.js",
	"./br.js": "./node_modules/moment/locale/br.js",
	"./bs": "./node_modules/moment/locale/bs.js",
	"./bs.js": "./node_modules/moment/locale/bs.js",
	"./ca": "./node_modules/moment/locale/ca.js",
	"./ca.js": "./node_modules/moment/locale/ca.js",
	"./cs": "./node_modules/moment/locale/cs.js",
	"./cs.js": "./node_modules/moment/locale/cs.js",
	"./cv": "./node_modules/moment/locale/cv.js",
	"./cv.js": "./node_modules/moment/locale/cv.js",
	"./cy": "./node_modules/moment/locale/cy.js",
	"./cy.js": "./node_modules/moment/locale/cy.js",
	"./da": "./node_modules/moment/locale/da.js",
	"./da.js": "./node_modules/moment/locale/da.js",
	"./de": "./node_modules/moment/locale/de.js",
	"./de-at": "./node_modules/moment/locale/de-at.js",
	"./de-at.js": "./node_modules/moment/locale/de-at.js",
	"./de-ch": "./node_modules/moment/locale/de-ch.js",
	"./de-ch.js": "./node_modules/moment/locale/de-ch.js",
	"./de.js": "./node_modules/moment/locale/de.js",
	"./dv": "./node_modules/moment/locale/dv.js",
	"./dv.js": "./node_modules/moment/locale/dv.js",
	"./el": "./node_modules/moment/locale/el.js",
	"./el.js": "./node_modules/moment/locale/el.js",
	"./en-SG": "./node_modules/moment/locale/en-SG.js",
	"./en-SG.js": "./node_modules/moment/locale/en-SG.js",
	"./en-au": "./node_modules/moment/locale/en-au.js",
	"./en-au.js": "./node_modules/moment/locale/en-au.js",
	"./en-ca": "./node_modules/moment/locale/en-ca.js",
	"./en-ca.js": "./node_modules/moment/locale/en-ca.js",
	"./en-gb": "./node_modules/moment/locale/en-gb.js",
	"./en-gb.js": "./node_modules/moment/locale/en-gb.js",
	"./en-ie": "./node_modules/moment/locale/en-ie.js",
	"./en-ie.js": "./node_modules/moment/locale/en-ie.js",
	"./en-il": "./node_modules/moment/locale/en-il.js",
	"./en-il.js": "./node_modules/moment/locale/en-il.js",
	"./en-nz": "./node_modules/moment/locale/en-nz.js",
	"./en-nz.js": "./node_modules/moment/locale/en-nz.js",
	"./eo": "./node_modules/moment/locale/eo.js",
	"./eo.js": "./node_modules/moment/locale/eo.js",
	"./es": "./node_modules/moment/locale/es.js",
	"./es-do": "./node_modules/moment/locale/es-do.js",
	"./es-do.js": "./node_modules/moment/locale/es-do.js",
	"./es-us": "./node_modules/moment/locale/es-us.js",
	"./es-us.js": "./node_modules/moment/locale/es-us.js",
	"./es.js": "./node_modules/moment/locale/es.js",
	"./et": "./node_modules/moment/locale/et.js",
	"./et.js": "./node_modules/moment/locale/et.js",
	"./eu": "./node_modules/moment/locale/eu.js",
	"./eu.js": "./node_modules/moment/locale/eu.js",
	"./fa": "./node_modules/moment/locale/fa.js",
	"./fa.js": "./node_modules/moment/locale/fa.js",
	"./fi": "./node_modules/moment/locale/fi.js",
	"./fi.js": "./node_modules/moment/locale/fi.js",
	"./fo": "./node_modules/moment/locale/fo.js",
	"./fo.js": "./node_modules/moment/locale/fo.js",
	"./fr": "./node_modules/moment/locale/fr.js",
	"./fr-ca": "./node_modules/moment/locale/fr-ca.js",
	"./fr-ca.js": "./node_modules/moment/locale/fr-ca.js",
	"./fr-ch": "./node_modules/moment/locale/fr-ch.js",
	"./fr-ch.js": "./node_modules/moment/locale/fr-ch.js",
	"./fr.js": "./node_modules/moment/locale/fr.js",
	"./fy": "./node_modules/moment/locale/fy.js",
	"./fy.js": "./node_modules/moment/locale/fy.js",
	"./ga": "./node_modules/moment/locale/ga.js",
	"./ga.js": "./node_modules/moment/locale/ga.js",
	"./gd": "./node_modules/moment/locale/gd.js",
	"./gd.js": "./node_modules/moment/locale/gd.js",
	"./gl": "./node_modules/moment/locale/gl.js",
	"./gl.js": "./node_modules/moment/locale/gl.js",
	"./gom-latn": "./node_modules/moment/locale/gom-latn.js",
	"./gom-latn.js": "./node_modules/moment/locale/gom-latn.js",
	"./gu": "./node_modules/moment/locale/gu.js",
	"./gu.js": "./node_modules/moment/locale/gu.js",
	"./he": "./node_modules/moment/locale/he.js",
	"./he.js": "./node_modules/moment/locale/he.js",
	"./hi": "./node_modules/moment/locale/hi.js",
	"./hi.js": "./node_modules/moment/locale/hi.js",
	"./hr": "./node_modules/moment/locale/hr.js",
	"./hr.js": "./node_modules/moment/locale/hr.js",
	"./hu": "./node_modules/moment/locale/hu.js",
	"./hu.js": "./node_modules/moment/locale/hu.js",
	"./hy-am": "./node_modules/moment/locale/hy-am.js",
	"./hy-am.js": "./node_modules/moment/locale/hy-am.js",
	"./id": "./node_modules/moment/locale/id.js",
	"./id.js": "./node_modules/moment/locale/id.js",
	"./is": "./node_modules/moment/locale/is.js",
	"./is.js": "./node_modules/moment/locale/is.js",
	"./it": "./node_modules/moment/locale/it.js",
	"./it-ch": "./node_modules/moment/locale/it-ch.js",
	"./it-ch.js": "./node_modules/moment/locale/it-ch.js",
	"./it.js": "./node_modules/moment/locale/it.js",
	"./ja": "./node_modules/moment/locale/ja.js",
	"./ja.js": "./node_modules/moment/locale/ja.js",
	"./jv": "./node_modules/moment/locale/jv.js",
	"./jv.js": "./node_modules/moment/locale/jv.js",
	"./ka": "./node_modules/moment/locale/ka.js",
	"./ka.js": "./node_modules/moment/locale/ka.js",
	"./kk": "./node_modules/moment/locale/kk.js",
	"./kk.js": "./node_modules/moment/locale/kk.js",
	"./km": "./node_modules/moment/locale/km.js",
	"./km.js": "./node_modules/moment/locale/km.js",
	"./kn": "./node_modules/moment/locale/kn.js",
	"./kn.js": "./node_modules/moment/locale/kn.js",
	"./ko": "./node_modules/moment/locale/ko.js",
	"./ko.js": "./node_modules/moment/locale/ko.js",
	"./ku": "./node_modules/moment/locale/ku.js",
	"./ku.js": "./node_modules/moment/locale/ku.js",
	"./ky": "./node_modules/moment/locale/ky.js",
	"./ky.js": "./node_modules/moment/locale/ky.js",
	"./lb": "./node_modules/moment/locale/lb.js",
	"./lb.js": "./node_modules/moment/locale/lb.js",
	"./lo": "./node_modules/moment/locale/lo.js",
	"./lo.js": "./node_modules/moment/locale/lo.js",
	"./lt": "./node_modules/moment/locale/lt.js",
	"./lt.js": "./node_modules/moment/locale/lt.js",
	"./lv": "./node_modules/moment/locale/lv.js",
	"./lv.js": "./node_modules/moment/locale/lv.js",
	"./me": "./node_modules/moment/locale/me.js",
	"./me.js": "./node_modules/moment/locale/me.js",
	"./mi": "./node_modules/moment/locale/mi.js",
	"./mi.js": "./node_modules/moment/locale/mi.js",
	"./mk": "./node_modules/moment/locale/mk.js",
	"./mk.js": "./node_modules/moment/locale/mk.js",
	"./ml": "./node_modules/moment/locale/ml.js",
	"./ml.js": "./node_modules/moment/locale/ml.js",
	"./mn": "./node_modules/moment/locale/mn.js",
	"./mn.js": "./node_modules/moment/locale/mn.js",
	"./mr": "./node_modules/moment/locale/mr.js",
	"./mr.js": "./node_modules/moment/locale/mr.js",
	"./ms": "./node_modules/moment/locale/ms.js",
	"./ms-my": "./node_modules/moment/locale/ms-my.js",
	"./ms-my.js": "./node_modules/moment/locale/ms-my.js",
	"./ms.js": "./node_modules/moment/locale/ms.js",
	"./mt": "./node_modules/moment/locale/mt.js",
	"./mt.js": "./node_modules/moment/locale/mt.js",
	"./my": "./node_modules/moment/locale/my.js",
	"./my.js": "./node_modules/moment/locale/my.js",
	"./nb": "./node_modules/moment/locale/nb.js",
	"./nb.js": "./node_modules/moment/locale/nb.js",
	"./ne": "./node_modules/moment/locale/ne.js",
	"./ne.js": "./node_modules/moment/locale/ne.js",
	"./nl": "./node_modules/moment/locale/nl.js",
	"./nl-be": "./node_modules/moment/locale/nl-be.js",
	"./nl-be.js": "./node_modules/moment/locale/nl-be.js",
	"./nl.js": "./node_modules/moment/locale/nl.js",
	"./nn": "./node_modules/moment/locale/nn.js",
	"./nn.js": "./node_modules/moment/locale/nn.js",
	"./pa-in": "./node_modules/moment/locale/pa-in.js",
	"./pa-in.js": "./node_modules/moment/locale/pa-in.js",
	"./pl": "./node_modules/moment/locale/pl.js",
	"./pl.js": "./node_modules/moment/locale/pl.js",
	"./pt": "./node_modules/moment/locale/pt.js",
	"./pt-br": "./node_modules/moment/locale/pt-br.js",
	"./pt-br.js": "./node_modules/moment/locale/pt-br.js",
	"./pt.js": "./node_modules/moment/locale/pt.js",
	"./ro": "./node_modules/moment/locale/ro.js",
	"./ro.js": "./node_modules/moment/locale/ro.js",
	"./ru": "./node_modules/moment/locale/ru.js",
	"./ru.js": "./node_modules/moment/locale/ru.js",
	"./sd": "./node_modules/moment/locale/sd.js",
	"./sd.js": "./node_modules/moment/locale/sd.js",
	"./se": "./node_modules/moment/locale/se.js",
	"./se.js": "./node_modules/moment/locale/se.js",
	"./si": "./node_modules/moment/locale/si.js",
	"./si.js": "./node_modules/moment/locale/si.js",
	"./sk": "./node_modules/moment/locale/sk.js",
	"./sk.js": "./node_modules/moment/locale/sk.js",
	"./sl": "./node_modules/moment/locale/sl.js",
	"./sl.js": "./node_modules/moment/locale/sl.js",
	"./sq": "./node_modules/moment/locale/sq.js",
	"./sq.js": "./node_modules/moment/locale/sq.js",
	"./sr": "./node_modules/moment/locale/sr.js",
	"./sr-cyrl": "./node_modules/moment/locale/sr-cyrl.js",
	"./sr-cyrl.js": "./node_modules/moment/locale/sr-cyrl.js",
	"./sr.js": "./node_modules/moment/locale/sr.js",
	"./ss": "./node_modules/moment/locale/ss.js",
	"./ss.js": "./node_modules/moment/locale/ss.js",
	"./sv": "./node_modules/moment/locale/sv.js",
	"./sv.js": "./node_modules/moment/locale/sv.js",
	"./sw": "./node_modules/moment/locale/sw.js",
	"./sw.js": "./node_modules/moment/locale/sw.js",
	"./ta": "./node_modules/moment/locale/ta.js",
	"./ta.js": "./node_modules/moment/locale/ta.js",
	"./te": "./node_modules/moment/locale/te.js",
	"./te.js": "./node_modules/moment/locale/te.js",
	"./tet": "./node_modules/moment/locale/tet.js",
	"./tet.js": "./node_modules/moment/locale/tet.js",
	"./tg": "./node_modules/moment/locale/tg.js",
	"./tg.js": "./node_modules/moment/locale/tg.js",
	"./th": "./node_modules/moment/locale/th.js",
	"./th.js": "./node_modules/moment/locale/th.js",
	"./tl-ph": "./node_modules/moment/locale/tl-ph.js",
	"./tl-ph.js": "./node_modules/moment/locale/tl-ph.js",
	"./tlh": "./node_modules/moment/locale/tlh.js",
	"./tlh.js": "./node_modules/moment/locale/tlh.js",
	"./tr": "./node_modules/moment/locale/tr.js",
	"./tr.js": "./node_modules/moment/locale/tr.js",
	"./tzl": "./node_modules/moment/locale/tzl.js",
	"./tzl.js": "./node_modules/moment/locale/tzl.js",
	"./tzm": "./node_modules/moment/locale/tzm.js",
	"./tzm-latn": "./node_modules/moment/locale/tzm-latn.js",
	"./tzm-latn.js": "./node_modules/moment/locale/tzm-latn.js",
	"./tzm.js": "./node_modules/moment/locale/tzm.js",
	"./ug-cn": "./node_modules/moment/locale/ug-cn.js",
	"./ug-cn.js": "./node_modules/moment/locale/ug-cn.js",
	"./uk": "./node_modules/moment/locale/uk.js",
	"./uk.js": "./node_modules/moment/locale/uk.js",
	"./ur": "./node_modules/moment/locale/ur.js",
	"./ur.js": "./node_modules/moment/locale/ur.js",
	"./uz": "./node_modules/moment/locale/uz.js",
	"./uz-latn": "./node_modules/moment/locale/uz-latn.js",
	"./uz-latn.js": "./node_modules/moment/locale/uz-latn.js",
	"./uz.js": "./node_modules/moment/locale/uz.js",
	"./vi": "./node_modules/moment/locale/vi.js",
	"./vi.js": "./node_modules/moment/locale/vi.js",
	"./x-pseudo": "./node_modules/moment/locale/x-pseudo.js",
	"./x-pseudo.js": "./node_modules/moment/locale/x-pseudo.js",
	"./yo": "./node_modules/moment/locale/yo.js",
	"./yo.js": "./node_modules/moment/locale/yo.js",
	"./zh-cn": "./node_modules/moment/locale/zh-cn.js",
	"./zh-cn.js": "./node_modules/moment/locale/zh-cn.js",
	"./zh-hk": "./node_modules/moment/locale/zh-hk.js",
	"./zh-hk.js": "./node_modules/moment/locale/zh-hk.js",
	"./zh-tw": "./node_modules/moment/locale/zh-tw.js",
	"./zh-tw.js": "./node_modules/moment/locale/zh-tw.js"
};


function webpackContext(req) {
	var id = webpackContextResolve(req);
	return __webpack_require__(id);
}
function webpackContextResolve(req) {
	if(!__webpack_require__.o(map, req)) {
		var e = new Error("Cannot find module '" + req + "'");
		e.code = 'MODULE_NOT_FOUND';
		throw e;
	}
	return map[req];
}
webpackContext.keys = function webpackContextKeys() {
	return Object.keys(map);
};
webpackContext.resolve = webpackContextResolve;
module.exports = webpackContext;
webpackContext.id = "./node_modules/moment/locale sync recursive ^\\.\\/.*$";

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/app.component.html":
/*!**************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/app.component.html ***!
  \**************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<router-outlet></router-outlet>\r\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/composition/menu/menu.component.html":
/*!**************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/composition/menu/menu.component.html ***!
  \**************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div fxLayout=\"column\">\r\n    <div style=\"height: 50px\"></div>\r\n    <secondary-header></secondary-header>\r\n    <div>\r\n        <mat-drawer-container autosize class=\"menu-container mt-50\">\r\n            <mat-drawer #drawer\r\n                        *ngIf=\"projectEventService.subject.isEvent | async\"\r\n                        [@fadeEnterLeave]\r\n                        [disableClose]=\"true\"\r\n                        [opened]=\"menuOpen\"\r\n                        class=\"menu-sidenav\"\r\n                        mode=\"side\"\r\n            >\r\n                <div class=\"layer\" fxLayout=\"column\" fxLayoutAlign=\"space-between\">\r\n                    <div fxFlex fxLayout=\"column\">\r\n                        <div class=\"close-wrapper\" fxFlex=\"50px\">\r\n                            <button (click)=\"toggleDrawer()\" mat-icon-button>\r\n                                <mat-icon>close</mat-icon>\r\n                            </button>\r\n                        </div>\r\n                        <side-options fxFlex></side-options>\r\n                    </div>\r\n                    <div fxFlex=\"230px\" fxLayout=\"row\" fxLayoutAlign=\"space-between\">\r\n                        <div (dblclick)=\"toggleLanguage()\"\r\n                             class=\"version\"\r\n                             fxFlex\r\n                             fxLayoutAlign=\"flex-start flex-end\"\r\n                        >{{version}}</div>\r\n                        <div class=\"mr-10 mb-5\" fxFlex fxLayoutAlign=\"flex-end flex-end\">\r\n                            <img [src]=\"'assets/img/iihf-logo-without-text-transparent.png'\"\r\n                                 alt=\"iihf logo\"\r\n                                 height=\"170\"\r\n                            >\r\n                        </div>\r\n                    </div>\r\n                </div>\r\n            </mat-drawer>\r\n            <div fxLayout=\"column\">\r\n                <div class=\"menu-topnav\"\r\n                     fxLayout=\"row\"\r\n                     fxLayoutAlign=\"space-between center\"\r\n                >\r\n                </div>\r\n                <div [@routeAnimations]=\"animateRoute(outlet)\">\r\n                    <button (click)=\"toggleDrawer()\"\r\n                            *ngIf=\"!menuOpen\"\r\n                            class=\"drawer-open\"\r\n                            mat-icon-button\r\n                    >\r\n                        <mat-icon>menu</mat-icon>\r\n                    </button>\r\n                    <router-outlet #outlet=\"outlet\"></router-outlet>\r\n                </div>\r\n            </div>\r\n        </mat-drawer-container>\r\n    </div>\r\n</div>\r\n\r\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/composition/menu/secondary-header/secondary-header.component.html":
/*!*******************************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/composition/menu/secondary-header/secondary-header.component.html ***!
  \*******************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div *ngIf=\"projectEventService.subject.isEvent | async\"\r\n     class=\"project-header m-0 p-0\"\r\n     fxLayout=\"row\"\r\n>\r\n    <div [@fadeEnterLeave]\r\n         class=\"pt-10 pb-5\"\r\n         fxFlex=\"50px\"\r\n         fxLayoutAlign=\"center center\"\r\n    >\r\n        \r\n        <div style=\"background: white; width: 27px; height: 45px; border-radius: 3px;\">\r\n            <img [src]=\"projectEventService.instant.imagePath\"\r\n                 alt=\"iihf logo\"\r\n                 class=\"project-image p-2\"\r\n                 height=\"41\"\r\n                 width=\"24\"\r\n            >\r\n        </div>\r\n    </div>\r\n    <div [@fadeEnterLeave]\r\n         class=\"mt-7\"\r\n         fxFlex=\"90\"\r\n         fxLayoutAlign=\"start center\"\r\n    >\r\n        <h3 class=\"secondary-header m-0 ml-10\">\r\n            {{projectEventService.instant.year}} {{projectEventService.instant.projectName}}\r\n        </h3>\r\n    </div>\r\n    <div [@fadeEnterLeave]\r\n         class=\"mt-3\"\r\n         fxFlex\r\n         fxLayoutAlign=\"end center\"\r\n    >\r\n        <button (click)=\"routeToDashboard()\" mat-icon-button>\r\n            <mat-icon>close</mat-icon>\r\n        </button>\r\n    </div>\r\n</div>\r\n\r\n<div *ngIf=\"!(projectEventService.subject.isEvent | async)\" class=\"project-header\" fxLayout=\"row\"\r\n     fxLayoutAlign=\"start center\"\r\n>\r\n    <h3 [@fadeEnterLeave] class=\"m-0 ml-20 mt-7 dashboard-text\">{{ 'dashboard.dashboard' | translate}}</h3>\r\n    <a (click)=\"toggleFilter('ALL')\" [@fadeEnterLeave] [matRippleColor]=\"'rgba(255,255,255,0.2)'\"\r\n       [ngClass]=\"(activeFilter === 'ALL') ? 'activated' : 'non-activated'\"\r\n       class=\"ml-50 mt-7 dashboard-filter\"\r\n       mat-ripple\r\n    >\r\n        {{ 'dashboard.all' | translate}}\r\n    </a>\r\n    <a (click)=\"toggleFilter('OPEN')\" [@fadeEnterLeave] [matRippleColor]=\"'rgba(255,255,255,0.2)'\"\r\n       [ngClass]=\"(activeFilter === 'OPEN') ? 'activated' : 'non-activated'\"\r\n       class=\"ml-50 mt-7 dashboard-filter\"\r\n       mat-ripple\r\n    >\r\n        {{ 'dashboard.open' | translate}}\r\n    </a>\r\n    <a (click)=\"toggleFilter('CLOSED')\" [@fadeEnterLeave] [matRippleColor]=\"'rgba(255,255,255,0.2)'\"\r\n       [ngClass]=\"(activeFilter === 'CLOSED') ? 'activated' : 'non-activated'\"\r\n       class=\"ml-50 mt-7 dashboard-filter\"\r\n       mat-ripple\r\n    >\r\n        {{ 'dashboard.closed' | translate}}\r\n    </a>\r\n</div>\r\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/composition/side-options/side-options.component.html":
/*!******************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/composition/side-options/side-options.component.html ***!
  \******************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div *ngFor=\"let menuItem of routes;\">\r\n    <div (click)=\"highlightAndNavigateOption(menuItem.path)\"\r\n         *ngIf=\"checkRoute(menuItem, false)\"\r\n         class=\"menu-option h-26\"\r\n         matRipple\r\n    >\r\n        <div [ngClass]=\"getClass(menuItem.path)\">\r\n        </div>\r\n        <span class=\"menu-text\">{{menuItem.data[\"title\"] | translate}}</span>\r\n        <div class=\"bottom-border mt-25\"></div>\r\n    </div>\r\n    <div (click)=\"toggleMenuSelect()\"\r\n         *ngIf=\"checkRoute(menuItem, true)\"\r\n         class=\"menu-option h-26\"\r\n         matRipple\r\n    >\r\n        <span class=\"menu-text\">{{menuItem.data[\"title\"] | translate}}</span>\r\n        <mat-icon *ngIf=\"menuItem.hasOwnProperty('children')\"\r\n                  [ngClass]=\"{'rotate-180': menuSelect, 'rotate-360': !menuSelect}\"\r\n                  class=\"menu-icon-dropdown\"\r\n        >\r\n            keyboard_arrow_down\r\n        </mat-icon>\r\n    </div>\r\n    <div *ngIf=\"checkRoute(menuItem, true)\"\r\n         [ngClass]=\"{'child-container-open': menuSelect,\r\n                 'child-container': !menuSelect}\"\r\n    >\r\n        <side-options [routes]=\"menuItem.children\"></side-options>\r\n    </div>\r\n</div>\r\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/layouts/admin-layout/admin-layout.component.html":
/*!**************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/layouts/admin-layout/admin-layout.component.html ***!
  \**************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\r\n<div class=\"top-bar\" fxLayout=\"row\">\r\n    <div class=\"p-5\">\r\n        <img [src]=\"'assets/img/iihf-logo-without-text-transparent.png'\"\r\n             class=\"project-image p-2\"\r\n             alt=\"iihf logo\"\r\n             width=\"24\"\r\n             height=\"41\"\r\n        >\r\n    </div>\r\n    <div class=\"mt-10 ml-19 no-select title-text\" fxLayout=\"row\">\r\n        <span class=\"red-title\" style=\"margin-left: 19px;\">\r\n            {{'app.iihf' | translate}}\r\n        </span> &nbsp;\r\n        <span class=\"blue-title\">\r\n            {{'app.planningSystem' | translate}}\r\n        </span>\r\n        <span *ngIf=\"projectUserService.subject.authToken | async\"\r\n              style=\"position:absolute; right: 20px;\"\r\n              [@moveLeft]\r\n        >\r\n            <div fxLayout=\"row\">\r\n                <div>\r\n                    <mat-icon class=\"pr-20 user-icon\">account_circle</mat-icon>\r\n                </div>\r\n\r\n                <div>\r\n                    <span class=\"small-text\">{{login}}</span>\r\n                    <button mat-icon-button [matMenuTriggerFor]=\"menu\">\r\n                        <mat-icon>keyboard_arrow_down</mat-icon>\r\n                    </button>\r\n                    <mat-menu #menu=\"matMenu\">\r\n                      <button mat-menu-item class=\"small-text\" (click)=\"logout()\">\r\n                           <mat-icon>exit_to_app</mat-icon>\r\n                          {{'app.logout' | translate}}\r\n                      </button>\r\n                    </mat-menu>\r\n                </div>\r\n            </div>\r\n\r\n        </span>\r\n    </div>\r\n</div>\r\n\r\n<menu class=\"clear-spaces\"></menu>\r\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/layouts/auth-layout/auth-layout.component.html":
/*!************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/layouts/auth-layout/auth-layout.component.html ***!
  \************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<mat-sidenav-container>\r\n    <router-outlet></router-outlet>\r\n</mat-sidenav-container>\r\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/shared/components/dialog/image-dialog/image-dialog.component.html":
/*!*************************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/shared/components/dialog/image-dialog/image-dialog.component.html ***!
  \*************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div class=\"close-button-wrapper\">\r\n    <button (click)=\"close()\" color=\"priamry\" mat-icon-button>\r\n        <mat-icon>close</mat-icon>\r\n    </button>\r\n</div>\r\n<div class=\"image-wrapper\">\r\n    <img *ngIf=\"data.image\"\r\n         [src]=\"data.image\"\r\n         alt=\"attachment image\"\r\n         class=\"image\"\r\n    />\r\n</div>\r\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/shared/components/dialog/pdf-dialog/pdf-dialog.component.html":
/*!*********************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/shared/components/dialog/pdf-dialog/pdf-dialog.component.html ***!
  \*********************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div class=\"close-button-wrapper\">\r\n    <button (click)=\"close()\" color=\"priamry\" mat-icon-button>\r\n        <mat-icon>close</mat-icon>\r\n    </button>\r\n</div>\r\n<div class=\"pdf-wrapper\">\r\n    <pdf-viewer\r\n        [fit-to-page]=\"true\"\r\n        [original-size]=\"true\"\r\n        [render-text]=\"true\"\r\n        [show-all]=\"true\"\r\n        [src]=\"data.source\"\r\n    >\r\n    </pdf-viewer>\r\n</div>\r\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/shared/hazlenut/abstract-inputs/core-input/core-input.component.html":
/*!****************************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/shared/hazlenut/abstract-inputs/core-input/core-input.component.html ***!
  \****************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<mat-form-field [appearance]=\"appearance\" [ngStyle]=\"styles\">\r\n    <mat-label>{{ label }}</mat-label>\r\n    <input (blur)=\"handleBlur()\"\r\n           (focus)=\"handleFocus()\"\r\n           *ngIf=\"type === 'string'\"\r\n           [formControl]=\"formControl\"\r\n           [ngStyle]=\"inputStyles\"\r\n           [placeholder]=\"placeholder\"\r\n           [required]=\"required\"\r\n           autocomplete=\"off\"\r\n           matInput\r\n           style=\"width: 100%;\"\r\n    />\r\n    <textarea (blur)=\"manageUserInput()\"\r\n              *ngIf=\"type === 'textarea'\"\r\n              [formControl]=\"formControl\"\r\n              [placeholder]=\"placeholder\"\r\n              [required]=\"required\"\r\n              autocomplete=\"off\"\r\n              cdkAutosizeMaxRows=\"10\"\r\n              cdkAutosizeMinRows=\"2\"\r\n              cdkTextareaAutosize\r\n              matInput\r\n              style=\"width: 100%;\"\r\n    ></textarea>\r\n    <span *ngIf=\"textSuffix\" [ngStyle]=\"formControl.disabled ? {'color': '#989898'} : {}\" matSuffix>{{textSuffix}}</span>\r\n    <mat-hint align=\"start\">{{ displayedError }}</mat-hint>\r\n    <mat-hint align=\"end\">{{ displayedHint }}</mat-hint>\r\n    <mat-error *ngIf=\"showErrors\">{{ displayedError }}</mat-error>\r\n</mat-form-field>\r\n\r\n\r\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/shared/hazlenut/abstract-inputs/input-date-range/input-date-range.component.html":
/*!****************************************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/shared/hazlenut/abstract-inputs/input-date-range/input-date-range.component.html ***!
  \****************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div [ngClass]=\"'w-' + (dateWidth * 2 + 5)\" fxLayout=\"row\">\r\n    <haz-input-date [formControl]=\"fromFormControl\"\r\n                    [max]=\"transformToDate(toFormControl.value)\"\r\n                    class=\"mr-5\">\r\n    </haz-input-date>\r\n    <haz-input-date [formControl]=\"toFormControl\"\r\n                    [min]=\"transformToDate(fromFormControl.value)\">\r\n    </haz-input-date>\r\n    <mat-error *ngIf=\"dateRangeForm.errors && dateRangeForm.errors['minmax']\" class=\"error-message\">\r\n        {{ errorInterval }}\r\n    </mat-error>\r\n</div>\r\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/shared/hazlenut/abstract-inputs/input-date/input-date.component.html":
/*!****************************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/shared/hazlenut/abstract-inputs/input-date/input-date.component.html ***!
  \****************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<mat-form-field [ngClass]=\"'w-' + dateWidth\" class=\"pt-2\">\r\n    <input [formControl]=\"formControl\"\r\n           [matDatepicker]=\"date\"\r\n           [placeholder]=\"placeholder\"\r\n           [min]=\"min\"\r\n           [max]=\"max\"\r\n           matInput>\r\n    <mat-datepicker-toggle [for]=\"date\" matSuffix>\r\n    </mat-datepicker-toggle>\r\n    <mat-datepicker [dateClass]=\"dateClass\" #date></mat-datepicker>\r\n</mat-form-field>\r\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/shared/hazlenut/abstract-inputs/input-number-range/input-number-range.component.html":
/*!********************************************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/shared/hazlenut/abstract-inputs/input-number-range/input-number-range.component.html ***!
  \********************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div [ngClass]=\"'w-' + inputSize\" class=\"flex-end-column\">\r\n    <div class=\"flex-end-row\">\r\n        <haz-input-number [formControl]=\"fromControl\"\r\n                          [inputStyles]=\"inputStyles\"\r\n                          [label]=\"fromLabel\"\r\n                          class=\"mr-10\"\r\n                          [ngClass]=\"actualError === 'minmax' ? 'red-error' : ''\"\r\n                          [styles]=\"realStyles\">\r\n        </haz-input-number>\r\n        <haz-input-number [label]=\"toLabel\"\r\n                          [styles]=\"realStyles\"\r\n                          [inputStyles]=\"inputStyles\"\r\n                          [ngClass]=\"actualError === 'minmax' ? 'red-error' : ''\"\r\n                          [formControl]=\"toControl\">\r\n        </haz-input-number>\r\n    </div>\r\n    <mat-error *ngIf=\"actualError === 'minmax'\" class=\"error-message flex-end-row\">\r\n        {{errorInterval}}\r\n    </mat-error>\r\n</div>\r\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/shared/hazlenut/abstract-inputs/input-number/input-number.component.html":
/*!********************************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/shared/hazlenut/abstract-inputs/input-number/input-number.component.html ***!
  \********************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\r\n<ng-template [ngIf]=\"!customInput\">\r\n    <mat-form-field [appearance]=\"appearance\" [ngStyle]=\"styles\">\r\n        <mat-label>{{ label }}</mat-label>\r\n        <input (blur)=\"onTouched(this.value)\"\r\n               [formControl]=\"control\"\r\n               [placeholder]=\"placeholder\"\r\n               autocomplete=\"off\"\r\n               matInput\r\n               style=\"width: 100%;\"\r\n               maxlength=\"16\"\r\n        />\r\n        <mat-hint align=\"start\">{{ displayedError }}</mat-hint>\r\n        <mat-hint align=\"end\">{{ displayedHint }}</mat-hint>\r\n        <mat-error *ngIf=\"showErrors\">{{ displayedError }}</mat-error>\r\n    </mat-form-field>\r\n\r\n</ng-template>\r\n\r\n<ng-template [ngIf]=\"customInput\">\r\n    <ng-container [ngStyle]=\"styles\"\r\n                  *ngTemplateOutlet=\"customInput; context: { control: control, label: label }\"></ng-container>\r\n</ng-template>\r\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/shared/hazlenut/core-table/components/core-table-filter/core-table-filter.component.html":
/*!************************************************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/shared/hazlenut/core-table/components/core-table-filter/core-table-filter.component.html ***!
  \************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ng-container [formGroup]=\"filtersElement\" [ngSwitch]=\"columnConfig.filter?.type\">\r\n    <mat-form-field *ngSwitchCase=\"filterTypeEnum.STRING\"\r\n                    [ngClass]=\"widthClass\"\r\n                    class=\"custom-filter-input\"\r\n    >\r\n        <input (blur)=\"showSearchIcon = true\" (focus)=\"showSearchIcon = false\"\r\n               [formControlName]=\"columnConfig.filterElement\"\r\n               autocomplete=\"off\"\r\n               matInput\r\n               maxlength=\"255\"\r\n               type=\"text\"\r\n        >\r\n        <mat-icon (click)=\"filtersElement.reset()\"\r\n                  *ngIf=\"filtersElement.value[columnConfig.filterElement]\"\r\n                  [@fadeEnterLeave]\r\n                  class=\"suffix-close\"\r\n                  matSuffix\r\n        >\r\n            close\r\n        </mat-icon>\r\n    </mat-form-field>\r\n    \r\n    <mat-form-field *ngSwitchCase=\"filterTypeEnum.SELECT\" [ngClass]=\"widthClass\">\r\n        <mat-select [formControlName]=\"columnConfig.filterElement\">\r\n            <mat-option *ngFor=\"let option of columnConfig.filter.select\" [value]=\"option.code | async\">\r\n                {{ option.value | async }}\r\n            </mat-option>\r\n        </mat-select>\r\n    </mat-form-field>\r\n    \r\n    <mat-form-field *ngSwitchCase=\"filterTypeEnum.RESPONSIBLE\" [ngClass]=\"widthClass\">\r\n        <mat-select [formControlName]=\"columnConfig.filterElement\">\r\n            <mat-option [value]=\"'All'\">\r\n                {{ 'all.persons' | translate }}\r\n            </mat-option>\r\n            <mat-option *ngFor=\"let option of userList$ | async\" [value]=\"option.id\">\r\n                {{ option.firstName }} {{ option.lastName }}\r\n            </mat-option>\r\n        </mat-select>\r\n    </mat-form-field>\r\n    \r\n    <mat-form-field *ngSwitchCase=\"filterTypeEnum.CATEGORY\" [ngClass]=\"widthClass\">\r\n        <mat-select [formControlName]=\"columnConfig.filterElement\">\r\n            <mat-option [value]=\"'All'\">\r\n                {{ 'venue.value.all' | translate }}\r\n            </mat-option>\r\n            <mat-option *ngFor=\"let option of categoryList$\" [value]=\"option.name\">\r\n                {{ option.name }}\r\n            </mat-option>\r\n        </mat-select>\r\n    </mat-form-field>\r\n    \r\n    <mat-form-field *ngSwitchCase=\"filterTypeEnum.TYPE\" [ngClass]=\"widthClass\">\r\n        <mat-select [formControlName]=\"columnConfig.filterElement\">\r\n            <mat-option *ngFor=\"let option of columnConfig.filter.select\" [value]=\"option.code | async\">\r\n                {{ option.value | async }}\r\n            </mat-option>\r\n        </mat-select>\r\n    </mat-form-field>\r\n    \r\n    <mat-form-field *ngSwitchCase=\"filterTypeEnum.SELECT_STRING\" [ngClass]=\"widthClass\">\r\n        <mat-select [formControlName]=\"columnConfig.filterElement\">\r\n            <mat-option *ngFor=\"let option of columnConfig.filter.select\" [value]=\"option.code | async\">\r\n                {{ option.value | async }}\r\n            </mat-option>\r\n        </mat-select>\r\n    </mat-form-field>\r\n    \r\n    <mat-form-field *ngSwitchCase=\"filterTypeEnum.SELECT_NUMBER\"\r\n                    [ngClass]=\"widthClass\"\r\n    >\r\n        <mat-select [formControlName]=\"columnConfig.filterElement\">\r\n            <mat-option *ngFor=\"let option of columnConfig.filter.select\" [value]=\"option.value\">\r\n                {{ option.code | async }}\r\n            </mat-option>\r\n        </mat-select>\r\n    </mat-form-field>\r\n    \r\n    <mat-form-field *ngSwitchCase=\"filterTypeEnum.SELECT_ANY_DATE_TIME\"\r\n                    [ngClass]=\"widthClass\"\r\n    >\r\n        <mat-select [formControlName]=\"columnConfig.filterElement\">\r\n            <mat-option *ngFor=\"let option of columnConfig.filter.select\" [value]=\"option.code | async\">\r\n                {{ option.value | async }}\r\n            </mat-option>\r\n        </mat-select>\r\n    </mat-form-field>\r\n    <mat-form-field *ngSwitchCase=\"filterTypeEnum.TRAFFIC_LIGHT\"\r\n                    [ngClass]=\"widthClass\"\r\n    >\r\n        <mat-select-trigger *ngIf=\"columnConfig.filter.select\">\r\n            {{columnConfig.filterElement.value}}\r\n        </mat-select-trigger>\r\n        <mat-select [formControlName]=\"columnConfig.filterElement\" multiple>\r\n            <mat-option [value]=\"'green'\">\r\n                <div\r\n                    style=\"width: 12px;height: 12px;background:#20bf55;border-radius:50%; position: absolute;right: 12px;top:12px;\"\r\n                ></div>\r\n                {{'color.green' | translate}}\r\n            </mat-option>\r\n            <mat-option [value]=\"'amber'\">\r\n                <div\r\n                    style=\"width: 12px;height: 12px;background:#f79824;border-radius:50%; position: absolute;right: 12px;top:12px;\"\r\n                ></div>\r\n                {{'color.amber' | translate}}\r\n            </mat-option>\r\n            <mat-option [value]=\"'red'\">\r\n                <div\r\n                    style=\"width: 12px;height: 12px;background:#ce211f;border-radius:50%; position: absolute;right: 12px;top:12px;\"\r\n                ></div>\r\n                {{'color.red' | translate}}\r\n            </mat-option>\r\n            <mat-option [value]=\"'none'\">\r\n                {{'color.none' | translate}}\r\n            </mat-option>\r\n        </mat-select>\r\n    </mat-form-field>\r\n    \r\n    <ng-container *ngSwitchCase=\"filterTypeEnum.CUSTOM\">\r\n        <ng-container\r\n            *ngTemplateOutlet=\"columnConfig.filter.template; context: { columnConfig: columnConfig, control: control }\"\r\n        ></ng-container>\r\n    </ng-container>\r\n    \r\n    <haz-input-date-range *ngSwitchCase=\"filterTypeEnum.DATERANGE\" [formControlName]=\"columnConfig.filterElement\"\r\n                          class=\"min-w-165\"\r\n    >\r\n    </haz-input-date-range>\r\n    \r\n    <div *ngSwitchCase=\"filterTypeEnum.DATETIME_AS_DATERANGE\" class=\"min-w-210\">\r\n        <haz-input-date-range\r\n            [formControlName]=\"columnConfig.filterElement\"\r\n        >\r\n        </haz-input-date-range>\r\n    </div>\r\n    \r\n    <div *ngSwitchCase=\"filterTypeEnum.NUMBER\" class=\"min-w-130\" fxLayout=\"row\" style=\"justify-content: flex-end;\">\r\n        <haz-input-number-range [formControlName]=\"columnConfig.filterElement\">\r\n        </haz-input-number-range>\r\n    </div>\r\n    \r\n    <div *ngSwitchCase=\"filterTypeEnum.CLEAR_FILTERS\" fxLayout=\"row\" style=\"justify-content: flex-end;\">\r\n        <button (click)=\"clearFilters()\" mat-icon-button>\r\n            <mat-icon>cancel</mat-icon>\r\n        </button>\r\n    </div>\r\n    \r\n    <span *ngSwitchDefault></span>\r\n</ng-container>\r\n\r\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/shared/hazlenut/core-table/components/core-table.component.html":
/*!***********************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/shared/hazlenut/core-table/components/core-table.component.html ***!
  \***********************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div class=\"styled-table-container\">\r\n    <table [dataSource]=\"data?.content\"\r\n           [ngClass]=\"{'border-columns': configuration.columnBorders}\"\r\n           class=\"styled-table\"\r\n           mat-table\r\n           matSort\r\n           multiTemplateDataRows\r\n           [matSortActive]=\"configuration.predefinedSortActive ? configuration.predefinedSortActive : null\"\r\n           [matSortDirection]=\"configuration.predefinedSortDirection ? configuration.predefinedSortDirection : null\">\r\n        <!--header cells sticky-->\r\n        <div *ngIf=\"configuration.stickyEnd\">\r\n            <div *ngFor=\"let columnConfig of configuration.columns; let i = index\">\r\n                <ng-container *ngIf=\"i>configuration.stickyEnd\"\r\n                              [matColumnDef]=\"columnConfig.columnDef\" stickyEnd>\r\n                    <!-- header cell -->\r\n\r\n                    <!-- selection checkbox cell -->\r\n                    <ng-container *ngIf=\"i === 0 && selectableTable\">\r\n                        <td *matCellDef=\"let row\" mat-cell>\r\n                            <mat-checkbox\r\n                                (change)=\"$event ? selection.toggle(row) : null\"\r\n                                (click)=\"$event.stopPropagation()\"\r\n                                [checked]=\"selection.isSelected(row)\"\r\n                                [color]=\"configuration.selectionColor\"\r\n                            >\r\n                            </mat-checkbox>\r\n                        </td>\r\n                    </ng-container>\r\n\r\n                    <!-- dynamically set sorting -->\r\n                    <ng-container *ngIf=\"columnConfig.sorting\">\r\n                        <th\r\n                            *matHeaderCellDef\r\n                            [ngClass]=\"{ 'header-flexend': isRightAligned(columnConfig.type) || columnConfig.align === 'right' }\"\r\n                            mat-header-cell\r\n                            mat-sort-header\r\n                        >\r\n                            {{getLabel(columnConfig) | async}}\r\n                        </th>\r\n                    </ng-container>\r\n                    <ng-container *ngIf=\"!columnConfig.sorting\">\r\n                        <th *matHeaderCellDef mat-header-cell>\r\n                            <div\r\n                                [ngClass]=\"{\r\n                            'right-align-header': isRightAligned(configuration.columns[i].type) || columnConfig.align === 'right'\r\n                        }\"\r\n                            >\r\n                                {{getLabel(columnConfig) | async}}\r\n                            </div>\r\n                        </th>\r\n                    </ng-container>\r\n\r\n                    <!-- data row cell -->\r\n                    <ng-container *ngIf=\"dataRowsDisplayed\">\r\n                        <td *matCellDef=\"let row\" [ngClass]=\"{ data: configuration.expandedRowTemplate }\" mat-cell>\r\n                            <haz-table-cell [columnConfig]=\"columnConfig\" [row]=\"row\"></haz-table-cell>\r\n                        </td>\r\n                    </ng-container>\r\n                </ng-container>\r\n                <ng-container *ngIf=\"i<=configuration.stickyEnd\"\r\n                              [matColumnDef]=\"columnConfig.columnDef\">\r\n                    <!-- header cell -->\r\n\r\n                    <!-- selection checkbox cell -->\r\n                    <ng-container *ngIf=\"i === 0 && selectableTable\">\r\n                        <td *matCellDef=\"let row\" mat-cell>\r\n                            <mat-checkbox\r\n                                (change)=\"$event ? selection.toggle(row) : null\"\r\n                                (click)=\"$event.stopPropagation()\"\r\n                                [checked]=\"selection.isSelected(row)\"\r\n                                [color]=\"configuration.selectionColor\"\r\n                            >\r\n                            </mat-checkbox>\r\n                        </td>\r\n                    </ng-container>\r\n\r\n                    <!-- dynamically set sorting -->\r\n                    <ng-container *ngIf=\"columnConfig.sorting\">\r\n                        <th\r\n                            *matHeaderCellDef\r\n                            [ngClass]=\"{ 'header-flexend': isRightAligned(columnConfig.type) || columnConfig.align === 'right' }\"\r\n                            mat-header-cell\r\n                            mat-sort-header\r\n                        >\r\n                            {{getLabel(columnConfig) | async}}\r\n                        </th>\r\n                    </ng-container>\r\n                    <ng-container *ngIf=\"!columnConfig.sorting\">\r\n                        <th *matHeaderCellDef mat-header-cell>\r\n                            <div\r\n                                [ngClass]=\"{\r\n                            'right-align-header': isRightAligned(configuration.columns[i].type) || columnConfig.align === 'right'\r\n                        }\"\r\n                            >\r\n                                {{getLabel(columnConfig) | async}}\r\n                            </div>\r\n                        </th>\r\n                    </ng-container>\r\n\r\n                    <!-- data row cell -->\r\n                    <ng-container *ngIf=\"dataRowsDisplayed\">\r\n                        <td *matCellDef=\"let row\" [ngClass]=\"{ data: configuration.expandedRowTemplate }\" mat-cell>\r\n                            <haz-table-cell [columnConfig]=\"columnConfig\" [row]=\"row\"></haz-table-cell>\r\n                        </td>\r\n                    </ng-container>\r\n                </ng-container>\r\n            </div>\r\n        </div>\r\n\r\n        <!--header cells-->\r\n        <div *ngIf=\"!configuration.stickyEnd\">\r\n            <ng-container *ngFor=\"let columnConfig of configuration.columns; let i = index\"\r\n                          [matColumnDef]=\"columnConfig.columnDef\">\r\n                <!-- header cell -->\r\n\r\n                <!-- selection checkbox cell -->\r\n                <ng-container *ngIf=\"i === 0 && selectableTable\">\r\n                    <td *matCellDef=\"let row\" mat-cell>\r\n                        <mat-checkbox\r\n                            (change)=\"$event ? selection.toggle(row) : null\"\r\n                            (click)=\"$event.stopPropagation()\"\r\n                            [checked]=\"selection.isSelected(row)\"\r\n                            [color]=\"configuration.selectionColor\"\r\n                        >\r\n                        </mat-checkbox>\r\n                    </td>\r\n                </ng-container>\r\n\r\n                <!-- dynamically set sorting -->\r\n                <ng-container *ngIf=\"columnConfig.sorting\">\r\n                    <th\r\n                        *matHeaderCellDef\r\n                        [ngClass]=\"{ 'header-flexend': isRightAligned(columnConfig.type) || columnConfig.align === 'right' }\"\r\n                        mat-header-cell\r\n                        mat-sort-header\r\n                    >\r\n                        {{getLabel(columnConfig) | async}}\r\n                    </th>\r\n                </ng-container>\r\n                <ng-container *ngIf=\"!columnConfig.sorting\">\r\n                    <th *matHeaderCellDef mat-header-cell>\r\n                        <div\r\n                            [ngClass]=\"{\r\n                            'right-align-header': isRightAligned(configuration.columns[i].type) || columnConfig.align === 'right'\r\n                        }\"\r\n                        >\r\n                            {{getLabel(columnConfig) | async}}\r\n                        </div>\r\n                    </th>\r\n                </ng-container>\r\n\r\n                <!-- data row cell -->\r\n                <ng-container *ngIf=\"dataRowsDisplayed\">\r\n                    <td *matCellDef=\"let row\" [ngClass]=\"{ data: configuration.expandedRowTemplate }\" mat-cell>\r\n                        <haz-table-cell [columnConfig]=\"columnConfig\" [row]=\"row\"></haz-table-cell>\r\n                    </td>\r\n                </ng-container>\r\n            </ng-container>\r\n        </div>\r\n\r\n        <!--filter row cell-->\r\n\r\n        <div *ngIf=\"configuration.stickyEnd\">\r\n            <div *ngFor=\"let columnConfig of configuration.columns; let i = index\">\r\n                <ng-container *ngIf=\"i>configuration.stickyEnd\"\r\n                              [matColumnDef]=\"columnConfig.filterElement\"\r\n                              stickyEnd>\r\n                    <th *matHeaderCellDef mat-header-cell>\r\n                        <haz-core-table-filter *ngIf=\"columnConfig.filter\" [columnConfig]=\"columnConfig\"\r\n                                               (resetFilters)=\"resetFilters($event)\">\r\n                        </haz-core-table-filter>\r\n                    </th>\r\n                </ng-container>\r\n                <ng-container *ngIf=\"i<=configuration.stickyEnd\"\r\n                              [matColumnDef]=\"columnConfig.filterElement\"\r\n                >\r\n                    <th *matHeaderCellDef mat-header-cell>\r\n                        <haz-core-table-filter *ngIf=\"columnConfig.filter\" [columnConfig]=\"columnConfig\"\r\n                                               (resetFilters)=\"resetFilters($event)\">\r\n                        </haz-core-table-filter>\r\n                    </th>\r\n                </ng-container>\r\n            </div>\r\n        </div>\r\n\r\n        <div *ngIf=\"!configuration.stickyEnd\">\r\n            <ng-container *ngFor=\"let columnConfig of configuration.columns; let i = index\"\r\n                          [matColumnDef]=\"columnConfig.filterElement\">\r\n                <th *matHeaderCellDef mat-header-cell>\r\n                    <haz-core-table-filter *ngIf=\"columnConfig.filter\" [columnConfig]=\"columnConfig\"\r\n                                           (resetFilters)=\"resetFilters($event)\">\r\n                    </haz-core-table-filter>\r\n                </th>\r\n            </ng-container>\r\n        </div>\r\n\r\n        <!-- expanded rows cell -->\r\n        <ng-container matColumnDef=\"expandedDetail\">\r\n            <td *matCellDef=\"let row\" [attr.colspan]=\"displayedColumns?.length\" class=\"expand-td\" mat-cell>\r\n                <div [@detailExpand]=\"row == selectedRow ? 'expanded' : 'collapsed'\" class=\"expand-element-detail\"\r\n                >\r\n                    <ng-container\r\n                        *ngTemplateOutlet=\"configuration.expandedRowTemplate; context: { row: row }\"></ng-container>\r\n                </div>\r\n            </td>\r\n        </ng-container>\r\n\r\n        <!--  header row -->\r\n        <tr *matHeaderRowDef=\"displayedColumns; sticky: true\"\r\n            [ngClass]=\"{ headerColor: configuration.headerColor, 'last-header-row': !anyFilter }\"\r\n            class=\" p-0 m-0 first-header-row\"\r\n            mat-header-row\r\n        ></tr>\r\n\r\n        <!-- filters row -->\r\n        <ng-container *ngIf=\"anyFilter\">\r\n            <tr *matHeaderRowDef=\"columnsFilters; sticky: true\" class=\"p-0 m-0 last-header-row\"\r\n                mat-header-row></tr>\r\n        </ng-container>\r\n\r\n        <!-- data rows -->\r\n        <ng-container>\r\n            <tr\r\n                (click)=\"onExpandableRowClicked(row); rowClicked(row)\"\r\n                *matRowDef=\"let row; columns: displayedColumns; let i = index\"\r\n                [class.data-row]=\"configuration.expandedRowTemplate || configuration.trClasses === 'data-row'\"\r\n                [ngClass]=\"getClass(row)\"\r\n                mat-row\r\n            ></tr>\r\n        </ng-container>\r\n\r\n        <!-- expanded rows -->\r\n        <ng-container *ngIf=\"configuration.expandedRowTemplate\">\r\n            <tr *matRowDef=\"let detail; columns: ['expandedDetail']\" class=\"expand-detail-row\" mat-row></tr>\r\n        </ng-container>\r\n    </table>\r\n</div>\r\n\r\n<!-- text on no data present -->\r\n<div *ngIf=\"!dataRowsDisplayed\" class=\"white-box row\">\r\n    <p class=\"pl-40 pt-15\">{{ configuration.noDataText }}</p>\r\n</div>\r\n\r\n<mat-paginator\r\n    [hidden]=\"(configuration?.pageSizeOptions && data?.totalElements < configuration.pageSizeOptions[0]) || !configuration.paging\"\r\n    [length]=\"data?.totalElements\"\r\n    [pageSizeOptions]=\"configuration.pageSizeOptions\"\r\n    [hidePageSize]=\"!configuration.paging\"\r\n    [pageIndex]=\"configuration.predefinedPageIndex ? configuration.predefinedPageIndex : 0\"\r\n    [pageSize]=\"configuration.predefinedPageSize ? configuration.predefinedPageSize : 15\"\r\n    class=\"paginator\"\r\n    showFirstLastButtons>\r\n</mat-paginator>\r\n\r\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/shared/hazlenut/core-table/components/table-cell-clickable/table-cell-clickable.component.html":
/*!******************************************************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/shared/hazlenut/core-table/components/table-cell-clickable/table-cell-clickable.component.html ***!
  \******************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<td>\r\n    <div (click)=\"onClick()\" class=\"hover-clickable-text\">\r\n        {{ params.content }}\r\n    </div>\r\n</td>\r\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/shared/hazlenut/core-table/components/table-cell/table-cell.component.html":
/*!**********************************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/shared/hazlenut/core-table/components/table-cell/table-cell.component.html ***!
  \**********************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ng-container [ngSwitch]=\"columnConfig.type\">\r\n    <div *ngSwitchCase=\"tableCellType.NUMBER\" class=\"num-value\">{{ cellValue | thousandDelimiter: ',' }}</div>\r\n\r\n    <div *ngSwitchCase=\"tableCellType.NUMBER_SIMPLE\"\r\n         class=\"num-value\">{{ cellValue }}</div>\r\n\r\n    <div *ngSwitchCase=\"tableCellType.NUMBERINT\"\r\n         class=\"num-value\">{{ cellValue | roundToDecimal: 2 | number: '1.0-0' }}</div>\r\n\r\n    <div *ngSwitchCase=\"tableCellType.NUMBERFLOAT1\"\r\n         class=\"num-value\">{{ cellValue | roundToDecimal: 2 | number: '1.1-1' }}</div>\r\n\r\n    <div *ngSwitchCase=\"tableCellType.NUMBERFLOAT2\"\r\n         class=\"num-value\">{{ cellValue | roundToDecimal: 2 | number: '1.2-2' }}</div>\r\n\r\n    <div *ngSwitchCase=\"tableCellType.PERCENT\"\r\n         class=\"text-nowrap num-value\">{{ cellValue | roundToDecimal: 2 | number: '1.2-2' }} %\r\n    </div>\r\n\r\n    <div *ngSwitchCase=\"tableCellType.TOPERCENT\" class=\"num-value\">{{ cellValue | percent }}</div>\r\n\r\n    <div *ngSwitchCase=\"tableCellType.DATE\">{{ cellValue | date }}</div>\r\n\r\n    <div *ngSwitchCase=\"tableCellType.DATETIME\">{{ cellValue | date: 'short' }}</div>\r\n\r\n    <div *ngSwitchCase=\"tableCellType.CUSTOM_VALUE\" [innerHTML]=\"customValue\"></div>\r\n\r\n    <ng-container *ngSwitchCase=\"tableCellType.CONTENT\">\r\n        <div [ngClass]=\"columnConfig.tdClasses\">\r\n            <ng-container *ngTemplateOutlet=\"columnConfig.tableCellTemplate; context: {\r\n                              row: row, columnConfig: columnConfig, value: cellValue\r\n                          }\"\r\n            ></ng-container>\r\n        </div>\r\n    </ng-container>\r\n\r\n    <div *ngSwitchDefault [ngClass]=\"columnConfig.tdClasses\"\r\n         class=\"wrap-ellipsis\">{{ cellValue }}</div>\r\n</ng-container>\r\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/shared/hazlenut/small-components/indeterminate-progress-bar/indeterminate-progress-bar.component.html":
/*!*************************************************************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/shared/hazlenut/small-components/indeterminate-progress-bar/indeterminate-progress-bar.component.html ***!
  \*************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<!--loading component-->\r\n<mat-progress-bar *ngIf=\"loading\" mode=\"indeterminate\"></mat-progress-bar>\r\n<div *ngIf=\"!loading\" style=\"height: 4px;\"></div>\r\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/shared/hazlenut/small-components/notifications/notification-snack-bar/notification-snack-bar.component.html":
/*!*******************************************************************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/shared/hazlenut/small-components/notifications/notification-snack-bar/notification-snack-bar.component.html ***!
  \*******************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<span>\r\n    <strong>{{data.message}}</strong>\r\n    <mat-icon *ngIf=\"data.type === 0\" style=\"position: absolute; right: 10px;\">done</mat-icon>\r\n</span>\r\n");

/***/ }),

/***/ "./node_modules/tslib/tslib.es6.js":
/*!*****************************************!*\
  !*** ./node_modules/tslib/tslib.es6.js ***!
  \*****************************************/
/*! exports provided: __extends, __assign, __rest, __decorate, __param, __metadata, __awaiter, __generator, __exportStar, __values, __read, __spread, __spreadArrays, __await, __asyncGenerator, __asyncDelegator, __asyncValues, __makeTemplateObject, __importStar, __importDefault */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__extends", function() { return __extends; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__assign", function() { return __assign; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__rest", function() { return __rest; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__decorate", function() { return __decorate; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__param", function() { return __param; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__metadata", function() { return __metadata; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__awaiter", function() { return __awaiter; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__generator", function() { return __generator; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__exportStar", function() { return __exportStar; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__values", function() { return __values; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__read", function() { return __read; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__spread", function() { return __spread; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__spreadArrays", function() { return __spreadArrays; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__await", function() { return __await; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__asyncGenerator", function() { return __asyncGenerator; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__asyncDelegator", function() { return __asyncDelegator; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__asyncValues", function() { return __asyncValues; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__makeTemplateObject", function() { return __makeTemplateObject; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__importStar", function() { return __importStar; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__importDefault", function() { return __importDefault; });
/*! *****************************************************************************
Copyright (c) Microsoft Corporation. All rights reserved.
Licensed under the Apache License, Version 2.0 (the "License"); you may not use
this file except in compliance with the License. You may obtain a copy of the
License at http://www.apache.org/licenses/LICENSE-2.0

THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION ANY IMPLIED
WARRANTIES OR CONDITIONS OF TITLE, FITNESS FOR A PARTICULAR PURPOSE,
MERCHANTABLITY OR NON-INFRINGEMENT.

See the Apache Version 2.0 License for specific language governing permissions
and limitations under the License.
***************************************************************************** */
/* global Reflect, Promise */

var extendStatics = function(d, b) {
    extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return extendStatics(d, b);
};

function __extends(d, b) {
    extendStatics(d, b);
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
}

var __assign = function() {
    __assign = Object.assign || function __assign(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
    }
    return __assign.apply(this, arguments);
}

function __rest(s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
}

function __decorate(decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
}

function __param(paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
}

function __metadata(metadataKey, metadataValue) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(metadataKey, metadataValue);
}

function __awaiter(thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
}

function __generator(thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
}

function __exportStar(m, exports) {
    for (var p in m) if (!exports.hasOwnProperty(p)) exports[p] = m[p];
}

function __values(o) {
    var m = typeof Symbol === "function" && o[Symbol.iterator], i = 0;
    if (m) return m.call(o);
    return {
        next: function () {
            if (o && i >= o.length) o = void 0;
            return { value: o && o[i++], done: !o };
        }
    };
}

function __read(o, n) {
    var m = typeof Symbol === "function" && o[Symbol.iterator];
    if (!m) return o;
    var i = m.call(o), r, ar = [], e;
    try {
        while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
    }
    catch (error) { e = { error: error }; }
    finally {
        try {
            if (r && !r.done && (m = i["return"])) m.call(i);
        }
        finally { if (e) throw e.error; }
    }
    return ar;
}

function __spread() {
    for (var ar = [], i = 0; i < arguments.length; i++)
        ar = ar.concat(__read(arguments[i]));
    return ar;
}

function __spreadArrays() {
    for (var s = 0, i = 0, il = arguments.length; i < il; i++) s += arguments[i].length;
    for (var r = Array(s), k = 0, i = 0; i < il; i++)
        for (var a = arguments[i], j = 0, jl = a.length; j < jl; j++, k++)
            r[k] = a[j];
    return r;
};

function __await(v) {
    return this instanceof __await ? (this.v = v, this) : new __await(v);
}

function __asyncGenerator(thisArg, _arguments, generator) {
    if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
    var g = generator.apply(thisArg, _arguments || []), i, q = [];
    return i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () { return this; }, i;
    function verb(n) { if (g[n]) i[n] = function (v) { return new Promise(function (a, b) { q.push([n, v, a, b]) > 1 || resume(n, v); }); }; }
    function resume(n, v) { try { step(g[n](v)); } catch (e) { settle(q[0][3], e); } }
    function step(r) { r.value instanceof __await ? Promise.resolve(r.value.v).then(fulfill, reject) : settle(q[0][2], r); }
    function fulfill(value) { resume("next", value); }
    function reject(value) { resume("throw", value); }
    function settle(f, v) { if (f(v), q.shift(), q.length) resume(q[0][0], q[0][1]); }
}

function __asyncDelegator(o) {
    var i, p;
    return i = {}, verb("next"), verb("throw", function (e) { throw e; }), verb("return"), i[Symbol.iterator] = function () { return this; }, i;
    function verb(n, f) { i[n] = o[n] ? function (v) { return (p = !p) ? { value: __await(o[n](v)), done: n === "return" } : f ? f(v) : v; } : f; }
}

function __asyncValues(o) {
    if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
    var m = o[Symbol.asyncIterator], i;
    return m ? m.call(o) : (o = typeof __values === "function" ? __values(o) : o[Symbol.iterator](), i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () { return this; }, i);
    function verb(n) { i[n] = o[n] && function (v) { return new Promise(function (resolve, reject) { v = o[n](v), settle(resolve, reject, v.done, v.value); }); }; }
    function settle(resolve, reject, d, v) { Promise.resolve(v).then(function(v) { resolve({ value: v, done: d }); }, reject); }
}

function __makeTemplateObject(cooked, raw) {
    if (Object.defineProperty) { Object.defineProperty(cooked, "raw", { value: raw }); } else { cooked.raw = raw; }
    return cooked;
};

function __importStar(mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
    result.default = mod;
    return result;
}

function __importDefault(mod) {
    return (mod && mod.__esModule) ? mod : { default: mod };
}


/***/ }),

/***/ "./src/$$_lazy_route_resource lazy recursive":
/*!**********************************************************!*\
  !*** ./src/$$_lazy_route_resource lazy namespace object ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var map = {
	"./pages/business-areas/business-areas.module": [
		"./src/app/pages/business-areas/business-areas.module.ts",
		"common",
		"pages-business-areas-business-areas-module"
	],
	"./pages/dashboard/dashboard.module": [
		"./src/app/pages/dashboard/dashboard.module.ts",
		"pages-dashboard-dashboard-module"
	],
	"./pages/facts/facts.module": [
		"./src/app/pages/facts/facts.module.ts",
		"default~pages-facts-facts-module~pages-tasks-tasks-module",
		"pages-facts-facts-module"
	],
	"./pages/project/project.module": [
		"./src/app/pages/project/project.module.ts",
		"pages-project-project-module"
	],
	"./pages/reports/reports.module": [
		"./src/app/pages/reports/reports.module.ts",
		"pages-reports-reports-module"
	],
	"./pages/session/session.module": [
		"./src/app/pages/session/session.module.ts",
		"pages-session-session-module"
	],
	"./pages/tasks/tasks.module": [
		"./src/app/pages/tasks/tasks.module.ts",
		"default~pages-facts-facts-module~pages-tasks-tasks-module",
		"common",
		"pages-tasks-tasks-module"
	]
};
function webpackAsyncContext(req) {
	if(!__webpack_require__.o(map, req)) {
		return Promise.resolve().then(function() {
			var e = new Error("Cannot find module '" + req + "'");
			e.code = 'MODULE_NOT_FOUND';
			throw e;
		});
	}

	var ids = map[req], id = ids[0];
	return Promise.all(ids.slice(1).map(__webpack_require__.e)).then(function() {
		return __webpack_require__(id);
	});
}
webpackAsyncContext.keys = function webpackAsyncContextKeys() {
	return Object.keys(map);
};
webpackAsyncContext.id = "./src/$$_lazy_route_resource lazy recursive";
module.exports = webpackAsyncContext;

/***/ }),

/***/ "./src/app/app.component.scss":
/*!************************************!*\
  !*** ./src/app/app.component.scss ***!
  \************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2FwcC5jb21wb25lbnQuc2NzcyJ9 */");

/***/ }),

/***/ "./src/app/app.component.ts":
/*!**********************************!*\
  !*** ./src/app/app.component.ts ***!
  \**********************************/
/*! exports provided: AppComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppComponent", function() { return AppComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ngx-translate/core */ "./node_modules/@ngx-translate/core/fesm5/ngx-translate-core.js");
/* harmony import */ var _shared_services_routing_storage_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./shared/services/routing-storage.service */ "./src/app/shared/services/routing-storage.service.ts");
/* harmony import */ var _shared_services_storage_project_user_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./shared/services/storage/project-user.service */ "./src/app/shared/services/storage/project-user.service.ts");





var AppComponent = /** @class */ (function () {
    /**
     * Set default language of app to english and save routes everytime it changes
     * @param translateService
     * @param routingStorageService
     */
    function AppComponent(translateService, routingStorageService, projectUserService) {
        this.translateService = translateService;
        this.routingStorageService = routingStorageService;
        this.projectUserService = projectUserService;
        translateService.setDefaultLang('en');
        this.routingStorageService.loadRouting();
    }
    /**
     * Use english language
     */
    AppComponent.prototype.ngOnInit = function () {
        this.translateService.use('en');
    };
    /**
     * Function serves for persisting data about current user.
     * Handy, when multiple users are logged in in the same browser.
     */
    AppComponent.prototype.unloadNotification = function () {
        localStorage.setItem('lastUser', this.projectUserService.instant.login);
    };
    AppComponent.ctorParameters = function () { return [
        { type: _ngx_translate_core__WEBPACK_IMPORTED_MODULE_2__["TranslateService"] },
        { type: _shared_services_routing_storage_service__WEBPACK_IMPORTED_MODULE_3__["RoutingStorageService"] },
        { type: _shared_services_storage_project_user_service__WEBPACK_IMPORTED_MODULE_4__["ProjectUserService"] }
    ]; };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["HostListener"])('window:beforeunload'),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Function),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", []),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:returntype", void 0)
    ], AppComponent.prototype, "unloadNotification", null);
    AppComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'iihf-root',
            template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./app.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/app.component.html")).default,
            styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./app.component.scss */ "./src/app/app.component.scss")).default]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ngx_translate_core__WEBPACK_IMPORTED_MODULE_2__["TranslateService"],
            _shared_services_routing_storage_service__WEBPACK_IMPORTED_MODULE_3__["RoutingStorageService"],
            _shared_services_storage_project_user_service__WEBPACK_IMPORTED_MODULE_4__["ProjectUserService"]])
    ], AppComponent);
    return AppComponent;
}());



/***/ }),

/***/ "./src/app/app.module.ts":
/*!*******************************!*\
  !*** ./src/app/app.module.ts ***!
  \*******************************/
/*! exports provided: AppModule, HttpLoaderFactory */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppModule", function() { return AppModule; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HttpLoaderFactory", function() { return HttpLoaderFactory; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_flex_layout__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/flex-layout */ "./node_modules/@angular/flex-layout/esm5/flex-layout.es5.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/platform-browser */ "./node_modules/@angular/platform-browser/fesm5/platform-browser.js");
/* harmony import */ var _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/platform-browser/animations */ "./node_modules/@angular/platform-browser/fesm5/animations.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ngx-translate/core */ "./node_modules/@ngx-translate/core/fesm5/ngx-translate-core.js");
/* harmony import */ var _ngx_translate_http_loader__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ngx-translate/http-loader */ "./node_modules/@ngx-translate/http-loader/fesm5/ngx-translate-http-loader.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm5/index.js");
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./app.component */ "./src/app/app.component.ts");
/* harmony import */ var _app_routing__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./app.routing */ "./src/app/app.routing.ts");
/* harmony import */ var _pages_composition_composition_module__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./pages/composition/composition.module */ "./src/app/pages/composition/composition.module.ts");
/* harmony import */ var _pages_layouts_admin_layout_admin_layout_component__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./pages/layouts/admin-layout/admin-layout.component */ "./src/app/pages/layouts/admin-layout/admin-layout.component.ts");
/* harmony import */ var _pages_layouts_auth_layout_auth_layout_component__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ./pages/layouts/auth-layout/auth-layout.component */ "./src/app/pages/layouts/auth-layout/auth-layout.component.ts");
/* harmony import */ var _shared_components_components_module__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ./shared/components/components.module */ "./src/app/shared/components/components.module.ts");
/* harmony import */ var _shared_components_dialog_image_dialog_image_dialog_component__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ./shared/components/dialog/image-dialog/image-dialog.component */ "./src/app/shared/components/dialog/image-dialog/image-dialog.component.ts");
/* harmony import */ var _shared_components_dialog_pdf_dialog_pdf_dialog_component__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ./shared/components/dialog/pdf-dialog/pdf-dialog.component */ "./src/app/shared/components/dialog/pdf-dialog/pdf-dialog.component.ts");
/* harmony import */ var _shared_hazlenut_core_table__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ./shared/hazlenut/core-table */ "./src/app/shared/hazlenut/core-table/index.ts");
/* harmony import */ var _shared_hazlenut_hazelnut_common__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! ./shared/hazlenut/hazelnut-common */ "./src/app/shared/hazlenut/hazelnut-common/index.ts");
/* harmony import */ var _shared_hazlenut_small_components_notifications__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! ./shared/hazlenut/small-components/notifications */ "./src/app/shared/hazlenut/small-components/notifications/index.ts");
/* harmony import */ var _shared_pipes_pipes_module__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! ./shared/pipes/pipes.module */ "./src/app/shared/pipes/pipes.module.ts");
/* harmony import */ var _shared_services_auth_guard__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! ./shared/services/auth-guard */ "./src/app/shared/services/auth-guard.ts");
/* harmony import */ var _shared_services_dashboard_service__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! ./shared/services/dashboard.service */ "./src/app/shared/services/dashboard.service.ts");
/* harmony import */ var _shared_services_global_error_handler_service__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! ./shared/services/global-error-handler.service */ "./src/app/shared/services/global-error-handler.service.ts");
/* harmony import */ var _shared_services_notification_service__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! ./shared/services/notification.service */ "./src/app/shared/services/notification.service.ts");
/* harmony import */ var _shared_services_translate_wrapper_service__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! ./shared/services/translate-wrapper.service */ "./src/app/shared/services/translate-wrapper.service.ts");




























var AppModule = /** @class */ (function () {
    function AppModule() {
    }
    AppModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["NgModule"])({
            declarations: [
                _app_component__WEBPACK_IMPORTED_MODULE_11__["AppComponent"],
                _pages_layouts_auth_layout_auth_layout_component__WEBPACK_IMPORTED_MODULE_15__["AuthLayoutComponent"],
                _pages_layouts_admin_layout_admin_layout_component__WEBPACK_IMPORTED_MODULE_14__["AdminLayoutComponent"],
            ],
            imports: [
                _angular_platform_browser__WEBPACK_IMPORTED_MODULE_5__["BrowserModule"],
                _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_6__["BrowserAnimationsModule"],
                _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClientModule"],
                _pages_composition_composition_module__WEBPACK_IMPORTED_MODULE_13__["CompositionModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormsModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_7__["RouterModule"].forRoot(_app_routing__WEBPACK_IMPORTED_MODULE_12__["AppRoutes"], { useHash: true }),
                _ngx_translate_core__WEBPACK_IMPORTED_MODULE_8__["TranslateModule"].forRoot({
                    loader: {
                        provide: _ngx_translate_core__WEBPACK_IMPORTED_MODULE_8__["TranslateLoader"],
                        useFactory: HttpLoaderFactory,
                        deps: [_angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"]]
                    }
                }),
                _shared_hazlenut_hazelnut_common__WEBPACK_IMPORTED_MODULE_20__["MaterialModule"],
                _shared_components_components_module__WEBPACK_IMPORTED_MODULE_16__["ComponentsModule"],
                _angular_flex_layout__WEBPACK_IMPORTED_MODULE_3__["FlexLayoutModule"],
                _shared_hazlenut_core_table__WEBPACK_IMPORTED_MODULE_19__["CoreTableModule"],
                _shared_pipes_pipes_module__WEBPACK_IMPORTED_MODULE_22__["PipesModule"],
            ],
            providers: [
                _shared_services_auth_guard__WEBPACK_IMPORTED_MODULE_23__["AuthGuard"],
                {
                    provide: 'abstractInputConfig',
                    useValue: rxjs__WEBPACK_IMPORTED_MODULE_10__["config"]
                },
                {
                    provide: _shared_hazlenut_hazelnut_common__WEBPACK_IMPORTED_MODULE_20__["NOTIFICATION_WRAPPER_TOKEN"],
                    useClass: _shared_services_notification_service__WEBPACK_IMPORTED_MODULE_26__["NotificationService"]
                },
                {
                    provide: _shared_hazlenut_hazelnut_common__WEBPACK_IMPORTED_MODULE_20__["TRANSLATE_WRAPPER_TOKEN"],
                    useClass: _shared_services_translate_wrapper_service__WEBPACK_IMPORTED_MODULE_27__["TranslateWrapperService"]
                },
                {
                    provide: _shared_hazlenut_core_table__WEBPACK_IMPORTED_MODULE_19__["GLOBAL_CONFIG_TOKEN"],
                    useValue: {}
                },
                {
                    provide: _angular_core__WEBPACK_IMPORTED_MODULE_2__["ErrorHandler"],
                    useClass: _shared_services_global_error_handler_service__WEBPACK_IMPORTED_MODULE_25__["GlobalErrorHandlerService"]
                },
                _shared_services_dashboard_service__WEBPACK_IMPORTED_MODULE_24__["DashboardService"]
            ],
            entryComponents: [
                _shared_hazlenut_small_components_notifications__WEBPACK_IMPORTED_MODULE_21__["NotificationSnackBarComponent"],
                _shared_components_dialog_pdf_dialog_pdf_dialog_component__WEBPACK_IMPORTED_MODULE_18__["PdfDialogComponent"],
                _shared_components_dialog_image_dialog_image_dialog_component__WEBPACK_IMPORTED_MODULE_17__["ImageDialogComponent"]
            ],
            bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_11__["AppComponent"]]
        })
    ], AppModule);
    return AppModule;
}());

function HttpLoaderFactory(http) {
    return new _ngx_translate_http_loader__WEBPACK_IMPORTED_MODULE_9__["TranslateHttpLoader"](http);
}


/***/ }),

/***/ "./src/app/app.routing.ts":
/*!********************************!*\
  !*** ./src/app/app.routing.ts ***!
  \********************************/
/*! exports provided: AppRoutes */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppRoutes", function() { return AppRoutes; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _pages_layouts_admin_layout_admin_layout_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./pages/layouts/admin-layout/admin-layout.component */ "./src/app/pages/layouts/admin-layout/admin-layout.component.ts");
/* harmony import */ var _pages_layouts_auth_layout_auth_layout_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./pages/layouts/auth-layout/auth-layout.component */ "./src/app/pages/layouts/auth-layout/auth-layout.component.ts");
/* harmony import */ var _shared_services_auth_guard__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./shared/services/auth-guard */ "./src/app/shared/services/auth-guard.ts");




/**
 * Menu property in routes for showing screen option in app menu
 */
var AppRoutes = [
    {
        path: '',
        redirectTo: 'authentication',
        pathMatch: 'full',
    },
    {
        path: '',
        component: _pages_layouts_admin_layout_admin_layout_component__WEBPACK_IMPORTED_MODULE_1__["AdminLayoutComponent"],
        data: { menu: false },
        children: [
            {
                path: 'dashboard',
                loadChildren: './pages/dashboard/dashboard.module#DashboardModule',
                data: {
                    title: 'menu.dashboard',
                    icon: 'person',
                    animation: 'dashboard'
                },
                canActivate: [_shared_services_auth_guard__WEBPACK_IMPORTED_MODULE_3__["AuthGuard"]]
            },
            {
                path: 'project',
                loadChildren: './pages/project/project.module#ProjectModule',
                data: {
                    title: 'menu.project',
                    icon: 'person',
                    menu: true,
                    animation: 'project'
                },
                canActivate: [_shared_services_auth_guard__WEBPACK_IMPORTED_MODULE_3__["AuthGuard"]]
            },
            {
                path: 'business-areas',
                loadChildren: './pages/business-areas/business-areas.module#BusinessAreasModule',
                data: {
                    title: 'menu.businessAreas',
                    icon: 'person',
                    menu: true,
                    animation: 'tasks'
                },
                canActivate: [_shared_services_auth_guard__WEBPACK_IMPORTED_MODULE_3__["AuthGuard"]]
            },
            {
                path: 'tasks',
                loadChildren: './pages/tasks/tasks.module#TasksModule',
                data: {
                    title: 'menu.tasks',
                    icon: 'person',
                    animation: 'tasks'
                },
                canActivate: [_shared_services_auth_guard__WEBPACK_IMPORTED_MODULE_3__["AuthGuard"]]
            },
            {
                path: 'facts',
                loadChildren: './pages/facts/facts.module#FactsModule',
                data: {
                    title: 'menu.facts',
                    icon: 'person',
                    menu: true,
                    animation: 'facts'
                },
                canActivate: [_shared_services_auth_guard__WEBPACK_IMPORTED_MODULE_3__["AuthGuard"]]
            },
            {
                path: 'all-facts',
                loadChildren: './pages/facts/facts.module#FactsModule',
                data: {
                    title: 'menu.allFacts',
                    icon: 'person',
                    menu: true,
                    animation: 'facts'
                },
                canActivate: [_shared_services_auth_guard__WEBPACK_IMPORTED_MODULE_3__["AuthGuard"]]
            },
            {
                path: 'reports',
                loadChildren: './pages/reports/reports.module#ReportsModule',
                data: {
                    title: 'menu.reports',
                    icon: 'person',
                    menu: true,
                    animation: 'reports'
                },
                canActivate: [_shared_services_auth_guard__WEBPACK_IMPORTED_MODULE_3__["AuthGuard"]]
            },
        ],
    },
    {
        path: '',
        component: _pages_layouts_auth_layout_auth_layout_component__WEBPACK_IMPORTED_MODULE_2__["AuthLayoutComponent"],
        children: [
            {
                path: 'authentication',
                loadChildren: './pages/session/session.module#SessionModule',
            },
        ],
    },
    {
        path: '**',
        redirectTo: 'authentication',
    },
];


/***/ }),

/***/ "./src/app/pages/composition/composition.module.ts":
/*!*********************************************************!*\
  !*** ./src/app/pages/composition/composition.module.ts ***!
  \*********************************************************/
/*! exports provided: CompositionModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CompositionModule", function() { return CompositionModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_flex_layout__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/flex-layout */ "./node_modules/@angular/flex-layout/esm5/flex-layout.es5.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ngx-translate/core */ "./node_modules/@ngx-translate/core/fesm5/ngx-translate-core.js");
/* harmony import */ var _shared_hazlenut_hazelnut_common__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../shared/hazlenut/hazelnut-common */ "./src/app/shared/hazlenut/hazelnut-common/index.ts");
/* harmony import */ var _menu_menu_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./menu/menu.component */ "./src/app/pages/composition/menu/menu.component.ts");
/* harmony import */ var _menu_secondary_header_secondary_header_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./menu/secondary-header/secondary-header.component */ "./src/app/pages/composition/menu/secondary-header/secondary-header.component.ts");
/* harmony import */ var _side_options_side_options_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./side-options/side-options.component */ "./src/app/pages/composition/side-options/side-options.component.ts");










var CompositionModule = /** @class */ (function () {
    function CompositionModule() {
    }
    CompositionModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["NgModule"])({
            declarations: [
                _menu_menu_component__WEBPACK_IMPORTED_MODULE_7__["MenuComponent"],
                _side_options_side_options_component__WEBPACK_IMPORTED_MODULE_9__["SideOptionsComponent"],
                _menu_secondary_header_secondary_header_component__WEBPACK_IMPORTED_MODULE_8__["SecondaryHeaderComponent"]
            ],
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"],
                _angular_flex_layout__WEBPACK_IMPORTED_MODULE_3__["FlexLayoutModule"],
                _shared_hazlenut_hazelnut_common__WEBPACK_IMPORTED_MODULE_6__["MaterialModule"],
                _shared_hazlenut_hazelnut_common__WEBPACK_IMPORTED_MODULE_6__["SharedDirectivesModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"],
                _ngx_translate_core__WEBPACK_IMPORTED_MODULE_5__["TranslateModule"].forChild(),
            ],
            exports: [
                _menu_menu_component__WEBPACK_IMPORTED_MODULE_7__["MenuComponent"],
            ]
        })
    ], CompositionModule);
    return CompositionModule;
}());



/***/ }),

/***/ "./src/app/pages/composition/menu.service.ts":
/*!***************************************************!*\
  !*** ./src/app/pages/composition/menu.service.ts ***!
  \***************************************************/
/*! exports provided: MenuService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MenuService", function() { return MenuService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");


var MenuService = /** @class */ (function () {
    function MenuService() {
        this.selectedOptionPath = 'project';
        this.menuOpen = false;
    }
    MenuService.prototype.ngOnInit = function () {
    };
    MenuService.prototype.setSelectedOption = function (newSelectedOptionPath) {
        this.selectedOptionPath = newSelectedOptionPath;
    };
    MenuService.prototype.toggleMenu = function () {
        this.menuOpen = !this.menuOpen;
    };
    MenuService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root'
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
    ], MenuService);
    return MenuService;
}());



/***/ }),

/***/ "./src/app/pages/composition/menu/menu.component.scss":
/*!************************************************************!*\
  !*** ./src/app/pages/composition/menu/menu.component.scss ***!
  \************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("/*\n Icon and text color\n  */\n/*\n Menu background\n  */\n.full-width {\n  width: 100%;\n}\n.menu-container {\n  min-width: 100%;\n  min-height: calc(100vh - 106px);\n  padding: 0 !important;\n  margin: 0 !important;\n}\n.menu-topnav {\n  background: rgba(0, 45, 98, 0.5);\n  box-shadow: 0 3px 6px rgba(0, 0, 0, 0.16), 0 3px 6px rgba(0, 0, 0, 0.23);\n}\n.layer {\n  background: rgba(0, 45, 98, 0.5);\n  height: calc(100vh - 106px);\n}\n.menu-sidenav {\n  min-width: 245px;\n  box-shadow: 0 3px 6px rgba(0, 0, 0, 0.16), 0 3px 6px rgba(0, 0, 0, 0.23);\n}\n.move-down-close {\n  opacity: 0;\n  height: 0;\n  transition: height 250ms ease;\n}\n.move-down-open {\n  height: 60px;\n  transition: height 250ms ease;\n}\n.mat-icon {\n  color: white;\n}\n.mat-icon-black {\n  color: #000;\n}\n.close-wrapper {\n  display: none;\n  justify-content: flex-end;\n  align-items: center;\n}\n@media screen and (max-width: 1200px) {\n  .close-wrapper {\n    display: inline-flex;\n  }\n}\n.drawer-open {\n  margin-left: 5px;\n  margin-top: 5px;\n  position: absolute;\n  display: inline;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvY29tcG9zaXRpb24vbWVudS9EOlxccHJvamVjdHNcXGlpaGZcXHdmbS13ZWIvc3JjXFxhcHBcXHBhZ2VzXFxjb21wb3NpdGlvblxcbWVudVxcbWVudS5jb21wb25lbnQuc2NzcyIsInNyYy9hcHAvcGFnZXMvY29tcG9zaXRpb24vbWVudS9tZW51LmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOztHQUFBO0FBS0E7O0dBQUE7QUFhQTtFQUNJLFdBQUE7QUNYSjtBRGNBO0VBQ0ksZUFBQTtFQUNBLCtCQUFBO0VBQ0EscUJBQUE7RUFDQSxvQkFBQTtBQ1hKO0FEY0E7RUFDSSxnQ0F0QlM7RUF1QlQsd0VBQUE7QUNYSjtBRGNBO0VBQ0ksZ0NBM0JTO0VBNEJULDJCQUFBO0FDWEo7QURjQTtFQUNJLGdCQUFBO0VBQ0Esd0VBQUE7QUNYSjtBRGNBO0VBQ0ksVUFBQTtFQUNBLFNBQUE7RUFDQSw2QkFBQTtBQ1hKO0FEY0E7RUFDSSxZQUFBO0VBQ0EsNkJBQUE7QUNYSjtBRGNBO0VBQ0ksWUFyRFM7QUMwQ2I7QURjQTtFQUNJLFdBQUE7QUNYSjtBRGNBO0VBQ0ksYUFBQTtFQUNBLHlCQUFBO0VBQ0EsbUJBQUE7QUNYSjtBRGFJO0VBTEo7SUFNUSxvQkFBQTtFQ1ZOO0FBQ0Y7QURhQTtFQUNJLGdCQUFBO0VBQ0EsZUFBQTtFQUNBLGtCQUFBO0VBQ0EsZUFBQTtBQ1ZKIiwiZmlsZSI6InNyYy9hcHAvcGFnZXMvY29tcG9zaXRpb24vbWVudS9tZW51LmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLypcclxuIEljb24gYW5kIHRleHQgY29sb3JcclxuICAqL1xyXG4kdGV4dC1jb2xvcjogd2hpdGU7XHJcblxyXG4vKlxyXG4gTWVudSBiYWNrZ3JvdW5kXHJcbiAgKi9cclxuJGJhY2tncm91bmQ6IHJnYmEoMCwgNDUsIDk4LCAuNSk7XHJcblxyXG5AbWl4aW4gYmxvY2stc2VsZWN0aW5nLWVsZW1lbnRzIHtcclxuICAgIC13ZWJraXQtdG91Y2gtY2FsbG91dDogbm9uZTtcclxuICAgIC13ZWJraXQtdXNlci1zZWxlY3Q6IG5vbmU7XHJcbiAgICAtbW96LXVzZXItc2VsZWN0OiBub25lO1xyXG4gICAgLW1zLXVzZXItc2VsZWN0OiBub25lO1xyXG4gICAgdXNlci1zZWxlY3Q6IG5vbmU7XHJcbn1cclxuXHJcbi5mdWxsLXdpZHRoIHtcclxuICAgIHdpZHRoOiAxMDAlO1xyXG59XHJcblxyXG4ubWVudS1jb250YWluZXIge1xyXG4gICAgbWluLXdpZHRoOiAxMDAlO1xyXG4gICAgbWluLWhlaWdodDogY2FsYygxMDB2aCAtIDEwNnB4KTtcclxuICAgIHBhZGRpbmc6IDAgIWltcG9ydGFudDtcclxuICAgIG1hcmdpbjogMCAhaW1wb3J0YW50O1xyXG59XHJcblxyXG4ubWVudS10b3BuYXYge1xyXG4gICAgYmFja2dyb3VuZDogJGJhY2tncm91bmQ7XHJcbiAgICBib3gtc2hhZG93OiAwIDNweCA2cHggcmdiYSgwLCAwLCAwLCAuMTYpLCAwIDNweCA2cHggcmdiYSgwLCAwLCAwLCAuMjMpO1xyXG59XHJcblxyXG4ubGF5ZXIge1xyXG4gICAgYmFja2dyb3VuZDogJGJhY2tncm91bmQ7XHJcbiAgICBoZWlnaHQ6IGNhbGMoMTAwdmggLSAxMDZweCk7XHJcbn1cclxuXHJcbi5tZW51LXNpZGVuYXYge1xyXG4gICAgbWluLXdpZHRoOiAyNDVweDtcclxuICAgIGJveC1zaGFkb3c6IDAgM3B4IDZweCByZ2JhKDAsIDAsIDAsIC4xNiksIDAgM3B4IDZweCByZ2JhKDAsIDAsIDAsIC4yMyk7XHJcbn1cclxuXHJcbi5tb3ZlLWRvd24tY2xvc2Uge1xyXG4gICAgb3BhY2l0eTogMDtcclxuICAgIGhlaWdodDogMDtcclxuICAgIHRyYW5zaXRpb246IGhlaWdodCAyNTBtcyBlYXNlO1xyXG59XHJcblxyXG4ubW92ZS1kb3duLW9wZW4ge1xyXG4gICAgaGVpZ2h0OiA2MHB4O1xyXG4gICAgdHJhbnNpdGlvbjogaGVpZ2h0IDI1MG1zIGVhc2U7XHJcbn1cclxuXHJcbi5tYXQtaWNvbiB7XHJcbiAgICBjb2xvcjogJHRleHQtY29sb3I7XHJcbn1cclxuXHJcbi5tYXQtaWNvbi1ibGFjayB7XHJcbiAgICBjb2xvcjogIzAwMDtcclxufVxyXG5cclxuLmNsb3NlLXdyYXBwZXIge1xyXG4gICAgZGlzcGxheTogbm9uZTtcclxuICAgIGp1c3RpZnktY29udGVudDogZmxleC1lbmQ7XHJcbiAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG5cclxuICAgIEBtZWRpYSBzY3JlZW4gYW5kIChtYXgtd2lkdGg6IDEyMDBweCkge1xyXG4gICAgICAgIGRpc3BsYXk6IGlubGluZS1mbGV4O1xyXG4gICAgfVxyXG59XHJcblxyXG4uZHJhd2VyLW9wZW4ge1xyXG4gICAgbWFyZ2luLWxlZnQ6IDVweDtcclxuICAgIG1hcmdpbi10b3A6IDVweDtcclxuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAgIGRpc3BsYXk6IGlubGluZTtcclxufVxyXG4iLCIvKlxuIEljb24gYW5kIHRleHQgY29sb3JcbiAgKi9cbi8qXG4gTWVudSBiYWNrZ3JvdW5kXG4gICovXG4uZnVsbC13aWR0aCB7XG4gIHdpZHRoOiAxMDAlO1xufVxuXG4ubWVudS1jb250YWluZXIge1xuICBtaW4td2lkdGg6IDEwMCU7XG4gIG1pbi1oZWlnaHQ6IGNhbGMoMTAwdmggLSAxMDZweCk7XG4gIHBhZGRpbmc6IDAgIWltcG9ydGFudDtcbiAgbWFyZ2luOiAwICFpbXBvcnRhbnQ7XG59XG5cbi5tZW51LXRvcG5hdiB7XG4gIGJhY2tncm91bmQ6IHJnYmEoMCwgNDUsIDk4LCAwLjUpO1xuICBib3gtc2hhZG93OiAwIDNweCA2cHggcmdiYSgwLCAwLCAwLCAwLjE2KSwgMCAzcHggNnB4IHJnYmEoMCwgMCwgMCwgMC4yMyk7XG59XG5cbi5sYXllciB7XG4gIGJhY2tncm91bmQ6IHJnYmEoMCwgNDUsIDk4LCAwLjUpO1xuICBoZWlnaHQ6IGNhbGMoMTAwdmggLSAxMDZweCk7XG59XG5cbi5tZW51LXNpZGVuYXYge1xuICBtaW4td2lkdGg6IDI0NXB4O1xuICBib3gtc2hhZG93OiAwIDNweCA2cHggcmdiYSgwLCAwLCAwLCAwLjE2KSwgMCAzcHggNnB4IHJnYmEoMCwgMCwgMCwgMC4yMyk7XG59XG5cbi5tb3ZlLWRvd24tY2xvc2Uge1xuICBvcGFjaXR5OiAwO1xuICBoZWlnaHQ6IDA7XG4gIHRyYW5zaXRpb246IGhlaWdodCAyNTBtcyBlYXNlO1xufVxuXG4ubW92ZS1kb3duLW9wZW4ge1xuICBoZWlnaHQ6IDYwcHg7XG4gIHRyYW5zaXRpb246IGhlaWdodCAyNTBtcyBlYXNlO1xufVxuXG4ubWF0LWljb24ge1xuICBjb2xvcjogd2hpdGU7XG59XG5cbi5tYXQtaWNvbi1ibGFjayB7XG4gIGNvbG9yOiAjMDAwO1xufVxuXG4uY2xvc2Utd3JhcHBlciB7XG4gIGRpc3BsYXk6IG5vbmU7XG4gIGp1c3RpZnktY29udGVudDogZmxleC1lbmQ7XG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG59XG5AbWVkaWEgc2NyZWVuIGFuZCAobWF4LXdpZHRoOiAxMjAwcHgpIHtcbiAgLmNsb3NlLXdyYXBwZXIge1xuICAgIGRpc3BsYXk6IGlubGluZS1mbGV4O1xuICB9XG59XG5cbi5kcmF3ZXItb3BlbiB7XG4gIG1hcmdpbi1sZWZ0OiA1cHg7XG4gIG1hcmdpbi10b3A6IDVweDtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICBkaXNwbGF5OiBpbmxpbmU7XG59Il19 */");

/***/ }),

/***/ "./src/app/pages/composition/menu/menu.component.ts":
/*!**********************************************************!*\
  !*** ./src/app/pages/composition/menu/menu.component.ts ***!
  \**********************************************************/
/*! exports provided: MenuComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MenuComponent", function() { return MenuComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_material_sidenav__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/material/sidenav */ "./node_modules/@angular/material/esm5/sidenav.es5.js");
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ngx-translate/core */ "./node_modules/@ngx-translate/core/fesm5/ngx-translate-core.js");
/* harmony import */ var _shared_hazlenut_hazelnut_common_animations__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../shared/hazlenut/hazelnut-common/animations */ "./src/app/shared/hazlenut/hazelnut-common/animations/index.ts");
/* harmony import */ var _shared_services_storage_project_event_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../shared/services/storage/project-event.service */ "./src/app/shared/services/storage/project-event.service.ts");
/* harmony import */ var _shared_utils_constants__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../shared/utils/constants */ "./src/app/shared/utils/constants.ts");







var MenuComponent = /** @class */ (function () {
    function MenuComponent(projectEventService, translateService) {
        this.projectEventService = projectEventService;
        this.translateService = translateService;
        this.version = _shared_utils_constants__WEBPACK_IMPORTED_MODULE_6__["AppConstants"].version;
        this.menuOpen = true;
    }
    MenuComponent.prototype.ngOnInit = function () {
    };
    MenuComponent.prototype.toggleLanguage = function () {
        this.translateService.use(this.translateService.currentLang === 'sk' ? 'en' : 'sk');
    };
    MenuComponent.prototype.animateRoute = function (outlet) {
        return outlet && outlet.activatedRouteData && outlet.activatedRouteData.title;
    };
    MenuComponent.prototype.toggleDrawer = function () {
        this.drawer.toggle();
        this.menuOpen = !this.menuOpen;
    };
    MenuComponent.ctorParameters = function () { return [
        { type: _shared_services_storage_project_event_service__WEBPACK_IMPORTED_MODULE_5__["ProjectEventService"] },
        { type: _ngx_translate_core__WEBPACK_IMPORTED_MODULE_3__["TranslateService"] }
    ]; };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"])
    ], MenuComponent.prototype, "template", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])('drawer', { static: false }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_material_sidenav__WEBPACK_IMPORTED_MODULE_2__["MatDrawer"])
    ], MenuComponent.prototype, "drawer", void 0);
    MenuComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'menu',
            template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./menu.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/composition/menu/menu.component.html")).default,
            animations: [
                _shared_hazlenut_hazelnut_common_animations__WEBPACK_IMPORTED_MODULE_4__["routeAnimations"],
                _shared_hazlenut_hazelnut_common_animations__WEBPACK_IMPORTED_MODULE_4__["fadeEnterLeave"]
            ],
            styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./menu.component.scss */ "./src/app/pages/composition/menu/menu.component.scss")).default]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_shared_services_storage_project_event_service__WEBPACK_IMPORTED_MODULE_5__["ProjectEventService"], _ngx_translate_core__WEBPACK_IMPORTED_MODULE_3__["TranslateService"]])
    ], MenuComponent);
    return MenuComponent;
}());



/***/ }),

/***/ "./src/app/pages/composition/menu/secondary-header/secondary-header.component.scss":
/*!*****************************************************************************************!*\
  !*** ./src/app/pages/composition/menu/secondary-header/secondary-header.component.scss ***!
  \*****************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".project-header {\n  height: 56px;\n  background: #002d62;\n}\n\n.secondary-header {\n  color: white;\n}\n\n.mat-icon {\n  color: white;\n}\n\n.non-activated {\n  border: 1.5px solid rgba(255, 255, 255, 0);\n  border-radius: 30px;\n  padding: 5px 20px;\n  transition: border 0.3s ease-in-out;\n}\n\n.activated {\n  border: 1.5px solid red;\n  border-radius: 30px;\n  padding: 5px 20px;\n  transition: border 0.3s ease-in-out;\n}\n\n.dashboard-filter {\n  text-decoration: none;\n  color: #ddd;\n  cursor: pointer;\n  font-family: \"Roboto-Bold\", sans-serif;\n  transition: 0.3s;\n}\n\n.dashboard-filter:hover {\n  color: #fff;\n}\n\n.dashboard-text {\n  color: #fff;\n  font-family: \"Roboto-Bold\", sans-serif;\n  font-size: 20px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvY29tcG9zaXRpb24vbWVudS9zZWNvbmRhcnktaGVhZGVyL0Q6XFxwcm9qZWN0c1xcaWloZlxcd2ZtLXdlYi9zcmNcXGFwcFxccGFnZXNcXGNvbXBvc2l0aW9uXFxtZW51XFxzZWNvbmRhcnktaGVhZGVyXFxzZWNvbmRhcnktaGVhZGVyLmNvbXBvbmVudC5zY3NzIiwic3JjL2FwcC9wYWdlcy9jb21wb3NpdGlvbi9tZW51L3NlY29uZGFyeS1oZWFkZXIvc2Vjb25kYXJ5LWhlYWRlci5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLFlBQUE7RUFDQSxtQkFBQTtBQ0NKOztBREVBO0VBQ0ksWUFBQTtBQ0NKOztBREVBO0VBQ0ksWUFBQTtBQ0NKOztBREVBO0VBQ0ksMENBQUE7RUFDQSxtQkFBQTtFQUNBLGlCQUFBO0VBQ0EsbUNBQUE7QUNDSjs7QURFQTtFQUNJLHVCQUFBO0VBQ0EsbUJBQUE7RUFDQSxpQkFBQTtFQUNBLG1DQUFBO0FDQ0o7O0FERUE7RUFDSSxxQkFBQTtFQUNBLFdBQUE7RUFDQSxlQUFBO0VBQ0Esc0NBQUE7RUFDQSxnQkFBQTtBQ0NKOztBRENJO0VBQ0ksV0FBQTtBQ0NSOztBREdBO0VBQ0ksV0FBQTtFQUNBLHNDQUFBO0VBQ0EsZUFBQTtBQ0FKIiwiZmlsZSI6InNyYy9hcHAvcGFnZXMvY29tcG9zaXRpb24vbWVudS9zZWNvbmRhcnktaGVhZGVyL3NlY29uZGFyeS1oZWFkZXIuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIucHJvamVjdC1oZWFkZXIge1xyXG4gICAgaGVpZ2h0OiA1NnB4O1xyXG4gICAgYmFja2dyb3VuZDogIzAwMmQ2MjtcclxufVxyXG5cclxuLnNlY29uZGFyeS1oZWFkZXIge1xyXG4gICAgY29sb3I6IHdoaXRlO1xyXG59XHJcblxyXG4ubWF0LWljb24ge1xyXG4gICAgY29sb3I6IHdoaXRlO1xyXG59XHJcblxyXG4ubm9uLWFjdGl2YXRlZCB7XHJcbiAgICBib3JkZXI6IDEuNXB4IHNvbGlkIHJnYmEoMjU1LCAyNTUsIDI1NSwgMCk7XHJcbiAgICBib3JkZXItcmFkaXVzOiAzMHB4O1xyXG4gICAgcGFkZGluZzogNXB4IDIwcHg7XHJcbiAgICB0cmFuc2l0aW9uOiBib3JkZXIgMC4zcyBlYXNlLWluLW91dDtcclxufVxyXG5cclxuLmFjdGl2YXRlZCB7XHJcbiAgICBib3JkZXI6IDEuNXB4IHNvbGlkIHJlZDtcclxuICAgIGJvcmRlci1yYWRpdXM6IDMwcHg7XHJcbiAgICBwYWRkaW5nOiA1cHggMjBweDtcclxuICAgIHRyYW5zaXRpb246IGJvcmRlciAwLjNzIGVhc2UtaW4tb3V0O1xyXG59XHJcblxyXG4uZGFzaGJvYXJkLWZpbHRlciB7XHJcbiAgICB0ZXh0LWRlY29yYXRpb246IG5vbmU7XHJcbiAgICBjb2xvcjogI2RkZDtcclxuICAgIGN1cnNvcjogcG9pbnRlcjtcclxuICAgIGZvbnQtZmFtaWx5OiAnUm9ib3RvLUJvbGQnLCBzYW5zLXNlcmlmO1xyXG4gICAgdHJhbnNpdGlvbjogLjNzO1xyXG5cclxuICAgICY6aG92ZXIge1xyXG4gICAgICAgIGNvbG9yOiAjZmZmO1xyXG4gICAgfVxyXG59XHJcblxyXG4uZGFzaGJvYXJkLXRleHQge1xyXG4gICAgY29sb3I6ICNmZmY7XHJcbiAgICBmb250LWZhbWlseTogJ1JvYm90by1Cb2xkJywgc2Fucy1zZXJpZjtcclxuICAgIGZvbnQtc2l6ZTogMjBweDtcclxufVxyXG4iLCIucHJvamVjdC1oZWFkZXIge1xuICBoZWlnaHQ6IDU2cHg7XG4gIGJhY2tncm91bmQ6ICMwMDJkNjI7XG59XG5cbi5zZWNvbmRhcnktaGVhZGVyIHtcbiAgY29sb3I6IHdoaXRlO1xufVxuXG4ubWF0LWljb24ge1xuICBjb2xvcjogd2hpdGU7XG59XG5cbi5ub24tYWN0aXZhdGVkIHtcbiAgYm9yZGVyOiAxLjVweCBzb2xpZCByZ2JhKDI1NSwgMjU1LCAyNTUsIDApO1xuICBib3JkZXItcmFkaXVzOiAzMHB4O1xuICBwYWRkaW5nOiA1cHggMjBweDtcbiAgdHJhbnNpdGlvbjogYm9yZGVyIDAuM3MgZWFzZS1pbi1vdXQ7XG59XG5cbi5hY3RpdmF0ZWQge1xuICBib3JkZXI6IDEuNXB4IHNvbGlkIHJlZDtcbiAgYm9yZGVyLXJhZGl1czogMzBweDtcbiAgcGFkZGluZzogNXB4IDIwcHg7XG4gIHRyYW5zaXRpb246IGJvcmRlciAwLjNzIGVhc2UtaW4tb3V0O1xufVxuXG4uZGFzaGJvYXJkLWZpbHRlciB7XG4gIHRleHQtZGVjb3JhdGlvbjogbm9uZTtcbiAgY29sb3I6ICNkZGQ7XG4gIGN1cnNvcjogcG9pbnRlcjtcbiAgZm9udC1mYW1pbHk6IFwiUm9ib3RvLUJvbGRcIiwgc2Fucy1zZXJpZjtcbiAgdHJhbnNpdGlvbjogMC4zcztcbn1cbi5kYXNoYm9hcmQtZmlsdGVyOmhvdmVyIHtcbiAgY29sb3I6ICNmZmY7XG59XG5cbi5kYXNoYm9hcmQtdGV4dCB7XG4gIGNvbG9yOiAjZmZmO1xuICBmb250LWZhbWlseTogXCJSb2JvdG8tQm9sZFwiLCBzYW5zLXNlcmlmO1xuICBmb250LXNpemU6IDIwcHg7XG59Il19 */");

/***/ }),

/***/ "./src/app/pages/composition/menu/secondary-header/secondary-header.component.ts":
/*!***************************************************************************************!*\
  !*** ./src/app/pages/composition/menu/secondary-header/secondary-header.component.ts ***!
  \***************************************************************************************/
/*! exports provided: SecondaryHeaderComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SecondaryHeaderComponent", function() { return SecondaryHeaderComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _shared_hazlenut_hazelnut_common_animations__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../../shared/hazlenut/hazelnut-common/animations */ "./src/app/shared/hazlenut/hazelnut-common/animations/index.ts");
/* harmony import */ var _shared_services_dashboard_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../../shared/services/dashboard.service */ "./src/app/shared/services/dashboard.service.ts");
/* harmony import */ var _shared_services_storage_project_event_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../../shared/services/storage/project-event.service */ "./src/app/shared/services/storage/project-event.service.ts");






var SecondaryHeaderComponent = /** @class */ (function () {
    function SecondaryHeaderComponent(projectEventService, router, dashboardService) {
        this.projectEventService = projectEventService;
        this.router = router;
        this.dashboardService = dashboardService;
        this.dashboardVisible = true;
        this.activeFilter = 'ALL';
        this.imagePath = '';
    }
    SecondaryHeaderComponent.prototype.ngOnInit = function () {
        this.dashboardService.setSecondaryHeaderContent({ isDashboard: true });
        this.imagePath = this.projectEventService.instant.imagePath;
        this.dashboardVisible = this.projectEventService.instant.active;
    };
    SecondaryHeaderComponent.prototype.toggleFilter = function (filterValue) {
        this.dashboardService.setDashboardFilter(filterValue);
        this.activeFilter = filterValue;
        this.imagePath = this.projectEventService.instant.imagePath;
    };
    SecondaryHeaderComponent.prototype.routeToDashboard = function () {
        this.activeFilter = 'ALL';
        this.router.navigate(['dashboard']);
        this.dashboardService.setSecondaryHeaderContent({ isDashboard: true });
        this.projectEventService.setEventData();
    };
    SecondaryHeaderComponent.ctorParameters = function () { return [
        { type: _shared_services_storage_project_event_service__WEBPACK_IMPORTED_MODULE_5__["ProjectEventService"] },
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"] },
        { type: _shared_services_dashboard_service__WEBPACK_IMPORTED_MODULE_4__["DashboardService"] }
    ]; };
    SecondaryHeaderComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'secondary-header',
            template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./secondary-header.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/composition/menu/secondary-header/secondary-header.component.html")).default,
            animations: [_shared_hazlenut_hazelnut_common_animations__WEBPACK_IMPORTED_MODULE_3__["fadeEnterLeave"]],
            styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./secondary-header.component.scss */ "./src/app/pages/composition/menu/secondary-header/secondary-header.component.scss")).default]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_shared_services_storage_project_event_service__WEBPACK_IMPORTED_MODULE_5__["ProjectEventService"],
            _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"],
            _shared_services_dashboard_service__WEBPACK_IMPORTED_MODULE_4__["DashboardService"]])
    ], SecondaryHeaderComponent);
    return SecondaryHeaderComponent;
}());



/***/ }),

/***/ "./src/app/pages/composition/side-options/side-options.component.scss":
/*!****************************************************************************!*\
  !*** ./src/app/pages/composition/side-options/side-options.component.scss ***!
  \****************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("/*\n Icon and text color\n  */\n.bottom-border {\n  border-bottom: 1px solid white;\n}\n.menu-option {\n  -webkit-touch-callout: none;\n  -webkit-user-select: none;\n  -moz-user-select: none;\n  -ms-user-select: none;\n  user-select: none;\n  color: white;\n  padding: 21px 0 19px 19px;\n  cursor: pointer;\n}\n.menu-option:hover {\n  background: rgba(255, 255, 255, 0.1);\n}\n.child-container {\n  overflow: hidden;\n  max-height: 0;\n  padding-left: 20px;\n  transition: max-height 0.2s ease-out;\n}\n.child-container-open {\n  overflow: hidden;\n  max-height: 100vh;\n  padding-left: 20px;\n  transition: max-height 0.5s ease-in;\n}\n.child-container-icon {\n  overflow: hidden;\n  max-width: 0;\n  transition: max-width 0.2s ease-out;\n}\n.child-container-icon-open {\n  overflow: hidden;\n  max-width: 100vw;\n  transition: max-width 0.5s ease-in;\n}\n.rotate-360 {\n  transform: rotate(-360deg);\n  transition: transform 250ms ease;\n}\n.rotate-180 {\n  transform: rotate(-180deg);\n  transition: transform 250ms ease;\n}\n.menu-icon {\n  position: absolute;\n  margin-top: -3px;\n}\n.menu-icon-dropdown {\n  position: absolute;\n  margin-top: -3px;\n  right: 15px;\n}\n.mat-icon {\n  color: white;\n}\n.pl-35 {\n  padding-left: 35px;\n}\n.side-option-selected {\n  margin-top: -7px;\n  height: 30px;\n  width: 2px;\n  background: white;\n  position: absolute;\n  right: 3px;\n  border-radius: 1px;\n  transition: height 0.2s ease-in, margin 0.2s ease-in;\n}\n.side-option-unselected {\n  margin-top: 0;\n  height: 0;\n  width: 2px;\n  background: white;\n  position: absolute;\n  right: 3px;\n  border-radius: 1px;\n  transition: height 0.1s ease-out, margin 0.2s ease-in;\n}\n.menu-text {\n  font-family: \"Roboto-Bold\", sans-serif;\n  font-size: 14px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvY29tcG9zaXRpb24vc2lkZS1vcHRpb25zL0Q6XFxwcm9qZWN0c1xcaWloZlxcd2ZtLXdlYi9zcmNcXGFwcFxccGFnZXNcXGNvbXBvc2l0aW9uXFxzaWRlLW9wdGlvbnNcXHNpZGUtb3B0aW9ucy5jb21wb25lbnQuc2NzcyIsInNyYy9hcHAvcGFnZXMvY29tcG9zaXRpb24vc2lkZS1vcHRpb25zL3NpZGUtb3B0aW9ucy5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTs7R0FBQTtBQWFBO0VBQ0ksOEJBQUE7QUNUSjtBRFlBO0VBWEksMkJBQUE7RUFDQSx5QkFBQTtFQUNBLHNCQUFBO0VBQ0EscUJBQUE7RUFDQSxpQkFBQTtFQVNBLFlBaEJTO0VBaUJULHlCQUFBO0VBQ0EsZUFBQTtBQ0xKO0FET0k7RUFDSSxvQ0FBQTtBQ0xSO0FEU0E7RUFDSSxnQkFBQTtFQUNBLGFBQUE7RUFDQSxrQkFBQTtFQUNBLG9DQUFBO0FDTko7QURTQTtFQUNJLGdCQUFBO0VBQ0EsaUJBQUE7RUFDQSxrQkFBQTtFQUNBLG1DQUFBO0FDTko7QURTQTtFQUNJLGdCQUFBO0VBQ0EsWUFBQTtFQUNBLG1DQUFBO0FDTko7QURTQTtFQUNJLGdCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxrQ0FBQTtBQ05KO0FEU0E7RUFDSSwwQkFBQTtFQUNBLGdDQUFBO0FDTko7QURTQTtFQUNJLDBCQUFBO0VBQ0EsZ0NBQUE7QUNOSjtBRFNBO0VBQ0ksa0JBQUE7RUFDQSxnQkFBQTtBQ05KO0FEU0E7RUFDSSxrQkFBQTtFQUNBLGdCQUFBO0VBQ0EsV0FBQTtBQ05KO0FEU0E7RUFDSSxZQXpFUztBQ21FYjtBRFNBO0VBQ0ksa0JBQUE7QUNOSjtBRFNBO0VBQ0ksZ0JBQUE7RUFDQSxZQUFBO0VBQ0EsVUFBQTtFQUNBLGlCQXBGUztFQXFGVCxrQkFBQTtFQUNBLFVBQUE7RUFDQSxrQkFBQTtFQUNBLG9EQUFBO0FDTko7QURTQTtFQUNJLGFBQUE7RUFDQSxTQUFBO0VBQ0EsVUFBQTtFQUNBLGlCQS9GUztFQWdHVCxrQkFBQTtFQUNBLFVBQUE7RUFDQSxrQkFBQTtFQUNBLHFEQUFBO0FDTko7QURTQTtFQUNJLHNDQUFBO0VBQ0EsZUFBQTtBQ05KIiwiZmlsZSI6InNyYy9hcHAvcGFnZXMvY29tcG9zaXRpb24vc2lkZS1vcHRpb25zL3NpZGUtb3B0aW9ucy5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi8qXHJcbiBJY29uIGFuZCB0ZXh0IGNvbG9yXHJcbiAgKi9cclxuJHRleHQtY29sb3I6IHdoaXRlO1xyXG5cclxuQG1peGluIGJsb2NrLXNlbGVjdGluZy1lbGVtZW50cyB7XHJcbiAgICAtd2Via2l0LXRvdWNoLWNhbGxvdXQ6IG5vbmU7XHJcbiAgICAtd2Via2l0LXVzZXItc2VsZWN0OiBub25lO1xyXG4gICAgLW1vei11c2VyLXNlbGVjdDogbm9uZTtcclxuICAgIC1tcy11c2VyLXNlbGVjdDogbm9uZTtcclxuICAgIHVzZXItc2VsZWN0OiBub25lO1xyXG59XHJcblxyXG4uYm90dG9tLWJvcmRlciB7XHJcbiAgICBib3JkZXItYm90dG9tOiAxcHggc29saWQgd2hpdGU7XHJcbn1cclxuXHJcbi5tZW51LW9wdGlvbiB7XHJcbiAgICBAaW5jbHVkZSBibG9jay1zZWxlY3RpbmctZWxlbWVudHM7XHJcbiAgICBjb2xvcjogJHRleHQtY29sb3I7XHJcbiAgICBwYWRkaW5nOiAyMXB4IDAgMTlweCAxOXB4O1xyXG4gICAgY3Vyc29yOiBwb2ludGVyO1xyXG5cclxuICAgICY6aG92ZXIge1xyXG4gICAgICAgIGJhY2tncm91bmQ6IHJnYmEoMjU1LCAyNTUsIDI1NSwgLjEpO1xyXG4gICAgfVxyXG59XHJcblxyXG4uY2hpbGQtY29udGFpbmVyIHtcclxuICAgIG92ZXJmbG93OiBoaWRkZW47XHJcbiAgICBtYXgtaGVpZ2h0OiAwO1xyXG4gICAgcGFkZGluZy1sZWZ0OiAyMHB4O1xyXG4gICAgdHJhbnNpdGlvbjogbWF4LWhlaWdodCAuMnMgZWFzZS1vdXQ7XHJcbn1cclxuXHJcbi5jaGlsZC1jb250YWluZXItb3BlbiB7XHJcbiAgICBvdmVyZmxvdzogaGlkZGVuO1xyXG4gICAgbWF4LWhlaWdodDogMTAwdmg7XHJcbiAgICBwYWRkaW5nLWxlZnQ6IDIwcHg7XHJcbiAgICB0cmFuc2l0aW9uOiBtYXgtaGVpZ2h0IC41cyBlYXNlLWluO1xyXG59XHJcblxyXG4uY2hpbGQtY29udGFpbmVyLWljb24ge1xyXG4gICAgb3ZlcmZsb3c6IGhpZGRlbjtcclxuICAgIG1heC13aWR0aDogMDtcclxuICAgIHRyYW5zaXRpb246IG1heC13aWR0aCAuMnMgZWFzZS1vdXQ7XHJcbn1cclxuXHJcbi5jaGlsZC1jb250YWluZXItaWNvbi1vcGVuIHtcclxuICAgIG92ZXJmbG93OiBoaWRkZW47XHJcbiAgICBtYXgtd2lkdGg6IDEwMHZ3O1xyXG4gICAgdHJhbnNpdGlvbjogbWF4LXdpZHRoIC41cyBlYXNlLWluO1xyXG59XHJcblxyXG4ucm90YXRlLTM2MCB7XHJcbiAgICB0cmFuc2Zvcm06IHJvdGF0ZSgtMzYwZGVnKTtcclxuICAgIHRyYW5zaXRpb246IHRyYW5zZm9ybSAyNTBtcyBlYXNlO1xyXG59XHJcblxyXG4ucm90YXRlLTE4MCB7XHJcbiAgICB0cmFuc2Zvcm06IHJvdGF0ZSgtMTgwZGVnKTtcclxuICAgIHRyYW5zaXRpb246IHRyYW5zZm9ybSAyNTBtcyBlYXNlO1xyXG59XHJcblxyXG4ubWVudS1pY29uIHtcclxuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAgIG1hcmdpbi10b3A6IC0zcHg7XHJcbn1cclxuXHJcbi5tZW51LWljb24tZHJvcGRvd24ge1xyXG4gICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgbWFyZ2luLXRvcDogLTNweDtcclxuICAgIHJpZ2h0OiAxNXB4O1xyXG59XHJcblxyXG4ubWF0LWljb24ge1xyXG4gICAgY29sb3I6ICR0ZXh0LWNvbG9yO1xyXG59XHJcblxyXG4ucGwtMzUge1xyXG4gICAgcGFkZGluZy1sZWZ0OiAzNXB4O1xyXG59XHJcblxyXG4uc2lkZS1vcHRpb24tc2VsZWN0ZWQge1xyXG4gICAgbWFyZ2luLXRvcDogLTdweDtcclxuICAgIGhlaWdodDogMzBweDtcclxuICAgIHdpZHRoOiAycHg7XHJcbiAgICBiYWNrZ3JvdW5kOiAkdGV4dC1jb2xvcjtcclxuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAgIHJpZ2h0OiAzcHg7XHJcbiAgICBib3JkZXItcmFkaXVzOiAxcHg7XHJcbiAgICB0cmFuc2l0aW9uOiBoZWlnaHQgLjJzIGVhc2UtaW4sIG1hcmdpbiAuMnMgZWFzZS1pbjtcclxufVxyXG5cclxuLnNpZGUtb3B0aW9uLXVuc2VsZWN0ZWQge1xyXG4gICAgbWFyZ2luLXRvcDogMDtcclxuICAgIGhlaWdodDogMDtcclxuICAgIHdpZHRoOiAycHg7XHJcbiAgICBiYWNrZ3JvdW5kOiAkdGV4dC1jb2xvcjtcclxuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAgIHJpZ2h0OiAzcHg7XHJcbiAgICBib3JkZXItcmFkaXVzOiAxcHg7XHJcbiAgICB0cmFuc2l0aW9uOiBoZWlnaHQgLjFzIGVhc2Utb3V0LCBtYXJnaW4gLjJzIGVhc2UtaW47XHJcbn1cclxuXHJcbi5tZW51LXRleHQge1xyXG4gICAgZm9udC1mYW1pbHk6ICdSb2JvdG8tQm9sZCcsIHNhbnMtc2VyaWY7XHJcbiAgICBmb250LXNpemU6IDE0cHg7XHJcbn1cclxuIiwiLypcbiBJY29uIGFuZCB0ZXh0IGNvbG9yXG4gICovXG4uYm90dG9tLWJvcmRlciB7XG4gIGJvcmRlci1ib3R0b206IDFweCBzb2xpZCB3aGl0ZTtcbn1cblxuLm1lbnUtb3B0aW9uIHtcbiAgLXdlYmtpdC10b3VjaC1jYWxsb3V0OiBub25lO1xuICAtd2Via2l0LXVzZXItc2VsZWN0OiBub25lO1xuICAtbW96LXVzZXItc2VsZWN0OiBub25lO1xuICAtbXMtdXNlci1zZWxlY3Q6IG5vbmU7XG4gIHVzZXItc2VsZWN0OiBub25lO1xuICBjb2xvcjogd2hpdGU7XG4gIHBhZGRpbmc6IDIxcHggMCAxOXB4IDE5cHg7XG4gIGN1cnNvcjogcG9pbnRlcjtcbn1cbi5tZW51LW9wdGlvbjpob3ZlciB7XG4gIGJhY2tncm91bmQ6IHJnYmEoMjU1LCAyNTUsIDI1NSwgMC4xKTtcbn1cblxuLmNoaWxkLWNvbnRhaW5lciB7XG4gIG92ZXJmbG93OiBoaWRkZW47XG4gIG1heC1oZWlnaHQ6IDA7XG4gIHBhZGRpbmctbGVmdDogMjBweDtcbiAgdHJhbnNpdGlvbjogbWF4LWhlaWdodCAwLjJzIGVhc2Utb3V0O1xufVxuXG4uY2hpbGQtY29udGFpbmVyLW9wZW4ge1xuICBvdmVyZmxvdzogaGlkZGVuO1xuICBtYXgtaGVpZ2h0OiAxMDB2aDtcbiAgcGFkZGluZy1sZWZ0OiAyMHB4O1xuICB0cmFuc2l0aW9uOiBtYXgtaGVpZ2h0IDAuNXMgZWFzZS1pbjtcbn1cblxuLmNoaWxkLWNvbnRhaW5lci1pY29uIHtcbiAgb3ZlcmZsb3c6IGhpZGRlbjtcbiAgbWF4LXdpZHRoOiAwO1xuICB0cmFuc2l0aW9uOiBtYXgtd2lkdGggMC4ycyBlYXNlLW91dDtcbn1cblxuLmNoaWxkLWNvbnRhaW5lci1pY29uLW9wZW4ge1xuICBvdmVyZmxvdzogaGlkZGVuO1xuICBtYXgtd2lkdGg6IDEwMHZ3O1xuICB0cmFuc2l0aW9uOiBtYXgtd2lkdGggMC41cyBlYXNlLWluO1xufVxuXG4ucm90YXRlLTM2MCB7XG4gIHRyYW5zZm9ybTogcm90YXRlKC0zNjBkZWcpO1xuICB0cmFuc2l0aW9uOiB0cmFuc2Zvcm0gMjUwbXMgZWFzZTtcbn1cblxuLnJvdGF0ZS0xODAge1xuICB0cmFuc2Zvcm06IHJvdGF0ZSgtMTgwZGVnKTtcbiAgdHJhbnNpdGlvbjogdHJhbnNmb3JtIDI1MG1zIGVhc2U7XG59XG5cbi5tZW51LWljb24ge1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIG1hcmdpbi10b3A6IC0zcHg7XG59XG5cbi5tZW51LWljb24tZHJvcGRvd24ge1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIG1hcmdpbi10b3A6IC0zcHg7XG4gIHJpZ2h0OiAxNXB4O1xufVxuXG4ubWF0LWljb24ge1xuICBjb2xvcjogd2hpdGU7XG59XG5cbi5wbC0zNSB7XG4gIHBhZGRpbmctbGVmdDogMzVweDtcbn1cblxuLnNpZGUtb3B0aW9uLXNlbGVjdGVkIHtcbiAgbWFyZ2luLXRvcDogLTdweDtcbiAgaGVpZ2h0OiAzMHB4O1xuICB3aWR0aDogMnB4O1xuICBiYWNrZ3JvdW5kOiB3aGl0ZTtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICByaWdodDogM3B4O1xuICBib3JkZXItcmFkaXVzOiAxcHg7XG4gIHRyYW5zaXRpb246IGhlaWdodCAwLjJzIGVhc2UtaW4sIG1hcmdpbiAwLjJzIGVhc2UtaW47XG59XG5cbi5zaWRlLW9wdGlvbi11bnNlbGVjdGVkIHtcbiAgbWFyZ2luLXRvcDogMDtcbiAgaGVpZ2h0OiAwO1xuICB3aWR0aDogMnB4O1xuICBiYWNrZ3JvdW5kOiB3aGl0ZTtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICByaWdodDogM3B4O1xuICBib3JkZXItcmFkaXVzOiAxcHg7XG4gIHRyYW5zaXRpb246IGhlaWdodCAwLjFzIGVhc2Utb3V0LCBtYXJnaW4gMC4ycyBlYXNlLWluO1xufVxuXG4ubWVudS10ZXh0IHtcbiAgZm9udC1mYW1pbHk6IFwiUm9ib3RvLUJvbGRcIiwgc2Fucy1zZXJpZjtcbiAgZm9udC1zaXplOiAxNHB4O1xufSJdfQ== */");

/***/ }),

/***/ "./src/app/pages/composition/side-options/side-options.component.ts":
/*!**************************************************************************!*\
  !*** ./src/app/pages/composition/side-options/side-options.component.ts ***!
  \**************************************************************************/
/*! exports provided: SideOptionsComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SideOptionsComponent", function() { return SideOptionsComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _shared_services_menu_guard__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../shared/services/menu-guard */ "./src/app/shared/services/menu-guard.ts");
/* harmony import */ var _menu_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../menu.service */ "./src/app/pages/composition/menu.service.ts");





var SideOptionsComponent = /** @class */ (function () {
    function SideOptionsComponent(router, menuService, menuGuard) {
        this.router = router;
        this.menuService = menuService;
        this.menuGuard = menuGuard;
    }
    SideOptionsComponent.prototype.getClass = function (path) {
        return path === this.menuService.selectedOptionPath ? 'side-option-selected' : 'side-option-unselected';
    };
    SideOptionsComponent.prototype.ngOnInit = function () {
        var _this = this;
        if (!this.routes) {
            this.routes = this.router.config
                .find(function (group) { return group.component && group.component.name === 'AdminLayoutComponent'; })
                .children
                .filter(function (route) { return _this.menuGuard.menuRoutingCheck(route.data.title); });
        }
        this.setMenuOptionOnInitFromRouter();
        this.menuSelect = this.menuService.menuOpen;
    };
    SideOptionsComponent.prototype.toggleMenuSelect = function () {
        this.menuService.toggleMenu();
        this.menuSelect = this.menuService.menuOpen;
    };
    SideOptionsComponent.prototype.highlightAndNavigateOption = function (path, highlight) {
        if (highlight === void 0) { highlight = true; }
        if (highlight) {
            this.menuService.setSelectedOption(path);
        }
        this.router.navigate(['/' + path]);
    };
    SideOptionsComponent.prototype.checkRoute = function (object, hasChildren) {
        return object && object.data && object.data.hasOwnProperty('menu') && (object.hasOwnProperty('children') === hasChildren);
    };
    SideOptionsComponent.prototype.setMenuOptionOnInitFromRouter = function () {
        var _this = this;
        [
            'project',
            'reports',
            'facts',
            'business-areas',
            'all-facts'
        ].forEach(function (routeSubstring) {
            if (_this.router.url.includes(routeSubstring)) {
                _this.menuService.setSelectedOption(routeSubstring);
            }
        });
    };
    SideOptionsComponent.ctorParameters = function () { return [
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"] },
        { type: _menu_service__WEBPACK_IMPORTED_MODULE_4__["MenuService"] },
        { type: _shared_services_menu_guard__WEBPACK_IMPORTED_MODULE_3__["MenuGuard"] }
    ]; };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], SideOptionsComponent.prototype, "routes", void 0);
    SideOptionsComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'side-options',
            template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./side-options.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/composition/side-options/side-options.component.html")).default,
            styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./side-options.component.scss */ "./src/app/pages/composition/side-options/side-options.component.scss")).default]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"], _menu_service__WEBPACK_IMPORTED_MODULE_4__["MenuService"], _shared_services_menu_guard__WEBPACK_IMPORTED_MODULE_3__["MenuGuard"]])
    ], SideOptionsComponent);
    return SideOptionsComponent;
}());



/***/ }),

/***/ "./src/app/pages/layouts/admin-layout/admin-layout.component.scss":
/*!************************************************************************!*\
  !*** ./src/app/pages/layouts/admin-layout/admin-layout.component.scss ***!
  \************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".clear-spaces {\n  min-width: 100%;\n  padding: 0 !important;\n  margin: 0 !important;\n}\n\n.top-bar {\n  position: fixed !important;\n  top: 0 !important;\n  z-index: 100;\n  height: 56px;\n  background: white;\n  width: 100%;\n}\n\n.small-text {\n  color: #848484;\n  font-family: \"Roboto-Bold\", sans-serif;\n  font-size: 14px;\n}\n\n.person-icon {\n  width: 40px;\n  height: 40px;\n  background: red;\n  border-radius: 50%;\n}\n\n.title-text {\n  font-family: \"MPLUSRounded1c-ExtraBold\", sans-serif;\n}\n\n.user-icon {\n  font-size: 40px;\n  color: #ce211f;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvbGF5b3V0cy9hZG1pbi1sYXlvdXQvRDpcXHByb2plY3RzXFxpaWhmXFx3Zm0td2ViL3NyY1xcYXBwXFxwYWdlc1xcbGF5b3V0c1xcYWRtaW4tbGF5b3V0XFxhZG1pbi1sYXlvdXQuY29tcG9uZW50LnNjc3MiLCJzcmMvYXBwL3BhZ2VzL2xheW91dHMvYWRtaW4tbGF5b3V0L2FkbWluLWxheW91dC5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLGVBQUE7RUFDQSxxQkFBQTtFQUNBLG9CQUFBO0FDQ0Y7O0FERUE7RUFDSSwwQkFBQTtFQUNBLGlCQUFBO0VBQ0EsWUFBQTtFQUNBLFlBQUE7RUFDQSxpQkFBQTtFQUNBLFdBQUE7QUNDSjs7QURFQTtFQUNJLGNBQUE7RUFDQSxzQ0FBQTtFQUNBLGVBQUE7QUNDSjs7QURFQTtFQUNJLFdBQUE7RUFDQSxZQUFBO0VBQ0EsZUFBQTtFQUNBLGtCQUFBO0FDQ0o7O0FERUE7RUFDSSxtREFBQTtBQ0NKOztBREVBO0VBQ0ksZUFBQTtFQUNBLGNBQUE7QUNDSiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL2xheW91dHMvYWRtaW4tbGF5b3V0L2FkbWluLWxheW91dC5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5jbGVhci1zcGFjZXMge1xyXG4gIG1pbi13aWR0aDogMTAwJTtcclxuICBwYWRkaW5nOiAwICFpbXBvcnRhbnQ7XHJcbiAgbWFyZ2luOiAwICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbi50b3AtYmFyIHtcclxuICAgIHBvc2l0aW9uOiBmaXhlZCAhaW1wb3J0YW50O1xyXG4gICAgdG9wOiAwICFpbXBvcnRhbnQ7XHJcbiAgICB6LWluZGV4OiAxMDA7XHJcbiAgICBoZWlnaHQ6IDU2cHg7XHJcbiAgICBiYWNrZ3JvdW5kOiB3aGl0ZTtcclxuICAgIHdpZHRoOiAxMDAlO1xyXG59XHJcblxyXG4uc21hbGwtdGV4dCB7XHJcbiAgICBjb2xvcjogIzg0ODQ4NDtcclxuICAgIGZvbnQtZmFtaWx5OiAnUm9ib3RvLUJvbGQnLCBzYW5zLXNlcmlmO1xyXG4gICAgZm9udC1zaXplOiAxNHB4O1xyXG59XHJcblxyXG4ucGVyc29uLWljb24ge1xyXG4gICAgd2lkdGg6IDQwcHg7XHJcbiAgICBoZWlnaHQ6IDQwcHg7XHJcbiAgICBiYWNrZ3JvdW5kOiByZWQ7XHJcbiAgICBib3JkZXItcmFkaXVzOiA1MCU7XHJcbn1cclxuXHJcbi50aXRsZS10ZXh0IHtcclxuICAgIGZvbnQtZmFtaWx5OiAnTVBMVVNSb3VuZGVkMWMtRXh0cmFCb2xkJywgc2Fucy1zZXJpZjtcclxufVxyXG5cclxuLnVzZXItaWNvbiB7XHJcbiAgICBmb250LXNpemU6IDQwcHg7XHJcbiAgICBjb2xvcjogI2NlMjExZjtcclxufVxyXG4iLCIuY2xlYXItc3BhY2VzIHtcbiAgbWluLXdpZHRoOiAxMDAlO1xuICBwYWRkaW5nOiAwICFpbXBvcnRhbnQ7XG4gIG1hcmdpbjogMCAhaW1wb3J0YW50O1xufVxuXG4udG9wLWJhciB7XG4gIHBvc2l0aW9uOiBmaXhlZCAhaW1wb3J0YW50O1xuICB0b3A6IDAgIWltcG9ydGFudDtcbiAgei1pbmRleDogMTAwO1xuICBoZWlnaHQ6IDU2cHg7XG4gIGJhY2tncm91bmQ6IHdoaXRlO1xuICB3aWR0aDogMTAwJTtcbn1cblxuLnNtYWxsLXRleHQge1xuICBjb2xvcjogIzg0ODQ4NDtcbiAgZm9udC1mYW1pbHk6IFwiUm9ib3RvLUJvbGRcIiwgc2Fucy1zZXJpZjtcbiAgZm9udC1zaXplOiAxNHB4O1xufVxuXG4ucGVyc29uLWljb24ge1xuICB3aWR0aDogNDBweDtcbiAgaGVpZ2h0OiA0MHB4O1xuICBiYWNrZ3JvdW5kOiByZWQ7XG4gIGJvcmRlci1yYWRpdXM6IDUwJTtcbn1cblxuLnRpdGxlLXRleHQge1xuICBmb250LWZhbWlseTogXCJNUExVU1JvdW5kZWQxYy1FeHRyYUJvbGRcIiwgc2Fucy1zZXJpZjtcbn1cblxuLnVzZXItaWNvbiB7XG4gIGZvbnQtc2l6ZTogNDBweDtcbiAgY29sb3I6ICNjZTIxMWY7XG59Il19 */");

/***/ }),

/***/ "./src/app/pages/layouts/admin-layout/admin-layout.component.ts":
/*!**********************************************************************!*\
  !*** ./src/app/pages/layouts/admin-layout/admin-layout.component.ts ***!
  \**********************************************************************/
/*! exports provided: AdminLayoutComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AdminLayoutComponent", function() { return AdminLayoutComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _shared_hazlenut_hazelnut_common_animations__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../shared/hazlenut/hazelnut-common/animations */ "./src/app/shared/hazlenut/hazelnut-common/animations/index.ts");
/* harmony import */ var _shared_hazlenut_hazelnut_common_config_hazelnut_config__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../shared/hazlenut/hazelnut-common/config/hazelnut-config */ "./src/app/shared/hazlenut/hazelnut-common/config/hazelnut-config.ts");
/* harmony import */ var _shared_services_auth_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../shared/services/auth.service */ "./src/app/shared/services/auth.service.ts");
/* harmony import */ var _shared_services_storage_project_user_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../shared/services/storage/project-user.service */ "./src/app/shared/services/storage/project-user.service.ts");






var AdminLayoutComponent = /** @class */ (function () {
    function AdminLayoutComponent(projectUserService, authService) {
        this.projectUserService = projectUserService;
        this.authService = authService;
        this.language = _shared_hazlenut_hazelnut_common_config_hazelnut_config__WEBPACK_IMPORTED_MODULE_3__["hazelnutConfig"].LANGUAGE;
        this.login = '';
    }
    AdminLayoutComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.projectUserService.subject.login.subscribe(function (login) {
            _this.login = login;
        });
    };
    /**
     * Logout from app and navigate to login screen
     */
    AdminLayoutComponent.prototype.logout = function () {
        this.authService.logout();
        this.projectUserService.clearUserData();
    };
    AdminLayoutComponent.ctorParameters = function () { return [
        { type: _shared_services_storage_project_user_service__WEBPACK_IMPORTED_MODULE_5__["ProjectUserService"] },
        { type: _shared_services_auth_service__WEBPACK_IMPORTED_MODULE_4__["AuthService"] }
    ]; };
    AdminLayoutComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'iihf-admin-layout',
            template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./admin-layout.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/layouts/admin-layout/admin-layout.component.html")).default,
            animations: [_shared_hazlenut_hazelnut_common_animations__WEBPACK_IMPORTED_MODULE_2__["fadeEnterLeave"], _shared_hazlenut_hazelnut_common_animations__WEBPACK_IMPORTED_MODULE_2__["routeAnimations"], _shared_hazlenut_hazelnut_common_animations__WEBPACK_IMPORTED_MODULE_2__["moveDown"], _shared_hazlenut_hazelnut_common_animations__WEBPACK_IMPORTED_MODULE_2__["moveLeft"]],
            styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./admin-layout.component.scss */ "./src/app/pages/layouts/admin-layout/admin-layout.component.scss")).default]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_shared_services_storage_project_user_service__WEBPACK_IMPORTED_MODULE_5__["ProjectUserService"],
            _shared_services_auth_service__WEBPACK_IMPORTED_MODULE_4__["AuthService"]])
    ], AdminLayoutComponent);
    return AdminLayoutComponent;
}());



/***/ }),

/***/ "./src/app/pages/layouts/auth-layout/auth-layout.component.scss":
/*!**********************************************************************!*\
  !*** ./src/app/pages/layouts/auth-layout/auth-layout.component.scss ***!
  \**********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("::ng-deep .mat-sidenav-content {\n  padding: 0;\n}\n\n.mat-sidenav-container {\n  z-index: 1000;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvbGF5b3V0cy9hdXRoLWxheW91dC9EOlxccHJvamVjdHNcXGlpaGZcXHdmbS13ZWIvc3JjXFxhcHBcXHBhZ2VzXFxsYXlvdXRzXFxhdXRoLWxheW91dFxcYXV0aC1sYXlvdXQuY29tcG9uZW50LnNjc3MiLCJzcmMvYXBwL3BhZ2VzL2xheW91dHMvYXV0aC1sYXlvdXQvYXV0aC1sYXlvdXQuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxVQUFBO0FDQ0Y7O0FERUE7RUFDRSxhQUFBO0FDQ0YiLCJmaWxlIjoic3JjL2FwcC9wYWdlcy9sYXlvdXRzL2F1dGgtbGF5b3V0L2F1dGgtbGF5b3V0LmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiOjpuZy1kZWVwIC5tYXQtc2lkZW5hdi1jb250ZW50IHtcclxuICBwYWRkaW5nOiAwO1xyXG59XHJcblxyXG4ubWF0LXNpZGVuYXYtY29udGFpbmVyIHtcclxuICB6LWluZGV4OiAxMDAwO1xyXG59XHJcbiIsIjo6bmctZGVlcCAubWF0LXNpZGVuYXYtY29udGVudCB7XG4gIHBhZGRpbmc6IDA7XG59XG5cbi5tYXQtc2lkZW5hdi1jb250YWluZXIge1xuICB6LWluZGV4OiAxMDAwO1xufSJdfQ== */");

/***/ }),

/***/ "./src/app/pages/layouts/auth-layout/auth-layout.component.ts":
/*!********************************************************************!*\
  !*** ./src/app/pages/layouts/auth-layout/auth-layout.component.ts ***!
  \********************************************************************/
/*! exports provided: AuthLayoutComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AuthLayoutComponent", function() { return AuthLayoutComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");


var AuthLayoutComponent = /** @class */ (function () {
    function AuthLayoutComponent() {
    }
    AuthLayoutComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'iihf-auth-layout',
            template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./auth-layout.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/layouts/auth-layout/auth-layout.component.html")).default,
            styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./auth-layout.component.scss */ "./src/app/pages/layouts/auth-layout/auth-layout.component.scss")).default]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
    ], AuthLayoutComponent);
    return AuthLayoutComponent;
}());



/***/ }),

/***/ "./src/app/shared/components/components.module.ts":
/*!********************************************************!*\
  !*** ./src/app/shared/components/components.module.ts ***!
  \********************************************************/
/*! exports provided: ComponentsModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ComponentsModule", function() { return ComponentsModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var ng2_pdf_viewer__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ng2-pdf-viewer */ "./node_modules/ng2-pdf-viewer/fesm5/ng2-pdf-viewer.js");
/* harmony import */ var _hazlenut_hazelnut_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../hazlenut/hazelnut-common */ "./src/app/shared/hazlenut/hazelnut-common/index.ts");
/* harmony import */ var _hazlenut_small_components__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../hazlenut/small-components */ "./src/app/shared/hazlenut/small-components/index.ts");
/* harmony import */ var _hazlenut_small_components_notifications__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../hazlenut/small-components/notifications */ "./src/app/shared/hazlenut/small-components/notifications/index.ts");
/* harmony import */ var _dialog_pdf_dialog_pdf_dialog_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./dialog/pdf-dialog/pdf-dialog.component */ "./src/app/shared/components/dialog/pdf-dialog/pdf-dialog.component.ts");
/* harmony import */ var _dialog_image_dialog_image_dialog_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./dialog/image-dialog/image-dialog.component */ "./src/app/shared/components/dialog/image-dialog/image-dialog.component.ts");









var ComponentsModule = /** @class */ (function () {
    function ComponentsModule() {
    }
    ComponentsModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["NgModule"])({
            declarations: [_dialog_pdf_dialog_pdf_dialog_component__WEBPACK_IMPORTED_MODULE_7__["PdfDialogComponent"], _dialog_image_dialog_image_dialog_component__WEBPACK_IMPORTED_MODULE_8__["ImageDialogComponent"]],
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"],
                _hazlenut_small_components__WEBPACK_IMPORTED_MODULE_5__["SmallComponentsModule"],
                _hazlenut_hazelnut_common__WEBPACK_IMPORTED_MODULE_4__["MaterialModule"],
                ng2_pdf_viewer__WEBPACK_IMPORTED_MODULE_3__["PdfViewerModule"]
            ],
            exports: [
                _hazlenut_small_components_notifications__WEBPACK_IMPORTED_MODULE_6__["NotificationSnackBarComponent"],
                _dialog_pdf_dialog_pdf_dialog_component__WEBPACK_IMPORTED_MODULE_7__["PdfDialogComponent"],
                _dialog_image_dialog_image_dialog_component__WEBPACK_IMPORTED_MODULE_8__["ImageDialogComponent"]
            ]
        })
    ], ComponentsModule);
    return ComponentsModule;
}());



/***/ }),

/***/ "./src/app/shared/components/dialog/image-dialog/image-dialog.component.scss":
/*!***********************************************************************************!*\
  !*** ./src/app/shared/components/dialog/image-dialog/image-dialog.component.scss ***!
  \***********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".image-wrapper {\n  width: 100%;\n  max-height: 70vh;\n  overflow-y: auto;\n}\n.image-wrapper .image {\n  width: auto;\n  height: auto;\n  max-height: 68vh;\n  max-width: 100%;\n}\n.close-button-wrapper {\n  margin-bottom: 10px;\n  display: flex;\n  justify-content: flex-end;\n  height: 50px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvc2hhcmVkL2NvbXBvbmVudHMvZGlhbG9nL2ltYWdlLWRpYWxvZy9EOlxccHJvamVjdHNcXGlpaGZcXHdmbS13ZWIvc3JjXFxhcHBcXHNoYXJlZFxcY29tcG9uZW50c1xcZGlhbG9nXFxpbWFnZS1kaWFsb2dcXGltYWdlLWRpYWxvZy5jb21wb25lbnQuc2NzcyIsInNyYy9hcHAvc2hhcmVkL2NvbXBvbmVudHMvZGlhbG9nL2ltYWdlLWRpYWxvZy9pbWFnZS1kaWFsb2cuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQ0E7RUFDSSxXQUFBO0VBQ0EsZ0JBQUE7RUFDQSxnQkFBQTtBQ0FKO0FERUk7RUFDSSxXQUFBO0VBQ0EsWUFBQTtFQUNBLGdCQUFBO0VBQ0EsZUFBQTtBQ0FSO0FESUE7RUFDSSxtQkFBQTtFQUNBLGFBQUE7RUFDQSx5QkFBQTtFQUNBLFlBQUE7QUNESiIsImZpbGUiOiJzcmMvYXBwL3NoYXJlZC9jb21wb25lbnRzL2RpYWxvZy9pbWFnZS1kaWFsb2cvaW1hZ2UtZGlhbG9nLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiXHJcbi5pbWFnZS13cmFwcGVyIHtcclxuICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgbWF4LWhlaWdodDogNzB2aDtcclxuICAgIG92ZXJmbG93LXk6IGF1dG87XHJcblxyXG4gICAgLmltYWdlIHtcclxuICAgICAgICB3aWR0aDogYXV0bztcclxuICAgICAgICBoZWlnaHQ6IGF1dG87XHJcbiAgICAgICAgbWF4LWhlaWdodDogNjh2aDtcclxuICAgICAgICBtYXgtd2lkdGg6IDEwMCU7XHJcbiAgICB9XHJcbn1cclxuXHJcbi5jbG9zZS1idXR0b24td3JhcHBlciB7XHJcbiAgICBtYXJnaW4tYm90dG9tOiAxMHB4O1xyXG4gICAgZGlzcGxheTogZmxleDtcclxuICAgIGp1c3RpZnktY29udGVudDogZmxleC1lbmQ7XHJcbiAgICBoZWlnaHQ6IDUwcHg7XHJcbn1cclxuIiwiLmltYWdlLXdyYXBwZXIge1xuICB3aWR0aDogMTAwJTtcbiAgbWF4LWhlaWdodDogNzB2aDtcbiAgb3ZlcmZsb3cteTogYXV0bztcbn1cbi5pbWFnZS13cmFwcGVyIC5pbWFnZSB7XG4gIHdpZHRoOiBhdXRvO1xuICBoZWlnaHQ6IGF1dG87XG4gIG1heC1oZWlnaHQ6IDY4dmg7XG4gIG1heC13aWR0aDogMTAwJTtcbn1cblxuLmNsb3NlLWJ1dHRvbi13cmFwcGVyIHtcbiAgbWFyZ2luLWJvdHRvbTogMTBweDtcbiAgZGlzcGxheTogZmxleDtcbiAganVzdGlmeS1jb250ZW50OiBmbGV4LWVuZDtcbiAgaGVpZ2h0OiA1MHB4O1xufSJdfQ== */");

/***/ }),

/***/ "./src/app/shared/components/dialog/image-dialog/image-dialog.component.ts":
/*!*********************************************************************************!*\
  !*** ./src/app/shared/components/dialog/image-dialog/image-dialog.component.ts ***!
  \*********************************************************************************/
/*! exports provided: ImageDialogComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ImageDialogComponent", function() { return ImageDialogComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_material_dialog__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/material/dialog */ "./node_modules/@angular/material/esm5/dialog.es5.js");



var ImageDialogComponent = /** @class */ (function () {
    function ImageDialogComponent(dialogRef, data) {
        this.dialogRef = dialogRef;
        this.data = data;
    }
    ImageDialogComponent.prototype.close = function () {
        this.dialogRef.close();
    };
    ImageDialogComponent.ctorParameters = function () { return [
        { type: _angular_material_dialog__WEBPACK_IMPORTED_MODULE_2__["MatDialogRef"] },
        { type: undefined, decorators: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["Inject"], args: [_angular_material_dialog__WEBPACK_IMPORTED_MODULE_2__["MAT_DIALOG_DATA"],] }] }
    ]; };
    ImageDialogComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'image-dialog',
            template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./image-dialog.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/shared/components/dialog/image-dialog/image-dialog.component.html")).default,
            styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./image-dialog.component.scss */ "./src/app/shared/components/dialog/image-dialog/image-dialog.component.scss")).default]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__param"](1, Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Inject"])(_angular_material_dialog__WEBPACK_IMPORTED_MODULE_2__["MAT_DIALOG_DATA"])),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_material_dialog__WEBPACK_IMPORTED_MODULE_2__["MatDialogRef"], Object])
    ], ImageDialogComponent);
    return ImageDialogComponent;
}());



/***/ }),

/***/ "./src/app/shared/components/dialog/pdf-dialog/pdf-dialog.component.scss":
/*!*******************************************************************************!*\
  !*** ./src/app/shared/components/dialog/pdf-dialog/pdf-dialog.component.scss ***!
  \*******************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".pdf-wrapper {\n  width: 100%;\n  max-height: 70vh;\n  overflow-y: auto;\n}\n\n.close-button-wrapper {\n  margin-bottom: 10px;\n  display: flex;\n  justify-content: flex-end;\n  height: 50px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvc2hhcmVkL2NvbXBvbmVudHMvZGlhbG9nL3BkZi1kaWFsb2cvRDpcXHByb2plY3RzXFxpaWhmXFx3Zm0td2ViL3NyY1xcYXBwXFxzaGFyZWRcXGNvbXBvbmVudHNcXGRpYWxvZ1xccGRmLWRpYWxvZ1xccGRmLWRpYWxvZy5jb21wb25lbnQuc2NzcyIsInNyYy9hcHAvc2hhcmVkL2NvbXBvbmVudHMvZGlhbG9nL3BkZi1kaWFsb2cvcGRmLWRpYWxvZy5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFDQTtFQUNJLFdBQUE7RUFDQSxnQkFBQTtFQUNBLGdCQUFBO0FDQUo7O0FER0E7RUFDSSxtQkFBQTtFQUNBLGFBQUE7RUFDQSx5QkFBQTtFQUNBLFlBQUE7QUNBSiIsImZpbGUiOiJzcmMvYXBwL3NoYXJlZC9jb21wb25lbnRzL2RpYWxvZy9wZGYtZGlhbG9nL3BkZi1kaWFsb2cuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJcclxuLnBkZi13cmFwcGVyIHtcclxuICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgbWF4LWhlaWdodDogNzB2aDtcclxuICAgIG92ZXJmbG93LXk6IGF1dG87XHJcbn1cclxuXHJcbi5jbG9zZS1idXR0b24td3JhcHBlciB7XHJcbiAgICBtYXJnaW4tYm90dG9tOiAxMHB4O1xyXG4gICAgZGlzcGxheTogZmxleDtcclxuICAgIGp1c3RpZnktY29udGVudDogZmxleC1lbmQ7XHJcbiAgICBoZWlnaHQ6IDUwcHg7XHJcbn1cclxuIiwiLnBkZi13cmFwcGVyIHtcbiAgd2lkdGg6IDEwMCU7XG4gIG1heC1oZWlnaHQ6IDcwdmg7XG4gIG92ZXJmbG93LXk6IGF1dG87XG59XG5cbi5jbG9zZS1idXR0b24td3JhcHBlciB7XG4gIG1hcmdpbi1ib3R0b206IDEwcHg7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGp1c3RpZnktY29udGVudDogZmxleC1lbmQ7XG4gIGhlaWdodDogNTBweDtcbn0iXX0= */");

/***/ }),

/***/ "./src/app/shared/components/dialog/pdf-dialog/pdf-dialog.component.ts":
/*!*****************************************************************************!*\
  !*** ./src/app/shared/components/dialog/pdf-dialog/pdf-dialog.component.ts ***!
  \*****************************************************************************/
/*! exports provided: PdfDialogComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PdfDialogComponent", function() { return PdfDialogComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_material_dialog__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/material/dialog */ "./node_modules/@angular/material/esm5/dialog.es5.js");



var PdfDialogComponent = /** @class */ (function () {
    function PdfDialogComponent(dialogRef, data) {
        this.dialogRef = dialogRef;
        this.data = data;
    }
    PdfDialogComponent.prototype.close = function () {
        this.dialogRef.close();
    };
    PdfDialogComponent.ctorParameters = function () { return [
        { type: _angular_material_dialog__WEBPACK_IMPORTED_MODULE_2__["MatDialogRef"] },
        { type: undefined, decorators: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["Inject"], args: [_angular_material_dialog__WEBPACK_IMPORTED_MODULE_2__["MAT_DIALOG_DATA"],] }] }
    ]; };
    PdfDialogComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'pdf-dialog',
            template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./pdf-dialog.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/shared/components/dialog/pdf-dialog/pdf-dialog.component.html")).default,
            styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./pdf-dialog.component.scss */ "./src/app/shared/components/dialog/pdf-dialog/pdf-dialog.component.scss")).default]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__param"](1, Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Inject"])(_angular_material_dialog__WEBPACK_IMPORTED_MODULE_2__["MAT_DIALOG_DATA"])),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_material_dialog__WEBPACK_IMPORTED_MODULE_2__["MatDialogRef"], Object])
    ], PdfDialogComponent);
    return PdfDialogComponent;
}());



/***/ }),

/***/ "./src/app/shared/enums/report-type.enum.ts":
/*!**************************************************!*\
  !*** ./src/app/shared/enums/report-type.enum.ts ***!
  \**************************************************/
/*! exports provided: ReportType */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ReportType", function() { return ReportType; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");

var ReportType;
(function (ReportType) {
    ReportType["ToDoList"] = "toDoList";
    ReportType["RedFlagList"] = "redFlagList";
})(ReportType || (ReportType = {}));


/***/ }),

/***/ "./src/app/shared/enums/role.enum.ts":
/*!*******************************************!*\
  !*** ./src/app/shared/enums/role.enum.ts ***!
  \*******************************************/
/*! exports provided: Role */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Role", function() { return Role; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");

var Role;
(function (Role) {
    Role["RoleUpdateTask"] = "ROLE_UPDATE_TASK";
    Role["RoleUpdateTaskInAssignProject"] = "ROLE_UPDATE_TASK_IN_ASSIGN_PROJECT";
    Role["RoleExportReportRedFlagList"] = "ROLE_EXPORT_REPORT_RED_FLAG_LIST";
    Role["RoleExportReportRedFlagListInAssignProject"] = "ROLE_EXPORT_REPORT_RED_FLAG_LIST_IN_ASSIGN_PROJECT";
    Role["RoleReadProjectPhase"] = "ROLE_READ_PROJECT_PHASE";
    Role["RoleReadAllFactItem"] = "ROLE_READ_ALL_FACT_ITEM";
    Role["RoleMenuProject"] = "ROLE_MENU_PROJECT";
    Role["RoleMenuReports"] = "ROLE_MENU_REPORTS";
    Role["RoleDeleteProjectPhase"] = "ROLE_DELETE_PROJECT_PHASE";
    Role["RoleUploadImage"] = "ROLE_UPLOAD_IMAGE";
    Role["RoleReadTask"] = "ROLE_READ_TASK";
    Role["RoleReadTaskInAssignProject"] = "ROLE_READ_TASK_IN_ASSIGN_PROJECT";
    Role["RoleFilterCodeListItem"] = "ROLE_FILTER_CODE_LIST_ITEM";
    Role["RoleMenuTask"] = "ROLE_MENU_TASK";
    Role["RoleUpdateFactItem"] = "ROLE_UPDATE_FACT_ITEM";
    Role["RoleUpdateFactItemInAssignProject"] = "ROLE_UPDATE_FACT_ITEM_IN_ASSIGN_PROJECT";
    Role["RoleMenuAssignUser"] = "ROLE_MENU_ASSIGN_USER";
    Role["RoleReadDashboard"] = "ROLE_READ_DASHBOARD";
    Role["RoleFilterAssignUser"] = "ROLE_FILTER_ASSIGN_USER";
    Role["RoleFilterUser"] = "ROLE_FILTER_USER";
    Role["RoleExportReportToDoList"] = "ROLE_EXPORT_REPORT_TO_DO_LIST";
    Role["RoleExportReportToDoListInAssignProject"] = "ROLE_EXPORT_REPORT_TO_DO_LIST_IN_ASSIGN_PROJECT";
    Role["RoleExportReportTask"] = "ROLE_EXPORT_REPORT_TASK";
    Role["RoleExportReportTaskInAssignProject"] = "ROLE_EXPORT_REPORT_TASK_IN_ASSIGN_PROJECT";
    Role["RoleFilterProjectPhase"] = "ROLE_FILTER_PROJECT_PHASE";
    Role["RoleDeleteComment"] = "ROLE_DELETE_COMMENT";
    Role["RoleUpdateProjectPhase"] = "ROLE_UPDATE_PROJECT_PHASE";
    Role["RoleCreateComment"] = "ROLE_CREATE_COMMENT";
    Role["RoleCreateCommentInAssignProject"] = "ROLE_CREATE_COMMENT_IN_ASSIGN_PROJECT";
    Role["RoleReadProject"] = "ROLE_READ_PROJECT";
    Role["RoleReadAssignProject"] = "ROLE_READ_ASSIGN_PROJECT";
    Role["RoleUpdateProject"] = "ROLE_UPDATE_PROJECT";
    Role["RoleUpdateAssignProject"] = "ROLE_UPDATE_ASSIGN_PROJECT";
    Role["RoleMenuBusinessArea"] = "ROLE_MENU_BUSINESS_AREA";
    Role["RoleReadComment"] = "ROLE_READ_COMMENT";
    Role["RoleReadCommentInAssignProject"] = "ROLE_READ_COMMENT_IN_ASSIGN_PROJECT";
    Role["RoleExportAllFactItem"] = "ROLE_EXPORT_ALL_FACT_ITEM";
    Role["RoleCreateProject"] = "ROLE_CREATE_PROJECT";
    Role["RoleCreateFactItem"] = "ROLE_CREATE_FACT_ITEM";
    Role["RoleCreateFactItemInAssignProject"] = "ROLE_CREATE_FACT_ITEM_IN_ASSIGN_PROJECT";
    Role["RoleReadCodeListItem"] = "ROLE_READ_CODE_LIST_ITEM";
    Role["RoleFilterTask"] = "ROLE_FILTER_TASK";
    Role["RoleDownloadFile"] = "ROLE_DOWNLOAD_FILE";
    Role["RoleReadReports"] = "ROLE_READ_REPORTS";
    Role["RoleDeleteFactItem"] = "ROLE_DELETE_FACT_ITEM";
    Role["RoleFilterVenue"] = "ROLE_FILTER_VENUE";
    Role["RoleCreateAssignUser"] = "ROLE_CREATE_ASSIGN_USER";
    Role["RoleUpdateAssignUser"] = "ROLE_UPDATE_ASSIGN_USER";
    Role["RoleDownloadImage"] = "ROLE_DOWNLOAD_IMAGE";
    Role["RoleCloseProject"] = "ROLE_CLOSE_PROJECT";
    Role["RoleCreateTask"] = "ROLE_CREATE_TASK";
    Role["RoleCreateTaskInAssignProject"] = "ROLE_CREATE_TASK_IN_ASSIGN_PROJECT";
    Role["RoleMenuFactItem"] = "ROLE_MENU_FACT_ITEM";
    Role["RoleReadAssignUser"] = "ROLE_READ_ASSIGN_USER";
    Role["RoleCloseTask"] = "ROLE_CLOSE_TASK";
    Role["RoleCreateProjectPhase"] = "ROLE_CREATE_PROJECT_PHASE";
    Role["RoleFilterFactItem"] = "ROLE_FILTER_FACT_ITEM";
    Role["RoleUploadFile"] = "ROLE_UPLOAD_FILE";
    Role["RoleMenuAllFactItem"] = "ROLE_MENU_ALL_FACT_ITEM";
    Role["RoleUpdateOwnUser"] = "ROLE_UPDATE_OWN_USER";
    Role["RoleReadFactItem"] = "ROLE_READ_FACT_ITEM";
    Role["RoleReadFactItemInAssignProject"] = "ROLE_READ_FACT_ITEM_IN_ASSIGN_PROJECT";
    Role["RoleFilterProject"] = "ROLE_FILTER_PROJECT";
    Role["RoleReadOwnUser"] = "ROLE_READ_OWN_USER";
})(Role || (Role = {}));


/***/ }),

/***/ "./src/app/shared/hazlenut/abstract-inputs/abstract-inputs-config.ts":
/*!***************************************************************************!*\
  !*** ./src/app/shared/hazlenut/abstract-inputs/abstract-inputs-config.ts ***!
  \***************************************************************************/
/*! exports provided: ABSTRACT_INPUT_TOKEN */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ABSTRACT_INPUT_TOKEN", function() { return ABSTRACT_INPUT_TOKEN; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");


var ABSTRACT_INPUT_TOKEN = new _angular_core__WEBPACK_IMPORTED_MODULE_1__["InjectionToken"]('abstractInputConfig');


/***/ }),

/***/ "./src/app/shared/hazlenut/abstract-inputs/abstract-inputs.module.ts":
/*!***************************************************************************!*\
  !*** ./src/app/shared/hazlenut/abstract-inputs/abstract-inputs.module.ts ***!
  \***************************************************************************/
/*! exports provided: AbstractInputsModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AbstractInputsModule", function() { return AbstractInputsModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _hazelnut_common_material_material_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../hazelnut-common/material/material.module */ "./src/app/shared/hazlenut/hazelnut-common/material/material.module.ts");
/* harmony import */ var _abstract_inputs_config__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./abstract-inputs-config */ "./src/app/shared/hazlenut/abstract-inputs/abstract-inputs-config.ts");
/* harmony import */ var _core_input_core_input_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./core-input/core-input.component */ "./src/app/shared/hazlenut/abstract-inputs/core-input/core-input.component.ts");
/* harmony import */ var _input_date_range_input_date_range_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./input-date-range/input-date-range.component */ "./src/app/shared/hazlenut/abstract-inputs/input-date-range/input-date-range.component.ts");
/* harmony import */ var _input_date_input_date_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./input-date/input-date.component */ "./src/app/shared/hazlenut/abstract-inputs/input-date/input-date.component.ts");
/* harmony import */ var _input_number_range_input_number_range_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./input-number-range/input-number-range.component */ "./src/app/shared/hazlenut/abstract-inputs/input-number-range/input-number-range.component.ts");
/* harmony import */ var _input_number_input_number_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./input-number/input-number.component */ "./src/app/shared/hazlenut/abstract-inputs/input-number/input-number.component.ts");











var AbstractInputsModule = /** @class */ (function () {
    function AbstractInputsModule() {
    }
    AbstractInputsModule_1 = AbstractInputsModule;
    AbstractInputsModule.forRoot = function (config) {
        return {
            ngModule: AbstractInputsModule_1,
            providers: [
                { provide: _abstract_inputs_config__WEBPACK_IMPORTED_MODULE_5__["ABSTRACT_INPUT_TOKEN"], useValue: config }
            ]
        };
    };
    var AbstractInputsModule_1;
    AbstractInputsModule = AbstractInputsModule_1 = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["NgModule"])({
            declarations: [
                _core_input_core_input_component__WEBPACK_IMPORTED_MODULE_6__["CoreInputComponent"],
                _input_number_input_number_component__WEBPACK_IMPORTED_MODULE_10__["InputNumberComponent"],
                _input_number_range_input_number_range_component__WEBPACK_IMPORTED_MODULE_9__["InputNumberRangeComponent"],
                _input_date_range_input_date_range_component__WEBPACK_IMPORTED_MODULE_7__["InputDateRangeComponent"],
                _input_date_input_date_component__WEBPACK_IMPORTED_MODULE_8__["InputDateComponent"]
            ],
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"],
                _hazelnut_common_material_material_module__WEBPACK_IMPORTED_MODULE_4__["MaterialModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"],
            ],
            exports: [
                _core_input_core_input_component__WEBPACK_IMPORTED_MODULE_6__["CoreInputComponent"],
                _input_number_input_number_component__WEBPACK_IMPORTED_MODULE_10__["InputNumberComponent"],
                _input_number_range_input_number_range_component__WEBPACK_IMPORTED_MODULE_9__["InputNumberRangeComponent"],
                _input_date_range_input_date_range_component__WEBPACK_IMPORTED_MODULE_7__["InputDateRangeComponent"],
                _input_date_input_date_component__WEBPACK_IMPORTED_MODULE_8__["InputDateComponent"],
            ]
        })
    ], AbstractInputsModule);
    return AbstractInputsModule;
}());



/***/ }),

/***/ "./src/app/shared/hazlenut/abstract-inputs/core-input/core-input.component.scss":
/*!**************************************************************************************!*\
  !*** ./src/app/shared/hazlenut/abstract-inputs/core-input/core-input.component.scss ***!
  \**************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".minimum-height-20 {\n  min-height: 20px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvc2hhcmVkL2hhemxlbnV0L2Fic3RyYWN0LWlucHV0cy9jb3JlLWlucHV0L0Q6XFxwcm9qZWN0c1xcaWloZlxcd2ZtLXdlYi9zcmNcXGFwcFxcc2hhcmVkXFxoYXpsZW51dFxcYWJzdHJhY3QtaW5wdXRzXFxjb3JlLWlucHV0XFxjb3JlLWlucHV0LmNvbXBvbmVudC5zY3NzIiwic3JjL2FwcC9zaGFyZWQvaGF6bGVudXQvYWJzdHJhY3QtaW5wdXRzL2NvcmUtaW5wdXQvY29yZS1pbnB1dC5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLGdCQUFBO0FDQ0oiLCJmaWxlIjoic3JjL2FwcC9zaGFyZWQvaGF6bGVudXQvYWJzdHJhY3QtaW5wdXRzL2NvcmUtaW5wdXQvY29yZS1pbnB1dC5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5taW5pbXVtLWhlaWdodC0yMCB7XHJcbiAgICBtaW4taGVpZ2h0OiAyMHB4O1xyXG59XHJcbiIsIi5taW5pbXVtLWhlaWdodC0yMCB7XG4gIG1pbi1oZWlnaHQ6IDIwcHg7XG59Il19 */");

/***/ }),

/***/ "./src/app/shared/hazlenut/abstract-inputs/core-input/core-input.component.ts":
/*!************************************************************************************!*\
  !*** ./src/app/shared/hazlenut/abstract-inputs/core-input/core-input.component.ts ***!
  \************************************************************************************/
/*! exports provided: CoreInputComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CoreInputComponent", function() { return CoreInputComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm5/operators/index.js");
/* harmony import */ var _utils_removeLastChar__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../utils/removeLastChar */ "./src/app/shared/utils/removeLastChar.ts");
/* harmony import */ var _hazelnut_common_interfaces_translate_interface__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../hazelnut-common/interfaces/translate.interface */ "./src/app/shared/hazlenut/hazelnut-common/interfaces/translate.interface.ts");
/* harmony import */ var _hazelnut_common_utils_input_utils__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../hazelnut-common/utils/input-utils */ "./src/app/shared/hazlenut/hazelnut-common/utils/input-utils.ts");
/* harmony import */ var _validator_composer__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../validator-composer */ "./src/app/shared/hazlenut/abstract-inputs/validator-composer.ts");
/* harmony import */ var _pipes_thousand_delimiter_pipe__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./../../../pipes/thousand-delimiter.pipe */ "./src/app/shared/pipes/thousand-delimiter.pipe.ts");









var CoreInputComponent = /** @class */ (function () {
    function CoreInputComponent(translateWrapperService, changeDetectorRef, validatorComposer) {
        this.translateWrapperService = translateWrapperService;
        this.changeDetectorRef = changeDetectorRef;
        this.validatorComposer = validatorComposer;
        this.useInstantTranslates = false;
        this.required = false;
        this.styles = { width: '100%' };
        this.inputStyles = { width: '100%' };
        this.appearance = 'standard';
        this.type = 'string'; // TODO: Email, Password
        this.handleFocusAndBlur = false;
        this.errors = {};
    }
    CoreInputComponent_1 = CoreInputComponent;
    Object.defineProperty(CoreInputComponent.prototype, "disable", {
        set: function (value) {
            this.setDisabledState(value);
        },
        enumerable: true,
        configurable: true
    });
    CoreInputComponent.prototype.ngOnInit = function () {
        // TODO implement show errors toggle function
        this.showErrors = true;
        this.minLength = this.setAsExactIfNaN(this.minLength);
        this.maxLength = this.setAsExactIfNaN(this.maxLength);
        this.setFormControl();
        this.onFormControlChanges();
        _hazelnut_common_utils_input_utils__WEBPACK_IMPORTED_MODULE_6__["InputUtils"].setDefaultTranslates(this, this.translateWrapperService, this.useInstantTranslates);
        this.pipe = new _pipes_thousand_delimiter_pipe__WEBPACK_IMPORTED_MODULE_8__["ThousandDelimiterPipe"]();
    };
    CoreInputComponent.prototype.ngAfterViewChecked = function () {
        this.changeDetectorRef.detectChanges();
    };
    CoreInputComponent.prototype.onChange = function (value) {
    };
    CoreInputComponent.prototype.onTouched = function (value) {
    };
    CoreInputComponent.prototype.writeValue = function (value) {
        this.formControl.setValue(value || '', { emitEvent: false });
    };
    CoreInputComponent.prototype.registerOnChange = function (fn) {
        this.onChange = fn;
    };
    CoreInputComponent.prototype.registerOnTouched = function (fn) {
        this.onTouched = fn;
    };
    CoreInputComponent.prototype.setDisabledState = function (isDisabled) {
        if (isDisabled) {
            this.formControl.disable();
        }
        else {
            this.formControl.enable();
        }
    };
    CoreInputComponent.prototype.manageUserInput = function () {
        if (!this.formControl.errors) {
            this.displayedError = '';
            this.onChange(this.formControl.value);
            return;
        }
        switch (true) {
            case Boolean(this.formControl.errors.required):
                this.displayedError = this.showErrors ? this.errorRequired : (this.displayedError = '');
                break;
            case Boolean(this.formControl.errors.maxlength):
                this.removeInsertedCharacterAndShowHint(this.formControl, this.hintMaxlength);
                break;
            case Boolean(this.formControl.errors.pattern):
                if (this.formControl.errors.pattern.requiredPattern.includes(this.allowedCharactersPattern)) {
                    this.removeInsertedCharacterAndShowHint(this.formControl, this.hintBadCharacter);
                }
                if (this.formControl && this.formControl.errors && this.formControl.errors.pattern && this.formControl.errors.pattern.requiredPattern.includes(this.pattern)) {
                    this.displayedError = this.showErrors ? this.errorPattern : '';
                }
                break;
            case Boolean(this.formControl.errors.minlength):
                this.displayedError = this.showErrors && this.exactLength ?
                    this.formControl.errors.minlength.actualLength + "/" + this.formControl.errors.minlength.requiredLength :
                    this.errorMinlength + " (" + this.formControl.errors.minlength.requiredLength + ")";
                break;
            default: {
                this.displayedError = '';
                break;
            }
        }
        this.onChange(this.formControl.value);
    };
    CoreInputComponent.prototype.handleFocus = function () {
        if (this.handleFocusAndBlur) {
            this.formControl.setValue(this.formControl.value.replace(/\s/g, ''), { emitEvent: false });
            this.formControl.setValue(this.formControl.value.replace(',', '.'), { emitEvent: false });
        }
    };
    CoreInputComponent.prototype.handleBlur = function () {
        var _this = this;
        var blurTimeout = 250;
        if (this.handleFocusAndBlur) {
            this.formControl.setValue(Object(_utils_removeLastChar__WEBPACK_IMPORTED_MODULE_4__["checkAndRemoveLastDotComma"])(this.formControl.value));
            this.formControl.setValue(this.formControl.value.replace(/\s/g, ''), { emitEvent: false });
            setTimeout(function () {
                _this.formControl.setValue(_this.pipe.transform(_this.formControl.value, ','), { emitEvent: false });
            }, blurTimeout);
        }
    };
    CoreInputComponent.prototype.onFormControlChanges = function () {
        var _this = this;
        var timeoutAfterChange = 2000;
        this.formControl.valueChanges
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["tap"])(function () {
            _this.manageUserInput();
        }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["debounceTime"])(timeoutAfterChange))
            .subscribe(function () {
            _this.displayedHint = '';
        });
    };
    CoreInputComponent.prototype.removeInsertedCharacterAndShowHint = function (abstractControl, hint) {
        if (this.maxLength && abstractControl.value.length >= this.maxLength) {
            abstractControl.setValue(abstractControl.value.substring(0, this.maxLength));
        }
        else {
            abstractControl.setValue(abstractControl.value.slice(0, -1));
        }
        this.displayedHint = hint;
    };
    CoreInputComponent.prototype.toggleShowErrors = function (focused) {
        this.showErrors = focused;
        this.manageUserInput();
    };
    CoreInputComponent.prototype.setAsExactIfNaN = function (value) {
        if (isNaN(value)) {
            value = this.exactLength;
        }
        return value;
    };
    CoreInputComponent.prototype.setFormControl = function () {
        var validators = _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].compose(this.validatorComposer.addValidators(this.required, this.minLength, this.maxLength, this.pattern, this.allowedCharactersPattern));
        this.formControl = new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"]('', {
            validators: validators
        });
    };
    var CoreInputComponent_1;
    CoreInputComponent.ctorParameters = function () { return [
        { type: undefined, decorators: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["Inject"], args: [_hazelnut_common_interfaces_translate_interface__WEBPACK_IMPORTED_MODULE_5__["TRANSLATE_WRAPPER_TOKEN"],] }] },
        { type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["ChangeDetectorRef"] },
        { type: _validator_composer__WEBPACK_IMPORTED_MODULE_7__["ValidatorComposer"] }
    ]; };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", String)
    ], CoreInputComponent.prototype, "label", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", String)
    ], CoreInputComponent.prototype, "placeholder", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], CoreInputComponent.prototype, "useInstantTranslates", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], CoreInputComponent.prototype, "required", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Number)
    ], CoreInputComponent.prototype, "minLength", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Number)
    ], CoreInputComponent.prototype, "maxLength", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Number)
    ], CoreInputComponent.prototype, "exactLength", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", String)
    ], CoreInputComponent.prototype, "allowedCharactersPattern", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", String)
    ], CoreInputComponent.prototype, "pattern", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", String)
    ], CoreInputComponent.prototype, "textSuffix", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], CoreInputComponent.prototype, "styles", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], CoreInputComponent.prototype, "inputStyles", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", String)
    ], CoreInputComponent.prototype, "appearance", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", String)
    ], CoreInputComponent.prototype, "type", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], CoreInputComponent.prototype, "errorRequired", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], CoreInputComponent.prototype, "errorMinlength", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], CoreInputComponent.prototype, "errorPattern", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], CoreInputComponent.prototype, "hintMaxlength", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], CoreInputComponent.prototype, "hintBadCharacter", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], CoreInputComponent.prototype, "handleFocusAndBlur", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])('disabled'),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Boolean),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [Boolean])
    ], CoreInputComponent.prototype, "disable", null);
    CoreInputComponent = CoreInputComponent_1 = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'haz-core-input',
            template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./core-input.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/shared/hazlenut/abstract-inputs/core-input/core-input.component.html")).default,
            providers: [
                {
                    provide: _angular_forms__WEBPACK_IMPORTED_MODULE_2__["NG_VALUE_ACCESSOR"],
                    useExisting: Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["forwardRef"])(function () { return CoreInputComponent_1; }),
                    multi: true
                }
            ],
            styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./core-input.component.scss */ "./src/app/shared/hazlenut/abstract-inputs/core-input/core-input.component.scss")).default]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__param"](0, Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Inject"])(_hazelnut_common_interfaces_translate_interface__WEBPACK_IMPORTED_MODULE_5__["TRANSLATE_WRAPPER_TOKEN"])),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [Object, _angular_core__WEBPACK_IMPORTED_MODULE_1__["ChangeDetectorRef"],
            _validator_composer__WEBPACK_IMPORTED_MODULE_7__["ValidatorComposer"]])
    ], CoreInputComponent);
    return CoreInputComponent;
}());



/***/ }),

/***/ "./src/app/shared/hazlenut/abstract-inputs/input-date-range/input-date-range.component.scss":
/*!**************************************************************************************************!*\
  !*** ./src/app/shared/hazlenut/abstract-inputs/input-date-range/input-date-range.component.scss ***!
  \**************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".error-message {\n  font-size: 12px;\n  margin-top: -14px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvc2hhcmVkL2hhemxlbnV0L2Fic3RyYWN0LWlucHV0cy9pbnB1dC1kYXRlLXJhbmdlL0Q6XFxwcm9qZWN0c1xcaWloZlxcd2ZtLXdlYi9zcmNcXGFwcFxcc2hhcmVkXFxoYXpsZW51dFxcYWJzdHJhY3QtaW5wdXRzXFxpbnB1dC1kYXRlLXJhbmdlXFxpbnB1dC1kYXRlLXJhbmdlLmNvbXBvbmVudC5zY3NzIiwic3JjL2FwcC9zaGFyZWQvaGF6bGVudXQvYWJzdHJhY3QtaW5wdXRzL2lucHV0LWRhdGUtcmFuZ2UvaW5wdXQtZGF0ZS1yYW5nZS5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLGVBQUE7RUFDQSxpQkFBQTtBQ0NKIiwiZmlsZSI6InNyYy9hcHAvc2hhcmVkL2hhemxlbnV0L2Fic3RyYWN0LWlucHV0cy9pbnB1dC1kYXRlLXJhbmdlL2lucHV0LWRhdGUtcmFuZ2UuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuZXJyb3ItbWVzc2FnZSB7XHJcbiAgICBmb250LXNpemU6IDEycHg7XHJcbiAgICBtYXJnaW4tdG9wOiAtMTRweDtcclxufVxyXG4iLCIuZXJyb3ItbWVzc2FnZSB7XG4gIGZvbnQtc2l6ZTogMTJweDtcbiAgbWFyZ2luLXRvcDogLTE0cHg7XG59Il19 */");

/***/ }),

/***/ "./src/app/shared/hazlenut/abstract-inputs/input-date-range/input-date-range.component.ts":
/*!************************************************************************************************!*\
  !*** ./src/app/shared/hazlenut/abstract-inputs/input-date-range/input-date-range.component.ts ***!
  \************************************************************************************************/
/*! exports provided: InputDateRangeComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "InputDateRangeComponent", function() { return InputDateRangeComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_material__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/material */ "./node_modules/@angular/material/esm5/material.es5.js");
/* harmony import */ var _angular_material_moment_adapter__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/material-moment-adapter */ "./node_modules/@angular/material-moment-adapter/esm5/material-moment-adapter.es5.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm5/index.js");
/* harmony import */ var _hazelnut_common_hazelnut_utils_string_utils__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../hazelnut-common/hazelnut/utils/string.utils */ "./src/app/shared/hazlenut/hazelnut-common/hazelnut/utils/string.utils.ts");
/* harmony import */ var _hazelnut_common_interfaces_translate_interface__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../hazelnut-common/interfaces/translate.interface */ "./src/app/shared/hazlenut/hazelnut-common/interfaces/translate.interface.ts");
/* harmony import */ var _hazelnut_common_regex_regex__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../hazelnut-common/regex/regex */ "./src/app/shared/hazlenut/hazelnut-common/regex/regex.ts");
/* harmony import */ var _hazelnut_common_utils_input_utils__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../hazelnut-common/utils/input-utils */ "./src/app/shared/hazlenut/hazelnut-common/utils/input-utils.ts");










var DATE_FORMAT = 'DD.MM.YYYY';
var InputDateRangeComponent = /** @class */ (function () {
    function InputDateRangeComponent(cdRef, formBuilder, translateWrapperService) {
        this.cdRef = cdRef;
        this.formBuilder = formBuilder;
        this.translateWrapperService = translateWrapperService;
        this.type = 'dateTime'; // TODO: create enum
        this.errorMessageMinmax = '';
        this.minmaxError = true;
        this.errorInterval = this.translateWrapperService.instant('error.interval');
        this.columnErrorMessage = '';
        this.tooltipMessage = this.errorMessageMinmax;
    }
    InputDateRangeComponent_1 = InputDateRangeComponent;
    Object.defineProperty(InputDateRangeComponent.prototype, "fromFormControl", {
        get: function () {
            return this.dateRangeForm.get('from');
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(InputDateRangeComponent.prototype, "toFormControl", {
        get: function () {
            return this.dateRangeForm.get('to');
        },
        enumerable: true,
        configurable: true
    });
    InputDateRangeComponent.areDateEquals = function (currentDate, newDate) {
        if (currentDate === newDate) {
            return true;
        }
        if (!currentDate || !newDate) {
            return false;
        }
        if (currentDate.dateTo === newDate.dateTo && currentDate.dateFrom === newDate.dateFrom) {
            return true;
        }
        return (currentDate.dateTo && currentDate.dateTo._d) ===
            (newDate.dateTo && newDate.dateTo._d) &&
            (currentDate.dateFrom && currentDate.dateFrom._d) ===
                (newDate.dateFrom && newDate.dateFrom._d);
    };
    InputDateRangeComponent.prototype.ngOnInit = function () {
        this.setLabels();
        this.dateRangeForm = this.createForm();
        this.onFormGroupChanges(this.dateRangeForm);
        this.onFormControlChanges(this.fromFormControl);
        this.onFormControlChanges(this.toFormControl);
    };
    InputDateRangeComponent.prototype.onChange = function (value) {
    };
    InputDateRangeComponent.prototype.onTouched = function (value) {
    };
    InputDateRangeComponent.prototype.registerOnChange = function (method) {
        this.onChange = method;
    };
    InputDateRangeComponent.prototype.registerOnTouched = function (method) {
        this.onTouched = method;
    };
    InputDateRangeComponent.prototype.ngAfterViewChecked = function () {
        this.cdRef.detectChanges();
    };
    InputDateRangeComponent.prototype.writeValue = function (value) {
        if (!value) {
            return this.writeValue({
                dateFrom: null,
                dateTo: null
            });
        }
        this.toFormControl.setValue(value.dateTo, { emitEvent: false });
        this.fromFormControl.setValue(value.dateFrom, { emitEvent: false });
        this.cdRef.detectChanges();
    };
    InputDateRangeComponent.prototype.transformToDate = function (object) {
        return object ? new Date(object) : null;
    };
    InputDateRangeComponent.prototype.minMaxValidator = function (formGroup) {
        var fromFormControl = formGroup.get('from');
        var toFormControl = formGroup.get('to');
        this.minmaxError = fromFormControl.value && toFormControl.value && (Number(fromFormControl.value) > Number(toFormControl.value));
        return fromFormControl.value && toFormControl.value && (Number(fromFormControl.value) > Number(toFormControl.value)) ? { minmax: true } : null;
    };
    InputDateRangeComponent.prototype.createForm = function () {
        return this
            .formBuilder.group({
            from: [
                null,
                {
                    validators: _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].compose([
                        _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required
                    ])
                }
            ],
            to: [
                null,
                {
                    validators: _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].compose([
                        _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required
                    ])
                }
            ]
        }, { validator: this.minMaxValidator });
    };
    InputDateRangeComponent.prototype.onFormGroupChanges = function (formGroup) {
        var _this = this;
        formGroup.valueChanges.subscribe(function () {
            if (!_this.momentDateIsValid(_this.fromFormControl) || !_this.momentDateIsValid(_this.toFormControl)) {
                return;
            }
            if (!_this.momentDateIsValid(_this.fromFormControl) || !_this.momentDateIsValid(_this.toFormControl)) {
                return;
            }
            var newValue = {
                dateFrom: !_this.momentDateIsFullDate(_this.fromFormControl) ?
                    null :
                    (_this.fromFormControl.value.startOf('day')
                        .format()),
                dateTo: !_this.momentDateIsFullDate(_this.toFormControl) ?
                    null :
                    (_this.toFormControl.value.endOf('day')
                        .format())
            };
            _this.onChange(newValue);
        });
    };
    InputDateRangeComponent.prototype.onFormControlChanges = function (formControl) {
        var _this = this;
        formControl.valueChanges.subscribe(function () {
            _this.manageUserInput(_this.dateRangeForm);
        });
    };
    InputDateRangeComponent.prototype.momentDateIsValid = function (formControl) {
        if (!formControl.value || !formControl.value._i) {
            return true;
        }
        return (typeof formControl.value._i === 'string') ?
            RegExp(_hazelnut_common_regex_regex__WEBPACK_IMPORTED_MODULE_8__["Regex"].dateDotPattern)
                .test(formControl.value._i) :
            RegExp(_hazelnut_common_regex_regex__WEBPACK_IMPORTED_MODULE_8__["Regex"].dateDotPattern)
                .test(_hazelnut_common_hazelnut_utils_string_utils__WEBPACK_IMPORTED_MODULE_6__["StringUtils"].convertDateStringToDotString(formControl.value._d));
    };
    InputDateRangeComponent.prototype.momentDateIsFullDate = function (formControl) {
        if (!formControl.value || !formControl.value._i) {
            return false;
        }
        return (typeof formControl.value._i === 'string') ?
            RegExp(_hazelnut_common_regex_regex__WEBPACK_IMPORTED_MODULE_8__["Regex"].dateDotPattern)
                .test(formControl.value._i) :
            RegExp(_hazelnut_common_regex_regex__WEBPACK_IMPORTED_MODULE_8__["Regex"].dateDotPattern)
                .test(_hazelnut_common_hazelnut_utils_string_utils__WEBPACK_IMPORTED_MODULE_6__["StringUtils"].convertDateStringToDotString(formControl.value._d));
    };
    InputDateRangeComponent.prototype.manageUserInput = function (formGroup) {
        if (!formGroup.errors) {
            this.showColumnErrorMessage = false;
            this.errorMessage = '';
        }
        if (formGroup.errors && formGroup.errors.minmax) {
            this.showColumnErrorMessage = true;
            this.errorMessage = _hazelnut_common_hazelnut_utils_string_utils__WEBPACK_IMPORTED_MODULE_6__["StringUtils"].format(this.errorMessageMinmax, {
                from: 'Od',
                to: 'Do'
            });
        }
    };
    InputDateRangeComponent.prototype.setLabels = function () {
        _hazelnut_common_utils_input_utils__WEBPACK_IMPORTED_MODULE_9__["InputUtils"].setFromToTranslates(this, this.translateWrapperService);
    };
    var InputDateRangeComponent_1;
    InputDateRangeComponent.ctorParameters = function () { return [
        { type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["ChangeDetectorRef"] },
        { type: _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormBuilder"] },
        { type: undefined, decorators: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["Inject"], args: [_hazelnut_common_interfaces_translate_interface__WEBPACK_IMPORTED_MODULE_7__["TRANSLATE_WRAPPER_TOKEN"],] }] }
    ]; };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", rxjs__WEBPACK_IMPORTED_MODULE_5__["Observable"])
    ], InputDateRangeComponent.prototype, "fromLabel", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", rxjs__WEBPACK_IMPORTED_MODULE_5__["Observable"])
    ], InputDateRangeComponent.prototype, "toLabel", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", String)
    ], InputDateRangeComponent.prototype, "type", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], InputDateRangeComponent.prototype, "dateWidth", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], InputDateRangeComponent.prototype, "errorMessageMinmax", void 0);
    InputDateRangeComponent = InputDateRangeComponent_1 = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'haz-input-date-range',
            template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./input-date-range.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/shared/hazlenut/abstract-inputs/input-date-range/input-date-range.component.html")).default,
            providers: [
                {
                    provide: _angular_forms__WEBPACK_IMPORTED_MODULE_2__["NG_VALUE_ACCESSOR"],
                    useExisting: Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["forwardRef"])(function () { return InputDateRangeComponent_1; }),
                    multi: true
                },
                {
                    provide: _angular_material__WEBPACK_IMPORTED_MODULE_3__["DateAdapter"],
                    useClass: _angular_material_moment_adapter__WEBPACK_IMPORTED_MODULE_4__["MomentDateAdapter"],
                    deps: [_angular_material__WEBPACK_IMPORTED_MODULE_3__["MAT_DATE_LOCALE"]]
                },
            ],
            styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./input-date-range.component.scss */ "./src/app/shared/hazlenut/abstract-inputs/input-date-range/input-date-range.component.scss")).default]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__param"](2, Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Inject"])(_hazelnut_common_interfaces_translate_interface__WEBPACK_IMPORTED_MODULE_7__["TRANSLATE_WRAPPER_TOKEN"])),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ChangeDetectorRef"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormBuilder"], Object])
    ], InputDateRangeComponent);
    return InputDateRangeComponent;
}());



/***/ }),

/***/ "./src/app/shared/hazlenut/abstract-inputs/input-date/input-date.component.scss":
/*!**************************************************************************************!*\
  !*** ./src/app/shared/hazlenut/abstract-inputs/input-date/input-date.component.scss ***!
  \**************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3NoYXJlZC9oYXpsZW51dC9hYnN0cmFjdC1pbnB1dHMvaW5wdXQtZGF0ZS9pbnB1dC1kYXRlLmNvbXBvbmVudC5zY3NzIn0= */");

/***/ }),

/***/ "./src/app/shared/hazlenut/abstract-inputs/input-date/input-date.component.ts":
/*!************************************************************************************!*\
  !*** ./src/app/shared/hazlenut/abstract-inputs/input-date/input-date.component.ts ***!
  \************************************************************************************/
/*! exports provided: FORMAT, InputDateComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FORMAT", function() { return FORMAT; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "InputDateComponent", function() { return InputDateComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_material__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/material */ "./node_modules/@angular/material/esm5/material.es5.js");
/* harmony import */ var _angular_material_moment_adapter__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/material-moment-adapter */ "./node_modules/@angular/material-moment-adapter/esm5/material-moment-adapter.es5.js");
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! moment */ "./node_modules/moment/moment.js");
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm5/operators/index.js");







var moment = moment__WEBPACK_IMPORTED_MODULE_5__;
var FORMAT = {
    parse: {
        dateInput: 'D.M.YYYY',
    },
    display: {
        dateInput: 'D.M.YYYY',
        monthYearLabel: 'D.M.YYYY',
        dateA11yLabel: 'D.M.YYYY',
        monthYearA11yLabel: 'D.M.YYYY',
    },
};
var InputDateComponent = /** @class */ (function () {
    function InputDateComponent() {
        this.dateWidth = 100;
        this.formControl = new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"]();
        this.dateClass = function (date) {
            var dayInWeekMinusOne = 6;
            var day = moment(date)
                .toDate()
                .getDay();
            return (day === 0 || day === dayInWeekMinusOne) ? 'custom-date-class' : undefined;
        };
    }
    InputDateComponent_1 = InputDateComponent;
    InputDateComponent.prototype.ngOnInit = function () {
        this.onFormControlChanges();
    };
    InputDateComponent.prototype.setDisabledState = function (isDisabled) {
        if (isDisabled) {
            this.formControl.disable();
        }
        else {
            this.formControl.enable();
        }
    };
    InputDateComponent.prototype.onChange = function (value) {
    };
    InputDateComponent.prototype.onTouched = function (value) {
    };
    InputDateComponent.prototype.writeValue = function (value) {
        this.formControl.setValue(value || '', { emitEvent: false });
    };
    InputDateComponent.prototype.registerOnChange = function (fn) {
        this.onChange = fn;
    };
    InputDateComponent.prototype.registerOnTouched = function (fn) {
        this.onTouched = fn;
    };
    InputDateComponent.prototype.onFormControlChanges = function () {
        var _this = this;
        this.formControl.valueChanges.pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_6__["filter"])(function (newValue) { return newValue !== _this.lastValue; }))
            .subscribe(function (newValue) {
            _this.lastValue = newValue;
            _this.onChange(_this.formControl.value);
        });
    };
    var InputDateComponent_1;
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", String)
    ], InputDateComponent.prototype, "placeholder", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], InputDateComponent.prototype, "dateWidth", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Date)
    ], InputDateComponent.prototype, "min", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Date)
    ], InputDateComponent.prototype, "max", void 0);
    InputDateComponent = InputDateComponent_1 = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'haz-input-date',
            template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./input-date.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/shared/hazlenut/abstract-inputs/input-date/input-date.component.html")).default,
            providers: [
                {
                    provide: _angular_material__WEBPACK_IMPORTED_MODULE_3__["DateAdapter"],
                    useClass: _angular_material_moment_adapter__WEBPACK_IMPORTED_MODULE_4__["MomentDateAdapter"],
                    deps: [_angular_material__WEBPACK_IMPORTED_MODULE_3__["MAT_DATE_LOCALE"]]
                },
                {
                    provide: _angular_material__WEBPACK_IMPORTED_MODULE_3__["MAT_DATE_FORMATS"],
                    useValue: FORMAT
                },
                {
                    provide: _angular_forms__WEBPACK_IMPORTED_MODULE_2__["NG_VALUE_ACCESSOR"],
                    useExisting: Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["forwardRef"])(function () { return InputDateComponent_1; }),
                    multi: true
                },
            ],
            styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./input-date.component.scss */ "./src/app/shared/hazlenut/abstract-inputs/input-date/input-date.component.scss")).default]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
    ], InputDateComponent);
    return InputDateComponent;
}());



/***/ }),

/***/ "./src/app/shared/hazlenut/abstract-inputs/input-number-range/input-number-range.component.scss":
/*!******************************************************************************************************!*\
  !*** ./src/app/shared/hazlenut/abstract-inputs/input-number-range/input-number-range.component.scss ***!
  \******************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".error-message {\n  font-size: 12px;\n  margin-top: -14px;\n}\n\n.flex-end-row {\n  display: flex;\n  flex-direction: row;\n  justify-content: flex-end;\n}\n\n.flex-end-column {\n  display: flex;\n  flex-direction: column;\n  justify-content: flex-end;\n}\n\n::ng-deep .red-error .mat-form-field-flex {\n  border-bottom: 1.5px solid #d60000;\n}\n\n::ng-deep .red-error .mat-focused .mat-form-field-underline .mat-form-field-ripple {\n  background: #d60000;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvc2hhcmVkL2hhemxlbnV0L2Fic3RyYWN0LWlucHV0cy9pbnB1dC1udW1iZXItcmFuZ2UvRDpcXHByb2plY3RzXFxpaWhmXFx3Zm0td2ViL3NyY1xcYXBwXFxzaGFyZWRcXGhhemxlbnV0XFxhYnN0cmFjdC1pbnB1dHNcXGlucHV0LW51bWJlci1yYW5nZVxcaW5wdXQtbnVtYmVyLXJhbmdlLmNvbXBvbmVudC5zY3NzIiwic3JjL2FwcC9zaGFyZWQvaGF6bGVudXQvYWJzdHJhY3QtaW5wdXRzL2lucHV0LW51bWJlci1yYW5nZS9pbnB1dC1udW1iZXItcmFuZ2UuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxlQUFBO0VBQ0EsaUJBQUE7QUNDSjs7QURFQTtFQUNJLGFBQUE7RUFDQSxtQkFBQTtFQUNBLHlCQUFBO0FDQ0o7O0FERUE7RUFDSSxhQUFBO0VBQ0Esc0JBQUE7RUFDQSx5QkFBQTtBQ0NKOztBREdJO0VBQ0ksa0NBQUE7QUNBUjs7QURFSTtFQUNJLG1CQUFBO0FDQVIiLCJmaWxlIjoic3JjL2FwcC9zaGFyZWQvaGF6bGVudXQvYWJzdHJhY3QtaW5wdXRzL2lucHV0LW51bWJlci1yYW5nZS9pbnB1dC1udW1iZXItcmFuZ2UuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuZXJyb3ItbWVzc2FnZSB7XHJcbiAgICBmb250LXNpemU6IDEycHg7XHJcbiAgICBtYXJnaW4tdG9wOiAtMTRweDtcclxufVxyXG5cclxuLmZsZXgtZW5kLXJvdyB7XHJcbiAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgZmxleC1kaXJlY3Rpb246IHJvdztcclxuICAgIGp1c3RpZnktY29udGVudDogZmxleC1lbmQ7XHJcbn1cclxuXHJcbi5mbGV4LWVuZC1jb2x1bW4ge1xyXG4gICAgZGlzcGxheTogZmxleDtcclxuICAgIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XHJcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IGZsZXgtZW5kO1xyXG59XHJcblxyXG46Om5nLWRlZXAge1xyXG4gICAgLnJlZC1lcnJvciAubWF0LWZvcm0tZmllbGQtZmxleCB7XHJcbiAgICAgICAgYm9yZGVyLWJvdHRvbTogMS41cHggc29saWQgI2Q2MDAwMDtcclxuICAgIH0gICBcclxuICAgIC5yZWQtZXJyb3IgLm1hdC1mb2N1c2VkIC5tYXQtZm9ybS1maWVsZC11bmRlcmxpbmUgLm1hdC1mb3JtLWZpZWxkLXJpcHBsZXtcclxuICAgICAgICBiYWNrZ3JvdW5kOiAjZDYwMDAwO1xyXG4gICAgfVxyXG59XHJcbiIsIi5lcnJvci1tZXNzYWdlIHtcbiAgZm9udC1zaXplOiAxMnB4O1xuICBtYXJnaW4tdG9wOiAtMTRweDtcbn1cblxuLmZsZXgtZW5kLXJvdyB7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGZsZXgtZGlyZWN0aW9uOiByb3c7XG4gIGp1c3RpZnktY29udGVudDogZmxleC1lbmQ7XG59XG5cbi5mbGV4LWVuZC1jb2x1bW4ge1xuICBkaXNwbGF5OiBmbGV4O1xuICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xuICBqdXN0aWZ5LWNvbnRlbnQ6IGZsZXgtZW5kO1xufVxuXG46Om5nLWRlZXAgLnJlZC1lcnJvciAubWF0LWZvcm0tZmllbGQtZmxleCB7XG4gIGJvcmRlci1ib3R0b206IDEuNXB4IHNvbGlkICNkNjAwMDA7XG59XG46Om5nLWRlZXAgLnJlZC1lcnJvciAubWF0LWZvY3VzZWQgLm1hdC1mb3JtLWZpZWxkLXVuZGVybGluZSAubWF0LWZvcm0tZmllbGQtcmlwcGxlIHtcbiAgYmFja2dyb3VuZDogI2Q2MDAwMDtcbn0iXX0= */");

/***/ }),

/***/ "./src/app/shared/hazlenut/abstract-inputs/input-number-range/input-number-range.component.ts":
/*!****************************************************************************************************!*\
  !*** ./src/app/shared/hazlenut/abstract-inputs/input-number-range/input-number-range.component.ts ***!
  \****************************************************************************************************/
/*! exports provided: InputNumberRangeComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "InputNumberRangeComponent", function() { return InputNumberRangeComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm5/index.js");
/* harmony import */ var _hazelnut_common_hazelnut__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../..//hazelnut-common/hazelnut */ "./src/app/shared/hazlenut/hazelnut-common/hazelnut/index.ts");
/* harmony import */ var _hazelnut_common_utils_input_utils__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../..//hazelnut-common/utils/input-utils */ "./src/app/shared/hazlenut/hazelnut-common/utils/input-utils.ts");
/* harmony import */ var _hazelnut_common_enums_number_type_enum__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../hazelnut-common/enums/number-type.enum */ "./src/app/shared/hazlenut/hazelnut-common/enums/number-type.enum.ts");
/* harmony import */ var _hazelnut_common_interfaces_translate_interface__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../hazelnut-common/interfaces/translate.interface */ "./src/app/shared/hazlenut/hazelnut-common/interfaces/translate.interface.ts");








var InputNumberRangeComponent = /** @class */ (function () {
    function InputNumberRangeComponent(translateWrapperService) {
        this.translateWrapperService = translateWrapperService;
        this.min = NaN;
        this.max = NaN;
        this.type = _hazelnut_common_enums_number_type_enum__WEBPACK_IMPORTED_MODULE_6__["NumberType"].FLOAT;
        this.inputStyles = { width: '30px' };
        this.styles = {};
        this.useInstantTranslates = false;
        this.inputSize = 165;
        this.pattern = _hazelnut_common_hazelnut__WEBPACK_IMPORTED_MODULE_4__["Regexp"].numericCharactersPattern;
        this.fromControl = new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"]();
        this.toControl = new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"]();
        this.actualError = '';
        this.errorInterval = this.translateWrapperService.instant('error.interval');
        this._disabled = false;
    }
    InputNumberRangeComponent_1 = InputNumberRangeComponent;
    Object.defineProperty(InputNumberRangeComponent.prototype, "disabled", {
        get: function () {
            return this._disabled;
        },
        set: function (value) {
            this._disabled = value;
            if (value) {
                this.fromControl.disable();
                this.toControl.disable();
            }
            else {
                this.fromControl.enable();
                this.toControl.enable();
            }
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(InputNumberRangeComponent.prototype, "realStyles", {
        get: function () {
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__assign"]({}, this.styles, { width: '60px' });
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(InputNumberRangeComponent.prototype, "value", {
        get: function () {
            return {
                from: this.fromControl.value,
                to: this.toControl.value,
            };
        },
        enumerable: true,
        configurable: true
    });
    InputNumberRangeComponent.prototype.onChange = function (value) {
    };
    InputNumberRangeComponent.prototype.onTouched = function (value) {
    };
    InputNumberRangeComponent.prototype.registerOnChange = function (method) {
        this.onChange = method;
    };
    InputNumberRangeComponent.prototype.registerOnTouched = function (method) {
        this.onTouched = method;
    };
    InputNumberRangeComponent.prototype.ngOnInit = function () {
        var _this = this;
        _hazelnut_common_utils_input_utils__WEBPACK_IMPORTED_MODULE_5__["InputUtils"].setFromToTranslates(this, this.translateWrapperService);
        Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["merge"])(this.toControl.valueChanges, this.fromControl.valueChanges)
            .subscribe(function () {
            _this.onChange(_this.value);
            if (_this.value.from && _this.value.to && _this.toDotFormat(_this.value.from) > _this.toDotFormat(_this.value.to)) {
                _this.actualError = 'minmax';
            }
            else {
                _this.actualError = '';
            }
        });
    };
    InputNumberRangeComponent.prototype.setDisabledState = function (isDisabled) {
        this.disabled = isDisabled;
    };
    InputNumberRangeComponent.prototype.writeValue = function (obj) {
        if (!obj) {
            return this.writeValue({
                from: '',
                to: ''
            });
        }
        this._setFrom(obj.from);
        this._setTo(obj.to);
    };
    InputNumberRangeComponent.prototype._setFrom = function (value, emitEvent) {
        if (emitEvent === void 0) { emitEvent = false; }
        if (isNaN(parseFloat(value))) {
            this.actualError = '';
        }
        this.fromControl.setValue(_hazelnut_common_hazelnut__WEBPACK_IMPORTED_MODULE_4__["MathUtils"].validateValue({
            value: value,
            type: this.type
        }), { emitEvent: emitEvent });
    };
    InputNumberRangeComponent.prototype._setTo = function (value, emitEvent) {
        if (emitEvent === void 0) { emitEvent = false; }
        if (isNaN(parseFloat(value))) {
            this.actualError = '';
        }
        this.toControl.setValue(_hazelnut_common_hazelnut__WEBPACK_IMPORTED_MODULE_4__["MathUtils"].validateValue({
            value: value,
            type: this.type
        }), { emitEvent: emitEvent });
    };
    InputNumberRangeComponent.prototype.toDotFormat = function (value) {
        return Number(String(value)
            .replace(',', '.'));
    };
    var InputNumberRangeComponent_1;
    InputNumberRangeComponent.ctorParameters = function () { return [
        { type: undefined, decorators: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["Inject"], args: [_hazelnut_common_interfaces_translate_interface__WEBPACK_IMPORTED_MODULE_7__["TRANSLATE_WRAPPER_TOKEN"],] }] }
    ]; };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], InputNumberRangeComponent.prototype, "min", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], InputNumberRangeComponent.prototype, "max", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], InputNumberRangeComponent.prototype, "type", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], InputNumberRangeComponent.prototype, "inputStyles", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], InputNumberRangeComponent.prototype, "styles", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"])
    ], InputNumberRangeComponent.prototype, "customInput", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", rxjs__WEBPACK_IMPORTED_MODULE_3__["Observable"])
    ], InputNumberRangeComponent.prototype, "fromLabel", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", rxjs__WEBPACK_IMPORTED_MODULE_3__["Observable"])
    ], InputNumberRangeComponent.prototype, "toLabel", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], InputNumberRangeComponent.prototype, "useInstantTranslates", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], InputNumberRangeComponent.prototype, "inputSize", void 0);
    InputNumberRangeComponent = InputNumberRangeComponent_1 = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'haz-input-number-range',
            template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./input-number-range.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/shared/hazlenut/abstract-inputs/input-number-range/input-number-range.component.html")).default,
            providers: [
                {
                    provide: _angular_forms__WEBPACK_IMPORTED_MODULE_2__["NG_VALUE_ACCESSOR"],
                    useExisting: Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["forwardRef"])(function () { return InputNumberRangeComponent_1; }),
                    multi: true
                }
            ],
            styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./input-number-range.component.scss */ "./src/app/shared/hazlenut/abstract-inputs/input-number-range/input-number-range.component.scss")).default]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__param"](0, Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Inject"])(_hazelnut_common_interfaces_translate_interface__WEBPACK_IMPORTED_MODULE_7__["TRANSLATE_WRAPPER_TOKEN"])),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [Object])
    ], InputNumberRangeComponent);
    return InputNumberRangeComponent;
}());



/***/ }),

/***/ "./src/app/shared/hazlenut/abstract-inputs/input-number/input-number.component.scss":
/*!******************************************************************************************!*\
  !*** ./src/app/shared/hazlenut/abstract-inputs/input-number/input-number.component.scss ***!
  \******************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3NoYXJlZC9oYXpsZW51dC9hYnN0cmFjdC1pbnB1dHMvaW5wdXQtbnVtYmVyL2lucHV0LW51bWJlci5jb21wb25lbnQuc2NzcyJ9 */");

/***/ }),

/***/ "./src/app/shared/hazlenut/abstract-inputs/input-number/input-number.component.ts":
/*!****************************************************************************************!*\
  !*** ./src/app/shared/hazlenut/abstract-inputs/input-number/input-number.component.ts ***!
  \****************************************************************************************/
/*! exports provided: InputNumberComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "InputNumberComponent", function() { return InputNumberComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm5/index.js");
/* harmony import */ var _hazelnut_common_hazelnut__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../..//hazelnut-common/hazelnut */ "./src/app/shared/hazlenut/hazelnut-common/hazelnut/index.ts");
/* harmony import */ var _hazelnut_common_enums_number_type_enum__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../hazelnut-common/enums/number-type.enum */ "./src/app/shared/hazlenut/hazelnut-common/enums/number-type.enum.ts");






var InputNumberComponent = /** @class */ (function () {
    function InputNumberComponent() {
        this.type = _hazelnut_common_enums_number_type_enum__WEBPACK_IMPORTED_MODULE_5__["NumberType"].FLOAT;
        this.control = new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"](0);
    }
    InputNumberComponent_1 = InputNumberComponent;
    Object.defineProperty(InputNumberComponent.prototype, "disabled", {
        get: function () {
            return this.control.disabled;
        },
        set: function (value) {
            if (value) {
                this.control.disable();
            }
            else {
                this.control.enable();
            }
        },
        enumerable: true,
        configurable: true
    });
    InputNumberComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.control.valueChanges.subscribe(function (value) {
            // if number is not valid number
            if (value && (!value.match(/^-?\d+$/))) {
                _this.control.setValue(_this.lastValue);
                return;
            }
            _this.lastValue = value;
            _this.onChange(value);
        });
    };
    InputNumberComponent.prototype.onChange = function (value) {
    };
    InputNumberComponent.prototype.onTouched = function (value) {
    };
    InputNumberComponent.prototype.registerOnChange = function (method) {
        this.onChange = method;
    };
    InputNumberComponent.prototype.registerOnTouched = function (method) {
        this.onTouched = method;
    };
    InputNumberComponent.prototype.setDisabledState = function (isDisabled) {
        this.disabled = isDisabled;
    };
    InputNumberComponent.prototype.writeValue = function (value) {
        this.control.setValue(_hazelnut_common_hazelnut__WEBPACK_IMPORTED_MODULE_4__["MathUtils"].validateValue({ value: value, type: this.type }), { emitEvent: false });
    };
    var InputNumberComponent_1;
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], InputNumberComponent.prototype, "type", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"])
    ], InputNumberComponent.prototype, "customInput", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", rxjs__WEBPACK_IMPORTED_MODULE_3__["Observable"])
    ], InputNumberComponent.prototype, "label", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", String)
    ], InputNumberComponent.prototype, "placeholder", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], InputNumberComponent.prototype, "styles", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], InputNumberComponent.prototype, "inputStyles", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], InputNumberComponent.prototype, "labelStyles", void 0);
    InputNumberComponent = InputNumberComponent_1 = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'haz-input-number',
            template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./input-number.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/shared/hazlenut/abstract-inputs/input-number/input-number.component.html")).default,
            providers: [
                {
                    provide: _angular_forms__WEBPACK_IMPORTED_MODULE_2__["NG_VALUE_ACCESSOR"],
                    useExisting: Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["forwardRef"])(function () { return InputNumberComponent_1; }),
                    multi: true
                }
            ],
            styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./input-number.component.scss */ "./src/app/shared/hazlenut/abstract-inputs/input-number/input-number.component.scss")).default]
        })
        // TODO: extends from {@link CoreInputComponent}
        ,
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
    ], InputNumberComponent);
    return InputNumberComponent;
}());



/***/ }),

/***/ "./src/app/shared/hazlenut/abstract-inputs/validator-composer.ts":
/*!***********************************************************************!*\
  !*** ./src/app/shared/hazlenut/abstract-inputs/validator-composer.ts ***!
  \***********************************************************************/
/*! exports provided: ValidatorComposer */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ValidatorComposer", function() { return ValidatorComposer; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");



var ValidatorComposer = /** @class */ (function () {
    function ValidatorComposer() {
    }
    ValidatorComposer.prototype.addValidators = function (required, minLength, maxLength, pattern, allowedCharacters) {
        if (required === void 0) { required = true; }
        var validators = [];
        if (required) {
            validators.push(_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required);
        }
        if (minLength && minLength > 0) {
            validators.push(_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].minLength(minLength));
        }
        if (maxLength && maxLength > 0) {
            validators.push(_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].maxLength(maxLength));
        }
        if (pattern) {
            validators.push(_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].pattern(pattern));
        }
        if (allowedCharacters) {
            validators.push(_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].pattern(allowedCharacters));
        }
        return validators.slice();
    };
    ValidatorComposer = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root'
        })
    ], ValidatorComposer);
    return ValidatorComposer;
}());



/***/ }),

/***/ "./src/app/shared/hazlenut/core-table/components/core-table-filter/core-table-filter.component.scss":
/*!**********************************************************************************************************!*\
  !*** ./src/app/shared/hazlenut/core-table/components/core-table-filter/core-table-filter.component.scss ***!
  \**********************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".first-header-row th {\n  border-bottom: none;\n  white-space: nowrap;\n}\n\nth[mat-header-cell] {\n  font-weight: 600;\n  padding: 5px;\n  text-align: inherit;\n  color: black;\n}\n\ntd[mat-cell] {\n  font-size: 12px;\n  color: #575757;\n  padding: 0 5px 0 5px;\n}\n\n.data {\n  padding: 5px;\n  cursor: pointer;\n}\n\n.white-box {\n  background: white;\n  padding: 10px;\n  margin: 0;\n}\n\n.expand-detail-row {\n  height: 0;\n}\n\n.expand-element-detail {\n  overflow: hidden;\n  display: flex;\n  flex-direction: column;\n}\n\n.expand-td {\n  background: #e0f2f1;\n}\n\n.paginator-style {\n  border-top: 1px solid rgba(0, 0, 0, 0.12);\n}\n\n.search-icon {\n  color: gray;\n  font-size: 14px;\n  padding-right: 5px;\n  -webkit-animation-name: fadeIn;\n          animation-name: fadeIn;\n  -webkit-animation-duration: 1s;\n          animation-duration: 1s;\n}\n\n.w-100 {\n  width: 100px !important;\n}\n\n@-webkit-keyframes fadeIn {\n  0% {\n    opacity: 0;\n  }\n  100% {\n    opacity: 1;\n  }\n}\n\n@keyframes fadeIn {\n  0% {\n    opacity: 0;\n  }\n  100% {\n    opacity: 1;\n  }\n}\n\n::ng-deep .mat-primary .mat-pseudo-checkbox-checked {\n  background: #848484;\n}\n\n::ng-deep .mat-form-field .mat-form-field-flex {\n  background-color: #e8f0fe;\n  border-top-left-radius: 5px;\n  border-top-right-radius: 5px;\n}\n\n.suffix-close {\n  cursor: pointer;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvc2hhcmVkL2hhemxlbnV0L2NvcmUtdGFibGUvY29tcG9uZW50cy9jb3JlLXRhYmxlLWZpbHRlci9EOlxccHJvamVjdHNcXGlpaGZcXHdmbS13ZWIvc3JjXFxhcHBcXHNoYXJlZFxcaGF6bGVudXRcXGNvcmUtdGFibGVcXGNvbXBvbmVudHNcXGNvcmUtdGFibGUtZmlsdGVyXFxjb3JlLXRhYmxlLWZpbHRlci5jb21wb25lbnQuc2NzcyIsInNyYy9hcHAvc2hhcmVkL2hhemxlbnV0L2NvcmUtdGFibGUvY29tcG9uZW50cy9jb3JlLXRhYmxlLWZpbHRlci9jb3JlLXRhYmxlLWZpbHRlci5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLG1CQUFBO0VBQ0EsbUJBQUE7QUNDSjs7QURFQTtFQUNJLGdCQUFBO0VBQ0EsWUFBQTtFQUNBLG1CQUFBO0VBQ0EsWUFBQTtBQ0NKOztBREVBO0VBQ0ksZUFBQTtFQUNBLGNBQUE7RUFDQSxvQkFBQTtBQ0NKOztBREVBO0VBQ0ksWUFBQTtFQUNBLGVBQUE7QUNDSjs7QURFQTtFQUNJLGlCQUFBO0VBQ0EsYUFBQTtFQUNBLFNBQUE7QUNDSjs7QURFQTtFQUNJLFNBQUE7QUNDSjs7QURFQTtFQUNJLGdCQUFBO0VBQ0EsYUFBQTtFQUNBLHNCQUFBO0FDQ0o7O0FERUE7RUFDSSxtQkFBQTtBQ0NKOztBREVBO0VBQ0kseUNBQUE7QUNDSjs7QURFQTtFQUNJLFdBQUE7RUFDQSxlQUFBO0VBQ0Esa0JBQUE7RUFDQSw4QkFBQTtVQUFBLHNCQUFBO0VBQ0EsOEJBQUE7VUFBQSxzQkFBQTtBQ0NKOztBREVBO0VBQ0ksdUJBQUE7QUNDSjs7QURFQTtFQUNJO0lBQ0ksVUFBQTtFQ0NOO0VEQ0U7SUFDSSxVQUFBO0VDQ047QUFDRjs7QURQQTtFQUNJO0lBQ0ksVUFBQTtFQ0NOO0VEQ0U7SUFDSSxVQUFBO0VDQ047QUFDRjs7QURXQTtFQUNJLG1CQUFBO0FDVEo7O0FEYUk7RUFDSSx5QkFBQTtFQUNBLDJCQUFBO0VBQ0EsNEJBQUE7QUNWUjs7QURjQTtFQUNJLGVBQUE7QUNYSiIsImZpbGUiOiJzcmMvYXBwL3NoYXJlZC9oYXpsZW51dC9jb3JlLXRhYmxlL2NvbXBvbmVudHMvY29yZS10YWJsZS1maWx0ZXIvY29yZS10YWJsZS1maWx0ZXIuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuZmlyc3QtaGVhZGVyLXJvdyB0aCB7XHJcbiAgICBib3JkZXItYm90dG9tOiBub25lO1xyXG4gICAgd2hpdGUtc3BhY2U6IG5vd3JhcDtcclxufVxyXG5cclxudGhbbWF0LWhlYWRlci1jZWxsXSB7XHJcbiAgICBmb250LXdlaWdodDogNjAwO1xyXG4gICAgcGFkZGluZzogNXB4O1xyXG4gICAgdGV4dC1hbGlnbjogaW5oZXJpdDtcclxuICAgIGNvbG9yOiBibGFjaztcclxufVxyXG5cclxudGRbbWF0LWNlbGxdIHtcclxuICAgIGZvbnQtc2l6ZTogMTJweDtcclxuICAgIGNvbG9yOiAjNTc1NzU3O1xyXG4gICAgcGFkZGluZzogMCA1cHggMCA1cHg7XHJcbn1cclxuXHJcbi5kYXRhIHtcclxuICAgIHBhZGRpbmc6IDVweDtcclxuICAgIGN1cnNvcjogcG9pbnRlcjtcclxufVxyXG5cclxuLndoaXRlLWJveCB7XHJcbiAgICBiYWNrZ3JvdW5kOiB3aGl0ZTtcclxuICAgIHBhZGRpbmc6IDEwcHg7XHJcbiAgICBtYXJnaW46IDA7XHJcbn1cclxuXHJcbi5leHBhbmQtZGV0YWlsLXJvdyB7XHJcbiAgICBoZWlnaHQ6IDA7XHJcbn1cclxuXHJcbi5leHBhbmQtZWxlbWVudC1kZXRhaWwge1xyXG4gICAgb3ZlcmZsb3c6IGhpZGRlbjtcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xyXG59XHJcblxyXG4uZXhwYW5kLXRkIHtcclxuICAgIGJhY2tncm91bmQ6ICNlMGYyZjE7XHJcbn1cclxuXHJcbi5wYWdpbmF0b3Itc3R5bGUge1xyXG4gICAgYm9yZGVyLXRvcDogMXB4IHNvbGlkIHJnYmEoMCwgMCwgMCwgLjEyKTtcclxufVxyXG5cclxuLnNlYXJjaC1pY29uIHtcclxuICAgIGNvbG9yOiBncmF5O1xyXG4gICAgZm9udC1zaXplOiAxNHB4O1xyXG4gICAgcGFkZGluZy1yaWdodDogNXB4O1xyXG4gICAgYW5pbWF0aW9uLW5hbWU6IGZhZGVJbjtcclxuICAgIGFuaW1hdGlvbi1kdXJhdGlvbjogMXM7XHJcbn1cclxuXHJcbi53LTEwMCB7XHJcbiAgICB3aWR0aDogMTAwcHggIWltcG9ydGFudDtcclxufVxyXG5cclxuQGtleWZyYW1lcyBmYWRlSW4ge1xyXG4gICAgMCUge1xyXG4gICAgICAgIG9wYWNpdHk6IDA7XHJcbiAgICB9XHJcbiAgICAxMDAlIHtcclxuICAgICAgICBvcGFjaXR5OiAxO1xyXG4gICAgfVxyXG59XHJcblxyXG4vLzo6bmctZGVlcCB7XHJcbi8vICAgIC5jdXN0b20tZmlsdGVyLWlucHV0IC5tYXQtZm9ybS1maWVsZC1mbGV4IHtcclxuLy8gICAgICAgIGJhY2tncm91bmQtY29sb3I6ICNmM2Y5ZmQ7XHJcbi8vICAgICAgICBib3JkZXI6IDFweCBzb2xpZCAjYzRlNGY0O1xyXG4vLyAgICAgICAgYm9yZGVyLXRvcC1sZWZ0LXJhZGl1czogNXB4O1xyXG4vLyAgICAgICAgYm9yZGVyLXRvcC1yaWdodC1yYWRpdXM6IDVweDtcclxuLy8gICAgfVxyXG4vL31cclxuXHJcbjo6bmctZGVlcCAubWF0LXByaW1hcnkgLm1hdC1wc2V1ZG8tY2hlY2tib3gtY2hlY2tlZCB7XHJcbiAgICBiYWNrZ3JvdW5kOiAjODQ4NDg0O1xyXG59XHJcblxyXG46Om5nLWRlZXAge1xyXG4gICAgLm1hdC1mb3JtLWZpZWxkIC5tYXQtZm9ybS1maWVsZC1mbGV4IHtcclxuICAgICAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjZThmMGZlO1xyXG4gICAgICAgIGJvcmRlci10b3AtbGVmdC1yYWRpdXM6IDVweDtcclxuICAgICAgICBib3JkZXItdG9wLXJpZ2h0LXJhZGl1czogNXB4O1xyXG4gICAgfVxyXG59XHJcblxyXG4uc3VmZml4LWNsb3NlIHtcclxuICAgIGN1cnNvcjogcG9pbnRlcjtcclxufVxyXG5cclxuXHJcbiIsIi5maXJzdC1oZWFkZXItcm93IHRoIHtcbiAgYm9yZGVyLWJvdHRvbTogbm9uZTtcbiAgd2hpdGUtc3BhY2U6IG5vd3JhcDtcbn1cblxudGhbbWF0LWhlYWRlci1jZWxsXSB7XG4gIGZvbnQtd2VpZ2h0OiA2MDA7XG4gIHBhZGRpbmc6IDVweDtcbiAgdGV4dC1hbGlnbjogaW5oZXJpdDtcbiAgY29sb3I6IGJsYWNrO1xufVxuXG50ZFttYXQtY2VsbF0ge1xuICBmb250LXNpemU6IDEycHg7XG4gIGNvbG9yOiAjNTc1NzU3O1xuICBwYWRkaW5nOiAwIDVweCAwIDVweDtcbn1cblxuLmRhdGEge1xuICBwYWRkaW5nOiA1cHg7XG4gIGN1cnNvcjogcG9pbnRlcjtcbn1cblxuLndoaXRlLWJveCB7XG4gIGJhY2tncm91bmQ6IHdoaXRlO1xuICBwYWRkaW5nOiAxMHB4O1xuICBtYXJnaW46IDA7XG59XG5cbi5leHBhbmQtZGV0YWlsLXJvdyB7XG4gIGhlaWdodDogMDtcbn1cblxuLmV4cGFuZC1lbGVtZW50LWRldGFpbCB7XG4gIG92ZXJmbG93OiBoaWRkZW47XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XG59XG5cbi5leHBhbmQtdGQge1xuICBiYWNrZ3JvdW5kOiAjZTBmMmYxO1xufVxuXG4ucGFnaW5hdG9yLXN0eWxlIHtcbiAgYm9yZGVyLXRvcDogMXB4IHNvbGlkIHJnYmEoMCwgMCwgMCwgMC4xMik7XG59XG5cbi5zZWFyY2gtaWNvbiB7XG4gIGNvbG9yOiBncmF5O1xuICBmb250LXNpemU6IDE0cHg7XG4gIHBhZGRpbmctcmlnaHQ6IDVweDtcbiAgYW5pbWF0aW9uLW5hbWU6IGZhZGVJbjtcbiAgYW5pbWF0aW9uLWR1cmF0aW9uOiAxcztcbn1cblxuLnctMTAwIHtcbiAgd2lkdGg6IDEwMHB4ICFpbXBvcnRhbnQ7XG59XG5cbkBrZXlmcmFtZXMgZmFkZUluIHtcbiAgMCUge1xuICAgIG9wYWNpdHk6IDA7XG4gIH1cbiAgMTAwJSB7XG4gICAgb3BhY2l0eTogMTtcbiAgfVxufVxuOjpuZy1kZWVwIC5tYXQtcHJpbWFyeSAubWF0LXBzZXVkby1jaGVja2JveC1jaGVja2VkIHtcbiAgYmFja2dyb3VuZDogIzg0ODQ4NDtcbn1cblxuOjpuZy1kZWVwIC5tYXQtZm9ybS1maWVsZCAubWF0LWZvcm0tZmllbGQtZmxleCB7XG4gIGJhY2tncm91bmQtY29sb3I6ICNlOGYwZmU7XG4gIGJvcmRlci10b3AtbGVmdC1yYWRpdXM6IDVweDtcbiAgYm9yZGVyLXRvcC1yaWdodC1yYWRpdXM6IDVweDtcbn1cblxuLnN1ZmZpeC1jbG9zZSB7XG4gIGN1cnNvcjogcG9pbnRlcjtcbn0iXX0= */");

/***/ }),

/***/ "./src/app/shared/hazlenut/core-table/components/core-table-filter/core-table-filter.component.ts":
/*!********************************************************************************************************!*\
  !*** ./src/app/shared/hazlenut/core-table/components/core-table-filter/core-table-filter.component.ts ***!
  \********************************************************************************************************/
/*! exports provided: CoreTableFilterComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CoreTableFilterComponent", function() { return CoreTableFilterComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm5/operators/index.js");
/* harmony import */ var _services_data_business_area_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../../services/data/business-area.service */ "./src/app/shared/services/data/business-area.service.ts");
/* harmony import */ var _services_data_user_data_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../../services/data/user-data.service */ "./src/app/shared/services/data/user-data.service.ts");
/* harmony import */ var _services_notification_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../../services/notification.service */ "./src/app/shared/services/notification.service.ts");
/* harmony import */ var _hazelnut_common_animations__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../../hazelnut-common/animations */ "./src/app/shared/hazlenut/hazelnut-common/animations/index.ts");
/* harmony import */ var _hazelnut_common_hazelnut__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../../hazelnut-common/hazelnut */ "./src/app/shared/hazlenut/hazelnut-common/hazelnut/index.ts");
/* harmony import */ var _core_table_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../core-table.service */ "./src/app/shared/hazlenut/core-table/core-table.service.ts");
/* harmony import */ var _models_table_column_model__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../models/table-column.model */ "./src/app/shared/hazlenut/core-table/models/table-column.model.ts");
/* harmony import */ var _models_table_filter_type_enum__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../models/table-filter-type.enum */ "./src/app/shared/hazlenut/core-table/models/table-filter-type.enum.ts");












var CoreTableFilterComponent = /** @class */ (function () {
    function CoreTableFilterComponent(coreTableService, userDataService, notificationService, businessAreaService) {
        this.coreTableService = coreTableService;
        this.userDataService = userDataService;
        this.notificationService = notificationService;
        this.businessAreaService = businessAreaService;
        this.columnConfig = new _models_table_column_model__WEBPACK_IMPORTED_MODULE_10__["TableColumn"]({
            columnDef: '',
            label: ''
        });
        this.resetFilters = new _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"]();
        this.showSearchIcon = true;
        this.filterTypeEnum = _models_table_filter_type_enum__WEBPACK_IMPORTED_MODULE_11__["TableFilterType"];
        this.userList$ = this.userDataService.getUsers();
        this.categoryList$ = [];
        this._filtersElement = null;
    }
    Object.defineProperty(CoreTableFilterComponent.prototype, "filterDelay", {
        get: function () {
            return this.coreTableService && this.coreTableService.configuration ? this.coreTableService.configuration.filterDebounceTime : 0;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(CoreTableFilterComponent.prototype, "control", {
        get: function () {
            return this._filtersElement.controls[this.columnConfig.filterElement];
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(CoreTableFilterComponent.prototype, "widthClass", {
        get: function () {
            return this.columnConfig.filter.width ? "w-" + this.columnConfig.filter.width : 'w-100';
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(CoreTableFilterComponent.prototype, "filtersElement", {
        get: function () {
            return this._filtersElement;
        },
        enumerable: true,
        configurable: true
    });
    CoreTableFilterComponent.prototype.ngOnInit = function () {
        var elementName = this.columnConfig.filterElement;
        var formGroupOptions = {};
        formGroupOptions[elementName] = new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"](this.columnConfig.filter && this.columnConfig.filter.predefinedValue ? this.columnConfig.filter.predefinedValue[0] : null);
        this._filtersElement = new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormGroup"](formGroupOptions);
        this.processFormChanges();
        if (this.columnConfig.filter && this.columnConfig.filter.type === _models_table_filter_type_enum__WEBPACK_IMPORTED_MODULE_11__["TableFilterType"].CUSTOM) {
            this._filtersElement.addControl(this.columnConfig.filterElement, new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"]());
        }
        this.loadCategoryList();
        this.setPredefinedFilterValuesIntoTableFilters();
    };
    CoreTableFilterComponent.prototype.clearFilters = function () {
        this.resetFilters.next(true);
        this.coreTableService.clearFilters();
    };
    CoreTableFilterComponent.prototype.loadCategoryList = function () {
        var _this = this;
        this.businessAreaService.listCategories()
            .subscribe(function (data) {
            _this.categoryList$ = data.content;
        });
    };
    CoreTableFilterComponent.prototype.processFormChanges = function () {
        var _this = this;
        var elementName = this.columnConfig.filterElement;
        this.filtersElement.valueChanges.pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["debounceTime"])(this.filterDelay))
            .subscribe(function (values) {
            if (_this.filtersElement.status === 'VALID') {
                var newValue = values[elementName];
                _this.coreTableService.addFilter(_this.columnConfig, newValue);
            }
        });
    };
    CoreTableFilterComponent.prototype.setPredefinedFilterValuesIntoTableFilters = function () {
        var _this = this;
        var configuration = this.coreTableService.configuration;
        var isFilterFromPredefinedFilters = configuration &&
            configuration.predefinedFilters &&
            configuration.predefinedFilters.find(function (filter) { return filter.property === _hazelnut_common_hazelnut__WEBPACK_IMPORTED_MODULE_8__["StringUtils"].convertCamelToSnakeUpper(_this.columnConfig.columnDef); });
        var isPredefinedNumberValue = this.columnConfig.filter.type === 'number';
        var isPredefinedDateValue = this.columnConfig.config && this.columnConfig.config.filter && this.columnConfig.config.filter.valueType === 'DATE_TIME';
        var isPredefinedTrafficLightValue = this.columnConfig.columnDef === 'trafficLight';
        if (isFilterFromPredefinedFilters) {
            if (isPredefinedNumberValue) {
                this.setFilterElementByPredefinedNumberValues();
            }
            else if (isPredefinedDateValue) {
                // TODO apply set date filter
            }
            else if (isPredefinedTrafficLightValue) {
                this.setFilterElementByPredefinedTrafficLightValues();
            }
            else {
                this.filtersElement.controls[this.columnConfig.filterElement].patchValue(configuration.predefinedFilters
                    .find(function (filter) { return filter.property ===
                    _hazelnut_common_hazelnut__WEBPACK_IMPORTED_MODULE_8__["StringUtils"].convertCamelToSnakeUpper(_this.columnConfig.columnDef); }).value);
            }
        }
    };
    CoreTableFilterComponent.prototype.setFilterElementByPredefinedDateValues = function () {
        // TODO fix ExpressionChangedAfterItHasBeenCheckedError
        var lowerFilter = this.getNumberFilterFromPredefinedFiltersByOperator('GOE');
        var higherFilter = this.getNumberFilterFromPredefinedFiltersByOperator('LOE');
        this.filtersElement.controls[this.columnConfig.filterElement].patchValue({
            dateFrom: lowerFilter ? lowerFilter.value : null,
            dateTo: higherFilter ? higherFilter.value : null,
        });
    };
    CoreTableFilterComponent.prototype.setFilterElementByPredefinedNumberValues = function () {
        var lowerFilter = this.getNumberFilterFromPredefinedFiltersByOperator('GOE');
        var higherFilter = this.getNumberFilterFromPredefinedFiltersByOperator('LOE');
        this.filtersElement.controls[this.columnConfig.filterElement].patchValue({
            from: lowerFilter ? lowerFilter.value : null,
            to: higherFilter ? higherFilter.value : null,
        });
    };
    CoreTableFilterComponent.prototype.setFilterElementByPredefinedTrafficLightValues = function () {
        var _this = this;
        this.filtersElement.controls[this.columnConfig.filterElement].patchValue([
            'RED',
            'GREEN',
            'AMBER',
            'NONE'
        ]
            .map(function (color) { return _this.getTrafficLightFromPredefinedFiltersByColor(color); })
            .filter(function (filter) { return filter !== undefined; })
            .map(function (filter) { return filter.value.toString()
            .toLowerCase(); }));
    };
    CoreTableFilterComponent.prototype.getNumberFilterFromPredefinedFiltersByOperator = function (operator) {
        var _this = this;
        return this.coreTableService.configuration.predefinedFilters
            .filter(function (filter) { return filter.property === _hazelnut_common_hazelnut__WEBPACK_IMPORTED_MODULE_8__["StringUtils"].convertCamelToSnakeUpper(_this.columnConfig.columnDef); })
            .find(function (filter) { return filter.operator === operator; });
    };
    CoreTableFilterComponent.prototype.getTrafficLightFromPredefinedFiltersByColor = function (colorValue) {
        var _this = this;
        return this.coreTableService.configuration.predefinedFilters
            .filter(function (filter) { return filter.property === _hazelnut_common_hazelnut__WEBPACK_IMPORTED_MODULE_8__["StringUtils"].convertCamelToSnakeUpper(_this.columnConfig.columnDef); })
            .find(function (filter) { return filter.value === colorValue; });
    };
    CoreTableFilterComponent.ctorParameters = function () { return [
        { type: _core_table_service__WEBPACK_IMPORTED_MODULE_9__["CoreTableService"] },
        { type: _services_data_user_data_service__WEBPACK_IMPORTED_MODULE_5__["UserDataService"] },
        { type: _services_notification_service__WEBPACK_IMPORTED_MODULE_6__["NotificationService"] },
        { type: _services_data_business_area_service__WEBPACK_IMPORTED_MODULE_4__["BusinessAreaService"] }
    ]; };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _models_table_column_model__WEBPACK_IMPORTED_MODULE_10__["TableColumn"])
    ], CoreTableFilterComponent.prototype, "columnConfig", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Output"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], CoreTableFilterComponent.prototype, "resetFilters", void 0);
    CoreTableFilterComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'haz-core-table-filter',
            template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./core-table-filter.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/shared/hazlenut/core-table/components/core-table-filter/core-table-filter.component.html")).default,
            animations: [_hazelnut_common_animations__WEBPACK_IMPORTED_MODULE_7__["fadeEnterLeave"]],
            styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./core-table-filter.component.scss */ "./src/app/shared/hazlenut/core-table/components/core-table-filter/core-table-filter.component.scss")).default]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_core_table_service__WEBPACK_IMPORTED_MODULE_9__["CoreTableService"],
            _services_data_user_data_service__WEBPACK_IMPORTED_MODULE_5__["UserDataService"],
            _services_notification_service__WEBPACK_IMPORTED_MODULE_6__["NotificationService"],
            _services_data_business_area_service__WEBPACK_IMPORTED_MODULE_4__["BusinessAreaService"]])
    ], CoreTableFilterComponent);
    return CoreTableFilterComponent;
}());



/***/ }),

/***/ "./src/app/shared/hazlenut/core-table/components/core-table.component.scss":
/*!*********************************************************************************!*\
  !*** ./src/app/shared/hazlenut/core-table/components/core-table.component.scss ***!
  \*********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".styled-table-container {\n  max-height: calc(100vh - 220px);\n  overflow: auto;\n  font-family: \"-apple-system\", \"system-ui\", \"BlinkMacSystemFont\", \"Segoe UI\", \"Roboto\", \"Helvetica Neue\", \"Arial\", \"Apple Color Emoji\", \"Segoe UI Emoji\", \"Segoe UI Symbol\", sans-serif;\n}\n.styled-table-container .styled-table {\n  width: 100%;\n}\n.first-header-row th {\n  border-bottom: none;\n  white-space: nowrap;\n  padding-top: 30px !important;\n}\n.last-header-row th {\n  box-shadow: inset 0 -11px 2px -11px #424242;\n}\n.paginator {\n  border-top: 1px solid #bdbdbd;\n}\nth[mat-header-cell] {\n  font-weight: 600;\n  padding-left: 5px;\n  padding-right: 5px;\n  text-align: inherit;\n  color: black;\n}\n.border-columns td[mat-cell], .border-columns th[mat-header-cell] {\n  border-right: 1px solid #eee;\n}\ntd[mat-cell] {\n  font-size: 12px;\n  color: #616161;\n  padding-left: 5px;\n  padding-right: 5px;\n}\n.data {\n  padding: 5px;\n  cursor: pointer;\n}\n.data-row {\n  transition: background 0.3s ease;\n}\n.data-row:hover {\n  background: #fafafa;\n}\n.expand-detail-row {\n  height: 0;\n}\n.expand-element-detail {\n  overflow: hidden;\n  display: flex;\n  flex-direction: column;\n}\n.expand-td {\n  background: #eeeeee;\n}\n.white-box {\n  background: white;\n  padding: 10px;\n  margin: 0;\n}\n.right-align-header {\n  width: 100%;\n  display: flex;\n  justify-content: flex-end;\n}\n::ng-deep .mat-paginator .mat-form-field .mat-form-field-flex {\n  background-color: rgba(0, 0, 0, 0);\n}\n.table-sticky-end {\n  background: red !important;\n  border: 2px solid black;\n  position: -webkit-sticky;\n  position: sticky;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvc2hhcmVkL2hhemxlbnV0L2NvcmUtdGFibGUvY29tcG9uZW50cy9EOlxccHJvamVjdHNcXGlpaGZcXHdmbS13ZWIvc3JjXFxhcHBcXHNoYXJlZFxcaGF6bGVudXRcXGNvcmUtdGFibGVcXGNvbXBvbmVudHNcXGNvcmUtdGFibGUuY29tcG9uZW50LnNjc3MiLCJzcmMvYXBwL3NoYXJlZC9oYXpsZW51dC9jb3JlLXRhYmxlL2NvbXBvbmVudHMvY29yZS10YWJsZS5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFDQTtFQUNJLCtCQUFBO0VBQ0EsY0FBQTtFQUNBLHNMQUFBO0FDQUo7QURHSTtFQUNJLFdBQUE7QUNEUjtBREtBO0VBQ0ksbUJBQUE7RUFDQSxtQkFBQTtFQUNBLDRCQUFBO0FDRko7QURLQTtFQUNJLDJDQUFBO0FDRko7QURLQTtFQUNJLDZCQUFBO0FDRko7QURLQTtFQUNJLGdCQUFBO0VBQ0EsaUJBQUE7RUFDQSxrQkFBQTtFQUNBLG1CQUFBO0VBQ0EsWUFBQTtBQ0ZKO0FETUk7RUFDSSw0QkFBQTtBQ0hSO0FET0E7RUFDSSxlQUFBO0VBQ0EsY0FBQTtFQUNBLGlCQUFBO0VBQ0Esa0JBQUE7QUNKSjtBRE9BO0VBQ0ksWUFBQTtFQUNBLGVBQUE7QUNKSjtBRE9BO0VBQ0ksZ0NBQUE7QUNKSjtBRE1JO0VBQ0ksbUJBQUE7QUNKUjtBRFFBO0VBQ0ksU0FBQTtBQ0xKO0FEUUE7RUFDSSxnQkFBQTtFQUNBLGFBQUE7RUFDQSxzQkFBQTtBQ0xKO0FEUUE7RUFDSSxtQkFBQTtBQ0xKO0FEUUE7RUFDSSxpQkFBQTtFQUNBLGFBQUE7RUFDQSxTQUFBO0FDTEo7QURRQTtFQUNJLFdBQUE7RUFDQSxhQUFBO0VBQ0EseUJBQUE7QUNMSjtBRFVJO0VBQ0ksa0NBQUE7QUNQUjtBRFdBO0VBQ0ksMEJBQUE7RUFDQSx1QkFBQTtFQUNBLHdCQUFBO0VBQUEsZ0JBQUE7QUNSSiIsImZpbGUiOiJzcmMvYXBwL3NoYXJlZC9oYXpsZW51dC9jb3JlLXRhYmxlL2NvbXBvbmVudHMvY29yZS10YWJsZS5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIlxyXG4uc3R5bGVkLXRhYmxlLWNvbnRhaW5lciB7XHJcbiAgICBtYXgtaGVpZ2h0OiBjYWxjKDEwMHZoIC0gMjIwcHgpIDtcclxuICAgIG92ZXJmbG93OiBhdXRvO1xyXG4gICAgZm9udC1mYW1pbHk6ICctYXBwbGUtc3lzdGVtJywgJ3N5c3RlbS11aScsICdCbGlua01hY1N5c3RlbUZvbnQnLCAnU2Vnb2UgVUknLCAnUm9ib3RvJywgJ0hlbHZldGljYSBOZXVlJywgJ0FyaWFsJyxcclxuICAgICdBcHBsZSBDb2xvciBFbW9qaScsICdTZWdvZSBVSSBFbW9qaScsICdTZWdvZSBVSSBTeW1ib2wnLCBzYW5zLXNlcmlmO1xyXG5cclxuICAgIC5zdHlsZWQtdGFibGUge1xyXG4gICAgICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgfVxyXG59XHJcblxyXG4uZmlyc3QtaGVhZGVyLXJvdyB0aCB7XHJcbiAgICBib3JkZXItYm90dG9tOiBub25lO1xyXG4gICAgd2hpdGUtc3BhY2U6IG5vd3JhcDtcclxuICAgIHBhZGRpbmctdG9wOiAzMHB4ICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbi5sYXN0LWhlYWRlci1yb3cgdGgge1xyXG4gICAgYm94LXNoYWRvdzogaW5zZXQgMCAtMTFweCAycHggLTExcHggIzQyNDI0MjtcclxufVxyXG5cclxuLnBhZ2luYXRvciB7XHJcbiAgICBib3JkZXItdG9wOiAxcHggc29saWQgI2JkYmRiZDtcclxufVxyXG5cclxudGhbbWF0LWhlYWRlci1jZWxsXSB7XHJcbiAgICBmb250LXdlaWdodDogNjAwO1xyXG4gICAgcGFkZGluZy1sZWZ0OiA1cHg7XHJcbiAgICBwYWRkaW5nLXJpZ2h0OiA1cHg7XHJcbiAgICB0ZXh0LWFsaWduOiBpbmhlcml0O1xyXG4gICAgY29sb3I6IGJsYWNrO1xyXG59XHJcblxyXG4uYm9yZGVyLWNvbHVtbnMge1xyXG4gICAgdGRbbWF0LWNlbGxdLCB0aFttYXQtaGVhZGVyLWNlbGxdIHtcclxuICAgICAgICBib3JkZXItcmlnaHQ6IDFweCBzb2xpZCAjZWVlO1xyXG4gICAgfVxyXG59XHJcblxyXG50ZFttYXQtY2VsbF0ge1xyXG4gICAgZm9udC1zaXplOiAxMnB4O1xyXG4gICAgY29sb3I6ICM2MTYxNjE7XHJcbiAgICBwYWRkaW5nLWxlZnQ6IDVweDtcclxuICAgIHBhZGRpbmctcmlnaHQ6IDVweDtcclxufVxyXG5cclxuLmRhdGEge1xyXG4gICAgcGFkZGluZzogNXB4O1xyXG4gICAgY3Vyc29yOiBwb2ludGVyO1xyXG59XHJcblxyXG4uZGF0YS1yb3cge1xyXG4gICAgdHJhbnNpdGlvbjogYmFja2dyb3VuZCAuM3MgZWFzZTtcclxuXHJcbiAgICAmOmhvdmVyIHtcclxuICAgICAgICBiYWNrZ3JvdW5kOiAjZmFmYWZhO1xyXG4gICAgfVxyXG59XHJcblxyXG4uZXhwYW5kLWRldGFpbC1yb3cge1xyXG4gICAgaGVpZ2h0OiAwO1xyXG59XHJcblxyXG4uZXhwYW5kLWVsZW1lbnQtZGV0YWlsIHtcclxuICAgIG92ZXJmbG93OiBoaWRkZW47XHJcbiAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcclxufVxyXG5cclxuLmV4cGFuZC10ZCB7XHJcbiAgICBiYWNrZ3JvdW5kOiAjZWVlZWVlO1xyXG59XHJcblxyXG4ud2hpdGUtYm94IHtcclxuICAgIGJhY2tncm91bmQ6IHdoaXRlO1xyXG4gICAgcGFkZGluZzogMTBweDtcclxuICAgIG1hcmdpbjogMDtcclxufVxyXG5cclxuLnJpZ2h0LWFsaWduLWhlYWRlciB7XHJcbiAgICB3aWR0aDogMTAwJTtcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IGZsZXgtZW5kO1xyXG59XHJcblxyXG5cclxuOjpuZy1kZWVwIHtcclxuICAgIC5tYXQtcGFnaW5hdG9yIC5tYXQtZm9ybS1maWVsZCAubWF0LWZvcm0tZmllbGQtZmxleCB7XHJcbiAgICAgICAgYmFja2dyb3VuZC1jb2xvcjogcmdiYSgwLCAwLCAwLCAwKTtcclxuICAgIH1cclxufVxyXG5cclxuLnRhYmxlLXN0aWNreS1lbmQge1xyXG4gICAgYmFja2dyb3VuZDogcmVkICFpbXBvcnRhbnQ7XHJcbiAgICBib3JkZXI6IDJweCBzb2xpZCBibGFjaztcclxuICAgIHBvc2l0aW9uOiBzdGlja3k7XHJcbn1cclxuIiwiLnN0eWxlZC10YWJsZS1jb250YWluZXIge1xuICBtYXgtaGVpZ2h0OiBjYWxjKDEwMHZoIC0gMjIwcHgpO1xuICBvdmVyZmxvdzogYXV0bztcbiAgZm9udC1mYW1pbHk6IFwiLWFwcGxlLXN5c3RlbVwiLCBcInN5c3RlbS11aVwiLCBcIkJsaW5rTWFjU3lzdGVtRm9udFwiLCBcIlNlZ29lIFVJXCIsIFwiUm9ib3RvXCIsIFwiSGVsdmV0aWNhIE5ldWVcIiwgXCJBcmlhbFwiLCBcIkFwcGxlIENvbG9yIEVtb2ppXCIsIFwiU2Vnb2UgVUkgRW1vamlcIiwgXCJTZWdvZSBVSSBTeW1ib2xcIiwgc2Fucy1zZXJpZjtcbn1cbi5zdHlsZWQtdGFibGUtY29udGFpbmVyIC5zdHlsZWQtdGFibGUge1xuICB3aWR0aDogMTAwJTtcbn1cblxuLmZpcnN0LWhlYWRlci1yb3cgdGgge1xuICBib3JkZXItYm90dG9tOiBub25lO1xuICB3aGl0ZS1zcGFjZTogbm93cmFwO1xuICBwYWRkaW5nLXRvcDogMzBweCAhaW1wb3J0YW50O1xufVxuXG4ubGFzdC1oZWFkZXItcm93IHRoIHtcbiAgYm94LXNoYWRvdzogaW5zZXQgMCAtMTFweCAycHggLTExcHggIzQyNDI0Mjtcbn1cblxuLnBhZ2luYXRvciB7XG4gIGJvcmRlci10b3A6IDFweCBzb2xpZCAjYmRiZGJkO1xufVxuXG50aFttYXQtaGVhZGVyLWNlbGxdIHtcbiAgZm9udC13ZWlnaHQ6IDYwMDtcbiAgcGFkZGluZy1sZWZ0OiA1cHg7XG4gIHBhZGRpbmctcmlnaHQ6IDVweDtcbiAgdGV4dC1hbGlnbjogaW5oZXJpdDtcbiAgY29sb3I6IGJsYWNrO1xufVxuXG4uYm9yZGVyLWNvbHVtbnMgdGRbbWF0LWNlbGxdLCAuYm9yZGVyLWNvbHVtbnMgdGhbbWF0LWhlYWRlci1jZWxsXSB7XG4gIGJvcmRlci1yaWdodDogMXB4IHNvbGlkICNlZWU7XG59XG5cbnRkW21hdC1jZWxsXSB7XG4gIGZvbnQtc2l6ZTogMTJweDtcbiAgY29sb3I6ICM2MTYxNjE7XG4gIHBhZGRpbmctbGVmdDogNXB4O1xuICBwYWRkaW5nLXJpZ2h0OiA1cHg7XG59XG5cbi5kYXRhIHtcbiAgcGFkZGluZzogNXB4O1xuICBjdXJzb3I6IHBvaW50ZXI7XG59XG5cbi5kYXRhLXJvdyB7XG4gIHRyYW5zaXRpb246IGJhY2tncm91bmQgMC4zcyBlYXNlO1xufVxuLmRhdGEtcm93OmhvdmVyIHtcbiAgYmFja2dyb3VuZDogI2ZhZmFmYTtcbn1cblxuLmV4cGFuZC1kZXRhaWwtcm93IHtcbiAgaGVpZ2h0OiAwO1xufVxuXG4uZXhwYW5kLWVsZW1lbnQtZGV0YWlsIHtcbiAgb3ZlcmZsb3c6IGhpZGRlbjtcbiAgZGlzcGxheTogZmxleDtcbiAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcbn1cblxuLmV4cGFuZC10ZCB7XG4gIGJhY2tncm91bmQ6ICNlZWVlZWU7XG59XG5cbi53aGl0ZS1ib3gge1xuICBiYWNrZ3JvdW5kOiB3aGl0ZTtcbiAgcGFkZGluZzogMTBweDtcbiAgbWFyZ2luOiAwO1xufVxuXG4ucmlnaHQtYWxpZ24taGVhZGVyIHtcbiAgd2lkdGg6IDEwMCU7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGp1c3RpZnktY29udGVudDogZmxleC1lbmQ7XG59XG5cbjo6bmctZGVlcCAubWF0LXBhZ2luYXRvciAubWF0LWZvcm0tZmllbGQgLm1hdC1mb3JtLWZpZWxkLWZsZXgge1xuICBiYWNrZ3JvdW5kLWNvbG9yOiByZ2JhKDAsIDAsIDAsIDApO1xufVxuXG4udGFibGUtc3RpY2t5LWVuZCB7XG4gIGJhY2tncm91bmQ6IHJlZCAhaW1wb3J0YW50O1xuICBib3JkZXI6IDJweCBzb2xpZCBibGFjaztcbiAgcG9zaXRpb246IHN0aWNreTtcbn0iXX0= */");

/***/ }),

/***/ "./src/app/shared/hazlenut/core-table/components/core-table.component.ts":
/*!*******************************************************************************!*\
  !*** ./src/app/shared/hazlenut/core-table/components/core-table.component.ts ***!
  \*******************************************************************************/
/*! exports provided: CoreTableComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CoreTableComponent", function() { return CoreTableComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_cdk_collections__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/cdk/collections */ "./node_modules/@angular/cdk/esm5/collections.es5.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_material__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/material */ "./node_modules/@angular/material/esm5/material.es5.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm5/index.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm5/operators/index.js");
/* harmony import */ var tslint_lib_error__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! tslint/lib/error */ "./node_modules/tslint/lib/error.js");
/* harmony import */ var tslint_lib_error__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(tslint_lib_error__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _hazelnut_common_animations__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../hazelnut-common/animations */ "./src/app/shared/hazlenut/hazelnut-common/animations/index.ts");
/* harmony import */ var _hazelnut_common_hazelnut__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../hazelnut-common/hazelnut */ "./src/app/shared/hazlenut/hazelnut-common/hazelnut/index.ts");
/* harmony import */ var _hazelnut_common_interfaces__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../hazelnut-common/interfaces */ "./src/app/shared/hazlenut/hazelnut-common/interfaces/index.ts");
/* harmony import */ var _small_components_notifications__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../small-components/notifications */ "./src/app/shared/hazlenut/small-components/notifications/index.ts");
/* harmony import */ var _core_table_service__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../core-table.service */ "./src/app/shared/hazlenut/core-table/core-table.service.ts");
/* harmony import */ var _directives_expanded_detail_directive__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../directives/expanded-detail.directive */ "./src/app/shared/hazlenut/core-table/directives/expanded-detail.directive.ts");
/* harmony import */ var _models_table_cell_type_enum__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../models/table-cell-type.enum */ "./src/app/shared/hazlenut/core-table/models/table-cell-type.enum.ts");
/* harmony import */ var _models_table_column_model__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ../models/table-column.model */ "./src/app/shared/hazlenut/core-table/models/table-column.model.ts");
/* harmony import */ var _models_table_configuration_model__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ../models/table-configuration.model */ "./src/app/shared/hazlenut/core-table/models/table-configuration.model.ts");
/* harmony import */ var _models_table_request_parameters_model__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ../models/table-request-parameters.model */ "./src/app/shared/hazlenut/core-table/models/table-request-parameters.model.ts");
/* harmony import */ var _models_table_response_model__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ../models/table-response.model */ "./src/app/shared/hazlenut/core-table/models/table-response.model.ts");
/* harmony import */ var _table_change_event__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ../table-change-event */ "./src/app/shared/hazlenut/core-table/table-change-event.ts");
/* harmony import */ var _core_table_filter_core_table_filter_component__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ./core-table-filter/core-table-filter.component */ "./src/app/shared/hazlenut/core-table/components/core-table-filter/core-table-filter.component.ts");





















var DEFAULT_NO_DATA_KEY = 'common.noData';
var CoreTableComponent = /** @class */ (function () {
    function CoreTableComponent(translateWrapperService, notificationService, coreTableService) {
        this.translateWrapperService = translateWrapperService;
        this.notificationService = notificationService;
        this.coreTableService = coreTableService;
        this.toggle = true;
        this.configuration = new _models_table_configuration_model__WEBPACK_IMPORTED_MODULE_15__["TableConfiguration"]();
        this.requestData = new _angular_core__WEBPACK_IMPORTED_MODULE_2__["EventEmitter"](true);
        this.selectionChange = new _angular_core__WEBPACK_IMPORTED_MODULE_2__["EventEmitter"](true);
        this.rowClick = new _angular_core__WEBPACK_IMPORTED_MODULE_2__["EventEmitter"](true);
        this.filters = {};
    }
    Object.defineProperty(CoreTableComponent.prototype, "filtersRowDisplayed", {
        get: function () {
            return this.configuration && this.configuration.columns && this.anyFilter;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(CoreTableComponent.prototype, "displayedColumns", {
        get: function () {
            return this.configuration && this.configuration.columns.map(function (row) { return row.columnDef; });
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(CoreTableComponent.prototype, "columnsFilters", {
        get: function () {
            return this.configuration && this.configuration.columns.map(function (row) { return row.filterElement; });
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(CoreTableComponent.prototype, "anyFilter", {
        get: function () {
            return (this.configuration && this.configuration.columns && this.configuration.columns.some(function (row) { return row.filter && row.filter.enabled; }));
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(CoreTableComponent.prototype, "dataRowsDisplayed", {
        get: function () {
            return this.data && this.data.content && this.data.content.length > 0;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(CoreTableComponent.prototype, "selectableTable", {
        get: function () {
            return this.configuration.selection && this.configuration.selection !== 'none';
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(CoreTableComponent.prototype, "paginatorHidden", {
        get: function () {
            if (!this.configuration || !this.data || !this.configuration.paging) {
                return true;
            }
            return this.configuration.pageSizeOptions && this.data.totalElements < this.configuration.pageSizeOptions[0];
        },
        enumerable: true,
        configurable: true
    });
    CoreTableComponent.prototype.ngOnDestroy = function () {
        this.coreTableService.clearFilters();
    };
    CoreTableComponent.prototype.ngOnInit = function () {
        var _this = this;
        if (!this.configuration) {
            throw new tslint_lib_error__WEBPACK_IMPORTED_MODULE_6__["Error"]('this.configuration must be defined.');
        }
        var filters$ = this.coreTableService.filters$;
        this.configuration.columns.forEach(function (column) {
            if (column.filter && column.filter.predefinedValue && column.filter.predefinedValue.length > 0) {
                _this.coreTableService.addFilter(column, column.filter.predefinedValue[0]);
            }
        });
        var constructRequestParameters$ = filters$.pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["map"])(function (filters) {
            var requestParameters = new _models_table_request_parameters_model__WEBPACK_IMPORTED_MODULE_16__["TableRequestParameters"](_this.paginator, _this.sort);
            requestParameters.filter = filters;
            return requestParameters;
        }));
        if (this.sort) {
            this.sort.sortChange
                .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["switchMap"])(function () { return constructRequestParameters$; }))
                .subscribe(function (requestParameters) {
                _this.emitRequestParameters(_table_change_event__WEBPACK_IMPORTED_MODULE_18__["TableChangeEvent"].Create(_table_change_event__WEBPACK_IMPORTED_MODULE_18__["TableChangeType"].SORT, requestParameters, requestParameters.filter));
            });
        }
        this.paginator.page.pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["switchMap"])(function () { return constructRequestParameters$; }))
            .subscribe(function (requestParameters) {
            _this.requestData.emit(_table_change_event__WEBPACK_IMPORTED_MODULE_18__["TableChangeEvent"].Create(_table_change_event__WEBPACK_IMPORTED_MODULE_18__["TableChangeType"].PAGINATE, requestParameters, requestParameters.filter));
        });
        filters$.pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["switchMap"])(function () { return constructRequestParameters$; }))
            .subscribe(function (requestParameters) {
            _this.emitRequestParameters(_table_change_event__WEBPACK_IMPORTED_MODULE_18__["TableChangeEvent"].Create(_table_change_event__WEBPACK_IMPORTED_MODULE_18__["TableChangeType"].FILTER, requestParameters, requestParameters.filter));
        });
    };
    CoreTableComponent.prototype.ngOnChanges = function (simpleChanges) {
        var _this = this;
        if (this.selection) {
            this.selection.clear();
        }
        if (simpleChanges.configuration && simpleChanges.configuration.previousValue !== simpleChanges.configuration.currentValue) {
            this.configuration = this.coreTableService.processConfiguration(this.configuration);
            this.setPageSize();
            this.setLabels();
            if (this.selectableTable) {
                this.configuration.columns.unshift(new _models_table_column_model__WEBPACK_IMPORTED_MODULE_14__["TableColumn"]({ columnDef: 'nothing' }));
                this.selection = new _angular_cdk_collections__WEBPACK_IMPORTED_MODULE_1__["SelectionModel"](this.configuration.selection === 'multi', []);
                this.selection.changed.subscribe(function (data) {
                    // Filter out deleted items from selected items
                    data.source.selected.forEach(function (selectedItem) {
                        if (!_this.data.content || !_this.data.content.some(function (item) { return item.id === selectedItem.id; })) {
                            data.source.deselect(selectedItem);
                        }
                    });
                    _this.selectionChange.emit(data.source.selected);
                }, function (error) { return _this.notificationService.openErrorNotification('error.coreTable.changeError'); });
            }
        }
    };
    CoreTableComponent.prototype.getLabel = function (columnConfig) {
        var _this = this;
        if (columnConfig.label) {
            return Object(rxjs__WEBPACK_IMPORTED_MODULE_4__["of"])(columnConfig.label);
        }
        return this.translateWrapperService.get(columnConfig.labelKey)
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["map"])(function (label) {
            if (typeof label === 'string' && _this.configuration.uppercaseHeader !== false) {
                return label.toUpperCase();
            }
            return label;
        }));
    };
    CoreTableComponent.prototype.rowClicked = function (row) {
        this.rowClick.emit(row);
    };
    CoreTableComponent.prototype.onExpandableRowClicked = function (row) {
        // Rows are not expandable
        if (!this.configuration.expandedRowTemplate) {
            return;
        }
        // Click on an already selected row
        if (this.selectedRow === row) {
            this.selectedRow = undefined;
            return;
        }
        this.selectedRow = row;
    };
    CoreTableComponent.prototype.reset = function () {
        this.paginator.pageIndex = 0;
        return _table_change_event__WEBPACK_IMPORTED_MODULE_18__["TableChangeEvent"].Init(new _models_table_request_parameters_model__WEBPACK_IMPORTED_MODULE_16__["TableRequestParameters"]({
            pageSize: this.paginator.pageSize,
            pageIndex: 0
        }, this.sort), []);
    };
    CoreTableComponent.prototype.isRightAligned = function (columnType) {
        return [
            _models_table_cell_type_enum__WEBPACK_IMPORTED_MODULE_13__["TableCellType"].NUMBER,
            _models_table_cell_type_enum__WEBPACK_IMPORTED_MODULE_13__["TableCellType"].NUMBERINT,
            _models_table_cell_type_enum__WEBPACK_IMPORTED_MODULE_13__["TableCellType"].NUMBERFLOAT1,
            _models_table_cell_type_enum__WEBPACK_IMPORTED_MODULE_13__["TableCellType"].NUMBERFLOAT2,
            _models_table_cell_type_enum__WEBPACK_IMPORTED_MODULE_13__["TableCellType"].PERCENT,
            _models_table_cell_type_enum__WEBPACK_IMPORTED_MODULE_13__["TableCellType"].TOPERCENT,
        ].includes(columnType);
    };
    CoreTableComponent.prototype.getClass = function (row) {
        if (_hazelnut_common_hazelnut__WEBPACK_IMPORTED_MODULE_8__["MiscUtils"].isFunction(this.configuration.trClassesCond)) {
            var elements = this.data ? this.data.totalElements : 0;
            return this.configuration.trClasses + " " + this.configuration.trClassesCond(row, elements);
        }
        return this.configuration.trClasses;
    };
    CoreTableComponent.prototype.resetFilters = function (guard) {
        if (guard) {
            this.filtersElementHolder.forEach(function (filter) { return filter.filtersElement.reset(); });
        }
    };
    CoreTableComponent.prototype.emitRequestParameters = function (changeEvent) {
        if (_hazelnut_common_hazelnut__WEBPACK_IMPORTED_MODULE_8__["MiscUtils"].isFunction(this.paginator.firstPage)) {
            var hasPrev = this.paginator.hasPreviousPage();
            this.paginator.firstPage();
            if (!hasPrev) {
                this.requestData.emit(changeEvent);
            }
        }
    };
    CoreTableComponent.prototype.setPageSize = function () {
        if (this.configuration.paging) {
            this.paginator.pageSize = this.configuration.pageSize;
        }
        else if (this.data && this.data.content) {
            this.paginator.pageSize = this.data.content.length;
        }
        else {
            this.paginator.pageSize = this.configuration.pageSize;
        }
    };
    CoreTableComponent.prototype.setNoDataKey = function () {
        if (!this.configuration.noDataText) {
            this.configuration.noDataText = this.translateWrapperService.instant(DEFAULT_NO_DATA_KEY);
        }
    };
    CoreTableComponent.prototype.setLabels = function () {
        var _this = this;
        this.configuration.columns.forEach(function (column) {
            if (typeof column.label === 'string' && _this.configuration.uppercaseHeader !== false) {
                column.label = column.label.toUpperCase();
            }
        });
    };
    CoreTableComponent.ctorParameters = function () { return [
        { type: undefined, decorators: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__["Inject"], args: [_hazelnut_common_interfaces__WEBPACK_IMPORTED_MODULE_9__["TRANSLATE_WRAPPER_TOKEN"],] }] },
        { type: undefined, decorators: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__["Inject"], args: [_small_components_notifications__WEBPACK_IMPORTED_MODULE_10__["NOTIFICATION_WRAPPER_TOKEN"],] }] },
        { type: _core_table_service__WEBPACK_IMPORTED_MODULE_11__["CoreTableService"] }
    ]; };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _models_table_configuration_model__WEBPACK_IMPORTED_MODULE_15__["TableConfiguration"])
    ], CoreTableComponent.prototype, "configuration", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _models_table_response_model__WEBPACK_IMPORTED_MODULE_17__["TableResponse"])
    ], CoreTableComponent.prototype, "data", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Output"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_2__["EventEmitter"])
    ], CoreTableComponent.prototype, "requestData", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Output"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_2__["EventEmitter"])
    ], CoreTableComponent.prototype, "selectionChange", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Output"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_2__["EventEmitter"])
    ], CoreTableComponent.prototype, "rowClick", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["ViewChild"])(_angular_material__WEBPACK_IMPORTED_MODULE_3__["MatPaginator"], { static: true }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_material__WEBPACK_IMPORTED_MODULE_3__["MatPaginator"])
    ], CoreTableComponent.prototype, "paginator", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["ViewChild"])(_angular_material__WEBPACK_IMPORTED_MODULE_3__["MatSort"], { static: true }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_material__WEBPACK_IMPORTED_MODULE_3__["MatSort"])
    ], CoreTableComponent.prototype, "sort", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["ViewChildren"])(_core_table_filter_core_table_filter_component__WEBPACK_IMPORTED_MODULE_19__["CoreTableFilterComponent"]),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_2__["QueryList"])
    ], CoreTableComponent.prototype, "filtersElementHolder", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["ViewChildren"])(_directives_expanded_detail_directive__WEBPACK_IMPORTED_MODULE_12__["ExpandedDetailDirective"]),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_2__["QueryList"])
    ], CoreTableComponent.prototype, "expandedDetailHosts", void 0);
    CoreTableComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Component"])({
            selector: 'haz-core-table',
            template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./core-table.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/shared/hazlenut/core-table/components/core-table.component.html")).default,
            animations: [_hazelnut_common_animations__WEBPACK_IMPORTED_MODULE_7__["detailExpand"]],
            providers: [_core_table_service__WEBPACK_IMPORTED_MODULE_11__["CoreTableService"]],
            styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./core-table.component.scss */ "./src/app/shared/hazlenut/core-table/components/core-table.component.scss")).default]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__param"](0, Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Inject"])(_hazelnut_common_interfaces__WEBPACK_IMPORTED_MODULE_9__["TRANSLATE_WRAPPER_TOKEN"])),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__param"](1, Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Inject"])(_small_components_notifications__WEBPACK_IMPORTED_MODULE_10__["NOTIFICATION_WRAPPER_TOKEN"])),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [Object, Object, _core_table_service__WEBPACK_IMPORTED_MODULE_11__["CoreTableService"]])
    ], CoreTableComponent);
    return CoreTableComponent;
}());



/***/ }),

/***/ "./src/app/shared/hazlenut/core-table/components/table-cell-clickable/table-cell-clickable.component.scss":
/*!****************************************************************************************************************!*\
  !*** ./src/app/shared/hazlenut/core-table/components/table-cell-clickable/table-cell-clickable.component.scss ***!
  \****************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3NoYXJlZC9oYXpsZW51dC9jb3JlLXRhYmxlL2NvbXBvbmVudHMvdGFibGUtY2VsbC1jbGlja2FibGUvdGFibGUtY2VsbC1jbGlja2FibGUuY29tcG9uZW50LnNjc3MifQ== */");

/***/ }),

/***/ "./src/app/shared/hazlenut/core-table/components/table-cell-clickable/table-cell-clickable.component.ts":
/*!**************************************************************************************************************!*\
  !*** ./src/app/shared/hazlenut/core-table/components/table-cell-clickable/table-cell-clickable.component.ts ***!
  \**************************************************************************************************************/
/*! exports provided: TableCellClickableComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TableCellClickableComponent", function() { return TableCellClickableComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");


var TableCellClickableComponent = /** @class */ (function () {
    function TableCellClickableComponent() {
    }
    TableCellClickableComponent.prototype.ngOnInit = function () {
        // Empty
    };
    TableCellClickableComponent.prototype.onClick = function () {
        this.params.callback(this.row);
    };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], TableCellClickableComponent.prototype, "row", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], TableCellClickableComponent.prototype, "params", void 0);
    TableCellClickableComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'haz-table-cell-clickable',
            template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./table-cell-clickable.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/shared/hazlenut/core-table/components/table-cell-clickable/table-cell-clickable.component.html")).default,
            styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./table-cell-clickable.component.scss */ "./src/app/shared/hazlenut/core-table/components/table-cell-clickable/table-cell-clickable.component.scss")).default]
        })
    ], TableCellClickableComponent);
    return TableCellClickableComponent;
}());



/***/ }),

/***/ "./src/app/shared/hazlenut/core-table/components/table-cell/table-cell.component.scss":
/*!********************************************************************************************!*\
  !*** ./src/app/shared/hazlenut/core-table/components/table-cell/table-cell.component.scss ***!
  \********************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".num-value {\n  display: inline-block;\n  text-align: right;\n}\n\ndiv {\n  width: 100%;\n}\n\n*[data-state=success] {\n  color: green;\n}\n\n*[data-state=fail] {\n  color: red;\n}\n\n.wrap-ellipsis {\n  max-width: 30vw;\n  white-space: nowrap;\n  overflow: hidden;\n  text-overflow: ellipsis;\n}\n\n.text-nowrap {\n  white-space: nowrap !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvc2hhcmVkL2hhemxlbnV0L2NvcmUtdGFibGUvY29tcG9uZW50cy90YWJsZS1jZWxsL0Q6XFxwcm9qZWN0c1xcaWloZlxcd2ZtLXdlYi9zcmNcXGFwcFxcc2hhcmVkXFxoYXpsZW51dFxcY29yZS10YWJsZVxcY29tcG9uZW50c1xcdGFibGUtY2VsbFxcdGFibGUtY2VsbC5jb21wb25lbnQuc2NzcyIsInNyYy9hcHAvc2hhcmVkL2hhemxlbnV0L2NvcmUtdGFibGUvY29tcG9uZW50cy90YWJsZS1jZWxsL3RhYmxlLWNlbGwuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxxQkFBQTtFQUNBLGlCQUFBO0FDQ0o7O0FERUE7RUFDSSxXQUFBO0FDQ0o7O0FERUE7RUFDSSxZQUFBO0FDQ0o7O0FERUE7RUFDSSxVQUFBO0FDQ0o7O0FERUE7RUFDSSxlQUFBO0VBQ0EsbUJBQUE7RUFDQSxnQkFBQTtFQUNBLHVCQUFBO0FDQ0o7O0FERUE7RUFDSSw4QkFBQTtBQ0NKIiwiZmlsZSI6InNyYy9hcHAvc2hhcmVkL2hhemxlbnV0L2NvcmUtdGFibGUvY29tcG9uZW50cy90YWJsZS1jZWxsL3RhYmxlLWNlbGwuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIubnVtLXZhbHVlIHtcclxuICAgIGRpc3BsYXk6IGlubGluZS1ibG9jaztcclxuICAgIHRleHQtYWxpZ246IHJpZ2h0O1xyXG59XHJcblxyXG5kaXYge1xyXG4gICAgd2lkdGg6IDEwMCU7XHJcbn1cclxuXHJcbipbZGF0YS1zdGF0ZT0nc3VjY2VzcyddIHtcclxuICAgIGNvbG9yOiBncmVlbjtcclxufVxyXG5cclxuKltkYXRhLXN0YXRlPSdmYWlsJ10ge1xyXG4gICAgY29sb3I6IHJlZDtcclxufVxyXG5cclxuLndyYXAtZWxsaXBzaXMge1xyXG4gICAgbWF4LXdpZHRoOiAzMHZ3O1xyXG4gICAgd2hpdGUtc3BhY2U6IG5vd3JhcDtcclxuICAgIG92ZXJmbG93OiBoaWRkZW47XHJcbiAgICB0ZXh0LW92ZXJmbG93OiBlbGxpcHNpcztcclxufVxyXG5cclxuLnRleHQtbm93cmFwIHtcclxuICAgIHdoaXRlLXNwYWNlOiBub3dyYXAgIWltcG9ydGFudDtcclxufVxyXG4iLCIubnVtLXZhbHVlIHtcbiAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xuICB0ZXh0LWFsaWduOiByaWdodDtcbn1cblxuZGl2IHtcbiAgd2lkdGg6IDEwMCU7XG59XG5cbipbZGF0YS1zdGF0ZT1zdWNjZXNzXSB7XG4gIGNvbG9yOiBncmVlbjtcbn1cblxuKltkYXRhLXN0YXRlPWZhaWxdIHtcbiAgY29sb3I6IHJlZDtcbn1cblxuLndyYXAtZWxsaXBzaXMge1xuICBtYXgtd2lkdGg6IDMwdnc7XG4gIHdoaXRlLXNwYWNlOiBub3dyYXA7XG4gIG92ZXJmbG93OiBoaWRkZW47XG4gIHRleHQtb3ZlcmZsb3c6IGVsbGlwc2lzO1xufVxuXG4udGV4dC1ub3dyYXAge1xuICB3aGl0ZS1zcGFjZTogbm93cmFwICFpbXBvcnRhbnQ7XG59Il19 */");

/***/ }),

/***/ "./src/app/shared/hazlenut/core-table/components/table-cell/table-cell.component.ts":
/*!******************************************************************************************!*\
  !*** ./src/app/shared/hazlenut/core-table/components/table-cell/table-cell.component.ts ***!
  \******************************************************************************************/
/*! exports provided: TableCellComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TableCellComponent", function() { return TableCellComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _hazelnut_common_hazelnut__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../hazelnut-common/hazelnut */ "./src/app/shared/hazlenut/hazelnut-common/hazelnut/index.ts");
/* harmony import */ var _models_table_cell_type_enum__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../models/table-cell-type.enum */ "./src/app/shared/hazlenut/core-table/models/table-cell-type.enum.ts");
/* harmony import */ var _models_table_column_model__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../models/table-column.model */ "./src/app/shared/hazlenut/core-table/models/table-column.model.ts");





var TableCellComponent = /** @class */ (function () {
    function TableCellComponent() {
        this.columnConfig = new _models_table_column_model__WEBPACK_IMPORTED_MODULE_4__["TableColumn"]({ columnDef: '', label: '' });
        this.tableCellType = _models_table_cell_type_enum__WEBPACK_IMPORTED_MODULE_3__["TableCellType"];
    }
    Object.defineProperty(TableCellComponent.prototype, "cellValue", {
        get: function () {
            return _hazelnut_common_hazelnut__WEBPACK_IMPORTED_MODULE_2__["ObjectUtils"].getNestedProperty(this.row, this.columnConfig.columnDef);
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(TableCellComponent.prototype, "customValue", {
        get: function () {
            if (!_hazelnut_common_hazelnut__WEBPACK_IMPORTED_MODULE_2__["MiscUtils"].isFunction(this.columnConfig.customValue)) {
                throw new Error('customValue method should be specified for the CUSTOM_VALUE table cell type');
            }
            return this.columnConfig.customValue(this.row);
        },
        enumerable: true,
        configurable: true
    });
    TableCellComponent.prototype.ngOnInit = function () {
    };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _models_table_column_model__WEBPACK_IMPORTED_MODULE_4__["TableColumn"])
    ], TableCellComponent.prototype, "columnConfig", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], TableCellComponent.prototype, "row", void 0);
    TableCellComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'haz-table-cell',
            template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./table-cell.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/shared/hazlenut/core-table/components/table-cell/table-cell.component.html")).default,
            styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./table-cell.component.scss */ "./src/app/shared/hazlenut/core-table/components/table-cell/table-cell.component.scss")).default]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
    ], TableCellComponent);
    return TableCellComponent;
}());



/***/ }),

/***/ "./src/app/shared/hazlenut/core-table/core-table-config.interface.ts":
/*!***************************************************************************!*\
  !*** ./src/app/shared/hazlenut/core-table/core-table-config.interface.ts ***!
  \***************************************************************************/
/*! exports provided: GLOBAL_CONFIG_TOKEN */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "GLOBAL_CONFIG_TOKEN", function() { return GLOBAL_CONFIG_TOKEN; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");


var GLOBAL_CONFIG_TOKEN = new _angular_core__WEBPACK_IMPORTED_MODULE_1__["InjectionToken"]('CoreTableConfiguration');


/***/ }),

/***/ "./src/app/shared/hazlenut/core-table/core-table.module.ts":
/*!*****************************************************************!*\
  !*** ./src/app/shared/hazlenut/core-table/core-table.module.ts ***!
  \*****************************************************************/
/*! exports provided: CoreTableModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CoreTableModule", function() { return CoreTableModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_flex_layout__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/flex-layout */ "./node_modules/@angular/flex-layout/esm5/flex-layout.es5.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ngx-translate/core */ "./node_modules/@ngx-translate/core/fesm5/ngx-translate-core.js");
/* harmony import */ var _pipes_pipes_module__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../pipes/pipes.module */ "./src/app/shared/pipes/pipes.module.ts");
/* harmony import */ var _abstract_inputs_abstract_inputs_module__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../abstract-inputs/abstract-inputs.module */ "./src/app/shared/hazlenut/abstract-inputs/abstract-inputs.module.ts");
/* harmony import */ var _hazelnut_common_material_material_module__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../hazelnut-common/material/material.module */ "./src/app/shared/hazlenut/hazelnut-common/material/material.module.ts");
/* harmony import */ var _hazelnut_common_pipes__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../hazelnut-common/pipes */ "./src/app/shared/hazlenut/hazelnut-common/pipes/index.ts");
/* harmony import */ var _components_core_table_filter_core_table_filter_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./components/core-table-filter/core-table-filter.component */ "./src/app/shared/hazlenut/core-table/components/core-table-filter/core-table-filter.component.ts");
/* harmony import */ var _components_core_table_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./components/core-table.component */ "./src/app/shared/hazlenut/core-table/components/core-table.component.ts");
/* harmony import */ var _components_table_cell_clickable_table_cell_clickable_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./components/table-cell-clickable/table-cell-clickable.component */ "./src/app/shared/hazlenut/core-table/components/table-cell-clickable/table-cell-clickable.component.ts");
/* harmony import */ var _components_table_cell_table_cell_component__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./components/table-cell/table-cell.component */ "./src/app/shared/hazlenut/core-table/components/table-cell/table-cell.component.ts");
/* harmony import */ var _core_table_config_interface__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./core-table-config.interface */ "./src/app/shared/hazlenut/core-table/core-table-config.interface.ts");
/* harmony import */ var _directives_expanded_detail_directive__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ./directives/expanded-detail.directive */ "./src/app/shared/hazlenut/core-table/directives/expanded-detail.directive.ts");
/* harmony import */ var _directives_table_cell_customized_directive__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ./directives/table-cell-customized.directive */ "./src/app/shared/hazlenut/core-table/directives/table-cell-customized.directive.ts");
/* harmony import */ var _directives_table_filter_customized_directive__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ./directives/table-filter-customized.directive */ "./src/app/shared/hazlenut/core-table/directives/table-filter-customized.directive.ts");


















var CoreTableModule = /** @class */ (function () {
    function CoreTableModule() {
    }
    CoreTableModule_1 = CoreTableModule;
    CoreTableModule.forRoot = function (config) {
        return {
            ngModule: CoreTableModule_1,
            providers: [
                { provide: _core_table_config_interface__WEBPACK_IMPORTED_MODULE_14__["GLOBAL_CONFIG_TOKEN"], useValue: config },
            ],
        };
    };
    var CoreTableModule_1;
    CoreTableModule = CoreTableModule_1 = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["NgModule"])({
            declarations: [
                _components_core_table_component__WEBPACK_IMPORTED_MODULE_11__["CoreTableComponent"],
                _components_core_table_filter_core_table_filter_component__WEBPACK_IMPORTED_MODULE_10__["CoreTableFilterComponent"],
                _directives_expanded_detail_directive__WEBPACK_IMPORTED_MODULE_15__["ExpandedDetailDirective"],
                _components_table_cell_clickable_table_cell_clickable_component__WEBPACK_IMPORTED_MODULE_12__["TableCellClickableComponent"],
                _components_table_cell_table_cell_component__WEBPACK_IMPORTED_MODULE_13__["TableCellComponent"],
                _directives_table_cell_customized_directive__WEBPACK_IMPORTED_MODULE_16__["TableCellCustomizedDirective"],
                _directives_table_filter_customized_directive__WEBPACK_IMPORTED_MODULE_17__["TableFilterCustomizedDirective"],
            ],
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormsModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_4__["ReactiveFormsModule"],
                _abstract_inputs_abstract_inputs_module__WEBPACK_IMPORTED_MODULE_7__["AbstractInputsModule"],
                _hazelnut_common_material_material_module__WEBPACK_IMPORTED_MODULE_8__["MaterialModule"],
                _angular_flex_layout__WEBPACK_IMPORTED_MODULE_3__["FlexLayoutModule"],
                _hazelnut_common_pipes__WEBPACK_IMPORTED_MODULE_9__["SharedPipesModule"],
                _ngx_translate_core__WEBPACK_IMPORTED_MODULE_5__["TranslateModule"].forChild(),
                _pipes_pipes_module__WEBPACK_IMPORTED_MODULE_6__["PipesModule"]
            ],
            providers: [_hazelnut_common_pipes__WEBPACK_IMPORTED_MODULE_9__["RoundToDecimalPipe"]],
            exports: [_components_core_table_component__WEBPACK_IMPORTED_MODULE_11__["CoreTableComponent"]],
        })
    ], CoreTableModule);
    return CoreTableModule;
}());



/***/ }),

/***/ "./src/app/shared/hazlenut/core-table/core-table.service.ts":
/*!******************************************************************!*\
  !*** ./src/app/shared/hazlenut/core-table/core-table.service.ts ***!
  \******************************************************************/
/*! exports provided: CoreTableService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CoreTableService", function() { return CoreTableService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm5/index.js");
/* harmony import */ var _hazelnut_common_hazelnut___WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../hazelnut-common/hazelnut/ */ "./src/app/shared/hazlenut/hazelnut-common/hazelnut/index.ts");
/* harmony import */ var _hazelnut_common_models__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../hazelnut-common/models */ "./src/app/shared/hazlenut/hazelnut-common/models/index.ts");
/* harmony import */ var _core_table_config_interface__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./core-table-config.interface */ "./src/app/shared/hazlenut/core-table/core-table-config.interface.ts");
/* harmony import */ var _models_table_filter_type_enum__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./models/table-filter-type.enum */ "./src/app/shared/hazlenut/core-table/models/table-filter-type.enum.ts");







var defaultDebounceTime = 500;
var microPageSizeOption = 10;
var miniPageSizeOption = 15;
var smallPageSizeOption = 20;
var mediumPageSizeOption = 50;
var largePageSizeOption = 100;
var DEFAULT_PAGE_SIZE_OPTIONS = [
    microPageSizeOption,
    miniPageSizeOption,
    smallPageSizeOption,
    mediumPageSizeOption,
    largePageSizeOption
];
var CoreTableService = /** @class */ (function () {
    function CoreTableService(globalTableConfig) {
        this.globalTableConfig = globalTableConfig;
        this.filtersSubject$ = new rxjs__WEBPACK_IMPORTED_MODULE_2__["BehaviorSubject"]([]);
        this.filters$ = this.filtersSubject$.asObservable();
        this.filters = [];
    }
    Object.defineProperty(CoreTableService.prototype, "configuration", {
        get: function () {
            return this._configuration;
        },
        enumerable: true,
        configurable: true
    });
    CoreTableService.prototype.clearFilters = function () {
        this.filters.splice(0, this.filters.length);
    };
    CoreTableService.prototype.addFilter = function (column, value) {
        var _this = this;
        var propertyName = column.columnDef;
        this.deleteExistingChangedFilters(_hazelnut_common_hazelnut___WEBPACK_IMPORTED_MODULE_3__["StringUtils"].convertCamelToSnakeUpper(propertyName));
        if (!value) {
            this.filtersSubject$.next(this.filters);
            return;
        }
        switch (column.filter.type) {
            case _models_table_filter_type_enum__WEBPACK_IMPORTED_MODULE_6__["TableFilterType"].SELECT: {
                this.filters.push(new _hazelnut_common_models__WEBPACK_IMPORTED_MODULE_4__["Filter"](propertyName, value, 'ENUM', 'EQ'));
                break;
            }
            case _models_table_filter_type_enum__WEBPACK_IMPORTED_MODULE_6__["TableFilterType"].TYPE: {
                this.filters.push(new _hazelnut_common_models__WEBPACK_IMPORTED_MODULE_4__["Filter"](propertyName, value, 'TYPE', 'EQ'));
                break;
            }
            case _models_table_filter_type_enum__WEBPACK_IMPORTED_MODULE_6__["TableFilterType"].SELECT_STRING: {
                this.filters.push(new _hazelnut_common_models__WEBPACK_IMPORTED_MODULE_4__["Filter"](propertyName, value, 'STRING', 'EQ'));
                break;
            }
            case _models_table_filter_type_enum__WEBPACK_IMPORTED_MODULE_6__["TableFilterType"].RESPONSIBLE: {
                this.filters.push(new _hazelnut_common_models__WEBPACK_IMPORTED_MODULE_4__["Filter"]('RESPONSIBLE_USER_ID', value, 'NUMBER', 'EQ'));
                break;
            }
            case _models_table_filter_type_enum__WEBPACK_IMPORTED_MODULE_6__["TableFilterType"].CATEGORY: {
                if (value !== 'All') {
                    this.filters.push(new _hazelnut_common_models__WEBPACK_IMPORTED_MODULE_4__["Filter"]('CATEGORY_NAME', value, 'STRING', 'EQ'));
                }
                break;
            }
            case _models_table_filter_type_enum__WEBPACK_IMPORTED_MODULE_6__["TableFilterType"].SELECT_NUMBER: {
                this.filters.push(new _hazelnut_common_models__WEBPACK_IMPORTED_MODULE_4__["Filter"](propertyName, value, 'NUMBER', 'EQ'));
                break;
            }
            case _models_table_filter_type_enum__WEBPACK_IMPORTED_MODULE_6__["TableFilterType"].SELECT_ANY_DATE_TIME: {
                this.filters.push(new _hazelnut_common_models__WEBPACK_IMPORTED_MODULE_4__["Filter"](propertyName, null, 'DATE_TIME', value));
                break;
            }
            case _models_table_filter_type_enum__WEBPACK_IMPORTED_MODULE_6__["TableFilterType"].STRING: {
                this.filters.push(new _hazelnut_common_models__WEBPACK_IMPORTED_MODULE_4__["Filter"](propertyName, value, column.filter.valueType, 'LIKE_IGNORE_CASE'));
                break;
            }
            case _models_table_filter_type_enum__WEBPACK_IMPORTED_MODULE_6__["TableFilterType"].NUMBER: {
                if (value.from) {
                    this.filters.push(new _hazelnut_common_models__WEBPACK_IMPORTED_MODULE_4__["Filter"](propertyName, value.from, 'NUMBER', 'GOE'));
                }
                if (value.to) {
                    this.filters.push(new _hazelnut_common_models__WEBPACK_IMPORTED_MODULE_4__["Filter"](propertyName, value.to, 'NUMBER', 'LOE'));
                }
                break;
            }
            case _models_table_filter_type_enum__WEBPACK_IMPORTED_MODULE_6__["TableFilterType"].DATERANGE: {
                if (value.dateFrom) {
                    this.filters.push(new _hazelnut_common_models__WEBPACK_IMPORTED_MODULE_4__["Filter"](propertyName, value.dateFrom, 'DATE', 'GOE'));
                }
                if (value.dateTo) {
                    this.filters.push(new _hazelnut_common_models__WEBPACK_IMPORTED_MODULE_4__["Filter"](propertyName, value.dateTo, 'DATE', 'LOE'));
                }
                break;
            }
            case _models_table_filter_type_enum__WEBPACK_IMPORTED_MODULE_6__["TableFilterType"].DATETIME_AS_DATERANGE: {
                this.createFiltersFromDatetimeRange(value, propertyName);
                break;
            }
            case _models_table_filter_type_enum__WEBPACK_IMPORTED_MODULE_6__["TableFilterType"].TRAFFIC_LIGHT: {
                if (value.length > 0) {
                    var colorArray = value.toString()
                        .split(',');
                    colorArray.forEach(function (color) {
                        _this.filters.push(new _hazelnut_common_models__WEBPACK_IMPORTED_MODULE_4__["Filter"](propertyName, color.toString()
                            .toLocaleUpperCase(), 'ENUM', 'EQ', 'OR'));
                    });
                }
                break;
            }
        }
        this.filtersSubject$.next(this.filters);
    };
    CoreTableService.prototype.processConfiguration = function (localConfig) {
        this._configuration = tslib__WEBPACK_IMPORTED_MODULE_0__["__assign"]({}, localConfig);
        // Paging config
        this.setPagingByProcessingConfiguration();
        // Uppercase header
        if (this._configuration.uppercaseHeader === undefined) {
            this._configuration.uppercaseHeader = this.globalTableConfig.uppercaseHeader !== undefined ? this.globalTableConfig.uppercaseHeader : true;
        }
        // Table row classes
        if (!this._configuration.trClasses) {
            this._configuration.trClasses = this.globalTableConfig.trClasses || '';
        }
        // Column borders displayed
        if (this._configuration.columnBorders === undefined) {
            this._configuration.columnBorders = this.globalTableConfig.columnBorders || false;
        }
        // Filter delay debounce
        if (!this._configuration.filterDebounceTime) {
            this._configuration.filterDebounceTime = this.globalTableConfig.filterDebounceTime || defaultDebounceTime;
        }
        // Text displayed when no data
        if (!this._configuration.noDataText) {
            this._configuration.noDataText = this.globalTableConfig.noDataText || '';
        }
        return this._configuration;
    };
    CoreTableService.prototype.deleteExistingChangedFilters = function (propertyName) {
        var _this = this;
        var filters = this.filters.filter(function (item) { return item.property === propertyName; });
        filters.forEach(function (filter) {
            _this.filters.splice(_this.filters.indexOf(filter), 1);
        });
    };
    CoreTableService.prototype.createFiltersFromDatetimeRange = function (value, propertyName) {
        value.dateFrom = value.dateFrom !== null ? new Date(value.dateFrom).toISOString() : value.dateFrom;
        if (value.dateFrom) {
            this.filters.push(new _hazelnut_common_models__WEBPACK_IMPORTED_MODULE_4__["Filter"](propertyName, value.dateFrom, 'DATE_TIME', 'GOE'));
        }
        if (value.dateTo) {
            this.filters.push(new _hazelnut_common_models__WEBPACK_IMPORTED_MODULE_4__["Filter"](propertyName, value.dateTo, 'DATE_TIME', 'LOE'));
        }
    };
    CoreTableService.prototype.setPagingByProcessingConfiguration = function () {
        if (!this._configuration.pageSizeOptions) {
            this._configuration.pageSizeOptions = this.globalTableConfig.pageSizeOptions || DEFAULT_PAGE_SIZE_OPTIONS;
        }
        if (this._configuration.paging === undefined) {
            this._configuration.paging = this.globalTableConfig.paging !== undefined ? this.globalTableConfig.paging : true;
        }
        if (!this._configuration.pageSize) {
            this._configuration.pageSize = this.globalTableConfig.pageSize || miniPageSizeOption;
        }
    };
    CoreTableService.ctorParameters = function () { return [
        { type: undefined, decorators: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["Inject"], args: [_core_table_config_interface__WEBPACK_IMPORTED_MODULE_5__["GLOBAL_CONFIG_TOKEN"],] }] }
    ]; };
    CoreTableService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__param"](0, Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Inject"])(_core_table_config_interface__WEBPACK_IMPORTED_MODULE_5__["GLOBAL_CONFIG_TOKEN"])),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [Object])
    ], CoreTableService);
    return CoreTableService;
}());



/***/ }),

/***/ "./src/app/shared/hazlenut/core-table/directives/expanded-detail.directive.ts":
/*!************************************************************************************!*\
  !*** ./src/app/shared/hazlenut/core-table/directives/expanded-detail.directive.ts ***!
  \************************************************************************************/
/*! exports provided: ExpandedDetailDirective */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ExpandedDetailDirective", function() { return ExpandedDetailDirective; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");


var ExpandedDetailDirective = /** @class */ (function () {
    function ExpandedDetailDirective(viewContainerRef) {
        this.viewContainerRef = viewContainerRef;
    }
    ExpandedDetailDirective.ctorParameters = function () { return [
        { type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"] }
    ]; };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", String)
    ], ExpandedDetailDirective.prototype, "row", void 0);
    ExpandedDetailDirective = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Directive"])({
            selector: '[appExpandedDetail]',
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"]])
    ], ExpandedDetailDirective);
    return ExpandedDetailDirective;
}());



/***/ }),

/***/ "./src/app/shared/hazlenut/core-table/directives/table-cell-customized.directive.ts":
/*!******************************************************************************************!*\
  !*** ./src/app/shared/hazlenut/core-table/directives/table-cell-customized.directive.ts ***!
  \******************************************************************************************/
/*! exports provided: TableCellCustomizedDirective */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TableCellCustomizedDirective", function() { return TableCellCustomizedDirective; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");


var TableCellCustomizedDirective = /** @class */ (function () {
    function TableCellCustomizedDirective(viewContainerRef) {
        this.viewContainerRef = viewContainerRef;
    }
    TableCellCustomizedDirective.ctorParameters = function () { return [
        { type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"] }
    ]; };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], TableCellCustomizedDirective.prototype, "component", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], TableCellCustomizedDirective.prototype, "params", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])('appTableCellCustomized'),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", String)
    ], TableCellCustomizedDirective.prototype, "row", void 0);
    TableCellCustomizedDirective = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Directive"])({
            selector: '[appTableCellCustomized]',
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"]])
    ], TableCellCustomizedDirective);
    return TableCellCustomizedDirective;
}());



/***/ }),

/***/ "./src/app/shared/hazlenut/core-table/directives/table-filter-customized.directive.ts":
/*!********************************************************************************************!*\
  !*** ./src/app/shared/hazlenut/core-table/directives/table-filter-customized.directive.ts ***!
  \********************************************************************************************/
/*! exports provided: TableFilterCustomizedDirective */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TableFilterCustomizedDirective", function() { return TableFilterCustomizedDirective; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");


var TableFilterCustomizedDirective = /** @class */ (function () {
    function TableFilterCustomizedDirective(viewContainerRef) {
        this.viewContainerRef = viewContainerRef;
    }
    TableFilterCustomizedDirective.ctorParameters = function () { return [
        { type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"] }
    ]; };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], TableFilterCustomizedDirective.prototype, "component", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], TableFilterCustomizedDirective.prototype, "params", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])('pzsTableFilterCustomized'),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", String)
    ], TableFilterCustomizedDirective.prototype, "row", void 0);
    TableFilterCustomizedDirective = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Directive"])({
            selector: '[appTableFilterCustomized]',
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"]])
    ], TableFilterCustomizedDirective);
    return TableFilterCustomizedDirective;
}());



/***/ }),

/***/ "./src/app/shared/hazlenut/core-table/index.ts":
/*!*****************************************************!*\
  !*** ./src/app/shared/hazlenut/core-table/index.ts ***!
  \*****************************************************/
/*! exports provided: CoreTableModule, CoreTableComponent, CoreTableFilterComponent, TableCellComponent, TableCellClickableComponent, ListItem, TableCellType, TableColumn, TableConfiguration, TableFilterType, TableColumnFilter, TableRequestParameters, TableResponse, ExpandedDetailDirective, TableCellCustomizedDirective, TableFilterCustomizedDirective, TableChangeType, TableChangeEvent, GLOBAL_CONFIG_TOKEN */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _core_table_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./core-table.module */ "./src/app/shared/hazlenut/core-table/core-table.module.ts");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "CoreTableModule", function() { return _core_table_module__WEBPACK_IMPORTED_MODULE_1__["CoreTableModule"]; });

/* harmony import */ var _components_core_table_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./components/core-table.component */ "./src/app/shared/hazlenut/core-table/components/core-table.component.ts");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "CoreTableComponent", function() { return _components_core_table_component__WEBPACK_IMPORTED_MODULE_2__["CoreTableComponent"]; });

/* harmony import */ var _components_core_table_filter_core_table_filter_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./components/core-table-filter/core-table-filter.component */ "./src/app/shared/hazlenut/core-table/components/core-table-filter/core-table-filter.component.ts");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "CoreTableFilterComponent", function() { return _components_core_table_filter_core_table_filter_component__WEBPACK_IMPORTED_MODULE_3__["CoreTableFilterComponent"]; });

/* harmony import */ var _components_table_cell_table_cell_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./components/table-cell/table-cell.component */ "./src/app/shared/hazlenut/core-table/components/table-cell/table-cell.component.ts");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "TableCellComponent", function() { return _components_table_cell_table_cell_component__WEBPACK_IMPORTED_MODULE_4__["TableCellComponent"]; });

/* harmony import */ var _components_table_cell_clickable_table_cell_clickable_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./components/table-cell-clickable/table-cell-clickable.component */ "./src/app/shared/hazlenut/core-table/components/table-cell-clickable/table-cell-clickable.component.ts");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "TableCellClickableComponent", function() { return _components_table_cell_clickable_table_cell_clickable_component__WEBPACK_IMPORTED_MODULE_5__["TableCellClickableComponent"]; });

/* harmony import */ var _models_list_item_model__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./models/list-item.model */ "./src/app/shared/hazlenut/core-table/models/list-item.model.ts");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "ListItem", function() { return _models_list_item_model__WEBPACK_IMPORTED_MODULE_6__["ListItem"]; });

/* harmony import */ var _models_table_cell_type_enum__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./models/table-cell-type.enum */ "./src/app/shared/hazlenut/core-table/models/table-cell-type.enum.ts");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "TableCellType", function() { return _models_table_cell_type_enum__WEBPACK_IMPORTED_MODULE_7__["TableCellType"]; });

/* harmony import */ var _models_table_column_model__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./models/table-column.model */ "./src/app/shared/hazlenut/core-table/models/table-column.model.ts");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "TableColumn", function() { return _models_table_column_model__WEBPACK_IMPORTED_MODULE_8__["TableColumn"]; });

/* harmony import */ var _models_table_configuration_model__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./models/table-configuration.model */ "./src/app/shared/hazlenut/core-table/models/table-configuration.model.ts");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "TableConfiguration", function() { return _models_table_configuration_model__WEBPACK_IMPORTED_MODULE_9__["TableConfiguration"]; });

/* harmony import */ var _models_table_filter_type_enum__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./models/table-filter-type.enum */ "./src/app/shared/hazlenut/core-table/models/table-filter-type.enum.ts");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "TableFilterType", function() { return _models_table_filter_type_enum__WEBPACK_IMPORTED_MODULE_10__["TableFilterType"]; });

/* harmony import */ var _models_table_column_filter_model__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./models/table-column-filter.model */ "./src/app/shared/hazlenut/core-table/models/table-column-filter.model.ts");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "TableColumnFilter", function() { return _models_table_column_filter_model__WEBPACK_IMPORTED_MODULE_11__["TableColumnFilter"]; });

/* harmony import */ var _models_table_request_parameters_model__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./models/table-request-parameters.model */ "./src/app/shared/hazlenut/core-table/models/table-request-parameters.model.ts");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "TableRequestParameters", function() { return _models_table_request_parameters_model__WEBPACK_IMPORTED_MODULE_12__["TableRequestParameters"]; });

/* harmony import */ var _models_table_response_model__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./models/table-response.model */ "./src/app/shared/hazlenut/core-table/models/table-response.model.ts");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "TableResponse", function() { return _models_table_response_model__WEBPACK_IMPORTED_MODULE_13__["TableResponse"]; });

/* harmony import */ var _directives_expanded_detail_directive__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./directives/expanded-detail.directive */ "./src/app/shared/hazlenut/core-table/directives/expanded-detail.directive.ts");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "ExpandedDetailDirective", function() { return _directives_expanded_detail_directive__WEBPACK_IMPORTED_MODULE_14__["ExpandedDetailDirective"]; });

/* harmony import */ var _directives_table_cell_customized_directive__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ./directives/table-cell-customized.directive */ "./src/app/shared/hazlenut/core-table/directives/table-cell-customized.directive.ts");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "TableCellCustomizedDirective", function() { return _directives_table_cell_customized_directive__WEBPACK_IMPORTED_MODULE_15__["TableCellCustomizedDirective"]; });

/* harmony import */ var _directives_table_filter_customized_directive__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ./directives/table-filter-customized.directive */ "./src/app/shared/hazlenut/core-table/directives/table-filter-customized.directive.ts");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "TableFilterCustomizedDirective", function() { return _directives_table_filter_customized_directive__WEBPACK_IMPORTED_MODULE_16__["TableFilterCustomizedDirective"]; });

/* harmony import */ var _table_change_event__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ./table-change-event */ "./src/app/shared/hazlenut/core-table/table-change-event.ts");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "TableChangeType", function() { return _table_change_event__WEBPACK_IMPORTED_MODULE_17__["TableChangeType"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "TableChangeEvent", function() { return _table_change_event__WEBPACK_IMPORTED_MODULE_17__["TableChangeEvent"]; });

/* harmony import */ var _core_table_config_interface__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ./core-table-config.interface */ "./src/app/shared/hazlenut/core-table/core-table-config.interface.ts");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "GLOBAL_CONFIG_TOKEN", function() { return _core_table_config_interface__WEBPACK_IMPORTED_MODULE_18__["GLOBAL_CONFIG_TOKEN"]; });






















/***/ }),

/***/ "./src/app/shared/hazlenut/core-table/models/list-item.model.ts":
/*!**********************************************************************!*\
  !*** ./src/app/shared/hazlenut/core-table/models/list-item.model.ts ***!
  \**********************************************************************/
/*! exports provided: ListItem */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ListItem", function() { return ListItem; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm5/index.js");


var ListItem = /** @class */ (function () {
    function ListItem(code, value) {
        if (typeof value === 'string') {
            this.value = Object(rxjs__WEBPACK_IMPORTED_MODULE_1__["of"])(value);
        }
        else {
            this.value = value;
        }
        if (typeof code === 'string') {
            this.code = Object(rxjs__WEBPACK_IMPORTED_MODULE_1__["of"])(code);
        }
        else {
            this.code = code;
        }
    }
    return ListItem;
}());



/***/ }),

/***/ "./src/app/shared/hazlenut/core-table/models/table-cell-type.enum.ts":
/*!***************************************************************************!*\
  !*** ./src/app/shared/hazlenut/core-table/models/table-cell-type.enum.ts ***!
  \***************************************************************************/
/*! exports provided: TableCellType */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TableCellType", function() { return TableCellType; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");

/**
 * @enum
 */
var TableCellType;
(function (TableCellType) {
    TableCellType["NUMBER"] = "number";
    TableCellType["NUMBER_SIMPLE"] = "numberSimple";
    TableCellType["FULFILLMENT"] = "fulfillment";
    TableCellType["PERCENT"] = "percent";
    TableCellType["TOPERCENT"] = "toPercent";
    TableCellType["DATE"] = "date";
    TableCellType["DATETIME"] = "dateTime";
    TableCellType["NUMBERINT"] = "numberInt";
    TableCellType["NUMBERFLOAT1"] = "numberFloat1";
    TableCellType["NUMBERFLOAT2"] = "numberFloat2";
    TableCellType["CONTENT"] = "content";
    TableCellType["CUSTOM_VALUE"] = "customValue";
})(TableCellType || (TableCellType = {}));


/***/ }),

/***/ "./src/app/shared/hazlenut/core-table/models/table-column-filter.model.ts":
/*!********************************************************************************!*\
  !*** ./src/app/shared/hazlenut/core-table/models/table-column-filter.model.ts ***!
  \********************************************************************************/
/*! exports provided: TableColumnFilter */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TableColumnFilter", function() { return TableColumnFilter; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _table_filter_type_enum__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./table-filter-type.enum */ "./src/app/shared/hazlenut/core-table/models/table-filter-type.enum.ts");


var TableColumnFilter = /** @class */ (function () {
    function TableColumnFilter(config) {
        this.config = config;
        this.enabled = true;
        this.type = _table_filter_type_enum__WEBPACK_IMPORTED_MODULE_1__["TableFilterType"].STRING;
        this.valueType = 'STRING';
        this.select = [];
        this.template = config.template;
        this.predefinedValue = config.predefinedValue;
        this.select = config.select || this.select;
        this.valueType = config.valueType || this.valueType;
        this.type = config.type || this.type;
        this.width = config.width;
        this.property = config.property;
        this.enabled = typeof config.enabled === 'boolean' ? config.enabled : this.enabled;
    }
    return TableColumnFilter;
}());



/***/ }),

/***/ "./src/app/shared/hazlenut/core-table/models/table-column.model.ts":
/*!*************************************************************************!*\
  !*** ./src/app/shared/hazlenut/core-table/models/table-column.model.ts ***!
  \*************************************************************************/
/*! exports provided: TableColumn */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TableColumn", function() { return TableColumn; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");

/**
 * Abstract table column configuration
 * @module TableColumn
 */
var TableColumn = /** @class */ (function () {
    function TableColumn(config) {
        this.config = config;
        this.sorting = false;
        this.columnDef = config.columnDef;
        this.label = config.label;
        this.type = config.type;
        this.sorting = config.sorting || this.sorting;
        this.filter = config.filter || this.filter;
        this.tableCellTemplate = config.tableCellTemplate;
        this.componentParams = config.componentParams;
        this.customValue = config.customValue;
        this.align = config.align;
        this.labelKey = config.labelKey;
    }
    Object.defineProperty(TableColumn.prototype, "filterElement", {
        /**
         * Get filterElement
         *
         * @returns The filter name
         * @get
         */
        get: function () {
            return this.columnDef + 'Filter';
        },
        enumerable: true,
        configurable: true
    });
    return TableColumn;
}());



/***/ }),

/***/ "./src/app/shared/hazlenut/core-table/models/table-configuration.model.ts":
/*!********************************************************************************!*\
  !*** ./src/app/shared/hazlenut/core-table/models/table-configuration.model.ts ***!
  \********************************************************************************/
/*! exports provided: TableConfiguration */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TableConfiguration", function() { return TableConfiguration; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");

/**
 * @module TableConfiguration
 */
var TableConfiguration = /** @class */ (function () {
    function TableConfiguration() {
        /**
         * Array of data contains configuration for every column
         *
         * @default []
         */
        this.columns = [];
        /**
         * Enable / Disable paginator
         *
         * @default false
         */
        this.paging = true;
        /**
         * Option for lowercase header to save width
         *
         */
        this.uppercaseHeader = true;
        /**
         * TODO:
         * @default true
         */
        this.selectable = true;
        /**
         * TODO:
         * @default "none"
         */
        this.selection = 'none';
        /**
         * Color of chceckbox when selection is single or multi
         * @default "primary"
         */
        this.selectionColor = 'primary';
        /**
         * Defines classes for tr elements
         *
         * @default ""
         */
        this.trClasses = '';
        /*
        public check: () => void  = () => {
            if (Array.isArray(this.columns)) {
                this.columns.forEach((column) => column.check());
            } else {
                console.warn("Attribute columns must be array!!");
            }
        }
        */
    }
    return TableConfiguration;
}());



/***/ }),

/***/ "./src/app/shared/hazlenut/core-table/models/table-filter-type.enum.ts":
/*!*****************************************************************************!*\
  !*** ./src/app/shared/hazlenut/core-table/models/table-filter-type.enum.ts ***!
  \*****************************************************************************/
/*! exports provided: TableFilterType */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TableFilterType", function() { return TableFilterType; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");

var TableFilterType;
(function (TableFilterType) {
    TableFilterType["DATE"] = "date";
    TableFilterType["DATERANGE"] = "dateRange";
    TableFilterType["DATETIME_AS_DATERANGE"] = "dateTimeAsDateRange";
    TableFilterType["SELECT"] = "select";
    TableFilterType["SELECT_STRING"] = "selectString";
    TableFilterType["SELECT_NUMBER"] = "selectNumber";
    TableFilterType["SELECT_ANY_DATE_TIME"] = "selectAnyDateTime";
    TableFilterType["TYPE"] = "type";
    TableFilterType["NUMBER"] = "number";
    TableFilterType["STRING"] = "string";
    TableFilterType["CUSTOM"] = "custom";
    TableFilterType["TRAFFIC_LIGHT"] = "trafficLight";
    TableFilterType["CLEAR_FILTERS"] = "clearFilters";
    TableFilterType["RESPONSIBLE"] = "responsible";
    TableFilterType["CATEGORY"] = "category";
})(TableFilterType || (TableFilterType = {}));


/***/ }),

/***/ "./src/app/shared/hazlenut/core-table/models/table-request-parameters.model.ts":
/*!*************************************************************************************!*\
  !*** ./src/app/shared/hazlenut/core-table/models/table-request-parameters.model.ts ***!
  \*************************************************************************************/
/*! exports provided: TableRequestParameters */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TableRequestParameters", function() { return TableRequestParameters; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");

var TableRequestParameters = /** @class */ (function () {
    function TableRequestParameters(paginator, sort) {
        var microPageSize = 10;
        this.pageSize = paginator ? paginator.pageSize : microPageSize;
        this.pageIndex = paginator ? paginator.pageIndex : 0;
        this.sortActive = (sort ? sort.active : '');
        this.sortDirection = sort ? sort.direction : '';
        // Handle sorting ListItem type fields
        if (this.sortActive) {
            this.sortActive = this.sortActive.replace('.value', 'Code');
        }
    }
    return TableRequestParameters;
}());



/***/ }),

/***/ "./src/app/shared/hazlenut/core-table/models/table-response.model.ts":
/*!***************************************************************************!*\
  !*** ./src/app/shared/hazlenut/core-table/models/table-response.model.ts ***!
  \***************************************************************************/
/*! exports provided: TableResponse */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TableResponse", function() { return TableResponse; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");

var TableResponse = /** @class */ (function () {
    function TableResponse(array) {
        if (array) {
            this.content = array;
            this.totalElements = array.length;
        }
    }
    return TableResponse;
}());



/***/ }),

/***/ "./src/app/shared/hazlenut/core-table/table-change-event.ts":
/*!******************************************************************!*\
  !*** ./src/app/shared/hazlenut/core-table/table-change-event.ts ***!
  \******************************************************************/
/*! exports provided: TableChangeType, TableChangeEvent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TableChangeType", function() { return TableChangeType; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TableChangeEvent", function() { return TableChangeEvent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _hazelnut_common_hazelnut__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../hazelnut-common/hazelnut */ "./src/app/shared/hazlenut/hazelnut-common/hazelnut/index.ts");


var TableChangeType;
(function (TableChangeType) {
    TableChangeType["FILTER"] = "FILTER";
    TableChangeType["SORT"] = "SORT";
    TableChangeType["PAGINATE"] = "PAGINATE";
    TableChangeType["INIT"] = "INIT";
})(TableChangeType || (TableChangeType = {}));
var TableChangeEvent = /** @class */ (function () {
    function TableChangeEvent(type, params, filters) {
        this.type = type;
        this.filters = [];
        this.pageIndex = params.pageIndex;
        this.pageSize = params.pageSize;
        if (params.sortActive) {
            this.sortDirection = _hazelnut_common_hazelnut__WEBPACK_IMPORTED_MODULE_1__["StringUtils"].convertCamelToSnakeUpper(params.sortDirection);
            this.sortActive = _hazelnut_common_hazelnut__WEBPACK_IMPORTED_MODULE_1__["StringUtils"].convertCamelToSnakeUpper(params.sortActive);
        }
        this.filters = filters;
    }
    TableChangeEvent.Init = function (params, filters) {
        return new TableChangeEvent(TableChangeType.INIT, params, filters);
    };
    TableChangeEvent.Sort = function (params, filters) {
        return new TableChangeEvent(TableChangeType.SORT, params, filters);
    };
    TableChangeEvent.Filter = function (params, filters) {
        return new TableChangeEvent(TableChangeType.FILTER, params, filters);
    };
    TableChangeEvent.Paginate = function (params, filters) {
        return new TableChangeEvent(TableChangeType.PAGINATE, params, filters);
    };
    TableChangeEvent.Create = function (type, params, filters) {
        return new TableChangeEvent(TableChangeType.PAGINATE, params, filters);
    };
    return TableChangeEvent;
}());



/***/ }),

/***/ "./src/app/shared/hazlenut/hazelnut-common/animations/animations.ts":
/*!**************************************************************************!*\
  !*** ./src/app/shared/hazlenut/hazelnut-common/animations/animations.ts ***!
  \**************************************************************************/
/*! exports provided: detailExpand, fadeEnterLeave, enterLeave, enterLeaveSmooth, routeAnimations, moveDown, moveLeft */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "detailExpand", function() { return detailExpand; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "fadeEnterLeave", function() { return fadeEnterLeave; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "enterLeave", function() { return enterLeave; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "enterLeaveSmooth", function() { return enterLeaveSmooth; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "routeAnimations", function() { return routeAnimations; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "moveDown", function() { return moveDown; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "moveLeft", function() { return moveLeft; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_animations__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/animations */ "./node_modules/@angular/animations/fesm5/animations.js");


var smallAmountOfTime = 400;
var detailExpand = Object(_angular_animations__WEBPACK_IMPORTED_MODULE_1__["trigger"])('detailExpand', [
    Object(_angular_animations__WEBPACK_IMPORTED_MODULE_1__["state"])('collapsed', Object(_angular_animations__WEBPACK_IMPORTED_MODULE_1__["style"])({ height: '0px', minHeight: '0', display: 'none' })),
    Object(_angular_animations__WEBPACK_IMPORTED_MODULE_1__["state"])('expanded', Object(_angular_animations__WEBPACK_IMPORTED_MODULE_1__["style"])({ height: '*' })),
    Object(_angular_animations__WEBPACK_IMPORTED_MODULE_1__["transition"])('expanded <=> collapsed', Object(_angular_animations__WEBPACK_IMPORTED_MODULE_1__["animate"])('225ms cubic-bezier(0.4, 0.0, 0.2, 1)')),
]);
var fadeEnterLeave = Object(_angular_animations__WEBPACK_IMPORTED_MODULE_1__["trigger"])('fadeEnterLeave', [
    Object(_angular_animations__WEBPACK_IMPORTED_MODULE_1__["state"])('in', Object(_angular_animations__WEBPACK_IMPORTED_MODULE_1__["style"])({ opacity: 1 })),
    Object(_angular_animations__WEBPACK_IMPORTED_MODULE_1__["transition"])('void => *', [
        Object(_angular_animations__WEBPACK_IMPORTED_MODULE_1__["style"])({
            opacity: 0,
        }),
        Object(_angular_animations__WEBPACK_IMPORTED_MODULE_1__["animate"])('0.4s ease-in'),
    ]),
    Object(_angular_animations__WEBPACK_IMPORTED_MODULE_1__["transition"])('* => void', [
        Object(_angular_animations__WEBPACK_IMPORTED_MODULE_1__["animate"])('0.2s 0.1s ease-out', Object(_angular_animations__WEBPACK_IMPORTED_MODULE_1__["style"])({
            opacity: 0,
        })),
    ]),
]);
var enterLeave = Object(_angular_animations__WEBPACK_IMPORTED_MODULE_1__["trigger"])('enterLeave', [
    Object(_angular_animations__WEBPACK_IMPORTED_MODULE_1__["transition"])(':enter', [
        Object(_angular_animations__WEBPACK_IMPORTED_MODULE_1__["style"])({ transform: 'translateY(-20%)' }),
        Object(_angular_animations__WEBPACK_IMPORTED_MODULE_1__["animate"])(smallAmountOfTime),
    ]),
    Object(_angular_animations__WEBPACK_IMPORTED_MODULE_1__["transition"])(':leave', [
        Object(_angular_animations__WEBPACK_IMPORTED_MODULE_1__["group"])([
            Object(_angular_animations__WEBPACK_IMPORTED_MODULE_1__["animate"])('0.3s ease', Object(_angular_animations__WEBPACK_IMPORTED_MODULE_1__["style"])({ height: '0px' })),
            Object(_angular_animations__WEBPACK_IMPORTED_MODULE_1__["animate"])('0.3s ease', Object(_angular_animations__WEBPACK_IMPORTED_MODULE_1__["style"])({ opacity: 0 })),
        ]),
    ]),
]);
var enterLeaveSmooth = Object(_angular_animations__WEBPACK_IMPORTED_MODULE_1__["trigger"])('enterLeaveSmooth', [
    Object(_angular_animations__WEBPACK_IMPORTED_MODULE_1__["transition"])(':enter', [
        Object(_angular_animations__WEBPACK_IMPORTED_MODULE_1__["style"])({ transform: 'translateY(-20%)', height: '*' }),
        Object(_angular_animations__WEBPACK_IMPORTED_MODULE_1__["animate"])(smallAmountOfTime),
    ]),
    Object(_angular_animations__WEBPACK_IMPORTED_MODULE_1__["transition"])(':leave', [
        Object(_angular_animations__WEBPACK_IMPORTED_MODULE_1__["group"])([
            Object(_angular_animations__WEBPACK_IMPORTED_MODULE_1__["animate"])('0.3s ease', Object(_angular_animations__WEBPACK_IMPORTED_MODULE_1__["style"])({ height: '0px' })),
            Object(_angular_animations__WEBPACK_IMPORTED_MODULE_1__["animate"])('0.3s ease', Object(_angular_animations__WEBPACK_IMPORTED_MODULE_1__["style"])({ opacity: 0 })),
        ]),
    ]),
]);
var routeAnimations = Object(_angular_animations__WEBPACK_IMPORTED_MODULE_1__["trigger"])('routeAnimations', [
    Object(_angular_animations__WEBPACK_IMPORTED_MODULE_1__["transition"])('* <=> *', [
        Object(_angular_animations__WEBPACK_IMPORTED_MODULE_1__["style"])({ position: 'relative', height: '90vh', overflow: 'hidden' }),
        Object(_angular_animations__WEBPACK_IMPORTED_MODULE_1__["query"])(':enter, :leave', [
            Object(_angular_animations__WEBPACK_IMPORTED_MODULE_1__["style"])({
                position: 'absolute',
                top: 0,
                left: 0,
                width: '100%',
                overflow: 'hidden'
            })
        ], { optional: true }),
        Object(_angular_animations__WEBPACK_IMPORTED_MODULE_1__["query"])(':enter', [Object(_angular_animations__WEBPACK_IMPORTED_MODULE_1__["style"])({ left: '-100%' })], { optional: true }),
        Object(_angular_animations__WEBPACK_IMPORTED_MODULE_1__["query"])(':leave', Object(_angular_animations__WEBPACK_IMPORTED_MODULE_1__["animateChild"])(), { optional: true }),
        Object(_angular_animations__WEBPACK_IMPORTED_MODULE_1__["group"])([
            Object(_angular_animations__WEBPACK_IMPORTED_MODULE_1__["query"])(':leave', [Object(_angular_animations__WEBPACK_IMPORTED_MODULE_1__["animate"])('200ms ease-out', Object(_angular_animations__WEBPACK_IMPORTED_MODULE_1__["style"])({ left: '100%' }))], { optional: true }),
            Object(_angular_animations__WEBPACK_IMPORTED_MODULE_1__["query"])(':enter', [Object(_angular_animations__WEBPACK_IMPORTED_MODULE_1__["animate"])('300ms ease-out', Object(_angular_animations__WEBPACK_IMPORTED_MODULE_1__["style"])({ left: '0%' }))], { optional: true })
        ]),
        Object(_angular_animations__WEBPACK_IMPORTED_MODULE_1__["query"])(':enter', Object(_angular_animations__WEBPACK_IMPORTED_MODULE_1__["animateChild"])(), { optional: true })
    ])
]);
var moveDown = Object(_angular_animations__WEBPACK_IMPORTED_MODULE_1__["trigger"])('moveDown', [
    Object(_angular_animations__WEBPACK_IMPORTED_MODULE_1__["transition"])('void => *', [
        Object(_angular_animations__WEBPACK_IMPORTED_MODULE_1__["style"])({
            transform: 'translateY(-50px)'
        }),
        Object(_angular_animations__WEBPACK_IMPORTED_MODULE_1__["animate"])('0.3s ease-in')
    ]),
    Object(_angular_animations__WEBPACK_IMPORTED_MODULE_1__["transition"])('* => void', [
        Object(_angular_animations__WEBPACK_IMPORTED_MODULE_1__["animate"])('0.1s 0.05s ease-out', Object(_angular_animations__WEBPACK_IMPORTED_MODULE_1__["style"])({
            transform: 'translateY(-50px)'
        }))
    ])
]);
var moveLeft = Object(_angular_animations__WEBPACK_IMPORTED_MODULE_1__["trigger"])('moveLeft', [
    Object(_angular_animations__WEBPACK_IMPORTED_MODULE_1__["transition"])('void => *', [
        Object(_angular_animations__WEBPACK_IMPORTED_MODULE_1__["style"])({
            transform: 'translateX(100px)'
        }),
        Object(_angular_animations__WEBPACK_IMPORTED_MODULE_1__["animate"])('0.3s ease-in')
    ]),
    Object(_angular_animations__WEBPACK_IMPORTED_MODULE_1__["transition"])('* => void', [
        Object(_angular_animations__WEBPACK_IMPORTED_MODULE_1__["animate"])('0.1s 0.05s ease-out', Object(_angular_animations__WEBPACK_IMPORTED_MODULE_1__["style"])({
            transform: 'translateX(100px)'
        }))
    ])
]);


/***/ }),

/***/ "./src/app/shared/hazlenut/hazelnut-common/animations/index.ts":
/*!*********************************************************************!*\
  !*** ./src/app/shared/hazlenut/hazelnut-common/animations/index.ts ***!
  \*********************************************************************/
/*! exports provided: detailExpand, fadeEnterLeave, enterLeave, enterLeaveSmooth, routeAnimations, moveDown, moveLeft */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _animations__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./animations */ "./src/app/shared/hazlenut/hazelnut-common/animations/animations.ts");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "detailExpand", function() { return _animations__WEBPACK_IMPORTED_MODULE_1__["detailExpand"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "fadeEnterLeave", function() { return _animations__WEBPACK_IMPORTED_MODULE_1__["fadeEnterLeave"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "enterLeave", function() { return _animations__WEBPACK_IMPORTED_MODULE_1__["enterLeave"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "enterLeaveSmooth", function() { return _animations__WEBPACK_IMPORTED_MODULE_1__["enterLeaveSmooth"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "routeAnimations", function() { return _animations__WEBPACK_IMPORTED_MODULE_1__["routeAnimations"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "moveDown", function() { return _animations__WEBPACK_IMPORTED_MODULE_1__["moveDown"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "moveLeft", function() { return _animations__WEBPACK_IMPORTED_MODULE_1__["moveLeft"]; });





/***/ }),

/***/ "./src/app/shared/hazlenut/hazelnut-common/components/index.ts":
/*!*********************************************************************!*\
  !*** ./src/app/shared/hazlenut/hazelnut-common/components/index.ts ***!
  \*********************************************************************/
/*! exports provided: SharedComponentsModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _shared_components_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./shared-components.module */ "./src/app/shared/hazlenut/hazelnut-common/components/shared-components.module.ts");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "SharedComponentsModule", function() { return _shared_components_module__WEBPACK_IMPORTED_MODULE_1__["SharedComponentsModule"]; });





/***/ }),

/***/ "./src/app/shared/hazlenut/hazelnut-common/components/shared-components.module.ts":
/*!****************************************************************************************!*\
  !*** ./src/app/shared/hazlenut/hazelnut-common/components/shared-components.module.ts ***!
  \****************************************************************************************/
/*! exports provided: SharedComponentsModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SharedComponentsModule", function() { return SharedComponentsModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");





var SharedComponentsModule = /** @class */ (function () {
    function SharedComponentsModule() {
    }
    SharedComponentsModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"],
            ],
            declarations: [],
            entryComponents: [],
            exports: [],
        })
    ], SharedComponentsModule);
    return SharedComponentsModule;
}());



/***/ }),

/***/ "./src/app/shared/hazlenut/hazelnut-common/config/hazelnut-config.ts":
/*!***************************************************************************!*\
  !*** ./src/app/shared/hazlenut/hazelnut-common/config/hazelnut-config.ts ***!
  \***************************************************************************/
/*! exports provided: initHazelnutConfig, hazelnutConfig */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "initHazelnutConfig", function() { return initHazelnutConfig; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "hazelnutConfig", function() { return hazelnutConfig; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");

var config;
var lastCall = false;
/**
 * Function return new immutable clone of parameter
 *
 * @param data - config file
 * @param lastInit - flag if this is last config initialization
 */
var createConfig = function (data, lastInit) {
    if (lastCall) {
        throw new Error('Cannot call function initHazelnutConfig after calling this function with \'lastInit\' flag set on true');
    }
    lastCall = lastInit;
    var proxyHandler = {
        get: function (obj, prop) {
            return obj[prop];
        },
        set: function () {
            throw new Error('Cannot rewrite config property');
        },
    };
    return new Proxy(data, proxyHandler);
};
/**
 * Wrapper around object implements {@HazelnutConfigInterface} and make this object immutable
 */
var ClassAppConfig = /** @class */ (function () {
    function ClassAppConfig() {
    }
    Object.defineProperty(ClassAppConfig.prototype, "URL_API", {
        get: function () {
            return ClassAppConfig._checkConfig().URL_API;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(ClassAppConfig.prototype, "BROWSE_LIMIT", {
        get: function () {
            return ClassAppConfig._checkConfig().BROWSE_LIMIT;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(ClassAppConfig.prototype, "LANGUAGE", {
        get: function () {
            return ClassAppConfig._checkConfig().LANGUAGE;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(ClassAppConfig.prototype, "VERSION", {
        get: function () {
            return ClassAppConfig._checkConfig().VERSION;
        },
        enumerable: true,
        configurable: true
    });
    ClassAppConfig._checkConfig = function () {
        if (!config) {
            throw new Error('App config must be initializes(HazelnutConfig.initHazelnutConfig({...params}))');
        }
        return config;
    };
    return ClassAppConfig;
}());
/**
 * Function create and return configuration object
 *
 * @param appConfig - configuration object
 * @param lastInit - flag if this is last call of {@link initHazelnutConfig}
 * @returns - created config object with readonly attributes
 *
 * @example
 * initHazelnutConfig({
 *    URL_API: "/",
 *    LANGUAGE: "sk",
 *    VERSION: "0.0.1",
 *    BROWSE_LIMIT: 10
 * })
 */
function initHazelnutConfig(appConfig, lastInit) {
    if (lastInit === void 0) { lastInit = false; }
    return config = createConfig(appConfig, lastInit);
}
/**
 * immutable instance of {@link ClassAppConfig}
 */
var hazelnutConfig = new ClassAppConfig();


/***/ }),

/***/ "./src/app/shared/hazlenut/hazelnut-common/directives/click/external-link.directive.ts":
/*!*********************************************************************************************!*\
  !*** ./src/app/shared/hazlenut/hazelnut-common/directives/click/external-link.directive.ts ***!
  \*********************************************************************************************/
/*! exports provided: ExternalLinkDirective */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ExternalLinkDirective", function() { return ExternalLinkDirective; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");


var ExternalLinkDirective = /** @class */ (function () {
    function ExternalLinkDirective() {
        this.appExternalLink = '';
    }
    ExternalLinkDirective.prototype.onClick = function ($event) {
        $event.preventDefault();
        $event.stopPropagation();
        window.open(this.appExternalLink, '_blank');
    };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], ExternalLinkDirective.prototype, "appExternalLink", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["HostListener"])('click', ['$event']),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Function),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [MouseEvent]),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:returntype", void 0)
    ], ExternalLinkDirective.prototype, "onClick", null);
    ExternalLinkDirective = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Directive"])({
            selector: '[appExternalLink]',
        })
    ], ExternalLinkDirective);
    return ExternalLinkDirective;
}());



/***/ }),

/***/ "./src/app/shared/hazlenut/hazelnut-common/directives/click/navigate.directive.ts":
/*!****************************************************************************************!*\
  !*** ./src/app/shared/hazlenut/hazelnut-common/directives/click/navigate.directive.ts ***!
  \****************************************************************************************/
/*! exports provided: NavigateDirective */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NavigateDirective", function() { return NavigateDirective; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");



var NavigateDirective = /** @class */ (function () {
    function NavigateDirective(router) {
        this.router = router;
    }
    NavigateDirective.prototype.onClick = function () {
        this.router.navigate([this.navigate]);
    };
    NavigateDirective.ctorParameters = function () { return [
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"] }
    ]; };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", String)
    ], NavigateDirective.prototype, "navigate", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["HostListener"])('click'),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Function),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", []),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:returntype", void 0)
    ], NavigateDirective.prototype, "onClick", null);
    NavigateDirective = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Directive"])({
            selector: '[navigate]'
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]])
    ], NavigateDirective);
    return NavigateDirective;
}());



/***/ }),

/***/ "./src/app/shared/hazlenut/hazelnut-common/directives/drag-drop.directive.ts":
/*!***********************************************************************************!*\
  !*** ./src/app/shared/hazlenut/hazelnut-common/directives/drag-drop.directive.ts ***!
  \***********************************************************************************/
/*! exports provided: DragDropDirective */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DragDropDirective", function() { return DragDropDirective; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");


var DragDropDirective = /** @class */ (function () {
    function DragDropDirective() {
        this.onFileDropped = new _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"]();
    }
    DragDropDirective.prototype.onDragOver = function (event) {
        event.preventDefault();
        event.stopPropagation();
    };
    DragDropDirective.prototype.onDragLeave = function (event) {
        event.preventDefault();
        event.stopPropagation();
    };
    DragDropDirective.prototype.ondrop = function (event) {
        event.preventDefault();
        event.stopPropagation();
        var files = event.dataTransfer.files;
        if (files.length > 0) {
            this.onFileDropped.emit(files);
        }
    };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Output"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], DragDropDirective.prototype, "onFileDropped", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["HostListener"])('dragover', ['$event']),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Function),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [Object]),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:returntype", void 0)
    ], DragDropDirective.prototype, "onDragOver", null);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["HostListener"])('dragleave', ['$event']),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Function),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [Object]),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:returntype", void 0)
    ], DragDropDirective.prototype, "onDragLeave", null);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["HostListener"])('drop', ['$event']),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Function),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [Object]),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:returntype", void 0)
    ], DragDropDirective.prototype, "ondrop", null);
    DragDropDirective = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Directive"])({
            selector: '[dragDrop]'
        })
    ], DragDropDirective);
    return DragDropDirective;
}());



/***/ }),

/***/ "./src/app/shared/hazlenut/hazelnut-common/directives/index.ts":
/*!*********************************************************************!*\
  !*** ./src/app/shared/hazlenut/hazelnut-common/directives/index.ts ***!
  \*********************************************************************/
/*! exports provided: ExternalLinkDirective, SharedDirectivesModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _click_external_link_directive__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./click/external-link.directive */ "./src/app/shared/hazlenut/hazelnut-common/directives/click/external-link.directive.ts");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "ExternalLinkDirective", function() { return _click_external_link_directive__WEBPACK_IMPORTED_MODULE_1__["ExternalLinkDirective"]; });

/* harmony import */ var _shared_directives_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./shared-directives.module */ "./src/app/shared/hazlenut/hazelnut-common/directives/shared-directives.module.ts");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "SharedDirectivesModule", function() { return _shared_directives_module__WEBPACK_IMPORTED_MODULE_2__["SharedDirectivesModule"]; });






/***/ }),

/***/ "./src/app/shared/hazlenut/hazelnut-common/directives/shared-directives.module.ts":
/*!****************************************************************************************!*\
  !*** ./src/app/shared/hazlenut/hazelnut-common/directives/shared-directives.module.ts ***!
  \****************************************************************************************/
/*! exports provided: SharedDirectivesModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SharedDirectivesModule", function() { return SharedDirectivesModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _click_external_link_directive__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./click/external-link.directive */ "./src/app/shared/hazlenut/hazelnut-common/directives/click/external-link.directive.ts");
/* harmony import */ var _click_navigate_directive__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./click/navigate.directive */ "./src/app/shared/hazlenut/hazelnut-common/directives/click/navigate.directive.ts");
/* harmony import */ var _drag_drop_directive__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./drag-drop.directive */ "./src/app/shared/hazlenut/hazelnut-common/directives/drag-drop.directive.ts");






var SharedDirectivesModule = /** @class */ (function () {
    function SharedDirectivesModule() {
    }
    SharedDirectivesModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"],
            ],
            declarations: [
                _click_external_link_directive__WEBPACK_IMPORTED_MODULE_3__["ExternalLinkDirective"], _click_navigate_directive__WEBPACK_IMPORTED_MODULE_4__["NavigateDirective"], _drag_drop_directive__WEBPACK_IMPORTED_MODULE_5__["DragDropDirective"]
            ],
            exports: [
                _click_external_link_directive__WEBPACK_IMPORTED_MODULE_3__["ExternalLinkDirective"], _click_navigate_directive__WEBPACK_IMPORTED_MODULE_4__["NavigateDirective"], _drag_drop_directive__WEBPACK_IMPORTED_MODULE_5__["DragDropDirective"]
            ],
        })
    ], SharedDirectivesModule);
    return SharedDirectivesModule;
}());



/***/ }),

/***/ "./src/app/shared/hazlenut/hazelnut-common/enums/number-type.enum.ts":
/*!***************************************************************************!*\
  !*** ./src/app/shared/hazlenut/hazelnut-common/enums/number-type.enum.ts ***!
  \***************************************************************************/
/*! exports provided: NumberType */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NumberType", function() { return NumberType; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");

var NumberType;
(function (NumberType) {
    NumberType[NumberType["INTEGER"] = 0] = "INTEGER";
    NumberType[NumberType["POSITIVE_INTEGER"] = 1] = "POSITIVE_INTEGER";
    NumberType[NumberType["FLOAT"] = 2] = "FLOAT";
    NumberType[NumberType["POSITIVE_FLOAT"] = 3] = "POSITIVE_FLOAT";
    NumberType[NumberType["HEXA"] = 4] = "HEXA";
})(NumberType || (NumberType = {}));


/***/ }),

/***/ "./src/app/shared/hazlenut/hazelnut-common/hazelnut-common.module.ts":
/*!***************************************************************************!*\
  !*** ./src/app/shared/hazlenut/hazelnut-common/hazelnut-common.module.ts ***!
  \***************************************************************************/
/*! exports provided: HazelnutCommonModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HazelnutCommonModule", function() { return HazelnutCommonModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./components */ "./src/app/shared/hazlenut/hazelnut-common/components/index.ts");
/* harmony import */ var _directives__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./directives */ "./src/app/shared/hazlenut/hazelnut-common/directives/index.ts");
/* harmony import */ var _pipes__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./pipes */ "./src/app/shared/hazlenut/hazelnut-common/pipes/index.ts");






var HazelnutCommonModule = /** @class */ (function () {
    function HazelnutCommonModule() {
    }
    HazelnutCommonModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["NgModule"])({
            declarations: [],
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"],
                _components__WEBPACK_IMPORTED_MODULE_3__["SharedComponentsModule"],
                _directives__WEBPACK_IMPORTED_MODULE_4__["SharedDirectivesModule"],
                _pipes__WEBPACK_IMPORTED_MODULE_5__["SharedPipesModule"],
            ],
            exports: [
                _components__WEBPACK_IMPORTED_MODULE_3__["SharedComponentsModule"],
                _directives__WEBPACK_IMPORTED_MODULE_4__["SharedDirectivesModule"],
                _pipes__WEBPACK_IMPORTED_MODULE_5__["SharedPipesModule"],
            ],
        })
    ], HazelnutCommonModule);
    return HazelnutCommonModule;
}());



/***/ }),

/***/ "./src/app/shared/hazlenut/hazelnut-common/hazelnut/index.ts":
/*!*******************************************************************!*\
  !*** ./src/app/shared/hazlenut/hazelnut-common/hazelnut/index.ts ***!
  \*******************************************************************/
/*! exports provided: MathUtils, DomUtils, MiscUtils, StringUtils, contains, ObjectUtils, TimeUtils, Regexp */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _utils_math_utils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./utils/math.utils */ "./src/app/shared/hazlenut/hazelnut-common/hazelnut/utils/math.utils.ts");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "MathUtils", function() { return _utils_math_utils__WEBPACK_IMPORTED_MODULE_1__["MathUtils"]; });

/* harmony import */ var _utils_dom_utils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./utils/dom.utils */ "./src/app/shared/hazlenut/hazelnut-common/hazelnut/utils/dom.utils.ts");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "DomUtils", function() { return _utils_dom_utils__WEBPACK_IMPORTED_MODULE_2__["DomUtils"]; });

/* harmony import */ var _utils_misc_utils__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./utils/misc.utils */ "./src/app/shared/hazlenut/hazelnut-common/hazelnut/utils/misc.utils.ts");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "MiscUtils", function() { return _utils_misc_utils__WEBPACK_IMPORTED_MODULE_3__["MiscUtils"]; });

/* harmony import */ var _utils_string_utils__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./utils/string.utils */ "./src/app/shared/hazlenut/hazelnut-common/hazelnut/utils/string.utils.ts");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "StringUtils", function() { return _utils_string_utils__WEBPACK_IMPORTED_MODULE_4__["StringUtils"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "contains", function() { return _utils_string_utils__WEBPACK_IMPORTED_MODULE_4__["contains"]; });

/* harmony import */ var _utils_object_utils__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./utils/object.utils */ "./src/app/shared/hazlenut/hazelnut-common/hazelnut/utils/object.utils.ts");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "ObjectUtils", function() { return _utils_object_utils__WEBPACK_IMPORTED_MODULE_5__["ObjectUtils"]; });

/* harmony import */ var _utils_time_utils__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./utils/time.utils */ "./src/app/shared/hazlenut/hazelnut-common/hazelnut/utils/time.utils.ts");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "TimeUtils", function() { return _utils_time_utils__WEBPACK_IMPORTED_MODULE_6__["TimeUtils"]; });

/* harmony import */ var _others_regexp__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./others/regexp */ "./src/app/shared/hazlenut/hazelnut-common/hazelnut/others/regexp.ts");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "Regexp", function() { return _others_regexp__WEBPACK_IMPORTED_MODULE_7__["Regexp"]; });











/***/ }),

/***/ "./src/app/shared/hazlenut/hazelnut-common/hazelnut/others/regexp.ts":
/*!***************************************************************************!*\
  !*** ./src/app/shared/hazlenut/hazelnut-common/hazelnut/others/regexp.ts ***!
  \***************************************************************************/
/*! exports provided: Regexp */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Regexp", function() { return Regexp; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");

// @dynamic
var Regexp = /** @class */ (function () {
    function Regexp() {
    }
    Regexp.validPhoneNumberRegex = /^([+]|00)?[(]?[0-9]{3,4}[)]?[-\s.]?[0-9]{2,3}[-\s.]?[0-9]{2,6}([-\s.]?[0-9]{3})?$/im;
    // Format d.M.yyyy
    Regexp.dateSimpleDotPattern = /^(((0?[1-9])|([12][0-9])|([3][0-1]))\.((0?[1-9])|(1[0-2]))\.[0-9]{4})?$/;
    Regexp.numericCharactersPattern = '^-?(\\d*)?$';
    return Regexp;
}());



/***/ }),

/***/ "./src/app/shared/hazlenut/hazelnut-common/hazelnut/utils/dom.utils.ts":
/*!*****************************************************************************!*\
  !*** ./src/app/shared/hazlenut/hazelnut-common/hazelnut/utils/dom.utils.ts ***!
  \*****************************************************************************/
/*! exports provided: DomUtils */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DomUtils", function() { return DomUtils; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");

var DomUtils = /** @class */ (function () {
    function DomUtils() {
    }
    DomUtils.getWidth = function () {
        // @ts-ignore
        return window.innerWidth || document.documentElement.clientWidth || document.body.clientWidth;
    };
    return DomUtils;
}());



/***/ }),

/***/ "./src/app/shared/hazlenut/hazelnut-common/hazelnut/utils/math.utils.ts":
/*!******************************************************************************!*\
  !*** ./src/app/shared/hazlenut/hazelnut-common/hazelnut/utils/math.utils.ts ***!
  \******************************************************************************/
/*! exports provided: MathUtils */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MathUtils", function() { return MathUtils; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _enums_number_type_enum__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../enums/number-type.enum */ "./src/app/shared/hazlenut/hazelnut-common/enums/number-type.enum.ts");


var groupingSeparatorsRegexp = '[ _]';
var decimalSeparatorsRegexp = '[.,]';
var replaceGroupingSeparators = function (value, groupingSeparator) {
    if (value.match(new RegExp(groupingSeparatorsRegexp + '\\d{3}'))) { // If number contains grouping separator
        return value.replace(new RegExp(groupingSeparatorsRegexp, 'g'), groupingSeparator);
    }
    return value;
};
var replaceDecimalSeparators = function (value, decimalSeparator) {
    if (value.match(new RegExp("\\d" + decimalSeparatorsRegexp + "\\d"))) { // If number contains grouping separator
        return value.replace(new RegExp(decimalSeparatorsRegexp, 'g'), decimalSeparator);
    }
    return value;
};
var MathUtils = /** @class */ (function () {
    function MathUtils() {
    }
    MathUtils.roundToDecimals = function (number, decimals, noDecimalsForRounded) {
        if (decimals === void 0) { decimals = 2; }
        if (noDecimalsForRounded === void 0) { noDecimalsForRounded = false; }
        var divider = parseInt(1 + new Array(decimals + 1).join('0'), 10);
        if (noDecimalsForRounded && number % 1 === 0) {
            decimals = 0;
        }
        return (Math.round(number * divider) / divider).toFixed(decimals);
    };
    MathUtils.intToHexa = function (num) {
        var hexString = num.toString(16);
        if (hexString.length % 2) {
            return '0' + hexString;
        }
        return hexString;
    };
    MathUtils.validateValue = function (_a) {
        var value = _a.value, type = _a.type, _b = _a.defaultValue, defaultValue = _b === void 0 ? value : _b, _c = _a.decimalSeparator, decimalSeparator = _c === void 0 ? '.' : _c, _d = _a.groupingSeparator, groupingSeparator = _d === void 0 ? '' : _d;
        switch (type) {
            case _enums_number_type_enum__WEBPACK_IMPORTED_MODULE_1__["NumberType"].INTEGER:
                if (typeof value === 'string') {
                    value = replaceGroupingSeparators(String(value), groupingSeparator);
                }
                return value;
            case _enums_number_type_enum__WEBPACK_IMPORTED_MODULE_1__["NumberType"].POSITIVE_INTEGER:
                if (typeof value === 'string') {
                    value = value.replace(/-/, '');
                    value = replaceGroupingSeparators(String(value), groupingSeparator);
                }
                return value;
            case _enums_number_type_enum__WEBPACK_IMPORTED_MODULE_1__["NumberType"].HEXA:
                return MathUtils.intToHexa(parseInt(String(value), 10) || defaultValue);
            case _enums_number_type_enum__WEBPACK_IMPORTED_MODULE_1__["NumberType"].POSITIVE_FLOAT:
                if (typeof value === 'string') {
                    value = value.replace('-', '');
                    value = replaceGroupingSeparators(String(value), groupingSeparator);
                    value = replaceDecimalSeparators(String(value), decimalSeparator);
                }
                return value;
            case _enums_number_type_enum__WEBPACK_IMPORTED_MODULE_1__["NumberType"].FLOAT:
                if (typeof value === 'string') {
                    value = replaceGroupingSeparators(String(value), groupingSeparator);
                    value = replaceDecimalSeparators(String(value), decimalSeparator);
                }
                return value;
            default:
                throw new Error('Unknown number type: ' + type);
        }
    };
    return MathUtils;
}());



/***/ }),

/***/ "./src/app/shared/hazlenut/hazelnut-common/hazelnut/utils/misc.utils.ts":
/*!******************************************************************************!*\
  !*** ./src/app/shared/hazlenut/hazelnut-common/hazelnut/utils/misc.utils.ts ***!
  \******************************************************************************/
/*! exports provided: MiscUtils */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MiscUtils", function() { return MiscUtils; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");

var temporaryErrors = {
    'timeout': 'error.timeout',
    'no matching constant for [555]': 'error.unknownConstant555',
};
var MiscUtils = /** @class */ (function () {
    function MiscUtils() {
    }
    MiscUtils.getErrorMessage = function (error) {
        var textMessageKey = 'error.system_error';
        if (typeof error === 'string') {
            textMessageKey = error;
        }
        else if (error.error) {
            var errorJson = error.error;
            if (errorJson.message) {
                textMessageKey = errorJson.message;
            }
        }
        else if (error.message) {
            textMessageKey = error.message;
        }
        return temporaryErrors[textMessageKey.toLocaleLowerCase().trim()] || textMessageKey;
    };
    MiscUtils.isFunction = function (arg) {
        return typeof arg === 'function';
    };
    return MiscUtils;
}());



/***/ }),

/***/ "./src/app/shared/hazlenut/hazelnut-common/hazelnut/utils/object.utils.ts":
/*!********************************************************************************!*\
  !*** ./src/app/shared/hazlenut/hazelnut-common/hazelnut/utils/object.utils.ts ***!
  \********************************************************************************/
/*! exports provided: ObjectUtils */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ObjectUtils", function() { return ObjectUtils; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");

var ObjectUtils = /** @class */ (function () {
    function ObjectUtils() {
    }
    ObjectUtils.getNestedProperty = function (object, propertyPath, separator) {
        if (separator === void 0) { separator = '.'; }
        var propertyList = propertyPath.split(separator);
        return propertyList.reduce(function (currentNestedPropertyValue, propertyName) {
            return currentNestedPropertyValue ? currentNestedPropertyValue[propertyName] : undefined;
        }, object);
    };
    return ObjectUtils;
}());



/***/ }),

/***/ "./src/app/shared/hazlenut/hazelnut-common/hazelnut/utils/string.utils.ts":
/*!********************************************************************************!*\
  !*** ./src/app/shared/hazlenut/hazelnut-common/hazelnut/utils/string.utils.ts ***!
  \********************************************************************************/
/*! exports provided: StringUtils, contains */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "StringUtils", function() { return StringUtils; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "contains", function() { return contains; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var ___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! .. */ "./src/app/shared/hazlenut/hazelnut-common/hazelnut/index.ts");


var accentedLowerCharacters = 'ąàáäâãåæăćčĉďęèéëêĝĥìíïîĵłľńňòóöőôõðøśșşšŝťțţŭùúüűûñÿýçżźž';
var normalLowerCharacters = 'aaaaaaaaacccdeeeeeghiiiijllnnoooooooossssstttuuuuuunyyczzz';
var accentedCharacters = accentedLowerCharacters + accentedLowerCharacters.toUpperCase();
var normalCharacters = normalLowerCharacters + normalLowerCharacters.toUpperCase();
function addLeadingZero(text) {
    return '0' + text;
}
var StringUtils = /** @class */ (function () {
    function StringUtils() {
    }
    StringUtils.toLowerCaseWithDot = function (value) {
        return value.replace(' ', '.')
            .toLowerCase();
    };
    StringUtils.compareInDotLowerCase = function (firstString, secondString) {
        return StringUtils.toLowerCaseWithDot(firstString) === StringUtils.toLowerCaseWithDot(secondString);
    };
    StringUtils.removeAccentedCharacters = function (word) {
        if (!word || !word.replace) {
            return word;
        }
        return word.replace(/./g, function (e) {
            var index = accentedCharacters.indexOf(e);
            return index >= 0 ? normalCharacters[index] : e;
        });
    };
    StringUtils.join = function (data, delimiter, prefix, postfix) {
        if (delimiter === void 0) { delimiter = ' '; }
        if (prefix === void 0) { prefix = ''; }
        if (postfix === void 0) { postfix = ''; }
        if (!Array.isArray(data)) {
            return prefix + data + postfix;
        }
        return "" + prefix + data.join(delimiter) + postfix;
    };
    StringUtils.isValidPhoneNumber = function (phoneNumber) {
        if (!phoneNumber) {
            return false;
        }
        return ___WEBPACK_IMPORTED_MODULE_1__["Regexp"].validPhoneNumberRegex.test(phoneNumber.trim());
    };
    StringUtils.getLastPart = function (text, divider) {
        if (divider === void 0) { divider = ' '; }
        if (!text) {
            return text;
        }
        var splitText = text.split(divider);
        if (splitText.length === 0) {
            return text;
        }
        return splitText[splitText.length - 1];
    };
    StringUtils.toBasicForm = function (text) {
        return StringUtils.removeAccentedCharacters(text.toLowerCase());
    };
    StringUtils.contains = function (text, substring) {
        return !!text && StringUtils.removeAccentedCharacters(text.toLowerCase())
            .indexOf(substring) >= 0;
    };
    StringUtils.getFormattedNumber = function (phoneNumber, prefix) {
        if (prefix === void 0) { prefix = '+421'; }
        phoneNumber = phoneNumber.replace(/[( )/-]/g, '');
        if (phoneNumber.startsWith('+')) {
            return phoneNumber;
        }
        if (phoneNumber.startsWith('00')) {
            return phoneNumber.substring(2);
        }
        if (phoneNumber.startsWith('09') || phoneNumber.startsWith('02')) {
            return prefix + phoneNumber.substring(1);
        }
        return phoneNumber;
    };
    StringUtils.format = function (text, args) {
        for (var property in args) {
            if (args.hasOwnProperty(property)) {
                text = text.replace("${" + property + "}", args[property]);
            }
        }
        return text;
    };
    StringUtils.convertDateStringToDotString = function (date) {
        var dateObject = new Date(date);
        var day = dateObject.getDate() + '';
        var month = (dateObject.getMonth() + 1) + '';
        var year = dateObject.getFullYear();
        return day + "." + month + "." + year;
    };
    StringUtils.convertCamelToSnakeUpper = function (camelCaseString) {
        return StringUtils.convertCamelToSnake(camelCaseString)
            .toUpperCase();
    };
    StringUtils.convertCamelToSnake = function (camelCaseString) {
        return camelCaseString.replace(/([a-z])([A-Z])/g, '$1_$2');
    };
    StringUtils.convertSnakeToCamel = function (snakeCaseString) {
        if (!snakeCaseString) {
            return snakeCaseString;
        }
        return snakeCaseString.toLowerCase()
            .replace(/(_[a-z])+/g, function (element) { return element.toUpperCase(); })
            .replace('_', '');
    };
    StringUtils.convertDateStringToIsoString = function (date) {
        var dateObject = new Date(date);
        var day = dateObject.getDate() + '';
        var month = (dateObject.getMonth() + 1) + '';
        var year = dateObject.getFullYear();
        if (month.length < 2) {
            month = addLeadingZero(month);
        }
        if (day.length < 2) {
            day = addLeadingZero(day);
        }
        return year + "-" + month + "-" + day;
    };
    return StringUtils;
}());

function contains(text, substring) {
    return text.indexOf(substring) >= 0;
}
function fuzzy_match_simple(pattern, str) {
    var patternIdx = 0;
    var strIdx = 0;
    var patternLength = pattern.length;
    var strLength = str.length;
    while (patternIdx !== patternLength && strIdx !== strLength) {
        var patternChar = pattern.charAt(patternIdx)
            .toLowerCase();
        var strChar = str.charAt(strIdx)
            .toLowerCase();
        if (patternChar === strChar) {
            ++patternIdx;
        }
        ++strIdx;
    }
    return patternLength !== 0 && strLength !== 0 && patternIdx === patternLength;
}


/***/ }),

/***/ "./src/app/shared/hazlenut/hazelnut-common/hazelnut/utils/time.utils.ts":
/*!******************************************************************************!*\
  !*** ./src/app/shared/hazlenut/hazelnut-common/hazelnut/utils/time.utils.ts ***!
  \******************************************************************************/
/*! exports provided: TimeUtils */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TimeUtils", function() { return TimeUtils; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! moment */ "./node_modules/moment/moment.js");
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_1__);


var TimeUtils = /** @class */ (function () {
    function TimeUtils() {
    }
    // convert time from HH:mm:ss to HH:mm
    TimeUtils.formatTime = function (time) {
        var splitTime = time.split(':');
        if (splitTime.length >= 2) {
            return splitTime[0] + ":" + splitTime[1];
        }
        return '';
    };
    TimeUtils.getDurationInMinutes = function (from, to) {
        // format HH:mm:ss
        var fromDate = moment__WEBPACK_IMPORTED_MODULE_1__('1970-01-01T' + from);
        var toDate = moment__WEBPACK_IMPORTED_MODULE_1__('1970-01-01T' + to);
        var duration = moment__WEBPACK_IMPORTED_MODULE_1__["duration"](toDate.diff(fromDate));
        return duration.asMinutes();
    };
    TimeUtils.getStartOfTheMonthDate = function (date) {
        date.setDate(1);
        return TimeUtils.getDateShort(date);
    };
    TimeUtils.getDateShort = function (date) {
        return moment__WEBPACK_IMPORTED_MODULE_1__(date).format('YYYY-MM-DD');
    };
    TimeUtils.formatDateAndTime = function (date) {
        return moment__WEBPACK_IMPORTED_MODULE_1__(date).format('YYYY-MM-DD[T]HH:mm:ss');
    };
    TimeUtils.formatDateUTC = function (date) {
        if (!date) {
            return '';
        }
        return moment__WEBPACK_IMPORTED_MODULE_1__(date).utc().format();
    };
    TimeUtils.getMilliseconds = function (time) {
        if (!time) {
            return NaN;
        }
        return moment__WEBPACK_IMPORTED_MODULE_1__('2000-01-01T' + time).valueOf();
    };
    TimeUtils.getStartOfTheDay = function (date) {
        if (!date) {
            return new Date('');
        }
        return moment__WEBPACK_IMPORTED_MODULE_1__(date).startOf('day').toDate();
    };
    TimeUtils.getEndOfTheDay = function (date) {
        if (!date) {
            return new Date('');
        }
        return moment__WEBPACK_IMPORTED_MODULE_1__(date).endOf('day').toDate();
    };
    TimeUtils.formatDate = function (date) {
        return moment__WEBPACK_IMPORTED_MODULE_1__(date).format();
    };
    TimeUtils.getTimeFromDate = function (date) {
        return moment__WEBPACK_IMPORTED_MODULE_1__(date).format('HH:mm');
    };
    return TimeUtils;
}());



/***/ }),

/***/ "./src/app/shared/hazlenut/hazelnut-common/index.ts":
/*!**********************************************************!*\
  !*** ./src/app/shared/hazlenut/hazelnut-common/index.ts ***!
  \**********************************************************/
/*! exports provided: detailExpand, fadeEnterLeave, enterLeave, enterLeaveSmooth, routeAnimations, moveDown, moveLeft, NOTIFICATION_WRAPPER_TOKEN, BrowseResponse, Filter, PostContent, Sort, AbstractService, AbstractStorageService, ABSTRACT_STORAGE_TOKEN, UserService, MaterialModule, HazelnutCommonModule, SharedComponentsModule, ExternalLinkDirective, SharedDirectivesModule, TRANSLATE_WRAPPER_TOKEN, mergeTranslates, RoundToDecimalPipe, SharedPipesModule, MathUtils, DomUtils, MiscUtils, StringUtils, contains, ObjectUtils, TimeUtils, Regexp */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./components */ "./src/app/shared/hazlenut/hazelnut-common/components/index.ts");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "SharedComponentsModule", function() { return _components__WEBPACK_IMPORTED_MODULE_1__["SharedComponentsModule"]; });

/* harmony import */ var _directives__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./directives */ "./src/app/shared/hazlenut/hazelnut-common/directives/index.ts");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "ExternalLinkDirective", function() { return _directives__WEBPACK_IMPORTED_MODULE_2__["ExternalLinkDirective"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "SharedDirectivesModule", function() { return _directives__WEBPACK_IMPORTED_MODULE_2__["SharedDirectivesModule"]; });

/* harmony import */ var _animations__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./animations */ "./src/app/shared/hazlenut/hazelnut-common/animations/index.ts");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "detailExpand", function() { return _animations__WEBPACK_IMPORTED_MODULE_3__["detailExpand"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "fadeEnterLeave", function() { return _animations__WEBPACK_IMPORTED_MODULE_3__["fadeEnterLeave"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "enterLeave", function() { return _animations__WEBPACK_IMPORTED_MODULE_3__["enterLeave"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "enterLeaveSmooth", function() { return _animations__WEBPACK_IMPORTED_MODULE_3__["enterLeaveSmooth"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "routeAnimations", function() { return _animations__WEBPACK_IMPORTED_MODULE_3__["routeAnimations"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "moveDown", function() { return _animations__WEBPACK_IMPORTED_MODULE_3__["moveDown"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "moveLeft", function() { return _animations__WEBPACK_IMPORTED_MODULE_3__["moveLeft"]; });

/* harmony import */ var _interfaces__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./interfaces */ "./src/app/shared/hazlenut/hazelnut-common/interfaces/index.ts");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "NOTIFICATION_WRAPPER_TOKEN", function() { return _interfaces__WEBPACK_IMPORTED_MODULE_4__["NOTIFICATION_WRAPPER_TOKEN"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "TRANSLATE_WRAPPER_TOKEN", function() { return _interfaces__WEBPACK_IMPORTED_MODULE_4__["TRANSLATE_WRAPPER_TOKEN"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "mergeTranslates", function() { return _interfaces__WEBPACK_IMPORTED_MODULE_4__["mergeTranslates"]; });

/* harmony import */ var _models__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./models */ "./src/app/shared/hazlenut/hazelnut-common/models/index.ts");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "BrowseResponse", function() { return _models__WEBPACK_IMPORTED_MODULE_5__["BrowseResponse"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "Filter", function() { return _models__WEBPACK_IMPORTED_MODULE_5__["Filter"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "PostContent", function() { return _models__WEBPACK_IMPORTED_MODULE_5__["PostContent"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "Sort", function() { return _models__WEBPACK_IMPORTED_MODULE_5__["Sort"]; });

/* harmony import */ var _pipes__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./pipes */ "./src/app/shared/hazlenut/hazelnut-common/pipes/index.ts");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "RoundToDecimalPipe", function() { return _pipes__WEBPACK_IMPORTED_MODULE_6__["RoundToDecimalPipe"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "SharedPipesModule", function() { return _pipes__WEBPACK_IMPORTED_MODULE_6__["SharedPipesModule"]; });

/* harmony import */ var _services__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./services */ "./src/app/shared/hazlenut/hazelnut-common/services/index.ts");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "AbstractService", function() { return _services__WEBPACK_IMPORTED_MODULE_7__["AbstractService"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "AbstractStorageService", function() { return _services__WEBPACK_IMPORTED_MODULE_7__["AbstractStorageService"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "ABSTRACT_STORAGE_TOKEN", function() { return _services__WEBPACK_IMPORTED_MODULE_7__["ABSTRACT_STORAGE_TOKEN"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "UserService", function() { return _services__WEBPACK_IMPORTED_MODULE_7__["UserService"]; });

/* harmony import */ var _hazelnut__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./hazelnut */ "./src/app/shared/hazlenut/hazelnut-common/hazelnut/index.ts");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "MathUtils", function() { return _hazelnut__WEBPACK_IMPORTED_MODULE_8__["MathUtils"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "DomUtils", function() { return _hazelnut__WEBPACK_IMPORTED_MODULE_8__["DomUtils"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "MiscUtils", function() { return _hazelnut__WEBPACK_IMPORTED_MODULE_8__["MiscUtils"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "StringUtils", function() { return _hazelnut__WEBPACK_IMPORTED_MODULE_8__["StringUtils"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "contains", function() { return _hazelnut__WEBPACK_IMPORTED_MODULE_8__["contains"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "ObjectUtils", function() { return _hazelnut__WEBPACK_IMPORTED_MODULE_8__["ObjectUtils"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "TimeUtils", function() { return _hazelnut__WEBPACK_IMPORTED_MODULE_8__["TimeUtils"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "Regexp", function() { return _hazelnut__WEBPACK_IMPORTED_MODULE_8__["Regexp"]; });

/* harmony import */ var _material_material_module__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./material/material.module */ "./src/app/shared/hazlenut/hazelnut-common/material/material.module.ts");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "MaterialModule", function() { return _material_material_module__WEBPACK_IMPORTED_MODULE_9__["MaterialModule"]; });

/* harmony import */ var _hazelnut_common_module__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./hazelnut-common.module */ "./src/app/shared/hazlenut/hazelnut-common/hazelnut-common.module.ts");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "HazelnutCommonModule", function() { return _hazelnut_common_module__WEBPACK_IMPORTED_MODULE_10__["HazelnutCommonModule"]; });














/***/ }),

/***/ "./src/app/shared/hazlenut/hazelnut-common/interfaces/index.ts":
/*!*********************************************************************!*\
  !*** ./src/app/shared/hazlenut/hazelnut-common/interfaces/index.ts ***!
  \*********************************************************************/
/*! exports provided: NOTIFICATION_WRAPPER_TOKEN, TRANSLATE_WRAPPER_TOKEN, mergeTranslates */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _small_components_notifications_notification_wrapper__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../small-components/notifications/notification.wrapper */ "./src/app/shared/hazlenut/small-components/notifications/notification.wrapper.ts");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "NOTIFICATION_WRAPPER_TOKEN", function() { return _small_components_notifications_notification_wrapper__WEBPACK_IMPORTED_MODULE_1__["NOTIFICATION_WRAPPER_TOKEN"]; });

/* harmony import */ var _shared_interfaces__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./shared-interfaces */ "./src/app/shared/hazlenut/hazelnut-common/interfaces/shared-interfaces.ts");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "TRANSLATE_WRAPPER_TOKEN", function() { return _shared_interfaces__WEBPACK_IMPORTED_MODULE_2__["TRANSLATE_WRAPPER_TOKEN"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "mergeTranslates", function() { return _shared_interfaces__WEBPACK_IMPORTED_MODULE_2__["mergeTranslates"]; });






/***/ }),

/***/ "./src/app/shared/hazlenut/hazelnut-common/interfaces/shared-interfaces.ts":
/*!*********************************************************************************!*\
  !*** ./src/app/shared/hazlenut/hazelnut-common/interfaces/shared-interfaces.ts ***!
  \*********************************************************************************/
/*! exports provided: TRANSLATE_WRAPPER_TOKEN, mergeTranslates */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _translate_interface__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./translate.interface */ "./src/app/shared/hazlenut/hazelnut-common/interfaces/translate.interface.ts");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "TRANSLATE_WRAPPER_TOKEN", function() { return _translate_interface__WEBPACK_IMPORTED_MODULE_1__["TRANSLATE_WRAPPER_TOKEN"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "mergeTranslates", function() { return _translate_interface__WEBPACK_IMPORTED_MODULE_1__["mergeTranslates"]; });





/***/ }),

/***/ "./src/app/shared/hazlenut/hazelnut-common/interfaces/translate.interface.ts":
/*!***********************************************************************************!*\
  !*** ./src/app/shared/hazlenut/hazelnut-common/interfaces/translate.interface.ts ***!
  \***********************************************************************************/
/*! exports provided: TRANSLATE_WRAPPER_TOKEN, mergeTranslates */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TRANSLATE_WRAPPER_TOKEN", function() { return TRANSLATE_WRAPPER_TOKEN; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "mergeTranslates", function() { return mergeTranslates; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm5/index.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm5/operators/index.js");




var TRANSLATE_WRAPPER_TOKEN = new _angular_core__WEBPACK_IMPORTED_MODULE_1__["InjectionToken"]('translateServiceWrapper');
/**
 * Method extract translates from json with translates and map them into {@link Observable} contains translate as {@link KeyValue}
 *
 */
function mergeTranslates(translateWrapperService) {
    var keys = [];
    for (var _i = 1; _i < arguments.length; _i++) {
        keys[_i - 1] = arguments[_i];
    }
    /*
    merge(translateWrapperService.get('errorRequired').pipe(map((res) => ['errorRequired', res])),
        translateWrapperService.get('errorMinlength').pipe(map((res) => ['errorMinlength', res])),
        translateWrapperService.get('errorPattern').pipe(map((res) => ['errorPattern', res])),
        translateWrapperService.get('hintMaxlength').pipe(map((res) => ['hintMaxlength', res])),
        translateWrapperService.get('hintBadCharacter').pipe(map((res) => ['hintBadCharacter', res]))
    )
    */
    return rxjs__WEBPACK_IMPORTED_MODULE_2__["merge"].apply(void 0, keys.map(function (key) { return translateWrapperService.get(key)
        .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["map"])(function (value) { return ({ key: key, value: value }); })); }));
}


/***/ }),

/***/ "./src/app/shared/hazlenut/hazelnut-common/material/material.module.ts":
/*!*****************************************************************************!*\
  !*** ./src/app/shared/hazlenut/hazelnut-common/material/material.module.ts ***!
  \*****************************************************************************/
/*! exports provided: MaterialModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MaterialModule", function() { return MaterialModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_cdk_a11y__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/cdk/a11y */ "./node_modules/@angular/cdk/esm5/a11y.es5.js");
/* harmony import */ var _angular_cdk_accordion__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/cdk/accordion */ "./node_modules/@angular/cdk/esm5/accordion.es5.js");
/* harmony import */ var _angular_cdk_bidi__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/cdk/bidi */ "./node_modules/@angular/cdk/esm5/bidi.es5.js");
/* harmony import */ var _angular_cdk_drag_drop__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/cdk/drag-drop */ "./node_modules/@angular/cdk/esm5/drag-drop.es5.js");
/* harmony import */ var _angular_cdk_observers__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/cdk/observers */ "./node_modules/@angular/cdk/esm5/observers.es5.js");
/* harmony import */ var _angular_cdk_overlay__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/cdk/overlay */ "./node_modules/@angular/cdk/esm5/overlay.es5.js");
/* harmony import */ var _angular_cdk_platform__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/cdk/platform */ "./node_modules/@angular/cdk/esm5/platform.es5.js");
/* harmony import */ var _angular_cdk_portal__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/cdk/portal */ "./node_modules/@angular/cdk/esm5/portal.es5.js");
/* harmony import */ var _angular_cdk_table__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/cdk/table */ "./node_modules/@angular/cdk/esm5/table.es5.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_material__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/material */ "./node_modules/@angular/material/esm5/material.es5.js");
/* harmony import */ var _angular_material_moment_adapter__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/material-moment-adapter */ "./node_modules/@angular/material-moment-adapter/esm5/material-moment-adapter.es5.js");
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @ngx-translate/core */ "./node_modules/@ngx-translate/core/fesm5/ngx-translate-core.js");
/* harmony import */ var _material_paginator_intl__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ../material/paginator-intl */ "./src/app/shared/hazlenut/hazelnut-common/material/paginator-intl.ts");















/**
 * NgModule that includes all Material modules that are required.
 */
var MaterialModule = /** @class */ (function () {
    function MaterialModule() {
    }
    MaterialModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_10__["NgModule"])({
            imports: [],
            declarations: [],
            exports: [
                _angular_material__WEBPACK_IMPORTED_MODULE_11__["MatAutocompleteModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_11__["MatBadgeModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_11__["MatButtonModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_11__["MatButtonToggleModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_11__["MatCardModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_11__["MatCheckboxModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_11__["MatChipsModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_11__["MatDatepickerModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_11__["MatDialogModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_11__["MatExpansionModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_11__["MatIconModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_11__["MatInputModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_11__["MatListModule"],
                _angular_material_moment_adapter__WEBPACK_IMPORTED_MODULE_12__["MatMomentDateModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_11__["MatPaginatorModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_11__["MatProgressBarModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_11__["MatProgressSpinnerModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_11__["MatSelectModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_11__["MatSidenavModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_11__["MatSnackBarModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_11__["MatTableModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_11__["MatTooltipModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_11__["MatTabsModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_11__["MatToolbarModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_11__["MatDividerModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_11__["MatFormFieldModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_11__["MatGridListModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_11__["MatMenuModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_11__["MatRadioModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_11__["MatRippleModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_11__["MatSlideToggleModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_11__["MatSliderModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_11__["MatSortModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_11__["MatStepperModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_11__["MatNativeDateModule"],
                _angular_cdk_table__WEBPACK_IMPORTED_MODULE_9__["CdkTableModule"],
                _angular_cdk_a11y__WEBPACK_IMPORTED_MODULE_1__["A11yModule"],
                _angular_cdk_bidi__WEBPACK_IMPORTED_MODULE_3__["BidiModule"],
                _angular_cdk_accordion__WEBPACK_IMPORTED_MODULE_2__["CdkAccordionModule"],
                _angular_cdk_drag_drop__WEBPACK_IMPORTED_MODULE_4__["DragDropModule"],
                _angular_cdk_observers__WEBPACK_IMPORTED_MODULE_5__["ObserversModule"],
                _angular_cdk_overlay__WEBPACK_IMPORTED_MODULE_6__["OverlayModule"],
                _angular_cdk_platform__WEBPACK_IMPORTED_MODULE_7__["PlatformModule"],
                _angular_cdk_portal__WEBPACK_IMPORTED_MODULE_8__["PortalModule"]
            ],
            providers: [{
                    provide: _angular_material__WEBPACK_IMPORTED_MODULE_11__["MatPaginatorIntl"],
                    useFactory: function (translate) {
                        var paginatorIntl = new _material_paginator_intl__WEBPACK_IMPORTED_MODULE_14__["PaginatorIntl"]();
                        paginatorIntl.injectTranslateService(translate);
                        return paginatorIntl;
                    },
                    deps: [_ngx_translate_core__WEBPACK_IMPORTED_MODULE_13__["TranslateService"]]
                }]
        })
    ], MaterialModule);
    return MaterialModule;
}());



/***/ }),

/***/ "./src/app/shared/hazlenut/hazelnut-common/material/paginator-intl.ts":
/*!****************************************************************************!*\
  !*** ./src/app/shared/hazlenut/hazelnut-common/material/paginator-intl.ts ***!
  \****************************************************************************/
/*! exports provided: PaginatorIntl */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PaginatorIntl", function() { return PaginatorIntl; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_material__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/material */ "./node_modules/@angular/material/esm5/material.es5.js");



/**
 * Paginator object with translating
 */
var PaginatorIntl = /** @class */ (function (_super) {
    tslib__WEBPACK_IMPORTED_MODULE_0__["__extends"](PaginatorIntl, _super);
    function PaginatorIntl() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.getRangeLabel = function (page, pageSize, length) {
            if (length === 0 || pageSize === 0) {
                return "0 " + _this.from + " " + length;
            }
            length = Math.max(length, 0);
            var startIndex = page * pageSize;
            var endIndex = startIndex < length ? Math.min(startIndex + pageSize, length) : startIndex + pageSize;
            return startIndex + 1 + " - " + endIndex + " " + _this.from + " " + length;
        };
        return _this;
    }
    PaginatorIntl.prototype.injectTranslateService = function (translate) {
        var _this = this;
        this.translate = translate;
        this.translate.onLangChange.subscribe(function () {
            _this.translateLabels();
        });
        this.translateLabels();
    };
    PaginatorIntl.prototype.translateLabels = function () {
        this.itemsPerPageLabel = this.translate.instant('paginator.itemsPerPage');
        this.nextPageLabel = this.translate.instant('paginator.nextPage');
        this.previousPageLabel = this.translate.instant('paginator.previousPage');
        this.firstPageLabel = this.translate.instant('paginator.firstPage');
        this.lastPageLabel = this.translate.instant('paginator.lastPage');
        this.from = this.translate.instant('paginator.from');
    };
    PaginatorIntl = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])()
    ], PaginatorIntl);
    return PaginatorIntl;
}(_angular_material__WEBPACK_IMPORTED_MODULE_2__["MatPaginatorIntl"]));



/***/ }),

/***/ "./src/app/shared/hazlenut/hazelnut-common/models/browse-response.model.ts":
/*!*********************************************************************************!*\
  !*** ./src/app/shared/hazlenut/hazelnut-common/models/browse-response.model.ts ***!
  \*********************************************************************************/
/*! exports provided: BrowseResponse */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BrowseResponse", function() { return BrowseResponse; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");

/**
 * Object representing response from browse API
 */
var BrowseResponse = /** @class */ (function () {
    function BrowseResponse(array, totalElements) {
        if (!array) {
            this.content = [];
            totalElements = 0;
        }
        else if (Array.isArray(array)) {
            this.content = array;
            this.totalElements = array.length;
        }
        else {
            this.content = array.content;
            this.totalElements = array.totalElements;
        }
        if (!isNaN(totalElements)) {
            this.totalElements = totalElements;
        }
    }
    return BrowseResponse;
}());



/***/ }),

/***/ "./src/app/shared/hazlenut/hazelnut-common/models/filter.model.ts":
/*!************************************************************************!*\
  !*** ./src/app/shared/hazlenut/hazelnut-common/models/filter.model.ts ***!
  \************************************************************************/
/*! exports provided: Filter */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Filter", function() { return Filter; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");

/**
 * Filter object used in API criteria
 */
var Filter = /** @class */ (function () {
    function Filter(property, value, type, operator, logicalOperator) {
        if (type === void 0) { type = 'STRING'; }
        if (operator === void 0) { operator = 'EQ'; }
        if (logicalOperator === void 0) { logicalOperator = 'AND'; }
        this.logicalOperator = logicalOperator;
        this.property = property;
        this.value = value;
        this.valueType = type;
        this.operator = operator;
    }
    return Filter;
}());



/***/ }),

/***/ "./src/app/shared/hazlenut/hazelnut-common/models/index.ts":
/*!*****************************************************************!*\
  !*** ./src/app/shared/hazlenut/hazelnut-common/models/index.ts ***!
  \*****************************************************************/
/*! exports provided: BrowseResponse, Filter, PostContent, Sort */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _browse_response_model__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./browse-response.model */ "./src/app/shared/hazlenut/hazelnut-common/models/browse-response.model.ts");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "BrowseResponse", function() { return _browse_response_model__WEBPACK_IMPORTED_MODULE_1__["BrowseResponse"]; });

/* harmony import */ var _filter_model__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./filter.model */ "./src/app/shared/hazlenut/hazelnut-common/models/filter.model.ts");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "Filter", function() { return _filter_model__WEBPACK_IMPORTED_MODULE_2__["Filter"]; });

/* harmony import */ var _post_content_model__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./post-content.model */ "./src/app/shared/hazlenut/hazelnut-common/models/post-content.model.ts");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "PostContent", function() { return _post_content_model__WEBPACK_IMPORTED_MODULE_3__["PostContent"]; });

/* harmony import */ var _sort_model__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./sort.model */ "./src/app/shared/hazlenut/hazelnut-common/models/sort.model.ts");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "Sort", function() { return _sort_model__WEBPACK_IMPORTED_MODULE_4__["Sort"]; });








/***/ }),

/***/ "./src/app/shared/hazlenut/hazelnut-common/models/post-content.model.ts":
/*!******************************************************************************!*\
  !*** ./src/app/shared/hazlenut/hazelnut-common/models/post-content.model.ts ***!
  \******************************************************************************/
/*! exports provided: PostContent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PostContent", function() { return PostContent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _config_hazelnut_config__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../config/hazelnut-config */ "./src/app/shared/hazlenut/hazelnut-common/config/hazelnut-config.ts");
/* harmony import */ var _sort_model__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./sort.model */ "./src/app/shared/hazlenut/hazelnut-common/models/sort.model.ts");



var PostContent = /** @class */ (function () {
    function PostContent() {
        this.filterCriteria = { criteria: [] };
        this.sortingCriteria = { criteria: [] };
        this.paging = { offset: 0, limit: _config_hazelnut_config__WEBPACK_IMPORTED_MODULE_1__["hazelnutConfig"].BROWSE_LIMIT };
    }
    PostContent.create = function (limit, offset, filter, sort) {
        var _a, _b;
        if (filter === void 0) { filter = []; }
        if (sort === void 0) { sort = [new _sort_model__WEBPACK_IMPORTED_MODULE_2__["Sort"]()]; }
        return (_a = (_b = new PostContent().setLimit(limit).setOffset(offset)).addFilters.apply(_b, filter)).addSorts.apply(_a, sort);
    };
    PostContent.parse = function (object) {
        var result = new PostContent();
        if (object.paging) {
            result.paging = {
                offset: object.paging.offset,
                limit: object.paging.limit,
            };
        }
        else {
            result.paging = {
                offset: object.offset,
                limit: object.limit,
            };
        }
        result.filterCriteria = object.filterCriteria || object.filter;
        result.sortingCriteria = object.sortingCriteria || object.sort;
        return result;
    };
    PostContent.prototype.setLimit = function (limit) {
        this.paging.limit = limit;
        return this;
    };
    PostContent.prototype.setOffset = function (offset) {
        this.paging.offset = offset;
        return this;
    };
    PostContent.prototype.addFilters = function () {
        var _a;
        var filters = [];
        for (var _i = 0; _i < arguments.length; _i++) {
            filters[_i] = arguments[_i];
        }
        if (!this.filterCriteria) {
            this.filterCriteria = {
                criteria: [],
            };
        }
        (_a = this.filterCriteria.criteria).push.apply(_a, filters);
        return this;
    };
    PostContent.prototype.addSorts = function () {
        var _a;
        var sorts = [];
        for (var _i = 0; _i < arguments.length; _i++) {
            sorts[_i] = arguments[_i];
        }
        if (!this.sortingCriteria) {
            this.sortingCriteria = {
                criteria: [],
            };
        }
        (_a = this.sortingCriteria.criteria).push.apply(_a, sorts);
        return this;
    };
    PostContent.prototype.hasSort = function () {
        return this.sortingCriteria && Array.isArray(this.sortingCriteria.criteria) && this.sortingCriteria.criteria.length > 0;
    };
    PostContent.prototype.prepareAndGet = function (browseLimit) {
        if (!this.hasSort()) {
            this.addSorts(new _sort_model__WEBPACK_IMPORTED_MODULE_2__["Sort"]());
        }
        if (!this.paging.offset) {
            this.paging.offset = 0;
        }
        if (!this.paging.limit) {
            this.paging.limit = browseLimit;
        }
        return this;
    };
    return PostContent;
}());



/***/ }),

/***/ "./src/app/shared/hazlenut/hazelnut-common/models/sort.model.ts":
/*!**********************************************************************!*\
  !*** ./src/app/shared/hazlenut/hazelnut-common/models/sort.model.ts ***!
  \**********************************************************************/
/*! exports provided: Sort */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Sort", function() { return Sort; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");

/**
 * Sort object used in browse API criteria
 */
var Sort = /** @class */ (function () {
    function Sort(property, direction, precedence) {
        if (property === void 0) { property = 'ID'; }
        if (direction === void 0) { direction = 'ASC'; }
        if (precedence === void 0) { precedence = 'NONE'; }
        this.property = property;
        this.direction = direction;
        this.nullPrecedence = precedence;
    }
    return Sort;
}());



/***/ }),

/***/ "./src/app/shared/hazlenut/hazelnut-common/pipes/index.ts":
/*!****************************************************************!*\
  !*** ./src/app/shared/hazlenut/hazelnut-common/pipes/index.ts ***!
  \****************************************************************/
/*! exports provided: RoundToDecimalPipe, SharedPipesModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _round_to_decimal_pipe__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./round-to-decimal.pipe */ "./src/app/shared/hazlenut/hazelnut-common/pipes/round-to-decimal.pipe.ts");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "RoundToDecimalPipe", function() { return _round_to_decimal_pipe__WEBPACK_IMPORTED_MODULE_1__["RoundToDecimalPipe"]; });

/* harmony import */ var _shared_pipes_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./shared-pipes.module */ "./src/app/shared/hazlenut/hazelnut-common/pipes/shared-pipes.module.ts");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "SharedPipesModule", function() { return _shared_pipes_module__WEBPACK_IMPORTED_MODULE_2__["SharedPipesModule"]; });






/***/ }),

/***/ "./src/app/shared/hazlenut/hazelnut-common/pipes/round-to-decimal.pipe.ts":
/*!********************************************************************************!*\
  !*** ./src/app/shared/hazlenut/hazelnut-common/pipes/round-to-decimal.pipe.ts ***!
  \********************************************************************************/
/*! exports provided: RoundToDecimalPipe */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RoundToDecimalPipe", function() { return RoundToDecimalPipe; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _hazelnut__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../hazelnut */ "./src/app/shared/hazlenut/hazelnut-common/hazelnut/index.ts");



/**
 * Transform number value to integer
 */
var RoundToDecimalPipe = /** @class */ (function () {
    function RoundToDecimalPipe() {
    }
    RoundToDecimalPipe.prototype.transform = function (item, fractionDigits) {
        if (fractionDigits === void 0) { fractionDigits = 0; }
        if (!isFinite(item)) {
            item = 0;
        }
        return _hazelnut__WEBPACK_IMPORTED_MODULE_2__["MathUtils"].roundToDecimals(item, fractionDigits);
    };
    RoundToDecimalPipe = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Pipe"])({
            name: 'roundToDecimal',
        })
    ], RoundToDecimalPipe);
    return RoundToDecimalPipe;
}());



/***/ }),

/***/ "./src/app/shared/hazlenut/hazelnut-common/pipes/shared-pipes.module.ts":
/*!******************************************************************************!*\
  !*** ./src/app/shared/hazlenut/hazelnut-common/pipes/shared-pipes.module.ts ***!
  \******************************************************************************/
/*! exports provided: SharedPipesModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SharedPipesModule", function() { return SharedPipesModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _round_to_decimal_pipe__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./round-to-decimal.pipe */ "./src/app/shared/hazlenut/hazelnut-common/pipes/round-to-decimal.pipe.ts");




var SharedPipesModule = /** @class */ (function () {
    function SharedPipesModule() {
    }
    SharedPipesModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"],
            ],
            declarations: [
                _round_to_decimal_pipe__WEBPACK_IMPORTED_MODULE_3__["RoundToDecimalPipe"],
            ],
            exports: [
                _round_to_decimal_pipe__WEBPACK_IMPORTED_MODULE_3__["RoundToDecimalPipe"],
            ],
        })
    ], SharedPipesModule);
    return SharedPipesModule;
}());



/***/ }),

/***/ "./src/app/shared/hazlenut/hazelnut-common/regex/regex.ts":
/*!****************************************************************!*\
  !*** ./src/app/shared/hazlenut/hazelnut-common/regex/regex.ts ***!
  \****************************************************************/
/*! exports provided: Regex */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Regex", function() { return Regex; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/*
 naming convention is to use <yourDefinition>Pattern
 */

var Regex = /** @class */ (function () {
    function Regex() {
    }
    // format d.M.yyyy
    Regex.dateDotPattern = '^(((0?[1-9])|([12][0-9])|([3][0-1]))\\.((0?[1-9])|(1[0-2]))\\.[0-9]{4})?$';
    Regex.numberPattern = '^-?(0|[1-9]\\d*)?$';
    Regex.numericCharactersPattern = '^-?(\\d*)?$';
    Regex.icoPattern = '^([0-9]{8})$';
    Regex.yearPattern = '^[1-9][0-9]*$';
    Regex.numericPattern = '^[0-9]*$';
    Regex.notOnlyWhiteCharactersPattern = '^[\\s \\S]*[\\S]+[\\s \\S]*$';
    Regex.doublePattern = '^[0-9.]*$';
    Regex.decimalPattern = '^[0-9\\s]*[.|,]?[0-9]{0,2}$';
    Regex.telPattern = '^[0-9\\/*+().\\- ]*$';
    Regex.figuresPattern = '^[0-9]{1,}$';
    Regex.emailPattern = '^\\b[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-z]{2,}\\b$';
    Regex.fileNameFromContentDispositionPattern = /filename[^;=\n]*=((['"]).*?\2|[^;\n]*)/;
    /**
     *
     * (?!^)            # Assert we are not at start of line
     * (?=              # start of positive lookahead
     *      (?:\d{3})+  # assert there are 1 or more of 3 digit sets ahead
     *      (?:\.|$)    # followed by decimal point or end of string
     * )                # end of lookahead
     */
    Regex.thousandSeparatorOccurenceWithMaxTwoDecimal = /(?!^)(?=(?:\d{3})+(?:\.|$))/gm;
    return Regex;
}());



/***/ }),

/***/ "./src/app/shared/hazlenut/hazelnut-common/services/abstract-storage.service.ts":
/*!**************************************************************************************!*\
  !*** ./src/app/shared/hazlenut/hazelnut-common/services/abstract-storage.service.ts ***!
  \**************************************************************************************/
/*! exports provided: AbstractStorageService, ABSTRACT_STORAGE_TOKEN */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AbstractStorageService", function() { return AbstractStorageService; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ABSTRACT_STORAGE_TOKEN", function() { return ABSTRACT_STORAGE_TOKEN; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");


/**
 */
var actualStorage = localStorage;
/**
 * Storage service
 */
var AbstractStorageService = /** @class */ (function () {
    function AbstractStorageService() {
    }
    /**
     * Method set actual storage
     */
    AbstractStorageService.setStorage = function (newStorage) {
        if (!newStorage) {
            throw new Error("Cannot set " + newStorage + " as storage");
        }
        actualStorage = newStorage;
    };
    /**
     * Method store key value to actual storage
     *
     */
    AbstractStorageService.prototype.setItemValue = function (key, value) {
        actualStorage.setItem(key, typeof value === 'string' ? value : JSON.stringify(value));
    };
    /**
     * Method returns value from actual storage
     *
     * @returns value by key
     */
    AbstractStorageService.prototype.getItem = function (key) {
        return actualStorage.getItem(key);
    };
    /**
     *
     */
    AbstractStorageService.prototype.getObjectItem = function (key) {
        return JSON.parse(this.getItem(key));
    };
    /**
     *
     */
    AbstractStorageService.prototype.containsItem = function (key) {
        return Boolean(this.getItem(key));
    };
    /**
     * Method remove key from actual storage
     *
     */
    AbstractStorageService.prototype.removeItem = function (key) {
        actualStorage.removeItem(key);
    };
    AbstractStorageService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root'
        })
    ], AbstractStorageService);
    return AbstractStorageService;
}());

var ABSTRACT_STORAGE_TOKEN = new _angular_core__WEBPACK_IMPORTED_MODULE_1__["InjectionToken"]('abstractStorageService');


/***/ }),

/***/ "./src/app/shared/hazlenut/hazelnut-common/services/abstract.service.ts":
/*!******************************************************************************!*\
  !*** ./src/app/shared/hazlenut/hazelnut-common/services/abstract.service.ts ***!
  \******************************************************************************/
/*! exports provided: AbstractService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AbstractService", function() { return AbstractService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm5/index.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm5/operators/index.js");
/* harmony import */ var _enums_report_type_enum__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../enums/report-type.enum */ "./src/app/shared/enums/report-type.enum.ts");
/* harmony import */ var _small_components_notifications_notification_wrapper__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../small-components/notifications/notification.wrapper */ "./src/app/shared/hazlenut/small-components/notifications/notification.wrapper.ts");
/* harmony import */ var _config_hazelnut_config__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../config/hazelnut-config */ "./src/app/shared/hazlenut/hazelnut-common/config/hazelnut-config.ts");
/* harmony import */ var _models__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../models */ "./src/app/shared/hazlenut/hazelnut-common/models/index.ts");
/* harmony import */ var _core_service_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./core-service.service */ "./src/app/shared/hazlenut/hazelnut-common/services/core-service.service.ts");










/**
 * HTTP methods which find usage in multiple projects are here
 */
var AbstractService = /** @class */ (function (_super) {
    tslib__WEBPACK_IMPORTED_MODULE_0__["__extends"](AbstractService, _super);
    function AbstractService(http, notificationService, urlKey) {
        var _this = _super.call(this, http, notificationService) || this;
        _this.urlKey = urlKey;
        return _this;
    }
    /**
     * Function return results from browse api for {@link CoreTableComponent}
     */
    AbstractService.prototype.browseTable = function (params, url) {
        var _this = this;
        if (url === void 0) { url = this.urlKey + '/browse'; }
        var filters = Object.keys(params.filters)
            .map(function (key) { return params.filters[key]; });
        var sorts = [];
        if (params.sortActive) {
            sorts.push(new _models__WEBPACK_IMPORTED_MODULE_8__["Sort"](params.sortActive, params.sortDirection));
        }
        return this.browseInner(_config_hazelnut_config__WEBPACK_IMPORTED_MODULE_7__["hazelnutConfig"].URL_API + "/" + url, _models__WEBPACK_IMPORTED_MODULE_8__["PostContent"].create(params.pageSize, params.pageSize * params.pageIndex, filters, sorts), function (response) { return new _models__WEBPACK_IMPORTED_MODULE_8__["BrowseResponse"](_this.extractListData(response), response.totalElements); });
    };
    /**
     * Function returns list of results from browse API
     *
     */
    AbstractService.prototype.getBrowseList = function () {
        return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["of"])([]);
    };
    /**
     * Function returns list of results from filter API
     *
     */
    AbstractService.prototype.getFilterList = function () {
        return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["of"])([]);
    };
    /**
     * * Function returns list of result from browse API
     *
     * @param id - id of searched object
     * @param params
     * @param params
     */
    AbstractService.prototype.getDetail = function (id, params) {
        var realId = id ? "/" + id : '';
        return this.get({
            params: params,
            url: _config_hazelnut_config__WEBPACK_IMPORTED_MODULE_7__["hazelnutConfig"].URL_API + "/" + this.urlKey + realId,
            mapFunction: this.extractDetail
        });
    };
    /**
     * Function create new object
     *
     * @param body - instance of object for create
     */
    AbstractService.prototype.add = function (body, additionalUrl) {
        if (additionalUrl === void 0) { additionalUrl = ''; }
        return this.post({
            body: body,
            url: _config_hazelnut_config__WEBPACK_IMPORTED_MODULE_7__["hazelnutConfig"].URL_API + "/" + this.urlKey + additionalUrl,
            mapFunction: this.extractDetail,
        });
    };
    /**
     * Function update existing object
     *
     * @param id - if of object for update
     * @param body
     */
    AbstractService.prototype.update = function (id, body) {
        return this.put({
            body: body,
            url: _config_hazelnut_config__WEBPACK_IMPORTED_MODULE_7__["hazelnutConfig"].URL_API + "/" + this.urlKey + "/" + id,
            mapFunction: this.extractDetail
        });
    };
    AbstractService.prototype.deleteById = function (id, params) {
        var realId = id ? "/" + id : '';
        return this.delete({
            params: params,
            url: _config_hazelnut_config__WEBPACK_IMPORTED_MODULE_7__["hazelnutConfig"].URL_API + "/" + this.urlKey + realId,
            mapFunction: this.extractDetail
        });
    };
    AbstractService.prototype.uploadFile = function (url, file, fileName, mapFunction) {
        var fd = new FormData();
        fd.append(fileName, file, file ? file.name : undefined);
        return this.post({
            url: url,
            mapFunction: mapFunction,
            body: fd,
        });
    };
    /**
     *
     */
    AbstractService.prototype.browse = function (filter, sort, limit, offset) {
        if (filter === void 0) { filter = []; }
        if (sort === void 0) { sort = [new _models__WEBPACK_IMPORTED_MODULE_8__["Sort"]()]; }
        if (limit === void 0) { limit = _config_hazelnut_config__WEBPACK_IMPORTED_MODULE_7__["hazelnutConfig"].BROWSE_LIMIT; }
        if (offset === void 0) { offset = 0; }
        if (sort.length === 0) {
            sort.push(new _models__WEBPACK_IMPORTED_MODULE_8__["Sort"]());
        }
        return this.browseInner(_config_hazelnut_config__WEBPACK_IMPORTED_MODULE_7__["hazelnutConfig"].URL_API + "/" + this.urlKey + "/browse", _models__WEBPACK_IMPORTED_MODULE_8__["PostContent"].create(limit, offset, filter, sort), this.extractListData);
    };
    AbstractService.prototype.browseWithSummary = function (postContent, additionalUrl) {
        if (additionalUrl === void 0) { additionalUrl = ''; }
        if (!postContent.hasSort()) {
            postContent.addSorts(new _models__WEBPACK_IMPORTED_MODULE_8__["Sort"]());
        }
        if (additionalUrl.endsWith('/')) {
            additionalUrl = additionalUrl.substr(0, additionalUrl.length - 1);
        }
        if (additionalUrl.startsWith('/')) {
            if (this.urlKey.endsWith('/')) {
                additionalUrl = additionalUrl.substr(1, additionalUrl.length);
            }
        }
        else if (!this.urlKey.endsWith('/')) {
            additionalUrl = '/' + additionalUrl;
        }
        return this.browseInner(_config_hazelnut_config__WEBPACK_IMPORTED_MODULE_7__["hazelnutConfig"].URL_API + "/" + this.urlKey + additionalUrl + "browse", postContent, this.extractDetail);
    };
    /**
     *
     */
    AbstractService.prototype.count = function (infix, filter) {
        if (filter === void 0) { filter = []; }
        var content = {
            filterCriteria: {
                criteria: filter,
            },
        };
        return this.post({
            url: _config_hazelnut_config__WEBPACK_IMPORTED_MODULE_7__["hazelnutConfig"].URL_API + "/" + this.urlKey + infix + "/count",
            body: content,
            mapFunction: this.extractDetail
        });
    };
    /**
     *
     */
    AbstractService.prototype.filter = function (filter, sort) {
        if (filter === void 0) { filter = []; }
        if (sort === void 0) { sort = [new _models__WEBPACK_IMPORTED_MODULE_8__["Sort"]()]; }
        if (sort.length === 0) {
            sort.push(new _models__WEBPACK_IMPORTED_MODULE_8__["Sort"]());
        }
        var body = {
            filterCriteria: {
                criteria: filter,
            },
            sortingCriteria: {
                criteria: sort,
            },
        };
        return this.post({
            body: body,
            url: _config_hazelnut_config__WEBPACK_IMPORTED_MODULE_7__["hazelnutConfig"].URL_API + "/" + this.urlKey + "/filter",
            mapFunction: this.extractListData,
        });
    };
    /**
     * Function extract all data from response
     *
     */
    AbstractService.prototype.extractListData = function (res) {
        return (res && res.content) || [];
    };
    /**
     * Function parse and extract response
     *
     */
    AbstractService.prototype.extractDetail = function (res) {
        return res;
    };
    /**
     *
     */
    AbstractService.prototype.browseInner = function (url, content, mapFunction) {
        return this.post({
            url: url,
            mapFunction: mapFunction,
            body: content.prepareAndGet(_config_hazelnut_config__WEBPACK_IMPORTED_MODULE_7__["hazelnutConfig"].BROWSE_LIMIT)
        });
    };
    /**
     *
     * @param {Filter[]} filter
     * @param {Sort[]} sort
     * @returns {Observable<T>}
     */
    AbstractService.prototype.report = function (filter, sort, projectId) {
        if (filter === void 0) { filter = []; }
        if (sort === void 0) { sort = [new _models__WEBPACK_IMPORTED_MODULE_8__["Sort"]()]; }
        if (sort && sort.length === 0) {
            sort.push(new _models__WEBPACK_IMPORTED_MODULE_8__["Sort"]());
        }
        var content = {
            filterCriteria: { criteria: filter },
            sortingCriteria: { criteria: sort }
        };
        return this.postBlob(_config_hazelnut_config__WEBPACK_IMPORTED_MODULE_7__["hazelnutConfig"].URL_API + "/" + this.urlKey + "/project/" + projectId + "/report", content, this.extractDetail);
    };
    /**
     * @param {string} url
     * @param body
     * @param {(res: Response) => any[]} mapFunction
     * @param params
     * @returns {Observable<S>}
     */
    AbstractService.prototype.postBlob = function (url, body, mapFunction, params) {
        if (params === void 0) { params = {}; }
        return this.http.post(url, body, {
            params: params,
            headers: this.getHeader(),
            responseType: 'blob',
            observe: 'response'
        })
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["map"])(mapFunction), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(this.handleError));
    };
    /**
     *
     * @param {Filter[]} filter
     * @param {Sort[]} sort
     * @returns {Observable<T>}
     */
    AbstractService.prototype.reportGet = function (projectId, reportId) {
        return this.getBlob(_config_hazelnut_config__WEBPACK_IMPORTED_MODULE_7__["hazelnutConfig"].URL_API + "/report/" + (reportId === 1 ? _enums_report_type_enum__WEBPACK_IMPORTED_MODULE_5__["ReportType"].ToDoList : _enums_report_type_enum__WEBPACK_IMPORTED_MODULE_5__["ReportType"].RedFlagList) + "/project/" + projectId, this.extractDetail);
    };
    /**
     * @param {string} url
     * @param body
     * @param {(res: Response) => any[]} mapFunction
     * @param params
     * @returns {Observable<S>}
     */
    AbstractService.prototype.getBlob = function (url, mapFunction, params) {
        if (params === void 0) { params = {}; }
        return this.http.get(url, {
            params: params,
            headers: this.getHeader(),
            responseType: 'blob',
            observe: 'response'
        })
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["map"])(mapFunction), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(this.handleError));
    };
    AbstractService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        tslib__WEBPACK_IMPORTED_MODULE_0__["__param"](1, Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Inject"])(_small_components_notifications_notification_wrapper__WEBPACK_IMPORTED_MODULE_6__["NOTIFICATION_WRAPPER_TOKEN"])),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"], Object, String])
    ], AbstractService);
    return AbstractService;
}(_core_service_service__WEBPACK_IMPORTED_MODULE_9__["CoreService"]));



/***/ }),

/***/ "./src/app/shared/hazlenut/hazelnut-common/services/core-service.service.ts":
/*!**********************************************************************************!*\
  !*** ./src/app/shared/hazlenut/hazelnut-common/services/core-service.service.ts ***!
  \**********************************************************************************/
/*! exports provided: CoreService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CoreService", function() { return CoreService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm5/index.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm5/operators/index.js");
/* harmony import */ var _small_components_notifications_notification_wrapper__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../small-components/notifications/notification.wrapper */ "./src/app/shared/hazlenut/small-components/notifications/notification.wrapper.ts");






/**
 * Core HTTP methods
 */
var CoreService = /** @class */ (function () {
    function CoreService(http, notificationService) {
        this.http = http;
        this.notificationService = notificationService;
    }
    /**
     */
    CoreService.prototype.delete = function (_a) {
        var url = _a.url, body = _a.body, mapFunction = _a.mapFunction, _b = _a.params, params = _b === void 0 ? {} : _b, _c = _a.headers, headers = _c === void 0 ? this.getHeader() : _c;
        return this.http.delete(url, {
            headers: headers,
            params: this.getParameters(params),
        }).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["map"])(mapFunction), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(this.handleError));
    };
    /**
     * Function returns object Header, which contains all required headers for successfully request
     *
     */
    CoreService.prototype.getHeader = function () {
        throw new Error('CoreService.getHeader method must by implemented');
    };
    /**
     * Function return object HttpParams, which contains URL search parameters
     *
     */
    CoreService.prototype.getParameters = function (parameters) {
        var httpParams = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpParams"]();
        if (parameters) {
            for (var key in parameters) {
                if (parameters.hasOwnProperty(key)) {
                    httpParams = httpParams.append(key, parameters[key]);
                }
            }
        }
        return httpParams;
    };
    /**
     */
    CoreService.prototype.post = function (_a) {
        var url = _a.url, body = _a.body, mapFunction = _a.mapFunction, _b = _a.params, params = _b === void 0 ? {} : _b, _c = _a.headers, headers = _c === void 0 ? this.getHeader() : _c;
        return this.http.post(url, body, {
            params: params, headers: headers,
        }).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["map"])(mapFunction), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(this.handleError));
    };
    /**
     */
    CoreService.prototype.put = function (_a) {
        var url = _a.url, body = _a.body, mapFunction = _a.mapFunction, _b = _a.params, params = _b === void 0 ? {} : _b, _c = _a.headers, headers = _c === void 0 ? this.getHeader() : _c;
        return this.http.put(url, JSON.stringify(body), { headers: headers }).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["map"])(mapFunction), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(this.handleError));
    };
    /**
     */
    CoreService.prototype.get = function (_a) {
        var url = _a.url, body = _a.body, mapFunction = _a.mapFunction, _b = _a.params, params = _b === void 0 ? {} : _b, _c = _a.headers, headers = _c === void 0 ? this.getHeader() : _c;
        return this.http.get(url, {
            headers: headers,
            params: this.getParameters(params),
        }).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["map"])(mapFunction), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(this.handleError));
    };
    /**
     * Function handle error from HTTP request or from server
     *
     */
    CoreService.prototype.handleError = function (error) {
        if (error.status === 401) {
            window.location.hash = '/login';
            return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["throwError"])('error.unauthorized');
        }
        if (error.status === 504) {
            return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["throwError"])('error.gatewayTimeout');
        }
        return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["throwError"])(error);
    };
    CoreService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        tslib__WEBPACK_IMPORTED_MODULE_0__["__param"](1, Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Inject"])(_small_components_notifications_notification_wrapper__WEBPACK_IMPORTED_MODULE_5__["NOTIFICATION_WRAPPER_TOKEN"])),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"], Object])
    ], CoreService);
    return CoreService;
}());



/***/ }),

/***/ "./src/app/shared/hazlenut/hazelnut-common/services/index.ts":
/*!*******************************************************************!*\
  !*** ./src/app/shared/hazlenut/hazelnut-common/services/index.ts ***!
  \*******************************************************************/
/*! exports provided: AbstractService, AbstractStorageService, ABSTRACT_STORAGE_TOKEN, UserService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _abstract_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./abstract.service */ "./src/app/shared/hazlenut/hazelnut-common/services/abstract.service.ts");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "AbstractService", function() { return _abstract_service__WEBPACK_IMPORTED_MODULE_1__["AbstractService"]; });

/* harmony import */ var _abstract_storage_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./abstract-storage.service */ "./src/app/shared/hazlenut/hazelnut-common/services/abstract-storage.service.ts");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "AbstractStorageService", function() { return _abstract_storage_service__WEBPACK_IMPORTED_MODULE_2__["AbstractStorageService"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "ABSTRACT_STORAGE_TOKEN", function() { return _abstract_storage_service__WEBPACK_IMPORTED_MODULE_2__["ABSTRACT_STORAGE_TOKEN"]; });

/* harmony import */ var _user_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./user.service */ "./src/app/shared/hazlenut/hazelnut-common/services/user.service.ts");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "UserService", function() { return _user_service__WEBPACK_IMPORTED_MODULE_3__["UserService"]; });







/***/ }),

/***/ "./src/app/shared/hazlenut/hazelnut-common/services/user.service.ts":
/*!**************************************************************************!*\
  !*** ./src/app/shared/hazlenut/hazelnut-common/services/user.service.ts ***!
  \**************************************************************************/
/*! exports provided: UserService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UserService", function() { return UserService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm5/index.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm5/operators/index.js");
/* harmony import */ var util__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! util */ "./node_modules/util/util.js");
/* harmony import */ var util__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(util__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _abstract_storage_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./abstract-storage.service */ "./src/app/shared/hazlenut/hazelnut-common/services/abstract-storage.service.ts");






var UserService = /** @class */ (function () {
    function UserService(storageService) {
        var _this = this;
        this.storageService = storageService;
        var value = (this.loadData() || {});
        this._instant = new Proxy(value, {
            get: function (target, name) {
                return _this._behaviorSubject.value[name];
            },
            set: function () {
                throw new Error('Cannot set value directly');
            }
        });
        this._subject = new Proxy(value, {
            get: function (target, name) {
                return _this._behaviorSubject.pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["map"])(function (item) { return item[name]; }));
            },
            set: function () {
                throw new Error('Cannot set value directly');
            }
        });
        this._behaviorSubject = new rxjs__WEBPACK_IMPORTED_MODULE_2__["BehaviorSubject"](value);
    }
    Object.defineProperty(UserService.prototype, "instant", {
        get: function () {
            return this._instant;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(UserService.prototype, "subject", {
        get: function () {
            return this._subject;
        },
        enumerable: true,
        configurable: true
    });
    UserService.prototype.setProperty = function (key, value) {
        var newValue = tslib__WEBPACK_IMPORTED_MODULE_0__["__assign"]({}, this._behaviorSubject.value);
        newValue[key] = value;
        this._behaviorSubject.next(newValue);
        return newValue;
    };
    UserService.prototype.setData = function (data) {
        this._behaviorSubject.next(data);
        this.storeData(data);
        return data;
    };
    UserService.prototype.clearUserData = function () {
        this.storageService.removeItem(this.login);
        this.storageService.removeItem('lastUser');
        this._behaviorSubject.next({});
    };
    /*
     * when user refreshes the page, 'lastUser' is used
     */
    UserService.prototype.loadData = function () {
        if ((!Object(util__WEBPACK_IMPORTED_MODULE_4__["isNullOrUndefined"])(localStorage.getItem('lastUser')))) {
            this.login = localStorage.getItem('lastUser');
        }
        return this.storageService.getObjectItem(this.login);
    };
    UserService.prototype.storeData = function (data) {
        this.login = data.login;
        this.storageService.setItemValue(data.login, data);
    };
    UserService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        tslib__WEBPACK_IMPORTED_MODULE_0__["__param"](0, Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Inject"])(_abstract_storage_service__WEBPACK_IMPORTED_MODULE_5__["ABSTRACT_STORAGE_TOKEN"])),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_abstract_storage_service__WEBPACK_IMPORTED_MODULE_5__["AbstractStorageService"]])
    ], UserService);
    return UserService;
}());



/***/ }),

/***/ "./src/app/shared/hazlenut/hazelnut-common/utils/input-utils.ts":
/*!**********************************************************************!*\
  !*** ./src/app/shared/hazlenut/hazelnut-common/utils/input-utils.ts ***!
  \**********************************************************************/
/*! exports provided: InputUtils */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "InputUtils", function() { return InputUtils; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");


var InputUtils = /** @class */ (function () {
    function InputUtils() {
    }
    InputUtils.addValidators = function (required, minLength, maxLength, pattern) {
        if (required === void 0) { required = true; }
        var validators = [];
        if (required) {
            validators.push(_angular_forms__WEBPACK_IMPORTED_MODULE_1__["Validators"].required);
        }
        if (minLength && minLength > 0) {
            validators.push(_angular_forms__WEBPACK_IMPORTED_MODULE_1__["Validators"].minLength(minLength));
        }
        if (maxLength && maxLength > 0) {
            validators.push(_angular_forms__WEBPACK_IMPORTED_MODULE_1__["Validators"].maxLength(maxLength));
        }
        if (pattern) {
            validators.push(_angular_forms__WEBPACK_IMPORTED_MODULE_1__["Validators"].pattern(pattern));
        }
        return validators.slice();
    };
    InputUtils.setDefaultTranslates = function (target, translationService, instant) {
        if (instant) {
            target.errorRequired = target.errorRequired || translationService.instant('error.required');
            target.errorMinlength = target.errorMinlength || translationService.instant('error.minlength');
            target.errorPattern = target.errorPattern || translationService.instant('error.pattern');
            target.hintMaxlength = target.hintMaxlength || translationService.instant('hint.maxlength');
            target.hintBadCharacter = target.hintBadCharacter || translationService.instant('hint.badCharacter');
        }
        else {
            translationService.get('error.required')
                .subscribe(function (translate) {
                target.errorRequired = translate;
            });
            translationService.get('error.minlength')
                .subscribe(function (translate) {
                target.errorMinlength = translate;
            });
            translationService.get('error.pattern')
                .subscribe(function (translate) {
                target.errorPattern = translate;
            });
            translationService.get('hint.maxlength')
                .subscribe(function (translate) {
                target.hintMaxlength = translate;
            });
            translationService.get('hint.badCharacter')
                .subscribe(function (translate) {
                target.hintBadCharacter = translate;
            });
        }
    };
    InputUtils.setFromToTranslates = function (target, translationService) {
        target.fromLabel = target.fromLabel || translationService.instant('common.from');
        target.toLabel = target.toLabel || translationService.instant('common.to');
    };
    return InputUtils;
}());



/***/ }),

/***/ "./src/app/shared/hazlenut/small-components/indeterminate-progress-bar/indeterminate-progress-bar.component.scss":
/*!***********************************************************************************************************************!*\
  !*** ./src/app/shared/hazlenut/small-components/indeterminate-progress-bar/indeterminate-progress-bar.component.scss ***!
  \***********************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3NoYXJlZC9oYXpsZW51dC9zbWFsbC1jb21wb25lbnRzL2luZGV0ZXJtaW5hdGUtcHJvZ3Jlc3MtYmFyL2luZGV0ZXJtaW5hdGUtcHJvZ3Jlc3MtYmFyLmNvbXBvbmVudC5zY3NzIn0= */");

/***/ }),

/***/ "./src/app/shared/hazlenut/small-components/indeterminate-progress-bar/indeterminate-progress-bar.component.ts":
/*!*********************************************************************************************************************!*\
  !*** ./src/app/shared/hazlenut/small-components/indeterminate-progress-bar/indeterminate-progress-bar.component.ts ***!
  \*********************************************************************************************************************/
/*! exports provided: IndeterminateProgressBarComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "IndeterminateProgressBarComponent", function() { return IndeterminateProgressBarComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");


var IndeterminateProgressBarComponent = /** @class */ (function () {
    function IndeterminateProgressBarComponent() {
        this.loading = false;
    }
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], IndeterminateProgressBarComponent.prototype, "loading", void 0);
    IndeterminateProgressBarComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'haz-indeterminate-progress-bar',
            template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./indeterminate-progress-bar.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/shared/hazlenut/small-components/indeterminate-progress-bar/indeterminate-progress-bar.component.html")).default,
            styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./indeterminate-progress-bar.component.scss */ "./src/app/shared/hazlenut/small-components/indeterminate-progress-bar/indeterminate-progress-bar.component.scss")).default]
        })
        /**
         * Material progress bar based on loading
         */
        ,
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
    ], IndeterminateProgressBarComponent);
    return IndeterminateProgressBarComponent;
}());



/***/ }),

/***/ "./src/app/shared/hazlenut/small-components/index.ts":
/*!***********************************************************!*\
  !*** ./src/app/shared/hazlenut/small-components/index.ts ***!
  \***********************************************************/
/*! exports provided: SmallComponentsModule, NOTIFICATION_WRAPPER_TOKEN, NotificationSnackBarComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _small_components_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./small-components.module */ "./src/app/shared/hazlenut/small-components/small-components.module.ts");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "SmallComponentsModule", function() { return _small_components_module__WEBPACK_IMPORTED_MODULE_1__["SmallComponentsModule"]; });

/* harmony import */ var _notifications__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./notifications */ "./src/app/shared/hazlenut/small-components/notifications/index.ts");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "NOTIFICATION_WRAPPER_TOKEN", function() { return _notifications__WEBPACK_IMPORTED_MODULE_2__["NOTIFICATION_WRAPPER_TOKEN"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "NotificationSnackBarComponent", function() { return _notifications__WEBPACK_IMPORTED_MODULE_2__["NotificationSnackBarComponent"]; });






/***/ }),

/***/ "./src/app/shared/hazlenut/small-components/notifications/index.ts":
/*!*************************************************************************!*\
  !*** ./src/app/shared/hazlenut/small-components/notifications/index.ts ***!
  \*************************************************************************/
/*! exports provided: NOTIFICATION_WRAPPER_TOKEN, NotificationSnackBarComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _notification_wrapper__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./notification.wrapper */ "./src/app/shared/hazlenut/small-components/notifications/notification.wrapper.ts");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "NOTIFICATION_WRAPPER_TOKEN", function() { return _notification_wrapper__WEBPACK_IMPORTED_MODULE_1__["NOTIFICATION_WRAPPER_TOKEN"]; });

/* harmony import */ var _notification_snack_bar_notification_snack_bar_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./notification-snack-bar/notification-snack-bar.component */ "./src/app/shared/hazlenut/small-components/notifications/notification-snack-bar/notification-snack-bar.component.ts");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "NotificationSnackBarComponent", function() { return _notification_snack_bar_notification_snack_bar_component__WEBPACK_IMPORTED_MODULE_2__["NotificationSnackBarComponent"]; });






/***/ }),

/***/ "./src/app/shared/hazlenut/small-components/notifications/notification-snack-bar/notification-snack-bar.component.scss":
/*!*****************************************************************************************************************************!*\
  !*** ./src/app/shared/hazlenut/small-components/notifications/notification-snack-bar/notification-snack-bar.component.scss ***!
  \*****************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3NoYXJlZC9oYXpsZW51dC9zbWFsbC1jb21wb25lbnRzL25vdGlmaWNhdGlvbnMvbm90aWZpY2F0aW9uLXNuYWNrLWJhci9ub3RpZmljYXRpb24tc25hY2stYmFyLmNvbXBvbmVudC5zY3NzIn0= */");

/***/ }),

/***/ "./src/app/shared/hazlenut/small-components/notifications/notification-snack-bar/notification-snack-bar.component.ts":
/*!***************************************************************************************************************************!*\
  !*** ./src/app/shared/hazlenut/small-components/notifications/notification-snack-bar/notification-snack-bar.component.ts ***!
  \***************************************************************************************************************************/
/*! exports provided: NotificationSnackBarComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NotificationSnackBarComponent", function() { return NotificationSnackBarComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_material__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/material */ "./node_modules/@angular/material/esm5/material.es5.js");



var NotificationSnackBarComponent = /** @class */ (function () {
    function NotificationSnackBarComponent(data) {
        this.data = data;
    }
    NotificationSnackBarComponent.prototype.ngOnInit = function () {
    };
    NotificationSnackBarComponent.ctorParameters = function () { return [
        { type: undefined, decorators: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["Inject"], args: [_angular_material__WEBPACK_IMPORTED_MODULE_2__["MAT_SNACK_BAR_DATA"],] }] }
    ]; };
    NotificationSnackBarComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'notification-snack-bar',
            template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./notification-snack-bar.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/shared/hazlenut/small-components/notifications/notification-snack-bar/notification-snack-bar.component.html")).default,
            styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./notification-snack-bar.component.scss */ "./src/app/shared/hazlenut/small-components/notifications/notification-snack-bar/notification-snack-bar.component.scss")).default]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__param"](0, Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Inject"])(_angular_material__WEBPACK_IMPORTED_MODULE_2__["MAT_SNACK_BAR_DATA"])),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [Object])
    ], NotificationSnackBarComponent);
    return NotificationSnackBarComponent;
}());



/***/ }),

/***/ "./src/app/shared/hazlenut/small-components/notifications/notification-type.enum.ts":
/*!******************************************************************************************!*\
  !*** ./src/app/shared/hazlenut/small-components/notifications/notification-type.enum.ts ***!
  \******************************************************************************************/
/*! exports provided: NotificationType */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NotificationType", function() { return NotificationType; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");

var NotificationType;
(function (NotificationType) {
    NotificationType[NotificationType["SUCCESS"] = 0] = "SUCCESS";
    NotificationType[NotificationType["ERROR"] = 1] = "ERROR";
    NotificationType[NotificationType["WARNING"] = 2] = "WARNING";
})(NotificationType || (NotificationType = {}));


/***/ }),

/***/ "./src/app/shared/hazlenut/small-components/notifications/notification.wrapper.ts":
/*!****************************************************************************************!*\
  !*** ./src/app/shared/hazlenut/small-components/notifications/notification.wrapper.ts ***!
  \****************************************************************************************/
/*! exports provided: NOTIFICATION_WRAPPER_TOKEN */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NOTIFICATION_WRAPPER_TOKEN", function() { return NOTIFICATION_WRAPPER_TOKEN; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");


var NOTIFICATION_WRAPPER_TOKEN = new _angular_core__WEBPACK_IMPORTED_MODULE_1__["InjectionToken"]('notificationServiceWrapper');


/***/ }),

/***/ "./src/app/shared/hazlenut/small-components/small-components.module.ts":
/*!*****************************************************************************!*\
  !*** ./src/app/shared/hazlenut/small-components/small-components.module.ts ***!
  \*****************************************************************************/
/*! exports provided: SmallComponentsModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SmallComponentsModule", function() { return SmallComponentsModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _hazelnut_common_material_material_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../hazelnut-common/material/material.module */ "./src/app/shared/hazlenut/hazelnut-common/material/material.module.ts");
/* harmony import */ var _indeterminate_progress_bar_indeterminate_progress_bar_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./indeterminate-progress-bar/indeterminate-progress-bar.component */ "./src/app/shared/hazlenut/small-components/indeterminate-progress-bar/indeterminate-progress-bar.component.ts");
/* harmony import */ var _notifications_notification_snack_bar_notification_snack_bar_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./notifications/notification-snack-bar/notification-snack-bar.component */ "./src/app/shared/hazlenut/small-components/notifications/notification-snack-bar/notification-snack-bar.component.ts");






var SmallComponentsModule = /** @class */ (function () {
    function SmallComponentsModule() {
    }
    SmallComponentsModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["NgModule"])({
            declarations: [
                _notifications_notification_snack_bar_notification_snack_bar_component__WEBPACK_IMPORTED_MODULE_5__["NotificationSnackBarComponent"],
                _indeterminate_progress_bar_indeterminate_progress_bar_component__WEBPACK_IMPORTED_MODULE_4__["IndeterminateProgressBarComponent"],
            ],
            exports: [
                _notifications_notification_snack_bar_notification_snack_bar_component__WEBPACK_IMPORTED_MODULE_5__["NotificationSnackBarComponent"],
                _indeterminate_progress_bar_indeterminate_progress_bar_component__WEBPACK_IMPORTED_MODULE_4__["IndeterminateProgressBarComponent"]
            ],
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"],
                _hazelnut_common_material_material_module__WEBPACK_IMPORTED_MODULE_3__["MaterialModule"]
            ]
        })
    ], SmallComponentsModule);
    return SmallComponentsModule;
}());



/***/ }),

/***/ "./src/app/shared/pipes/pipes.module.ts":
/*!**********************************************!*\
  !*** ./src/app/shared/pipes/pipes.module.ts ***!
  \**********************************************/
/*! exports provided: PipesModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PipesModule", function() { return PipesModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _thousand_delimiter_pipe__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./thousand-delimiter.pipe */ "./src/app/shared/pipes/thousand-delimiter.pipe.ts");
/* harmony import */ var _venue_pipe__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./venue.pipe */ "./src/app/shared/pipes/venue.pipe.ts");





var PipesModule = /** @class */ (function () {
    function PipesModule() {
    }
    PipesModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["NgModule"])({
            declarations: [_venue_pipe__WEBPACK_IMPORTED_MODULE_4__["VenuePipe"], _thousand_delimiter_pipe__WEBPACK_IMPORTED_MODULE_3__["ThousandDelimiterPipe"]],
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"],
            ],
            exports: [_venue_pipe__WEBPACK_IMPORTED_MODULE_4__["VenuePipe"], _thousand_delimiter_pipe__WEBPACK_IMPORTED_MODULE_3__["ThousandDelimiterPipe"]]
        })
    ], PipesModule);
    return PipesModule;
}());



/***/ }),

/***/ "./src/app/shared/pipes/thousand-delimiter.pipe.ts":
/*!*********************************************************!*\
  !*** ./src/app/shared/pipes/thousand-delimiter.pipe.ts ***!
  \*********************************************************/
/*! exports provided: ThousandDelimiterPipe */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ThousandDelimiterPipe", function() { return ThousandDelimiterPipe; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var util__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! util */ "./node_modules/util/util.js");
/* harmony import */ var util__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(util__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _hazlenut_hazelnut_common_regex_regex__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../hazlenut/hazelnut-common/regex/regex */ "./src/app/shared/hazlenut/hazelnut-common/regex/regex.ts");




var ThousandDelimiterPipe = /** @class */ (function () {
    /**
     * Transform value to number with two decimal parameter and specified decimal separator
     */
    function ThousandDelimiterPipe() {
    }
    ThousandDelimiterPipe.prototype.transform = function (value, decimalSeparator) {
        if (decimalSeparator === void 0) { decimalSeparator = '.'; }
        value = Object(util__WEBPACK_IMPORTED_MODULE_2__["isNullOrUndefined"])(value) ? '' : value;
        var decimalPart = value.toString().split('.')[1];
        var element = (decimalPart && (decimalPart.length > 0))
            ? parseFloat(value.toString()).toFixed(2).toString()
            : value.toString();
        return element
            .replace(_hazlenut_hazelnut_common_regex_regex__WEBPACK_IMPORTED_MODULE_3__["Regex"].thousandSeparatorOccurenceWithMaxTwoDecimal, ' ')
            .replace('.', decimalSeparator);
    };
    ThousandDelimiterPipe = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Pipe"])({
            name: 'thousandDelimiter'
        })
        /**
         * Transform value to number with two decimal parameter and specified decimal separator
         */
    ], ThousandDelimiterPipe);
    return ThousandDelimiterPipe;
}());



/***/ }),

/***/ "./src/app/shared/pipes/venue.pipe.ts":
/*!********************************************!*\
  !*** ./src/app/shared/pipes/venue.pipe.ts ***!
  \********************************************/
/*! exports provided: VenuePipe */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "VenuePipe", function() { return VenuePipe; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ngx-translate/core */ "./node_modules/@ngx-translate/core/fesm5/ngx-translate-core.js");



var VenuePipe = /** @class */ (function () {
    function VenuePipe(translateService) {
        this.translateService = translateService;
    }
    VenuePipe.prototype.transform = function (value, args) {
        if (!value) {
            return;
        }
        switch (value.toString().toLowerCase()) {
            case 'all':
                return this.translateService.instant('venue.value.all');
            case 'both':
                return this.translateService.instant('venue.value.both');
            case 'none':
                return '';
            default:
        }
        return value;
    };
    VenuePipe.ctorParameters = function () { return [
        { type: _ngx_translate_core__WEBPACK_IMPORTED_MODULE_2__["TranslateService"] }
    ]; };
    VenuePipe = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Pipe"])({
            name: 'venue'
        })
        /**
         * Venue value transformation
         */
        ,
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ngx_translate_core__WEBPACK_IMPORTED_MODULE_2__["TranslateService"]])
    ], VenuePipe);
    return VenuePipe;
}());



/***/ }),

/***/ "./src/app/shared/services/auth-guard.ts":
/*!***********************************************!*\
  !*** ./src/app/shared/services/auth-guard.ts ***!
  \***********************************************/
/*! exports provided: AuthGuard */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AuthGuard", function() { return AuthGuard; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _menu_guard__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./menu-guard */ "./src/app/shared/services/menu-guard.ts");
/* harmony import */ var _storage_project_user_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./storage/project-user.service */ "./src/app/shared/services/storage/project-user.service.ts");





/**
 * Authentification guard service for enabling routes when user is authentificated
 */
var AuthGuard = /** @class */ (function () {
    function AuthGuard(userService, router, menuGuard) {
        this.userService = userService;
        this.router = router;
        this.menuGuard = menuGuard;
    }
    AuthGuard.prototype.canActivate = function (next, state) {
        if (this.userService.isLoggedIn) {
            return this.menuGuard.menuRoutingCheck(next.data.title);
        }
        this.router.navigate(['authentication/login']);
        return false;
    };
    AuthGuard.ctorParameters = function () { return [
        { type: _storage_project_user_service__WEBPACK_IMPORTED_MODULE_4__["ProjectUserService"] },
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"] },
        { type: _menu_guard__WEBPACK_IMPORTED_MODULE_3__["MenuGuard"] }
    ]; };
    AuthGuard = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_storage_project_user_service__WEBPACK_IMPORTED_MODULE_4__["ProjectUserService"], _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"], _menu_guard__WEBPACK_IMPORTED_MODULE_3__["MenuGuard"]])
    ], AuthGuard);
    return AuthGuard;
}());



/***/ }),

/***/ "./src/app/shared/services/auth.service.ts":
/*!*************************************************!*\
  !*** ./src/app/shared/services/auth.service.ts ***!
  \*************************************************/
/*! exports provided: AuthService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AuthService", function() { return AuthService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../environments/environment */ "./src/environments/environment.ts");
/* harmony import */ var _notification_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./notification.service */ "./src/app/shared/services/notification.service.ts");
/* harmony import */ var _storage_project_event_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./storage/project-event.service */ "./src/app/shared/services/storage/project-event.service.ts");
/* harmony import */ var _storage_project_user_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./storage/project-user.service */ "./src/app/shared/services/storage/project-user.service.ts");








var AuthService = /** @class */ (function () {
    function AuthService(httpClient, userService, notificationService, router, projectEventService, projectUserService) {
        this.httpClient = httpClient;
        this.userService = userService;
        this.notificationService = notificationService;
        this.router = router;
        this.projectEventService = projectEventService;
        this.projectUserService = projectUserService;
    }
    /**
     * Login wrapper function
     * @param loginName
     * @param password
     */
    AuthService.prototype.login = function (loginName, password) {
        this.loginBackend(loginName, password);
    };
    /**
     * Logout wrapper function
     */
    AuthService.prototype.logout = function () {
        this.logoutBackend(this.userService.instant.masterToken, this.userService.instant.authToken, this.userService.instant.deviceId);
    };
    /**
     * Logged user role validation
     * @param {Role} role
     * @returns {boolean}
     */
    AuthService.prototype.hasRole = function (role) {
        var roles = this.projectUserService.instant.roles;
        return roles && roles.indexOf(role) >= 0;
    };
    /**
     * Login API function with saving user into local storage and navigate to dashboard screen
     * @param login
     * @param password
     * @param deviceId
     */
    AuthService.prototype.loginBackend = function (login, password, deviceId) {
        var _this = this;
        if (deviceId === void 0) { deviceId = 'device1'; }
        var headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpHeaders"]({ 'Content-Type': 'application/json' });
        var accessDeniedCode = '9002';
        this.httpClient.post(_environments_environment__WEBPACK_IMPORTED_MODULE_4__["environment"].URL_API + '/security/authenticate', {
            login: login,
            password: password,
            deviceId: deviceId
        }, { headers: headers })
            .subscribe(function (data) {
            _this.userService.setAuthData(data);
            _this.projectEventService.setEventData();
            _this.router.navigate(['dashboard']);
        }, function (error) {
            if (error.error.code === accessDeniedCode) {
                _this.notificationService.openErrorNotification('error.loginData');
            }
            else {
                _this.notificationService.openErrorNotification('error.login');
            }
        });
    };
    /**
     * Logout API function
     * @param masterToken
     * @param authenticationToken
     * @param deviceId
     */
    AuthService.prototype.logoutBackend = function (masterToken, authenticationToken, deviceId) {
        var _this = this;
        if (deviceId === void 0) { deviceId = 'device1'; }
        var headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpHeaders"]({ 'Content-Type': 'application/json' });
        this.projectEventService.setEventData();
        this.httpClient.post(_environments_environment__WEBPACK_IMPORTED_MODULE_4__["environment"].URL_API + '/security/invalidate', {
            masterToken: masterToken,
            authenticationToken: authenticationToken,
            deviceId: deviceId
        }, { headers: headers })
            .subscribe(function (data) {
            _this.userService.clearUserData();
            _this.router.navigate(['authentication/login']);
        }, function (error) {
            _this.router.navigate(['authentication/login']);
            _this.notificationService.openErrorNotification('error.logout');
        });
    };
    AuthService.ctorParameters = function () { return [
        { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"] },
        { type: _storage_project_user_service__WEBPACK_IMPORTED_MODULE_7__["ProjectUserService"] },
        { type: _notification_service__WEBPACK_IMPORTED_MODULE_5__["NotificationService"] },
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"] },
        { type: _storage_project_event_service__WEBPACK_IMPORTED_MODULE_6__["ProjectEventService"] },
        { type: _storage_project_user_service__WEBPACK_IMPORTED_MODULE_7__["ProjectUserService"] }
    ]; };
    AuthService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Injectable"])({
            providedIn: 'root'
        })
        /**
         * Service for authentification
         */ ,
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"],
            _storage_project_user_service__WEBPACK_IMPORTED_MODULE_7__["ProjectUserService"],
            _notification_service__WEBPACK_IMPORTED_MODULE_5__["NotificationService"],
            _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"],
            _storage_project_event_service__WEBPACK_IMPORTED_MODULE_6__["ProjectEventService"],
            _storage_project_user_service__WEBPACK_IMPORTED_MODULE_7__["ProjectUserService"]])
    ], AuthService);
    return AuthService;
}());



/***/ }),

/***/ "./src/app/shared/services/dashboard.service.ts":
/*!******************************************************!*\
  !*** ./src/app/shared/services/dashboard.service.ts ***!
  \******************************************************/
/*! exports provided: DashboardService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DashboardService", function() { return DashboardService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm5/index.js");
/* harmony import */ var _hazlenut_hazelnut_common_models__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../hazlenut/hazelnut-common/models */ "./src/app/shared/hazlenut/hazelnut-common/models/index.ts");
/* harmony import */ var _notification_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./notification.service */ "./src/app/shared/services/notification.service.ts");
/* harmony import */ var _project_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./project.service */ "./src/app/shared/services/project.service.ts");
/* harmony import */ var _storage_project_user_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./storage/project-user.service */ "./src/app/shared/services/storage/project-user.service.ts");








var DashboardService = /** @class */ (function (_super) {
    tslib__WEBPACK_IMPORTED_MODULE_0__["__extends"](DashboardService, _super);
    function DashboardService(http, notificationService, userService) {
        var _this = _super.call(this, http, 'projects', notificationService, userService) || this;
        _this.secondaryHeader = new rxjs__WEBPACK_IMPORTED_MODULE_3__["Subject"]();
        _this.dashboardFilter = new rxjs__WEBPACK_IMPORTED_MODULE_3__["Subject"]();
        _this.dashboardFilterNotifier$ = _this.dashboardFilter.asObservable();
        return _this;
    }
    /**
     * Add state filter
     * @param state
     */
    DashboardService.prototype.filterProjects = function (state) {
        var filters = [];
        if (state !== 'ALL') {
            filters.push(new _hazlenut_hazelnut_common_models__WEBPACK_IMPORTED_MODULE_4__["Filter"]('STATE', state, 'ENUM'));
        }
        return this.filter(filters);
    };
    DashboardService.prototype.setSecondaryHeaderContent = function (secondaryHeader) {
        this.secondaryHeader.next(secondaryHeader);
    };
    DashboardService.prototype.setDashboardFilter = function (filterValue) {
        this.dashboardFilter.next(filterValue);
    };
    DashboardService.ctorParameters = function () { return [
        { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"] },
        { type: _notification_service__WEBPACK_IMPORTED_MODULE_5__["NotificationService"] },
        { type: _storage_project_user_service__WEBPACK_IMPORTED_MODULE_7__["ProjectUserService"] }
    ]; };
    DashboardService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Injectable"])({
            providedIn: 'root'
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"],
            _notification_service__WEBPACK_IMPORTED_MODULE_5__["NotificationService"],
            _storage_project_user_service__WEBPACK_IMPORTED_MODULE_7__["ProjectUserService"]])
    ], DashboardService);
    return DashboardService;
}(_project_service__WEBPACK_IMPORTED_MODULE_6__["ProjectService"]));



/***/ }),

/***/ "./src/app/shared/services/data/business-area.service.ts":
/*!***************************************************************!*\
  !*** ./src/app/shared/services/data/business-area.service.ts ***!
  \***************************************************************/
/*! exports provided: BusinessAreaService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BusinessAreaService", function() { return BusinessAreaService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../../environments/environment */ "./src/environments/environment.ts");
/* harmony import */ var _hazlenut_hazelnut_common_hazelnut__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../hazlenut/hazelnut-common/hazelnut */ "./src/app/shared/hazlenut/hazelnut-common/hazelnut/index.ts");
/* harmony import */ var _hazlenut_hazelnut_common_models__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../hazlenut/hazelnut-common/models */ "./src/app/shared/hazlenut/hazelnut-common/models/index.ts");
/* harmony import */ var _notification_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../notification.service */ "./src/app/shared/services/notification.service.ts");
/* harmony import */ var _project_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../project.service */ "./src/app/shared/services/project.service.ts");
/* harmony import */ var _storage_project_event_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../storage/project-event.service */ "./src/app/shared/services/storage/project-event.service.ts");
/* harmony import */ var _storage_project_user_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../storage/project-user.service */ "./src/app/shared/services/storage/project-user.service.ts");










var BusinessAreaService = /** @class */ (function (_super) {
    tslib__WEBPACK_IMPORTED_MODULE_0__["__extends"](BusinessAreaService, _super);
    function BusinessAreaService(http, notificationService, userService, projectEventService) {
        var _this = _super.call(this, http, 'codeList', notificationService, userService) || this;
        _this.projectEventService = projectEventService;
        return _this;
    }
    /**
     * Get list of business area based on table change event criteria with specified code 'BAREA'
     * @param tableChangeEvent
     */
    BusinessAreaService.prototype.browseBusinessAreas = function (tableChangeEvent) {
        var filters = [];
        var sort = [];
        var limit = 15;
        var offset = 0;
        if (tableChangeEvent) {
            limit = tableChangeEvent.pageSize;
            offset = tableChangeEvent.pageIndex * tableChangeEvent.pageSize;
            filters = Object.values(tableChangeEvent.filters);
            filters.forEach(function (filter) {
                return filter.property = _hazlenut_hazelnut_common_hazelnut__WEBPACK_IMPORTED_MODULE_4__["StringUtils"].convertCamelToSnakeUpper(filter.property);
            });
            if (tableChangeEvent.sortActive && tableChangeEvent.sortDirection) {
                sort = [new _hazlenut_hazelnut_common_models__WEBPACK_IMPORTED_MODULE_5__["Sort"](tableChangeEvent.sortActive, tableChangeEvent.sortDirection)];
            }
            filters.push(new _hazlenut_hazelnut_common_models__WEBPACK_IMPORTED_MODULE_5__["Filter"]('CODE', 'BAREA'));
        }
        return this.browseWithSummary(_hazlenut_hazelnut_common_models__WEBPACK_IMPORTED_MODULE_5__["PostContent"].create(limit, offset, filters, sort));
    };
    /**
     * Get list of business area objects
     */
    BusinessAreaService.prototype.listBusinessAreas = function () {
        return this.browseWithSummary(_hazlenut_hazelnut_common_models__WEBPACK_IMPORTED_MODULE_5__["PostContent"].create(100, 0, [], []));
    };
    /**
     * Get list of source of agenda objects by code value 'ASO'
     */
    BusinessAreaService.prototype.listSourceOfAgendas = function () {
        return this.getListByCode('ASO');
    };
    /**
     * Get list of source of agenda objects by code value 'COUNTRY'
     */
    // TODO: create type and check active
    BusinessAreaService.prototype.listCountries = function () {
        return this.getListByCode('COUNTRY');
    };
    /**
     * Get list of category objects by code value 'CAT'
     */
    BusinessAreaService.prototype.listCategories = function () {
        return this.getListByCode('CAT');
    };
    /**
     * Get list of subcategory objects
     */
    BusinessAreaService.prototype.listSubCategories = function (categoryId) {
        return this.http.get(_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].URL_API + "/codeList/" + this.projectEventService.instant.id + "/" + categoryId, { headers: this.getHeader() });
    };
    /**
     * Browse list of objects from code list by code value
     * @param code
     */
    BusinessAreaService.prototype.getListByCode = function (code) {
        return this.browseWithSummary(_hazlenut_hazelnut_common_models__WEBPACK_IMPORTED_MODULE_5__["PostContent"].create(100, 0, [new _hazlenut_hazelnut_common_models__WEBPACK_IMPORTED_MODULE_5__["Filter"]('CODE', code)], []));
    };
    BusinessAreaService.ctorParameters = function () { return [
        { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"] },
        { type: _notification_service__WEBPACK_IMPORTED_MODULE_6__["NotificationService"] },
        { type: _storage_project_user_service__WEBPACK_IMPORTED_MODULE_9__["ProjectUserService"] },
        { type: _storage_project_event_service__WEBPACK_IMPORTED_MODULE_8__["ProjectEventService"] }
    ]; };
    BusinessAreaService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Injectable"])({
            providedIn: 'root'
        })
        /**
         * Service communicating with 'codeList' API url
         */
        ,
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"],
            _notification_service__WEBPACK_IMPORTED_MODULE_6__["NotificationService"],
            _storage_project_user_service__WEBPACK_IMPORTED_MODULE_9__["ProjectUserService"],
            _storage_project_event_service__WEBPACK_IMPORTED_MODULE_8__["ProjectEventService"]])
    ], BusinessAreaService);
    return BusinessAreaService;
}(_project_service__WEBPACK_IMPORTED_MODULE_7__["ProjectService"]));



/***/ }),

/***/ "./src/app/shared/services/data/images.service.ts":
/*!********************************************************!*\
  !*** ./src/app/shared/services/data/images.service.ts ***!
  \********************************************************/
/*! exports provided: ImagesService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ImagesService", function() { return ImagesService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm5/operators/index.js");
/* harmony import */ var _hazlenut_hazelnut_common_config_hazelnut_config__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../hazlenut/hazelnut-common/config/hazelnut-config */ "./src/app/shared/hazlenut/hazelnut-common/config/hazelnut-config.ts");
/* harmony import */ var _notification_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../notification.service */ "./src/app/shared/services/notification.service.ts");
/* harmony import */ var _project_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../project.service */ "./src/app/shared/services/project.service.ts");
/* harmony import */ var _storage_project_user_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../storage/project-user.service */ "./src/app/shared/services/storage/project-user.service.ts");








var ImagesService = /** @class */ (function (_super) {
    tslib__WEBPACK_IMPORTED_MODULE_0__["__extends"](ImagesService, _super);
    function ImagesService(http, notificationService, userService) {
        return _super.call(this, http, 'images', notificationService, userService) || this;
    }
    ImagesService.prototype.uploadImages = function (files) {
        var formData = new FormData();
        for (var _i = 0, files_1 = files; _i < files_1.length; _i++) {
            var file = files_1[_i];
            formData.append('images', file, file.name);
        }
        var headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpHeaders"]();
        headers = headers.set('device-id', this.userService.instant.deviceId);
        headers = headers.set('token', this.userService.instant.authToken);
        return this.post({
            headers: headers,
            url: _hazlenut_hazelnut_common_config_hazelnut_config__WEBPACK_IMPORTED_MODULE_4__["hazelnutConfig"].URL_API + "/internal/images",
            mapFunction: function (e) { return e; },
            body: formData,
        });
    };
    ImagesService.prototype.getImage = function (imageName) {
        return this.http.get(_hazlenut_hazelnut_common_config_hazelnut_config__WEBPACK_IMPORTED_MODULE_4__["hazelnutConfig"].URL_API + "/internal/images/0/" + imageName, {
            headers: this.getHeader(),
            responseType: 'blob',
        }).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["map"])(function (result) {
            return result;
        }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["catchError"])(this.handleError));
    };
    ImagesService.ctorParameters = function () { return [
        { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"] },
        { type: _notification_service__WEBPACK_IMPORTED_MODULE_5__["NotificationService"] },
        { type: _storage_project_user_service__WEBPACK_IMPORTED_MODULE_7__["ProjectUserService"] }
    ]; };
    ImagesService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Injectable"])({
            providedIn: 'root'
        })
        // TODO: remove project Service or add function to porject service
        ,
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"], _notification_service__WEBPACK_IMPORTED_MODULE_5__["NotificationService"], _storage_project_user_service__WEBPACK_IMPORTED_MODULE_7__["ProjectUserService"]])
    ], ImagesService);
    return ImagesService;
}(_project_service__WEBPACK_IMPORTED_MODULE_6__["ProjectService"]));



/***/ }),

/***/ "./src/app/shared/services/data/user-data.service.ts":
/*!***********************************************************!*\
  !*** ./src/app/shared/services/data/user-data.service.ts ***!
  \***********************************************************/
/*! exports provided: UserDataService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UserDataService", function() { return UserDataService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _notification_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../notification.service */ "./src/app/shared/services/notification.service.ts");
/* harmony import */ var _project_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../project.service */ "./src/app/shared/services/project.service.ts");
/* harmony import */ var _storage_project_user_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../storage/project-user.service */ "./src/app/shared/services/storage/project-user.service.ts");






var UserDataService = /** @class */ (function (_super) {
    tslib__WEBPACK_IMPORTED_MODULE_0__["__extends"](UserDataService, _super);
    function UserDataService(http, notificationService, userService) {
        return _super.call(this, http, 'user', notificationService, userService) || this;
    }
    /**
     * Get users object from API
     */
    UserDataService.prototype.getUsers = function () {
        return this.getDetail('');
    };
    UserDataService.ctorParameters = function () { return [
        { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"] },
        { type: _notification_service__WEBPACK_IMPORTED_MODULE_3__["NotificationService"] },
        { type: _storage_project_user_service__WEBPACK_IMPORTED_MODULE_5__["ProjectUserService"] }
    ]; };
    UserDataService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Injectable"])({
            providedIn: 'root'
        })
        /**
         * Fact service communicating with 'user' API url
         */
        ,
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"],
            _notification_service__WEBPACK_IMPORTED_MODULE_3__["NotificationService"],
            _storage_project_user_service__WEBPACK_IMPORTED_MODULE_5__["ProjectUserService"]])
    ], UserDataService);
    return UserDataService;
}(_project_service__WEBPACK_IMPORTED_MODULE_4__["ProjectService"]));



/***/ }),

/***/ "./src/app/shared/services/global-error-handler.service.ts":
/*!*****************************************************************!*\
  !*** ./src/app/shared/services/global-error-handler.service.ts ***!
  \*****************************************************************/
/*! exports provided: GlobalErrorHandlerService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "GlobalErrorHandlerService", function() { return GlobalErrorHandlerService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ngx-translate/core */ "./node_modules/@ngx-translate/core/fesm5/ngx-translate-core.js");
/* harmony import */ var _notification_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./notification.service */ "./src/app/shared/services/notification.service.ts");




var ERROR = 'errorCode.';
var GlobalErrorHandlerService = /** @class */ (function () {
    function GlobalErrorHandlerService(notificationService, translateService) {
        this.notificationService = notificationService;
        this.translateService = translateService;
    }
    GlobalErrorHandlerService.prototype.handleError = function (error) {
        var errorCode = '';
        // if (typeof error === 'string') {
        //     errorCode = error;
        // } else if (!isNullOrUndefined(error) && !isNullOrUndefined(error.error) && !isNullOrUndefined(error.error.code)) {
        //     errorCode = ERROR + error.error.code;
        // } else if (!isNullOrUndefined(error) && !isNullOrUndefined(error.error) && !isNullOrUndefined(error.error.message)) {
        //     errorCode = ERROR + error.error.message;
        // } else {
        //     errorCode = 'error.api';
        // }
        //
        // this.notificationService.openErrorNotification(this.translateService.instant(errorCode));
        console.error(error);
    };
    GlobalErrorHandlerService.ctorParameters = function () { return [
        { type: _notification_service__WEBPACK_IMPORTED_MODULE_3__["NotificationService"] },
        { type: _ngx_translate_core__WEBPACK_IMPORTED_MODULE_2__["TranslateService"] }
    ]; };
    GlobalErrorHandlerService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root'
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_notification_service__WEBPACK_IMPORTED_MODULE_3__["NotificationService"], _ngx_translate_core__WEBPACK_IMPORTED_MODULE_2__["TranslateService"]])
    ], GlobalErrorHandlerService);
    return GlobalErrorHandlerService;
}());



/***/ }),

/***/ "./src/app/shared/services/menu-guard.ts":
/*!***********************************************!*\
  !*** ./src/app/shared/services/menu-guard.ts ***!
  \***********************************************/
/*! exports provided: MenuGuard */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MenuGuard", function() { return MenuGuard; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _enums_role_enum__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../enums/role.enum */ "./src/app/shared/enums/role.enum.ts");
/* harmony import */ var _auth_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./auth.service */ "./src/app/shared/services/auth.service.ts");




var MenuGuard = /** @class */ (function () {
    function MenuGuard(authService) {
        this.authService = authService;
        this.menuOptionsVsRoles = [
            {
                option: 'menu.project',
                role: _enums_role_enum__WEBPACK_IMPORTED_MODULE_2__["Role"].RoleMenuProject
            },
            {
                option: 'menu.businessAreas',
                role: _enums_role_enum__WEBPACK_IMPORTED_MODULE_2__["Role"].RoleMenuBusinessArea
            },
            {
                option: 'menu.facts',
                role: _enums_role_enum__WEBPACK_IMPORTED_MODULE_2__["Role"].RoleMenuFactItem
            },
            {
                option: 'menu.allFacts',
                role: _enums_role_enum__WEBPACK_IMPORTED_MODULE_2__["Role"].RoleMenuAllFactItem
            },
            {
                option: 'menu.reports',
                role: _enums_role_enum__WEBPACK_IMPORTED_MODULE_2__["Role"].RoleMenuReports
            },
        ];
    }
    MenuGuard.prototype.menuRoutingCheck = function (menuOption) {
        var menuRouteIndex = this.menuOptionsVsRoles
            .map(function (menuItem) { return menuItem.option; })
            .indexOf(menuOption);
        if (menuRouteIndex > -1) {
            return this.authService.hasRole(this.menuOptionsVsRoles[menuRouteIndex].role);
        }
        return true;
    };
    MenuGuard.ctorParameters = function () { return [
        { type: _auth_service__WEBPACK_IMPORTED_MODULE_3__["AuthService"] }
    ]; };
    MenuGuard = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root'
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_auth_service__WEBPACK_IMPORTED_MODULE_3__["AuthService"]])
    ], MenuGuard);
    return MenuGuard;
}());



/***/ }),

/***/ "./src/app/shared/services/notification.service.ts":
/*!*********************************************************!*\
  !*** ./src/app/shared/services/notification.service.ts ***!
  \*********************************************************/
/*! exports provided: NotificationService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NotificationService", function() { return NotificationService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_material__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/material */ "./node_modules/@angular/material/esm5/material.es5.js");
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ngx-translate/core */ "./node_modules/@ngx-translate/core/fesm5/ngx-translate-core.js");
/* harmony import */ var _hazlenut_small_components_notifications__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../hazlenut/small-components/notifications */ "./src/app/shared/hazlenut/small-components/notifications/index.ts");
/* harmony import */ var _hazlenut_small_components_notifications_notification_type_enum__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../hazlenut/small-components/notifications/notification-type.enum */ "./src/app/shared/hazlenut/small-components/notifications/notification-type.enum.ts");






var DEFAULT_DURATION = 5000;
var NotificationService = /** @class */ (function () {
    function NotificationService(snackBar, translateService, zone) {
        this.snackBar = snackBar;
        this.translateService = translateService;
        this.zone = zone;
    }
    /**
     * Error notification when something fails
     * @param message
     */
    NotificationService.prototype.openErrorNotification = function (message) {
        var _this = this;
        this.zone.run(function () { return _this.snackBar.open(message); });
        return this.openNotification('snack-error', { message: message, type: _hazlenut_small_components_notifications_notification_type_enum__WEBPACK_IMPORTED_MODULE_5__["NotificationType"].ERROR });
    };
    /**
     * Info notification
     * @param message
     */
    NotificationService.prototype.openInfoNotification = function (message) {
        var _this = this;
        this.zone.run(function () { return _this.snackBar.open(message); });
        return this.openNotification('snack-info', { message: message, type: _hazlenut_small_components_notifications_notification_type_enum__WEBPACK_IMPORTED_MODULE_5__["NotificationType"].WARNING });
    };
    /**
     * Sucess notification when something done properly
     * @param message
     */
    NotificationService.prototype.openSuccessNotification = function (message) {
        var _this = this;
        this.zone.run(function () { return _this.snackBar.open(message); });
        return this.openNotification('snack-success', { message: message, type: _hazlenut_small_components_notifications_notification_type_enum__WEBPACK_IMPORTED_MODULE_5__["NotificationType"].SUCCESS });
    };
    /**
     * Show snack bar notification
     * @param styleClass
     * @param type
     * @param message
     * @param duration
     */
    NotificationService.prototype.openNotification = function (styleClass, _a) {
        var type = _a.type, message = _a.message, _b = _a.duration, duration = _b === void 0 ? DEFAULT_DURATION : _b;
        return this.snackBar.openFromComponent(_hazlenut_small_components_notifications__WEBPACK_IMPORTED_MODULE_4__["NotificationSnackBarComponent"], {
            duration: duration,
            data: { type: type, message: this.translateService.instant(message) },
            panelClass: [styleClass]
        });
    };
    NotificationService.ctorParameters = function () { return [
        { type: _angular_material__WEBPACK_IMPORTED_MODULE_2__["MatSnackBar"] },
        { type: _ngx_translate_core__WEBPACK_IMPORTED_MODULE_3__["TranslateService"] },
        { type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["NgZone"] }
    ]; };
    NotificationService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root'
        })
        /**
         * Notification service for showing notifications in snack bar
         */
        ,
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_material__WEBPACK_IMPORTED_MODULE_2__["MatSnackBar"],
            _ngx_translate_core__WEBPACK_IMPORTED_MODULE_3__["TranslateService"],
            _angular_core__WEBPACK_IMPORTED_MODULE_1__["NgZone"]])
    ], NotificationService);
    return NotificationService;
}());



/***/ }),

/***/ "./src/app/shared/services/project.service.ts":
/*!****************************************************!*\
  !*** ./src/app/shared/services/project.service.ts ***!
  \****************************************************/
/*! exports provided: ProjectService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProjectService", function() { return ProjectService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _hazlenut_hazelnut_common_config_hazelnut_config__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../hazlenut/hazelnut-common/config/hazelnut-config */ "./src/app/shared/hazlenut/hazelnut-common/config/hazelnut-config.ts");
/* harmony import */ var _hazlenut_hazelnut_common_services__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../hazlenut/hazelnut-common/services */ "./src/app/shared/hazlenut/hazelnut-common/services/index.ts");




/**
 * HTTP methods only for this project should be in project service
 */
var ProjectService = /** @class */ (function (_super) {
    tslib__WEBPACK_IMPORTED_MODULE_0__["__extends"](ProjectService, _super);
    function ProjectService(http, url, notificationService, userService) {
        var _this = _super.call(this, http, notificationService, url) || this;
        _this.userService = userService;
        return _this;
    }
    /**
     * Function returns list of result from browse API
     * @param id - id of searched object
     * @param projectId - projectId of searched object
     */
    ProjectService.prototype.getFactItemDetail = function (id, projectId) {
        var realIds = id && projectId ? "/" + id + "/" + projectId : '';
        return this.get({
            url: _hazlenut_hazelnut_common_config_hazelnut_config__WEBPACK_IMPORTED_MODULE_2__["hazelnutConfig"].URL_API + "/" + this.urlKey + realIds,
            mapFunction: this.extractDetail
        });
    };
    ProjectService.prototype.getHeader = function () {
        var headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpHeaders"]();
        headers = headers.set('device-id', this.userService.instant.deviceId);
        headers = headers.set('token', localStorage.getItem(this.userService.login) ? JSON.parse(localStorage.getItem(this.userService.login)).authToken : '');
        headers = headers.set('Content-Type', 'application/json');
        return headers;
    };
    return ProjectService;
}(_hazlenut_hazelnut_common_services__WEBPACK_IMPORTED_MODULE_3__["AbstractService"]));



/***/ }),

/***/ "./src/app/shared/services/routing-storage.service.ts":
/*!************************************************************!*\
  !*** ./src/app/shared/services/routing-storage.service.ts ***!
  \************************************************************/
/*! exports provided: RoutingStorageService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RoutingStorageService", function() { return RoutingStorageService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm5/operators/index.js");




var RoutingStorageService = /** @class */ (function () {
    function RoutingStorageService(router) {
        this.router = router;
        this.history = [];
    }
    /**
     * Start storing of urls
     */
    RoutingStorageService.prototype.loadRouting = function () {
        var _this = this;
        this.router.events
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["filter"])(function (event) { return event instanceof _angular_router__WEBPACK_IMPORTED_MODULE_2__["NavigationEnd"]; }))
            .subscribe(function (_a) {
            var urlAfterRedirects = _a.urlAfterRedirects;
            _this.history = _this.history.concat([urlAfterRedirects]);
        });
    };
    /**
     * Get url array. Array represent showed url in application in order
     */
    RoutingStorageService.prototype.getHistory = function () {
        return this.history;
    };
    /**
     * Get previous url
     */
    RoutingStorageService.prototype.getPreviousUrl = function () {
        return this.history[this.history.length - 2] || '/index';
    };
    RoutingStorageService.ctorParameters = function () { return [
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"] }
    ]; };
    RoutingStorageService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root'
        })
        /**
         * Service for storing path of showed url in application
         */
        ,
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]])
    ], RoutingStorageService);
    return RoutingStorageService;
}());



/***/ }),

/***/ "./src/app/shared/services/storage/event.service.ts":
/*!**********************************************************!*\
  !*** ./src/app/shared/services/storage/event.service.ts ***!
  \**********************************************************/
/*! exports provided: EventService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EventService", function() { return EventService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm5/index.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm5/operators/index.js");
/* harmony import */ var _hazlenut_hazelnut_common_services__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../hazlenut/hazelnut-common/services */ "./src/app/shared/hazlenut/hazelnut-common/services/index.ts");





var EventService = /** @class */ (function () {
    function EventService(storageService) {
        var _this = this;
        this.storageService = storageService;
        var value = (this.loadData() || {});
        this._instant = new Proxy(value, {
            get: function (target, name) {
                return _this._behaviorSubject.value[name];
            },
            set: function () {
                throw new Error('Cannot set value directly');
            }
        });
        this._subject = new Proxy(value, {
            get: function (target, name) {
                return _this._behaviorSubject.pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["map"])(function (item) { return item[name]; }));
            },
            set: function () {
                throw new Error('Cannot set value directly');
            }
        });
        this._behaviorSubject = new rxjs__WEBPACK_IMPORTED_MODULE_2__["BehaviorSubject"](value);
    }
    Object.defineProperty(EventService.prototype, "instant", {
        get: function () {
            return this._instant;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(EventService.prototype, "subject", {
        get: function () {
            return this._subject;
        },
        enumerable: true,
        configurable: true
    });
    EventService.prototype.setProperty = function (key, value) {
        var newValue = tslib__WEBPACK_IMPORTED_MODULE_0__["__assign"]({}, this._behaviorSubject.value);
        newValue[key] = value;
        this._behaviorSubject.next(newValue);
        return newValue;
    };
    EventService.prototype.setData = function (data) {
        this._behaviorSubject.next(data);
        this.storeData(data);
        return data;
    };
    EventService.prototype.clearUserData = function () {
        this.storageService.removeItem('projectData');
    };
    EventService.prototype.loadData = function () {
        return this.storageService.getObjectItem('projectData');
    };
    EventService.prototype.storeData = function (data) {
        this.storageService.setItemValue('projectData', data);
    };
    EventService.ctorParameters = function () { return [
        { type: _hazlenut_hazelnut_common_services__WEBPACK_IMPORTED_MODULE_4__["AbstractStorageService"], decorators: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["Inject"], args: [_hazlenut_hazelnut_common_services__WEBPACK_IMPORTED_MODULE_4__["ABSTRACT_STORAGE_TOKEN"],] }] }
    ]; };
    EventService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root'
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__param"](0, Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Inject"])(_hazlenut_hazelnut_common_services__WEBPACK_IMPORTED_MODULE_4__["ABSTRACT_STORAGE_TOKEN"])),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_hazlenut_hazelnut_common_services__WEBPACK_IMPORTED_MODULE_4__["AbstractStorageService"]])
    ], EventService);
    return EventService;
}());



/***/ }),

/***/ "./src/app/shared/services/storage/project-event.service.ts":
/*!******************************************************************!*\
  !*** ./src/app/shared/services/storage/project-event.service.ts ***!
  \******************************************************************/
/*! exports provided: ProjectEventService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProjectEventService", function() { return ProjectEventService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _hazlenut_hazelnut_common_services__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../hazlenut/hazelnut-common/services */ "./src/app/shared/hazlenut/hazelnut-common/services/index.ts");
/* harmony import */ var _data_images_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../data/images.service */ "./src/app/shared/services/data/images.service.ts");
/* harmony import */ var _event_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./event.service */ "./src/app/shared/services/storage/event.service.ts");





var ProjectEventService = /** @class */ (function (_super) {
    tslib__WEBPACK_IMPORTED_MODULE_0__["__extends"](ProjectEventService, _super);
    function ProjectEventService(storageService, imagesService) {
        var _this = _super.call(this, storageService) || this;
        _this.imagesService = imagesService;
        _this.imagePath = 'assets/img/event-logos/default_logo.png';
        return _this;
    }
    ProjectEventService.prototype.setEventData = function (project, isEvent, imagePath) {
        if (project === void 0) { project = null; }
        if (isEvent === void 0) { isEvent = false; }
        if (imagePath === void 0) { imagePath = null; }
        this.setData({
            isEvent: isEvent,
            imagePath: imagePath,
            id: project ? project.id : null,
            year: project ? +project.year : null,
            projectName: project ? project.name : null,
            firstVenue: project && project.venues[0] ? project.venues[0].city : null,
            secondVenue: project && project.venues[1] ? project.venues[1].city : null,
            active: project ? project.state === 'OPEN' : null,
        });
    };
    ProjectEventService.prototype.setEventDataFromDetail = function (project, isEvent, imagePath) {
        var _this = this;
        if (project === void 0) { project = null; }
        if (isEvent === void 0) { isEvent = false; }
        if (imagePath === void 0) { imagePath = null; }
        if (!imagePath) {
            this.setDetailObject(project, isEvent);
        }
        else {
            this.imagesService.getImage(imagePath)
                .subscribe(function (blob) {
                var reader = new FileReader();
                reader.onload = function () {
                    _this.imagePath = reader.result;
                    _this.setDetailObject(project, isEvent);
                };
                reader.readAsDataURL(blob);
            });
        }
    };
    ProjectEventService.prototype.setDetailObject = function (project, isEvent) {
        this.setData({
            isEvent: isEvent,
            imagePath: this.imagePath,
            id: project ? project.projectId : null,
            year: project ? +project.year : null,
            projectName: project ? project.name : null,
            firstVenue: project && project.firstVenue ? project.firstVenue : null,
            secondVenue: project && project.secondVenue ? project.secondVenue : null,
            active: project ? project.status === 'OPEN' : null,
        });
    };
    ProjectEventService.ctorParameters = function () { return [
        { type: _hazlenut_hazelnut_common_services__WEBPACK_IMPORTED_MODULE_2__["AbstractStorageService"] },
        { type: _data_images_service__WEBPACK_IMPORTED_MODULE_3__["ImagesService"] }
    ]; };
    ProjectEventService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root'
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_hazlenut_hazelnut_common_services__WEBPACK_IMPORTED_MODULE_2__["AbstractStorageService"], _data_images_service__WEBPACK_IMPORTED_MODULE_3__["ImagesService"]])
    ], ProjectEventService);
    return ProjectEventService;
}(_event_service__WEBPACK_IMPORTED_MODULE_4__["EventService"]));



/***/ }),

/***/ "./src/app/shared/services/storage/project-user.service.ts":
/*!*****************************************************************!*\
  !*** ./src/app/shared/services/storage/project-user.service.ts ***!
  \*****************************************************************/
/*! exports provided: ProjectUserService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProjectUserService", function() { return ProjectUserService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _hazlenut_hazelnut_common_services__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../hazlenut/hazelnut-common/services */ "./src/app/shared/hazlenut/hazelnut-common/services/index.ts");



var ProjectUserService = /** @class */ (function (_super) {
    tslib__WEBPACK_IMPORTED_MODULE_0__["__extends"](ProjectUserService, _super);
    function ProjectUserService(storageService) {
        return _super.call(this, storageService) || this;
    }
    Object.defineProperty(ProjectUserService.prototype, "isLoggedIn", {
        get: function () {
            return Boolean(this.instant && this.instant.authToken);
        },
        enumerable: true,
        configurable: true
    });
    ProjectUserService.prototype.setAuthData = function (data) {
        this.setData({
            id: data.accountData.id,
            login: data.accountData.login,
            email: data.accountData.email,
            roles: data.accountData.roles,
            masterToken: data.masterTokenData.generatedToken,
            authToken: data.authenticationTokenData.generatedToken,
            userId: data.accountData.user.id,
            deviceId: 'device1',
        });
    };
    ProjectUserService.ctorParameters = function () { return [
        { type: _hazlenut_hazelnut_common_services__WEBPACK_IMPORTED_MODULE_2__["AbstractStorageService"] }
    ]; };
    ProjectUserService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root'
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_hazlenut_hazelnut_common_services__WEBPACK_IMPORTED_MODULE_2__["AbstractStorageService"]])
    ], ProjectUserService);
    return ProjectUserService;
}(_hazlenut_hazelnut_common_services__WEBPACK_IMPORTED_MODULE_2__["UserService"]));



/***/ }),

/***/ "./src/app/shared/services/translate-wrapper.service.ts":
/*!**************************************************************!*\
  !*** ./src/app/shared/services/translate-wrapper.service.ts ***!
  \**************************************************************/
/*! exports provided: TranslateWrapperService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TranslateWrapperService", function() { return TranslateWrapperService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ngx-translate/core */ "./node_modules/@ngx-translate/core/fesm5/ngx-translate-core.js");



var TranslateWrapperService = /** @class */ (function () {
    function TranslateWrapperService(translateService) {
        this.translateService = translateService;
    }
    TranslateWrapperService.prototype.get = function (key) {
        return this.translateService.get(key);
    };
    TranslateWrapperService.prototype.instant = function (key) {
        return this.translateService.instant(key);
    };
    TranslateWrapperService.ctorParameters = function () { return [
        { type: _ngx_translate_core__WEBPACK_IMPORTED_MODULE_2__["TranslateService"] }
    ]; };
    TranslateWrapperService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root'
        })
        /**
         * Translate wrapper
         */
        ,
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ngx_translate_core__WEBPACK_IMPORTED_MODULE_2__["TranslateService"]])
    ], TranslateWrapperService);
    return TranslateWrapperService;
}());



/***/ }),

/***/ "./src/app/shared/utils/constants.ts":
/*!*******************************************!*\
  !*** ./src/app/shared/utils/constants.ts ***!
  \*******************************************/
/*! exports provided: AppConstants */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppConstants", function() { return AppConstants; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");

var AppConstants = /** @class */ (function () {
    function AppConstants() {
    }
    // Current project version, also need to be changed in package.json file
    AppConstants.version = '1.3.2';
    return AppConstants;
}());



/***/ }),

/***/ "./src/app/shared/utils/removeLastChar.ts":
/*!************************************************!*\
  !*** ./src/app/shared/utils/removeLastChar.ts ***!
  \************************************************/
/*! exports provided: checkAndRemoveLastDotComma */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "checkAndRemoveLastDotComma", function() { return checkAndRemoveLastDotComma; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var util__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! util */ "./node_modules/util/util.js");
/* harmony import */ var util__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(util__WEBPACK_IMPORTED_MODULE_1__);


function checkAndRemoveLastDotComma(value) {
    if (Object(util__WEBPACK_IMPORTED_MODULE_1__["isNullOrUndefined"])(value)) {
        return null;
    }
    var lastCharacter = value.toString()
        .slice(-1);
    if (lastCharacter !== '' && (lastCharacter === '.' || lastCharacter === ',')) {
        value = value.toString()
            .substring(0, value.toString().length - 1);
    }
    value = value.replace(',', '.');
    value = value.split(' ').join('');
    return value;
}


/***/ }),

/***/ "./src/environments/environment.ts":
/*!*****************************************!*\
  !*** ./src/environments/environment.ts ***!
  \*****************************************/
/*! exports provided: environment */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "environment", function() { return environment; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");

var environment = {
    production: false,
    URL_API: 'https://iihfapi.demo.qbsw.sk/api',
};


/***/ }),

/***/ "./src/main.ts":
/*!*********************!*\
  !*** ./src/main.ts ***!
  \*********************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/platform-browser-dynamic */ "./node_modules/@angular/platform-browser-dynamic/fesm5/platform-browser-dynamic.js");
/* harmony import */ var hammerjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! hammerjs */ "./node_modules/hammerjs/hammer.js");
/* harmony import */ var hammerjs__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(hammerjs__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _app_app_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./app/app.module */ "./src/app/app.module.ts");
/* harmony import */ var _app_shared_hazlenut_hazelnut_common_config_hazelnut_config__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./app/shared/hazlenut/hazelnut-common/config/hazelnut-config */ "./src/app/shared/hazlenut/hazelnut-common/config/hazelnut-config.ts");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./environments/environment */ "./src/environments/environment.ts");







Object(_app_shared_hazlenut_hazelnut_common_config_hazelnut_config__WEBPACK_IMPORTED_MODULE_5__["initHazelnutConfig"])({
    URL_API: _environments_environment__WEBPACK_IMPORTED_MODULE_6__["environment"].URL_API,
    LANGUAGE: 'en',
    VERSION: '1.0.0',
    BROWSE_LIMIT: 15
});
if (_environments_environment__WEBPACK_IMPORTED_MODULE_6__["environment"].production) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["enableProdMode"])();
}
Object(_angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_2__["platformBrowserDynamic"])()
    .bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_4__["AppModule"])
    .catch(function (error) { return console.error(error); });


/***/ }),

/***/ 0:
/*!***************************!*\
  !*** multi ./src/main.ts ***!
  \***************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! D:\projects\iihf\wfm-web\src\main.ts */"./src/main.ts");


/***/ }),

/***/ 1:
/*!**********************!*\
  !*** zlib (ignored) ***!
  \**********************/
/*! no static exports found */
/***/ (function(module, exports) {

/* (ignored) */

/***/ }),

/***/ 2:
/*!********************!*\
  !*** fs (ignored) ***!
  \********************/
/*! no static exports found */
/***/ (function(module, exports) {

/* (ignored) */

/***/ }),

/***/ 3:
/*!**********************!*\
  !*** http (ignored) ***!
  \**********************/
/*! no static exports found */
/***/ (function(module, exports) {

/* (ignored) */

/***/ }),

/***/ 4:
/*!***********************!*\
  !*** https (ignored) ***!
  \***********************/
/*! no static exports found */
/***/ (function(module, exports) {

/* (ignored) */

/***/ })

},[[0,"runtime","vendor"]]]);
//# sourceMappingURL=main.js.map