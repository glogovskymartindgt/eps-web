(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["common"],{

/***/ "./src/app/shared/services/storage/area.service.ts":
/*!*********************************************************!*\
  !*** ./src/app/shared/services/storage/area.service.ts ***!
  \*********************************************************/
/*! exports provided: AreaService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AreaService", function() { return AreaService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm5/index.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm5/operators/index.js");
/* harmony import */ var _hazlenut_hazelnut_common_services__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../hazlenut/hazelnut-common/services */ "./src/app/shared/hazlenut/hazelnut-common/services/index.ts");





var AreaService = /** @class */ (function () {
    function AreaService(storageService) {
        var _this = this;
        this.storageService = storageService;
        var value = (this.loadData() || {});
        this._instant = new Proxy(value, {
            get: function (target, name) {
                return _this._behaviorSubject.value[name];
            },
            set: function () {
                throw new Error('Cannot set value directly');
            }
        });
        this._subject = new Proxy(value, {
            get: function (target, name) {
                return _this._behaviorSubject.pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["map"])(function (item) { return item[name]; }));
            },
            set: function () {
                throw new Error('Cannot set value directly');
            }
        });
        this._behaviorSubject = new rxjs__WEBPACK_IMPORTED_MODULE_2__["BehaviorSubject"](value);
    }
    Object.defineProperty(AreaService.prototype, "instant", {
        get: function () {
            return this._instant;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(AreaService.prototype, "subject", {
        get: function () {
            return this._subject;
        },
        enumerable: true,
        configurable: true
    });
    AreaService.prototype.setProperty = function (key, value) {
        var newValue = tslib__WEBPACK_IMPORTED_MODULE_0__["__assign"]({}, this._behaviorSubject.value);
        newValue[key] = value;
        this._behaviorSubject.next(newValue);
        return newValue;
    };
    AreaService.prototype.setData = function (data) {
        this._behaviorSubject.next(data);
        this.storeData(data);
        return data;
    };
    AreaService.prototype.clearUserData = function () {
        this.storageService.removeItem('areaData');
    };
    AreaService.prototype.loadData = function () {
        return this.storageService.getObjectItem('areaData');
    };
    AreaService.prototype.storeData = function (data) {
        this.storageService.setItemValue('areaData', data);
    };
    AreaService.ctorParameters = function () { return [
        { type: _hazlenut_hazelnut_common_services__WEBPACK_IMPORTED_MODULE_4__["AbstractStorageService"], decorators: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["Inject"], args: [_hazlenut_hazelnut_common_services__WEBPACK_IMPORTED_MODULE_4__["ABSTRACT_STORAGE_TOKEN"],] }] }
    ]; };
    AreaService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root'
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__param"](0, Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Inject"])(_hazlenut_hazelnut_common_services__WEBPACK_IMPORTED_MODULE_4__["ABSTRACT_STORAGE_TOKEN"])),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_hazlenut_hazelnut_common_services__WEBPACK_IMPORTED_MODULE_4__["AbstractStorageService"]])
    ], AreaService);
    return AreaService;
}());



/***/ }),

/***/ "./src/app/shared/services/storage/selected-area.service.ts":
/*!******************************************************************!*\
  !*** ./src/app/shared/services/storage/selected-area.service.ts ***!
  \******************************************************************/
/*! exports provided: SelectedAreaService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SelectedAreaService", function() { return SelectedAreaService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _hazlenut_hazelnut_common_services__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../hazlenut/hazelnut-common/services */ "./src/app/shared/hazlenut/hazelnut-common/services/index.ts");
/* harmony import */ var _area_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./area.service */ "./src/app/shared/services/storage/area.service.ts");




var SelectedAreaService = /** @class */ (function (_super) {
    tslib__WEBPACK_IMPORTED_MODULE_0__["__extends"](SelectedAreaService, _super);
    function SelectedAreaService(storageService) {
        return _super.call(this, storageService) || this;
    }
    SelectedAreaService.prototype.setSelectedArea = function (selectedArea) {
        this.setData({
            selectedArea: selectedArea
        });
    };
    SelectedAreaService.ctorParameters = function () { return [
        { type: _hazlenut_hazelnut_common_services__WEBPACK_IMPORTED_MODULE_2__["AbstractStorageService"] }
    ]; };
    SelectedAreaService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root'
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_hazlenut_hazelnut_common_services__WEBPACK_IMPORTED_MODULE_2__["AbstractStorageService"]])
    ], SelectedAreaService);
    return SelectedAreaService;
}(_area_service__WEBPACK_IMPORTED_MODULE_3__["AreaService"]));



/***/ })

}]);
//# sourceMappingURL=common.js.map