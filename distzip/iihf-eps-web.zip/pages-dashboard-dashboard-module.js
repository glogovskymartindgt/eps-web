(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-dashboard-dashboard-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/dashboard/project-card/project-card.component.html":
/*!****************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/dashboard/project-card/project-card.component.html ***!
  \****************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<!--Project component showing basic information about project and logo-->\r\n<div class=\"project-card m-13\" fxLayout=\"row\">\r\n    <div (click)=\"onProjectSelected()\" class=\"project-card-content\" fxFlex=\"95\">\r\n        <div class=\"p-10\" fxFlex=\"15\" fxLayoutAlign=\"center center\">\r\n            <!--Logo image is from static list in assets, not from API-->\r\n            <img (error)=\"'assets/img/event-logos/default_logo.png'\"\r\n                 [src]=\"imagePath\"\r\n                 alt=\"championship logo\"\r\n                 class=\"project-image\"\r\n            >\r\n        </div>\r\n        <div fxFlex=\"85\">\r\n            <p class=\"project-card-primary-font mb-0 mt-25\">{{project?.year}} {{project?.name}}</p>\r\n            <p *ngIf=\"showOneCountry\" class=\"project-card-secondary-font m-0 mt-5\">{{project?.venues[0]?.country}}</p>\r\n            <p *ngIf=\"showAllCountries\" class=\"project-card-secondary-font m-0 mt-5\">{{project?.venues[0]?.country}}\r\n                <span *ngIf=\"project?.venues[1]?.country\">and {{project?.venues[1]?.country}}</span></p>\r\n            <p *ngIf=\"showOneCity\" class=\"project-card-location-font m-0 mt-5\">{{project?.venues[0]?.city}}</p>\r\n            <p *ngIf=\"showAllCities\" class=\"project-card-secondary-font m-0 mt-5\">{{project?.venues[0]?.city}}\r\n                <span *ngIf=\"project?.venues[0]?.city && project?.venues[1]?.city\">and</span>&nbsp;<span *ngIf=\"project?.venues[1]?.city\">{{project?.venues[1]?.city}}</span></p>\r\n        </div>\r\n    </div>\r\n    <div [ngClass]=\"(project?.state == 'OPEN') ? 'open' : (project?.state == 'CLOSED')  ? 'closed'  : '' \"\r\n         class=\"project-card-right\" fxFlex=\"5\"\r\n    >\r\n    </div>\r\n</div>\r\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/dashboard/project-list/project-list.component.html":
/*!****************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/dashboard/project-list/project-list.component.html ***!
  \****************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<!--Project components showing basic information about project and logo responsive design on project cards-->\r\n<div class=\"wrapper mb-40\" fxLayout=\"row wrap\" fxLayoutAlign=\"start center\">\r\n    <project-card *ngFor=\"let project of projects\" [project]=\"project\">\r\n    </project-card>\r\n</div>\r\n");

/***/ }),

/***/ "./src/app/pages/dashboard/dashboard-routing.module.ts":
/*!*************************************************************!*\
  !*** ./src/app/pages/dashboard/dashboard-routing.module.ts ***!
  \*************************************************************/
/*! exports provided: DashboardRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DashboardRoutingModule", function() { return DashboardRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _project_list_project_list_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./project-list/project-list.component */ "./src/app/pages/dashboard/project-list/project-list.component.ts");




var routes = [
    {
        path: '',
        children: [
            {
                path: '',
                pathMatch: 'full',
                redirectTo: 'list',
                data: { title: 'projectList' },
            },
            {
                path: 'list',
                component: _project_list_project_list_component__WEBPACK_IMPORTED_MODULE_3__["ProjectListComponent"],
                data: { title: 'projectList' },
            },
        ],
    }
];
var DashboardRoutingModule = /** @class */ (function () {
    function DashboardRoutingModule() {
    }
    DashboardRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
            exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
        })
    ], DashboardRoutingModule);
    return DashboardRoutingModule;
}());



/***/ }),

/***/ "./src/app/pages/dashboard/dashboard.module.ts":
/*!*****************************************************!*\
  !*** ./src/app/pages/dashboard/dashboard.module.ts ***!
  \*****************************************************/
/*! exports provided: DashboardModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DashboardModule", function() { return DashboardModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_flex_layout__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/flex-layout */ "./node_modules/@angular/flex-layout/esm5/flex-layout.es5.js");
/* harmony import */ var _shared_hazlenut_hazelnut_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../shared/hazlenut/hazelnut-common */ "./src/app/shared/hazlenut/hazelnut-common/index.ts");
/* harmony import */ var _dashboard_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./dashboard-routing.module */ "./src/app/pages/dashboard/dashboard-routing.module.ts");
/* harmony import */ var _project_card_project_card_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./project-card/project-card.component */ "./src/app/pages/dashboard/project-card/project-card.component.ts");
/* harmony import */ var _project_list_project_list_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./project-list/project-list.component */ "./src/app/pages/dashboard/project-list/project-list.component.ts");








var DashboardModule = /** @class */ (function () {
    function DashboardModule() {
    }
    DashboardModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["NgModule"])({
            declarations: [
                _project_list_project_list_component__WEBPACK_IMPORTED_MODULE_7__["ProjectListComponent"],
                _project_card_project_card_component__WEBPACK_IMPORTED_MODULE_6__["ProjectCardComponent"]
            ],
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"],
                _dashboard_routing_module__WEBPACK_IMPORTED_MODULE_5__["DashboardRoutingModule"],
                _angular_flex_layout__WEBPACK_IMPORTED_MODULE_3__["FlexLayoutModule"],
                _shared_hazlenut_hazelnut_common__WEBPACK_IMPORTED_MODULE_4__["MaterialModule"],
            ]
        })
    ], DashboardModule);
    return DashboardModule;
}());



/***/ }),

/***/ "./src/app/pages/dashboard/project-card/project-card.component.scss":
/*!**************************************************************************!*\
  !*** ./src/app/pages/dashboard/project-card/project-card.component.scss ***!
  \**************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".project-card-location-font, .project-card-secondary-font, .project-card-primary-font {\n  font-family: \"Roboto-Bold\", sans-serif;\n  color: #002d62;\n  font-weight: bold;\n  font-size: 20px;\n}\n\n.project-card {\n  cursor: pointer;\n  width: 620px;\n  height: 115px;\n  background-color: #fff;\n  border-radius: 23px;\n  box-shadow: 0 0 20px 0 rgba(0, 0, 0, 0.2), 0 0 20px 0 rgba(0, 0, 0, 0.2);\n  transition: all 0.15s ease-in-out;\n}\n\n.project-card:hover {\n  box-shadow: 0 0 15px 0 rgba(21, 149, 211, 0.2), 0 0 15px 0 rgba(21, 149, 211, 0.8);\n  /* IE 9 */\n  /* Safari */\n  transform: scale(1.03);\n  /* Standard syntax */\n}\n\n.project-card-content {\n  background-color: #fff;\n  border-top-left-radius: 20px;\n  border-bottom-left-radius: 20px;\n}\n\n.project-card-right {\n  border-top-right-radius: 20px;\n  border-bottom-right-radius: 20px;\n}\n\n.open {\n  background-color: #1595d3;\n}\n\n.closed {\n  background-color: #848484;\n}\n\n.project-card-secondary-font {\n  font-size: 16px;\n}\n\n.project-card-location-font {\n  font-size: 16px;\n  font-weight: normal;\n}\n\n@media screen and (max-width: 680px) {\n  .project-card {\n    width: 450px;\n    height: 135px;\n  }\n}\n\n.project-image {\n  width: 55px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvZGFzaGJvYXJkL3Byb2plY3QtY2FyZC9EOlxccHJvamVjdHNcXGlpaGZcXHdmbS13ZWIvc3JjXFxhcHBcXHBhZ2VzXFxkYXNoYm9hcmRcXHByb2plY3QtY2FyZFxccHJvamVjdC1jYXJkLmNvbXBvbmVudC5zY3NzIiwic3JjL2FwcC9wYWdlcy9kYXNoYm9hcmQvcHJvamVjdC1jYXJkL3Byb2plY3QtY2FyZC5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFHQTtFQUNJLHNDQUFBO0VBQ0EsY0FBQTtFQUNBLGlCQUFBO0VBQ0EsZUFBQTtBQ0ZKOztBREtBO0VBQ0ksZUFBQTtFQUNBLFlBQUE7RUFDQSxhQUFBO0VBQ0Esc0JBYlM7RUFjVCxtQkFmSztFQWdCTCx3RUFBQTtFQUNBLGlDQUFBO0FDRko7O0FESUk7RUFDSSxrRkFBQTtFQUM0QixTQUFBO0VBQ0ksV0FBQTtFQUNoQyxzQkFBQTtFQUF3QixvQkFBQTtBQ0NoQzs7QURHQTtFQUNJLHNCQTNCUztFQTRCVCw0QkFBQTtFQUNBLCtCQUFBO0FDQUo7O0FER0E7RUFDSSw2QkFBQTtFQUNBLGdDQUFBO0FDQUo7O0FER0E7RUFDSSx5QkFBQTtBQ0FKOztBREdBO0VBQ0kseUJBQUE7QUNBSjs7QURPQTtFQUVJLGVBQUE7QUNMSjs7QURRQTtFQUVJLGVBQUE7RUFDQSxtQkFBQTtBQ05KOztBRFNBO0VBQ0k7SUFDSSxZQUFBO0lBQ0EsYUFBQTtFQ05OO0FBQ0Y7O0FEU0E7RUFDSSxXQUFBO0FDUEoiLCJmaWxlIjoic3JjL2FwcC9wYWdlcy9kYXNoYm9hcmQvcHJvamVjdC1jYXJkL3Byb2plY3QtY2FyZC5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIiRyYWRpdXM6IDIzcHg7XHJcbiRjYXJkLWNvbG9yOiAjZmZmO1xyXG5cclxuJXByb2plY3QtY2FyZC1mb250LWJhc2Uge1xyXG4gICAgZm9udC1mYW1pbHk6ICdSb2JvdG8tQm9sZCcsIHNhbnMtc2VyaWY7XHJcbiAgICBjb2xvcjogIzAwMmQ2MjtcclxuICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xyXG4gICAgZm9udC1zaXplOiAyMHB4O1xyXG59XHJcblxyXG4ucHJvamVjdC1jYXJkIHtcclxuICAgIGN1cnNvcjogcG9pbnRlcjtcclxuICAgIHdpZHRoOiA2MjBweDtcclxuICAgIGhlaWdodDogMTE1cHg7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAkY2FyZC1jb2xvcjtcclxuICAgIGJvcmRlci1yYWRpdXM6ICRyYWRpdXM7XHJcbiAgICBib3gtc2hhZG93OiAwIDAgMjBweCAwIHJnYmEoMCwgMCwgMCwgMC4yKSwgMCAwIDIwcHggMCByZ2JhKDAsIDAsIDAsIDAuMik7XHJcbiAgICB0cmFuc2l0aW9uOiBhbGwgLjE1cyBlYXNlLWluLW91dDtcclxuXHJcbiAgICAmOmhvdmVyIHtcclxuICAgICAgICBib3gtc2hhZG93OiAwIDAgMTVweCAwIHJnYmEoIzE1OTVkMywgMC4yKSwgMCAwIDE1cHggMCByZ2JhKCMxNTk1ZDMsIDAuOCk7XHJcbiAgICAgICAgLW1zLXRyYW5zZm9ybTogc2NhbGUoMS4wMyk7IC8qIElFIDkgKi9cclxuICAgICAgICAtd2Via2l0LXRyYW5zZm9ybTogc2NhbGUoMS4wMyk7IC8qIFNhZmFyaSAqL1xyXG4gICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMS4wMyk7IC8qIFN0YW5kYXJkIHN5bnRheCAqL1xyXG4gICAgfVxyXG59XHJcblxyXG4ucHJvamVjdC1jYXJkLWNvbnRlbnQge1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogJGNhcmQtY29sb3I7XHJcbiAgICBib3JkZXItdG9wLWxlZnQtcmFkaXVzOiAkcmFkaXVzIC0gM3B4O1xyXG4gICAgYm9yZGVyLWJvdHRvbS1sZWZ0LXJhZGl1czogJHJhZGl1cyAtIDNweDtcclxufVxyXG5cclxuLnByb2plY3QtY2FyZC1yaWdodCB7XHJcbiAgICBib3JkZXItdG9wLXJpZ2h0LXJhZGl1czogJHJhZGl1cyAtIDNweDtcclxuICAgIGJvcmRlci1ib3R0b20tcmlnaHQtcmFkaXVzOiAkcmFkaXVzIC0gM3B4O1xyXG59XHJcblxyXG4ub3BlbiB7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjMTU5NWQzO1xyXG59XHJcblxyXG4uY2xvc2VkIHtcclxuICAgIGJhY2tncm91bmQtY29sb3I6ICM4NDg0ODQ7XHJcbn1cclxuXHJcbi5wcm9qZWN0LWNhcmQtcHJpbWFyeS1mb250IHtcclxuICAgIEBleHRlbmQgJXByb2plY3QtY2FyZC1mb250LWJhc2U7XHJcbn1cclxuXHJcbi5wcm9qZWN0LWNhcmQtc2Vjb25kYXJ5LWZvbnQge1xyXG4gICAgQGV4dGVuZCAlcHJvamVjdC1jYXJkLWZvbnQtYmFzZTtcclxuICAgIGZvbnQtc2l6ZTogMTZweDtcclxufVxyXG5cclxuLnByb2plY3QtY2FyZC1sb2NhdGlvbi1mb250IHtcclxuICAgIEBleHRlbmQgJXByb2plY3QtY2FyZC1mb250LWJhc2U7XHJcbiAgICBmb250LXNpemU6IDE2cHg7XHJcbiAgICBmb250LXdlaWdodDogbm9ybWFsO1xyXG59XHJcblxyXG5AbWVkaWEgc2NyZWVuIGFuZCAobWF4LXdpZHRoOiA2ODBweCkge1xyXG4gICAgLnByb2plY3QtY2FyZCB7XHJcbiAgICAgICAgd2lkdGg6IDQ1MHB4O1xyXG4gICAgICAgIGhlaWdodDogMTM1cHg7XHJcbiAgICB9XHJcbn1cclxuXHJcbi5wcm9qZWN0LWltYWdlIHtcclxuICAgIHdpZHRoOiA1NXB4O1xyXG59XHJcblxyXG4iLCIucHJvamVjdC1jYXJkLWxvY2F0aW9uLWZvbnQsIC5wcm9qZWN0LWNhcmQtc2Vjb25kYXJ5LWZvbnQsIC5wcm9qZWN0LWNhcmQtcHJpbWFyeS1mb250IHtcbiAgZm9udC1mYW1pbHk6IFwiUm9ib3RvLUJvbGRcIiwgc2Fucy1zZXJpZjtcbiAgY29sb3I6ICMwMDJkNjI7XG4gIGZvbnQtd2VpZ2h0OiBib2xkO1xuICBmb250LXNpemU6IDIwcHg7XG59XG5cbi5wcm9qZWN0LWNhcmQge1xuICBjdXJzb3I6IHBvaW50ZXI7XG4gIHdpZHRoOiA2MjBweDtcbiAgaGVpZ2h0OiAxMTVweDtcbiAgYmFja2dyb3VuZC1jb2xvcjogI2ZmZjtcbiAgYm9yZGVyLXJhZGl1czogMjNweDtcbiAgYm94LXNoYWRvdzogMCAwIDIwcHggMCByZ2JhKDAsIDAsIDAsIDAuMiksIDAgMCAyMHB4IDAgcmdiYSgwLCAwLCAwLCAwLjIpO1xuICB0cmFuc2l0aW9uOiBhbGwgMC4xNXMgZWFzZS1pbi1vdXQ7XG59XG4ucHJvamVjdC1jYXJkOmhvdmVyIHtcbiAgYm94LXNoYWRvdzogMCAwIDE1cHggMCByZ2JhKDIxLCAxNDksIDIxMSwgMC4yKSwgMCAwIDE1cHggMCByZ2JhKDIxLCAxNDksIDIxMSwgMC44KTtcbiAgLW1zLXRyYW5zZm9ybTogc2NhbGUoMS4wMyk7XG4gIC8qIElFIDkgKi9cbiAgLXdlYmtpdC10cmFuc2Zvcm06IHNjYWxlKDEuMDMpO1xuICAvKiBTYWZhcmkgKi9cbiAgdHJhbnNmb3JtOiBzY2FsZSgxLjAzKTtcbiAgLyogU3RhbmRhcmQgc3ludGF4ICovXG59XG5cbi5wcm9qZWN0LWNhcmQtY29udGVudCB7XG4gIGJhY2tncm91bmQtY29sb3I6ICNmZmY7XG4gIGJvcmRlci10b3AtbGVmdC1yYWRpdXM6IDIwcHg7XG4gIGJvcmRlci1ib3R0b20tbGVmdC1yYWRpdXM6IDIwcHg7XG59XG5cbi5wcm9qZWN0LWNhcmQtcmlnaHQge1xuICBib3JkZXItdG9wLXJpZ2h0LXJhZGl1czogMjBweDtcbiAgYm9yZGVyLWJvdHRvbS1yaWdodC1yYWRpdXM6IDIwcHg7XG59XG5cbi5vcGVuIHtcbiAgYmFja2dyb3VuZC1jb2xvcjogIzE1OTVkMztcbn1cblxuLmNsb3NlZCB7XG4gIGJhY2tncm91bmQtY29sb3I6ICM4NDg0ODQ7XG59XG5cbi5wcm9qZWN0LWNhcmQtc2Vjb25kYXJ5LWZvbnQge1xuICBmb250LXNpemU6IDE2cHg7XG59XG5cbi5wcm9qZWN0LWNhcmQtbG9jYXRpb24tZm9udCB7XG4gIGZvbnQtc2l6ZTogMTZweDtcbiAgZm9udC13ZWlnaHQ6IG5vcm1hbDtcbn1cblxuQG1lZGlhIHNjcmVlbiBhbmQgKG1heC13aWR0aDogNjgwcHgpIHtcbiAgLnByb2plY3QtY2FyZCB7XG4gICAgd2lkdGg6IDQ1MHB4O1xuICAgIGhlaWdodDogMTM1cHg7XG4gIH1cbn1cbi5wcm9qZWN0LWltYWdlIHtcbiAgd2lkdGg6IDU1cHg7XG59Il19 */");

/***/ }),

/***/ "./src/app/pages/dashboard/project-card/project-card.component.ts":
/*!************************************************************************!*\
  !*** ./src/app/pages/dashboard/project-card/project-card.component.ts ***!
  \************************************************************************/
/*! exports provided: ProjectCardComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProjectCardComponent", function() { return ProjectCardComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _shared_hazlenut_hazelnut_common_animations__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../shared/hazlenut/hazelnut-common/animations */ "./src/app/shared/hazlenut/hazelnut-common/animations/index.ts");
/* harmony import */ var _shared_models_project_model__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../shared/models/project.model */ "./src/app/shared/models/project.model.ts");
/* harmony import */ var _shared_services_dashboard_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../shared/services/dashboard.service */ "./src/app/shared/services/dashboard.service.ts");
/* harmony import */ var _shared_services_data_images_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../shared/services/data/images.service */ "./src/app/shared/services/data/images.service.ts");
/* harmony import */ var _shared_services_notification_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../../shared/services/notification.service */ "./src/app/shared/services/notification.service.ts");
/* harmony import */ var _shared_services_storage_project_event_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../../shared/services/storage/project-event.service */ "./src/app/shared/services/storage/project-event.service.ts");









var ProjectCardComponent = /** @class */ (function () {
    function ProjectCardComponent(router, dashboardService, projectEventService, imagesService, notificationService) {
        this.router = router;
        this.dashboardService = dashboardService;
        this.projectEventService = projectEventService;
        this.imagesService = imagesService;
        this.notificationService = notificationService;
        this.showAllCities = false;
        this.showOneCity = false;
        this.showAllCountries = false;
        this.showOneCountry = false;
        this.imagePath = 'assets/img/event-logos/default_logo.png';
    }
    /**
     * Project data setup in intialization
     */
    ProjectCardComponent.prototype.ngOnInit = function () {
        this.getImagePath();
        if (this.project.venues !== null && this.project.venues.length === 1) {
            this.showOneCity = true;
            this.showAllCities = false;
            this.showOneCountry = true;
            this.showAllCountries = false;
        }
        if (this.project.venues !== null && this.project.venues.length === 2) {
            var firstPosition = this.project.venues[0].screenPosition;
            var secondPosition = this.project.venues[1].screenPosition;
            if ((firstPosition !== null && secondPosition !== null) && (secondPosition < firstPosition)) {
                var venue = this.project.venues[0];
                this.project.venues[0] = this.project.venues[1];
                this.project.venues[1] = venue;
            }
            if (this.project.venues[0].country === this.project.venues[1].country) {
                this.showOneCountry = true;
                this.showAllCountries = false;
            }
            else {
                this.showOneCountry = false;
                this.showAllCountries = true;
            }
            if (this.project.venues[0].city === this.project.venues[1].city) {
                this.showOneCity = true;
                this.showAllCities = false;
            }
            else {
                this.showOneCity = false;
                this.showAllCities = true;
            }
        }
    };
    /**
     * Route to selected project detail screen
     */
    ProjectCardComponent.prototype.openAreas = function () {
        this.router.navigate(['project/detail']);
    };
    /**
     * Using projectEventService to store selected project information into local storage
     * Apply changes on second header to show project title logo and unselect project button
     */
    ProjectCardComponent.prototype.onProjectSelected = function () {
        this.projectEventService.setEventData(this.project, true, this.imagePath);
        this.dashboardService.setSecondaryHeaderContent({
            isDashboard: false,
            title: this.project.year + " " + this.project.name
        });
        this.openAreas();
    };
    ProjectCardComponent.prototype.getImagePath = function () {
        var _this = this;
        if (!this.project.logo) {
            return;
        }
        this.imagesService.getImage(this.project.logo)
            .subscribe(function (blob) {
            var reader = new FileReader();
            reader.onload = function () {
                _this.imagePath = reader.result;
            };
            reader.readAsDataURL(blob);
        });
    };
    ProjectCardComponent.ctorParameters = function () { return [
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"] },
        { type: _shared_services_dashboard_service__WEBPACK_IMPORTED_MODULE_5__["DashboardService"] },
        { type: _shared_services_storage_project_event_service__WEBPACK_IMPORTED_MODULE_8__["ProjectEventService"] },
        { type: _shared_services_data_images_service__WEBPACK_IMPORTED_MODULE_6__["ImagesService"] },
        { type: _shared_services_notification_service__WEBPACK_IMPORTED_MODULE_7__["NotificationService"] }
    ]; };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _shared_models_project_model__WEBPACK_IMPORTED_MODULE_4__["Project"])
    ], ProjectCardComponent.prototype, "project", void 0);
    ProjectCardComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'project-card',
            template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./project-card.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/dashboard/project-card/project-card.component.html")).default,
            animations: [_shared_hazlenut_hazelnut_common_animations__WEBPACK_IMPORTED_MODULE_3__["fadeEnterLeave"]],
            styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./project-card.component.scss */ "./src/app/pages/dashboard/project-card/project-card.component.scss")).default]
        })
        /**
         * Project card component with logo data
         */ ,
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"],
            _shared_services_dashboard_service__WEBPACK_IMPORTED_MODULE_5__["DashboardService"],
            _shared_services_storage_project_event_service__WEBPACK_IMPORTED_MODULE_8__["ProjectEventService"],
            _shared_services_data_images_service__WEBPACK_IMPORTED_MODULE_6__["ImagesService"],
            _shared_services_notification_service__WEBPACK_IMPORTED_MODULE_7__["NotificationService"]])
    ], ProjectCardComponent);
    return ProjectCardComponent;
}());



/***/ }),

/***/ "./src/app/pages/dashboard/project-list/project-list.component.scss":
/*!**************************************************************************!*\
  !*** ./src/app/pages/dashboard/project-list/project-list.component.scss ***!
  \**************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".wrapper {\n  margin: 0 auto;\n  width: 2188px;\n}\n\n@media screen and (max-width: 680px) {\n  .wrapper {\n    width: 380px;\n  }\n}\n\n@media screen and (min-width: 681px) and (max-width: 1350px) {\n  .wrapper {\n    width: 645px;\n  }\n}\n\n@media screen and (min-width: 1351px) and (max-width: 2100px) {\n  .wrapper {\n    width: 1300px;\n  }\n}\n\n@media screen and (min-width: 2101px) and (max-width: 2690px) {\n  .wrapper {\n    width: 1940px;\n  }\n}\n\n@media screen and (min-width: 2691px) and (max-width: 3750px) {\n  .wrapper {\n    width: 2590px;\n  }\n}\n\n@media screen and (min-width: 3751px) {\n  .wrapper {\n    width: 3235px;\n  }\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvZGFzaGJvYXJkL3Byb2plY3QtbGlzdC9EOlxccHJvamVjdHNcXGlpaGZcXHdmbS13ZWIvc3JjXFxhcHBcXHBhZ2VzXFxkYXNoYm9hcmRcXHByb2plY3QtbGlzdFxccHJvamVjdC1saXN0LmNvbXBvbmVudC5zY3NzIiwic3JjL2FwcC9wYWdlcy9kYXNoYm9hcmQvcHJvamVjdC1saXN0L3Byb2plY3QtbGlzdC5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLGNBQUE7RUFDQSxhQUFBO0FDQ0o7O0FERUE7RUFDSTtJQUNJLFlBQUE7RUNDTjtBQUNGOztBREVBO0VBQ0k7SUFDSSxZQUFBO0VDQU47QUFDRjs7QURHQTtFQUNJO0lBQ0ksYUFBQTtFQ0ROO0FBQ0Y7O0FESUE7RUFDSTtJQUNJLGFBQUE7RUNGTjtBQUNGOztBREtBO0VBQ0k7SUFDSSxhQUFBO0VDSE47QUFDRjs7QURNQTtFQUNJO0lBQ0ksYUFBQTtFQ0pOO0FBQ0YiLCJmaWxlIjoic3JjL2FwcC9wYWdlcy9kYXNoYm9hcmQvcHJvamVjdC1saXN0L3Byb2plY3QtbGlzdC5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi53cmFwcGVyIHtcclxuICAgIG1hcmdpbjogMCBhdXRvO1xyXG4gICAgd2lkdGg6IDIxODhweDtcclxufVxyXG5cclxuQG1lZGlhIHNjcmVlbiBhbmQgKG1heC13aWR0aDogNjgwcHgpIHtcclxuICAgIC53cmFwcGVyIHtcclxuICAgICAgICB3aWR0aDogMzgwcHg7XHJcbiAgICB9XHJcbn1cclxuXHJcbkBtZWRpYSBzY3JlZW4gYW5kIChtaW4td2lkdGg6IDY4MXB4KSBhbmQgKG1heC13aWR0aDogMTM1MHB4KSB7XHJcbiAgICAud3JhcHBlciB7XHJcbiAgICAgICAgd2lkdGg6IDY0NXB4O1xyXG4gICAgfVxyXG59XHJcblxyXG5AbWVkaWEgc2NyZWVuIGFuZCAobWluLXdpZHRoOiAxMzUxcHgpIGFuZCAobWF4LXdpZHRoOiAyMTAwcHgpIHtcclxuICAgIC53cmFwcGVyIHtcclxuICAgICAgICB3aWR0aDogMTMwMHB4O1xyXG4gICAgfVxyXG59XHJcblxyXG5AbWVkaWEgc2NyZWVuIGFuZCAobWluLXdpZHRoOiAyMTAxcHgpIGFuZCAobWF4LXdpZHRoOiAyNjkwcHgpIHtcclxuICAgIC53cmFwcGVyIHtcclxuICAgICAgICB3aWR0aDogMTk0MHB4O1xyXG4gICAgfVxyXG59XHJcblxyXG5AbWVkaWEgc2NyZWVuIGFuZCAobWluLXdpZHRoOiAyNjkxcHgpIGFuZCAobWF4LXdpZHRoOiAzNzUwcHgpIHtcclxuICAgIC53cmFwcGVyIHtcclxuICAgICAgICB3aWR0aDogMjU5MHB4O1xyXG4gICAgfVxyXG59XHJcblxyXG5AbWVkaWEgc2NyZWVuIGFuZCAobWluLXdpZHRoOiAzNzUxcHgpIHtcclxuICAgIC53cmFwcGVyIHtcclxuICAgICAgICB3aWR0aDogMzIzNXB4O1xyXG4gICAgfVxyXG59XHJcbiIsIi53cmFwcGVyIHtcbiAgbWFyZ2luOiAwIGF1dG87XG4gIHdpZHRoOiAyMTg4cHg7XG59XG5cbkBtZWRpYSBzY3JlZW4gYW5kIChtYXgtd2lkdGg6IDY4MHB4KSB7XG4gIC53cmFwcGVyIHtcbiAgICB3aWR0aDogMzgwcHg7XG4gIH1cbn1cbkBtZWRpYSBzY3JlZW4gYW5kIChtaW4td2lkdGg6IDY4MXB4KSBhbmQgKG1heC13aWR0aDogMTM1MHB4KSB7XG4gIC53cmFwcGVyIHtcbiAgICB3aWR0aDogNjQ1cHg7XG4gIH1cbn1cbkBtZWRpYSBzY3JlZW4gYW5kIChtaW4td2lkdGg6IDEzNTFweCkgYW5kIChtYXgtd2lkdGg6IDIxMDBweCkge1xuICAud3JhcHBlciB7XG4gICAgd2lkdGg6IDEzMDBweDtcbiAgfVxufVxuQG1lZGlhIHNjcmVlbiBhbmQgKG1pbi13aWR0aDogMjEwMXB4KSBhbmQgKG1heC13aWR0aDogMjY5MHB4KSB7XG4gIC53cmFwcGVyIHtcbiAgICB3aWR0aDogMTk0MHB4O1xuICB9XG59XG5AbWVkaWEgc2NyZWVuIGFuZCAobWluLXdpZHRoOiAyNjkxcHgpIGFuZCAobWF4LXdpZHRoOiAzNzUwcHgpIHtcbiAgLndyYXBwZXIge1xuICAgIHdpZHRoOiAyNTkwcHg7XG4gIH1cbn1cbkBtZWRpYSBzY3JlZW4gYW5kIChtaW4td2lkdGg6IDM3NTFweCkge1xuICAud3JhcHBlciB7XG4gICAgd2lkdGg6IDMyMzVweDtcbiAgfVxufSJdfQ== */");

/***/ }),

/***/ "./src/app/pages/dashboard/project-list/project-list.component.ts":
/*!************************************************************************!*\
  !*** ./src/app/pages/dashboard/project-list/project-list.component.ts ***!
  \************************************************************************/
/*! exports provided: ProjectListComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProjectListComponent", function() { return ProjectListComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _shared_services_auth_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../shared/services/auth.service */ "./src/app/shared/services/auth.service.ts");
/* harmony import */ var _shared_services_dashboard_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../shared/services/dashboard.service */ "./src/app/shared/services/dashboard.service.ts");
/* harmony import */ var _shared_services_storage_project_event_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../shared/services/storage/project-event.service */ "./src/app/shared/services/storage/project-event.service.ts");





var ProjectListComponent = /** @class */ (function () {
    function ProjectListComponent(projectEventService, dashboardService, authService) {
        this.projectEventService = projectEventService;
        this.dashboardService = dashboardService;
        this.authService = authService;
        this.projects = [];
    }
    /**
     * Create filter listener on projects and set default value to ALL
     */
    ProjectListComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.dashboardService.dashboardFilterNotifier$.subscribe(function (filterValue) {
            _this.filterProjects(filterValue);
        });
        this.filterProjects('ALL');
        this.dashboardService.setSecondaryHeaderContent({ isDashboard: true });
    };
    /**
     * Filter projects based on selected filter
     * @param filterValue
     */
    ProjectListComponent.prototype.filterProjects = function (filterValue) {
        var _this = this;
        if (filterValue === void 0) { filterValue = 'ALL'; }
        this.dashboardService.filterProjects(filterValue).subscribe(function (data) {
            _this.projects = data;
            _this.dashboardService.setSecondaryHeaderContent({ isDashboard: true });
        });
    };
    ProjectListComponent.ctorParameters = function () { return [
        { type: _shared_services_storage_project_event_service__WEBPACK_IMPORTED_MODULE_4__["ProjectEventService"] },
        { type: _shared_services_dashboard_service__WEBPACK_IMPORTED_MODULE_3__["DashboardService"] },
        { type: _shared_services_auth_service__WEBPACK_IMPORTED_MODULE_2__["AuthService"] }
    ]; };
    ProjectListComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'project-list',
            template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./project-list.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/dashboard/project-list/project-list.component.html")).default,
            styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./project-list.component.scss */ "./src/app/pages/dashboard/project-list/project-list.component.scss")).default]
        })
        /**
         * Custom responsive design project list of cards with filter option
         */
        ,
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_shared_services_storage_project_event_service__WEBPACK_IMPORTED_MODULE_4__["ProjectEventService"],
            _shared_services_dashboard_service__WEBPACK_IMPORTED_MODULE_3__["DashboardService"],
            _shared_services_auth_service__WEBPACK_IMPORTED_MODULE_2__["AuthService"]])
    ], ProjectListComponent);
    return ProjectListComponent;
}());



/***/ }),

/***/ "./src/app/shared/models/project.model.ts":
/*!************************************************!*\
  !*** ./src/app/shared/models/project.model.ts ***!
  \************************************************/
/*! exports provided: Project */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Project", function() { return Project; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");

var Project = /** @class */ (function () {
    function Project() {
    }
    return Project;
}());



/***/ })

}]);
//# sourceMappingURL=pages-dashboard-dashboard-module.js.map